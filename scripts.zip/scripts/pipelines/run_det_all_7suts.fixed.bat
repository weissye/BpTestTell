@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "ROOT=%~dp0..\..\.."
set "PY_EXE=%ROOT%\.venv\Scripts\python.exe"
if not exist "%PY_EXE%" set "PY_EXE=python"

if not defined GEN_PY set "GEN_PY=%ROOT%\scripts\llm\emit_llm_gold_from_openapi.py"
if not exist "%GEN_PY%" for %%F in ("%ROOT%\scripts\llm\emit_llm_gold_from_openapi*.py") do (
  set "GEN_PY=%%~fF"
  goto :got_gen
)
:got_gen
if not exist "%GEN_PY%" (
  echo [ERR] Generator script not found at "%GEN_PY%".
  exit /b 1
)

if not defined PROVIDER set "PROVIDER=openai"
if not defined MODEL set "MODEL=gpt-4o-mini"

set "EXTRA="
if "%FORCE%"=="1" set "EXTRA=%EXTRA% --force"

set /a ATTEMPTED=0, OK=0, FAILED=0

for %%S in (banking pharmacy library garage factory config_control web_shop) do (
  set /a ATTEMPTED+=1
  echo(
  echo ==== %%S (7-SUTS^) ====

  rem Try common locations for the 7-suts specs (first one wins).
  set "SPEC="
  if exist "%ROOT%\packs\7_suts\%%S\openapi.json"              set "SPEC=%ROOT%\packs\7_suts\%%S\openapi.json"
  if not defined SPEC if exist "%ROOT%\packs\7_suts_llm_provider\%%S\openapi.json" set "SPEC=%ROOT%\packs\7_suts_llm_provider\%%S\openapi.json"

  if not defined SPEC (
    echo [ERR] Could not locate openapi.json for "%%S".
    set /a FAILED+=1
    goto :cont
  )

  set "OUT=%ROOT%\artifacts\det_checked\7_suts_llm_provider\%%S"

  if "%CLEAN%"=="1" (
    if exist "!OUT!" rmdir /s /q "!OUT!"
  )
  if not exist "!OUT!" mkdir "!OUT!" >nul 2>&1

  echo [INFO] CWD=%CD%
  echo [RUN] provider=%PROVIDER%  model=%MODEL%
  echo [RUN] spec="!SPEC!"  out="!OUT!"

  "%PY_EXE%" "%GEN_PY%" --provider "%PROVIDER%" --model "%MODEL%" --spec "!SPEC!" --out "!OUT!" %EXTRA%
  if errorlevel 1 (
    echo [ERR] Generator failed for "%%S".
    echo [WARN] %%S failed.
    set /a FAILED+=1
  ) else (
    echo [OK] %%S
    set /a OK+=1
  )
  :cont
)

echo(
echo [SUMMARY] attempted=%ATTEMPTED%  ok=%OK%  failed=%FAILED%
endlocal
