// ====================================================================
// Auto-generated garage-style High-Level Stories (HLS)
// SUT: trello
// ====================================================================

var ANY = (typeof H !== 'undefined' && H.ANY) ? H.ANY : (typeof ANY !== 'undefined' ? ANY : '*');

// ===== ACTIVE LIFECYCLES =====


bthread("Boards_idOrganization lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_idOrganization(x.id);
  updateBoards_idOrganization(x.id);
  updateBoards_idOrganization(x.id);
  verifyBoards_idOrganizationExists(x.id);
  verifyBoards_idOrganizationUpdated(x.id);
});

bthread("Boards_members lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_members(x.id);
  updateBoards_members(x.id);
  updateBoards_members(x.id);
  verifyBoards_membersExists(x.id);
  verifyBoards_membersUpdated(x.id);
});

bthread("Lists_name lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLists_name(x.id);
  updateLists_name(x.id);
  updateLists_name(x.id);
  verifyLists_nameExists(x.id);
  verifyLists_nameUpdated(x.id);
});

bthread("Cards_membersVoted lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_membersVoted(x.id);
  updateCards_membersVoted(x.id);
  updateCards_membersVoted(x.id);
  verifyCards_membersVotedExists(x.id);
  verifyCards_membersVotedUpdated(x.id);
});

bthread("Organizations_desc lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOrganizations_desc(x.id);
  updateOrganizations_desc(x.id);
  updateOrganizations_desc(x.id);
  verifyOrganizations_descExists(x.id);
  verifyOrganizations_descUpdated(x.id);
});

bthread("Labels lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLabels(x.id);
  updateLabels(x.id);
  updateLabels(x.id);
  verifyLabelsExists(x.id);
  verifyLabelsUpdated(x.id);
});

bthread("MyPrefs_showSidebarBoardActions lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMyPrefs_showSidebarBoardActions(x.id);
  updateMyPrefs_showSidebarBoardActions(x.id);
  updateMyPrefs_showSidebarBoardActions(x.id);
  verifyMyPrefs_showSidebarBoardActionsExists(x.id);
  verifyMyPrefs_showSidebarBoardActionsUpdated(x.id);
});

bthread("Cards_checklist_idChecklistCurrent_checkItem lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_checklist_idChecklistCurrent_checkItem(x.id);
  updateCards_checklist_idChecklistCurrent_checkItem(x.id);
  updateCards_checklist_idChecklistCurrent_checkItem(x.id);
  verifyCards_checklist_idChecklistCurrent_checkItemExists(x.id);
  verifyCards_checklist_idChecklistCurrent_checkItemUpdated(x.id);
});

bthread("Organizations_memberships lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOrganizations_memberships(x.id);
  updateOrganizations_memberships(x.id);
  updateOrganizations_memberships(x.id);
  verifyOrganizations_membershipsExists(x.id);
  verifyOrganizations_membershipsUpdated(x.id);
});

bthread("MyPrefs_idEmailList lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMyPrefs_idEmailList(x.id);
  updateMyPrefs_idEmailList(x.id);
  updateMyPrefs_idEmailList(x.id);
  verifyMyPrefs_idEmailListExists(x.id);
  verifyMyPrefs_idEmailListUpdated(x.id);
});

bthread("Cards_name lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_name(x.id);
  updateCards_name(x.id);
  updateCards_name(x.id);
  verifyCards_nameExists(x.id);
  verifyCards_nameUpdated(x.id);
});

bthread("Boards_desc lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_desc(x.id);
  updateBoards_desc(x.id);
  updateBoards_desc(x.id);
  verifyBoards_descExists(x.id);
  verifyBoards_descUpdated(x.id);
});

bthread("Members_avatarSource lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_avatarSource(x.id);
  updateMembers_avatarSource(x.id);
  updateMembers_avatarSource(x.id);
  verifyMembers_avatarSourceExists(x.id);
  verifyMembers_avatarSourceUpdated(x.id);
});

bthread("Boards_labels lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_labels(x.id);
  updateBoards_labels(x.id);
  updateBoards_labels(x.id);
  verifyBoards_labelsExists(x.id);
  verifyBoards_labelsUpdated(x.id);
});

bthread("Cards_pos lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_pos(x.id);
  updateCards_pos(x.id);
  updateCards_pos(x.id);
  verifyCards_posExists(x.id);
  verifyCards_posUpdated(x.id);
});

bthread("LabelNames_purple lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLabelNames_purple(x.id);
  updateLabelNames_purple(x.id);
  updateLabelNames_purple(x.id);
  verifyLabelNames_purpleExists(x.id);
  verifyLabelNames_purpleUpdated(x.id);
});

bthread("Lists_subscribed lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLists_subscribed(x.id);
  updateLists_subscribed(x.id);
  updateLists_subscribed(x.id);
  verifyLists_subscribedExists(x.id);
  verifyLists_subscribedUpdated(x.id);
});

bthread("Organizations lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOrganizations(x.id);
  updateOrganizations(x.id);
  updateOrganizations(x.id);
  verifyOrganizationsExists(x.id);
  verifyOrganizationsUpdated(x.id);
});

bthread("Sessions lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSessions(x.id);
  updateSessions(x.id);
  updateSessions(x.id);
  verifySessionsExists(x.id);
  verifySessionsUpdated(x.id);
});

bthread("Tokens_webhooks lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTokens_webhooks(x.id);
  updateTokens_webhooks(x.id);
  updateTokens_webhooks(x.id);
  verifyTokens_webhooksExists(x.id);
  verifyTokens_webhooksUpdated(x.id);
});

bthread("Webhooks_idModel lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWebhooks_idModel(x.id);
  updateWebhooks_idModel(x.id);
  updateWebhooks_idModel(x.id);
  verifyWebhooks_idModelExists(x.id);
  verifyWebhooks_idModelUpdated(x.id);
});

bthread("Members_boardBackgrounds lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_boardBackgrounds(x.id);
  updateMembers_boardBackgrounds(x.id);
  updateMembers_boardBackgrounds(x.id);
  verifyMembers_boardBackgroundsExists(x.id);
  verifyMembers_boardBackgroundsUpdated(x.id);
});

bthread("Prefs_cardAging lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_cardAging(x.id);
  updatePrefs_cardAging(x.id);
  updatePrefs_cardAging(x.id);
  verifyPrefs_cardAgingExists(x.id);
  verifyPrefs_cardAgingUpdated(x.id);
});

bthread("Members_savedSearches lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_savedSearches(x.id);
  updateMembers_savedSearches(x.id);
  updateMembers_savedSearches(x.id);
  verifyMembers_savedSearchesExists(x.id);
  verifyMembers_savedSearchesUpdated(x.id);
});

bthread("Labels_name lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLabels_name(x.id);
  updateLabels_name(x.id);
  updateLabels_name(x.id);
  verifyLabels_nameExists(x.id);
  verifyLabels_nameUpdated(x.id);
});

bthread("Actions_comments lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addActions_comments(x.id);
  updateActions_comments(x.id);
  updateActions_comments(x.id);
  verifyActions_commentsExists(x.id);
  verifyActions_commentsUpdated(x.id);
});

bthread("Organizations_displayName lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOrganizations_displayName(x.id);
  updateOrganizations_displayName(x.id);
  updateOrganizations_displayName(x.id);
  verifyOrganizations_displayNameExists(x.id);
  verifyOrganizations_displayNameUpdated(x.id);
});

bthread("Lists_pos lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLists_pos(x.id);
  updateLists_pos(x.id);
  updateLists_pos(x.id);
  verifyLists_posExists(x.id);
  verifyLists_posUpdated(x.id);
});

bthread("LabelNames_blue lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLabelNames_blue(x.id);
  updateLabelNames_blue(x.id);
  updateLabelNames_blue(x.id);
  verifyLabelNames_blueExists(x.id);
  verifyLabelNames_blueUpdated(x.id);
});

bthread("Cards_checklist_checkItem_name lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_checklist_checkItem_name(x.id);
  updateCards_checklist_checkItem_name(x.id);
  updateCards_checklist_checkItem_name(x.id);
  verifyCards_checklist_checkItem_nameExists(x.id);
  verifyCards_checklist_checkItem_nameUpdated(x.id);
});

bthread("Prefs_externalMembersDisabled lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_externalMembersDisabled(x.id);
  updatePrefs_externalMembersDisabled(x.id);
  updatePrefs_externalMembersDisabled(x.id);
  verifyPrefs_externalMembersDisabledExists(x.id);
  verifyPrefs_externalMembersDisabledUpdated(x.id);
});

bthread("Checklists_idCard lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addChecklists_idCard(x.id);
  updateChecklists_idCard(x.id);
  updateChecklists_idCard(x.id);
  verifyChecklists_idCardExists(x.id);
  verifyChecklists_idCardUpdated(x.id);
});

bthread("Prefs_orgInviteRestrict lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_orgInviteRestrict(x.id);
  updatePrefs_orgInviteRestrict(x.id);
  updatePrefs_orgInviteRestrict(x.id);
  verifyPrefs_orgInviteRestrictExists(x.id);
  verifyPrefs_orgInviteRestrictUpdated(x.id);
});

bthread("Prefs_voting lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_voting(x.id);
  updatePrefs_voting(x.id);
  updatePrefs_voting(x.id);
  verifyPrefs_votingExists(x.id);
  verifyPrefs_votingUpdated(x.id);
});

bthread("Organizations_logo lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOrganizations_logo(x.id);
  updateOrganizations_logo(x.id);
  updateOrganizations_logo(x.id);
  verifyOrganizations_logoExists(x.id);
  verifyOrganizations_logoUpdated(x.id);
});

bthread("MyPrefs_showSidebarActivity lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMyPrefs_showSidebarActivity(x.id);
  updateMyPrefs_showSidebarActivity(x.id);
  updateMyPrefs_showSidebarActivity(x.id);
  verifyMyPrefs_showSidebarActivityExists(x.id);
  verifyMyPrefs_showSidebarActivityUpdated(x.id);
});

bthread("Members_boardStars_idBoard lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_boardStars_idBoard(x.id);
  updateMembers_boardStars_idBoard(x.id);
  updateMembers_boardStars_idBoard(x.id);
  verifyMembers_boardStars_idBoardExists(x.id);
  verifyMembers_boardStars_idBoardUpdated(x.id);
});

bthread("Actions_text lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addActions_text(x.id);
  updateActions_text(x.id);
  updateActions_text(x.id);
  verifyActions_textExists(x.id);
  verifyActions_textUpdated(x.id);
});

bthread("Boards_powerUps lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_powerUps(x.id);
  updateBoards_powerUps(x.id);
  updateBoards_powerUps(x.id);
  verifyBoards_powerUpsExists(x.id);
  verifyBoards_powerUpsUpdated(x.id);
});

bthread("Members_bio lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_bio(x.id);
  updateMembers_bio(x.id);
  updateMembers_bio(x.id);
  verifyMembers_bioExists(x.id);
  verifyMembers_bioUpdated(x.id);
});

bthread("Members_customBoardBackgrounds lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_customBoardBackgrounds(x.id);
  updateMembers_customBoardBackgrounds(x.id);
  updateMembers_customBoardBackgrounds(x.id);
  verifyMembers_customBoardBackgroundsExists(x.id);
  verifyMembers_customBoardBackgroundsUpdated(x.id);
});

bthread("Members_boardStars_pos lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_boardStars_pos(x.id);
  updateMembers_boardStars_pos(x.id);
  updateMembers_boardStars_pos(x.id);
  verifyMembers_boardStars_posExists(x.id);
  verifyMembers_boardStars_posUpdated(x.id);
});

bthread("Sessions_status lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSessions_status(x.id);
  updateSessions_status(x.id);
  updateSessions_status(x.id);
  verifySessions_statusExists(x.id);
  verifySessions_statusUpdated(x.id);
});

bthread("LabelNames_orange lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLabelNames_orange(x.id);
  updateLabelNames_orange(x.id);
  updateLabelNames_orange(x.id);
  verifyLabelNames_orangeExists(x.id);
  verifyLabelNames_orangeUpdated(x.id);
});

bthread("Webhooks lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWebhooks(x.id);
  updateWebhooks(x.id);
  updateWebhooks(x.id);
  verifyWebhooksExists(x.id);
  verifyWebhooksUpdated(x.id);
});

bthread("Organizations_members lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOrganizations_members(x.id);
  updateOrganizations_members(x.id);
  updateOrganizations_members(x.id);
  verifyOrganizations_membersExists(x.id);
  verifyOrganizations_membersUpdated(x.id);
});

bthread("Checklists_name lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addChecklists_name(x.id);
  updateChecklists_name(x.id);
  updateChecklists_name(x.id);
  verifyChecklists_nameExists(x.id);
  verifyChecklists_nameUpdated(x.id);
});

bthread("Cards_closed lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_closed(x.id);
  updateCards_closed(x.id);
  updateCards_closed(x.id);
  verifyCards_closedExists(x.id);
  verifyCards_closedUpdated(x.id);
});

bthread("Organizations_members_deactivated lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOrganizations_members_deactivated(x.id);
  updateOrganizations_members_deactivated(x.id);
  updateOrganizations_members_deactivated(x.id);
  verifyOrganizations_members_deactivatedExists(x.id);
  verifyOrganizations_members_deactivatedUpdated(x.id);
});

bthread("Cards_actions_comments lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_actions_comments(x.id);
  updateCards_actions_comments(x.id);
  updateCards_actions_comments(x.id);
  verifyCards_actions_commentsExists(x.id);
  verifyCards_actions_commentsUpdated(x.id);
});

bthread("Cards_checklist_checkItem lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_checklist_checkItem(x.id);
  updateCards_checklist_checkItem(x.id);
  updateCards_checklist_checkItem(x.id);
  verifyCards_checklist_checkItemExists(x.id);
  verifyCards_checklist_checkItemUpdated(x.id);
});

bthread("Organizations_website lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOrganizations_website(x.id);
  updateOrganizations_website(x.id);
  updateOrganizations_website(x.id);
  verifyOrganizations_websiteExists(x.id);
  verifyOrganizations_websiteUpdated(x.id);
});

bthread("Cards lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards(x.id);
  updateCards(x.id);
  updateCards(x.id);
  verifyCardsExists(x.id);
  verifyCardsUpdated(x.id);
});

bthread("Lists_idBoard lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLists_idBoard(x.id);
  updateLists_idBoard(x.id);
  updateLists_idBoard(x.id);
  verifyLists_idBoardExists(x.id);
  verifyLists_idBoardUpdated(x.id);
});

bthread("MyPrefs_showSidebarMembers lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMyPrefs_showSidebarMembers(x.id);
  updateMyPrefs_showSidebarMembers(x.id);
  updateMyPrefs_showSidebarMembers(x.id);
  verifyMyPrefs_showSidebarMembersExists(x.id);
  verifyMyPrefs_showSidebarMembersUpdated(x.id);
});

bthread("Checklists_checkItems lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addChecklists_checkItems(x.id);
  updateChecklists_checkItems(x.id);
  updateChecklists_checkItems(x.id);
  verifyChecklists_checkItemsExists(x.id);
  verifyChecklists_checkItemsUpdated(x.id);
});

bthread("Prefs_associatedDomain lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_associatedDomain(x.id);
  updatePrefs_associatedDomain(x.id);
  updatePrefs_associatedDomain(x.id);
  verifyPrefs_associatedDomainExists(x.id);
  verifyPrefs_associatedDomainUpdated(x.id);
});

bthread("Cards_labels lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_labels(x.id);
  updateCards_labels(x.id);
  updateCards_labels(x.id);
  verifyCards_labelsExists(x.id);
  verifyCards_labelsUpdated(x.id);
});

bthread("Lists_cards lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLists_cards(x.id);
  updateLists_cards(x.id);
  updateLists_cards(x.id);
  verifyLists_cardsExists(x.id);
  verifyLists_cardsUpdated(x.id);
});

bthread("MyPrefs_showSidebar lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMyPrefs_showSidebar(x.id);
  updateMyPrefs_showSidebar(x.id);
  updateMyPrefs_showSidebar(x.id);
  verifyMyPrefs_showSidebarExists(x.id);
  verifyMyPrefs_showSidebarUpdated(x.id);
});

bthread("Members lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers(x.id);
  updateMembers(x.id);
  updateMembers(x.id);
  verifyMembersExists(x.id);
  verifyMembersUpdated(x.id);
});

bthread("Prefs_invitations lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_invitations(x.id);
  updatePrefs_invitations(x.id);
  updatePrefs_invitations(x.id);
  verifyPrefs_invitationsExists(x.id);
  verifyPrefs_invitationsUpdated(x.id);
});

bthread("Cards_idMembers lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_idMembers(x.id);
  updateCards_idMembers(x.id);
  updateCards_idMembers(x.id);
  verifyCards_idMembersExists(x.id);
  verifyCards_idMembersUpdated(x.id);
});

bthread("Members_initials lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_initials(x.id);
  updateMembers_initials(x.id);
  updateMembers_initials(x.id);
  verifyMembers_initialsExists(x.id);
  verifyMembers_initialsUpdated(x.id);
});

bthread("Cards_checklist_checkItem_pos lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_checklist_checkItem_pos(x.id);
  updateCards_checklist_checkItem_pos(x.id);
  updateCards_checklist_checkItem_pos(x.id);
  verifyCards_checklist_checkItem_posExists(x.id);
  verifyCards_checklist_checkItem_posUpdated(x.id);
});

bthread("Prefs_comments lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_comments(x.id);
  updatePrefs_comments(x.id);
  updatePrefs_comments(x.id);
  verifyPrefs_commentsExists(x.id);
  verifyPrefs_commentsUpdated(x.id);
});

bthread("Prefs_selfJoin lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_selfJoin(x.id);
  updatePrefs_selfJoin(x.id);
  updatePrefs_selfJoin(x.id);
  verifyPrefs_selfJoinExists(x.id);
  verifyPrefs_selfJoinUpdated(x.id);
});

bthread("Prefs_cardCovers lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_cardCovers(x.id);
  updatePrefs_cardCovers(x.id);
  updatePrefs_cardCovers(x.id);
  verifyPrefs_cardCoversExists(x.id);
  verifyPrefs_cardCoversUpdated(x.id);
});

bthread("Actions lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addActions(x.id);
  updateActions(x.id);
  updateActions(x.id);
  verifyActionsExists(x.id);
  verifyActionsUpdated(x.id);
});

bthread("Organizations_name lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOrganizations_name(x.id);
  updateOrganizations_name(x.id);
  updateOrganizations_name(x.id);
  verifyOrganizations_nameExists(x.id);
  verifyOrganizations_nameUpdated(x.id);
});

bthread("Checklists lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addChecklists(x.id);
  updateChecklists(x.id);
  updateChecklists(x.id);
  verifyChecklistsExists(x.id);
  verifyChecklistsUpdated(x.id);
});

bthread("LabelNames_red lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLabelNames_red(x.id);
  updateLabelNames_red(x.id);
  updateLabelNames_red(x.id);
  verifyLabelNames_redExists(x.id);
  verifyLabelNames_redUpdated(x.id);
});

bthread("Webhooks_callbackURL lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWebhooks_callbackURL(x.id);
  updateWebhooks_callbackURL(x.id);
  updateWebhooks_callbackURL(x.id);
  verifyWebhooks_callbackURLExists(x.id);
  verifyWebhooks_callbackURLUpdated(x.id);
});

bthread("Members_savedSearches_pos lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_savedSearches_pos(x.id);
  updateMembers_savedSearches_pos(x.id);
  updateMembers_savedSearches_pos(x.id);
  verifyMembers_savedSearches_posExists(x.id);
  verifyMembers_savedSearches_posUpdated(x.id);
});

bthread("Prefs_permissionLevel lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_permissionLevel(x.id);
  updatePrefs_permissionLevel(x.id);
  updatePrefs_permissionLevel(x.id);
  verifyPrefs_permissionLevelExists(x.id);
  verifyPrefs_permissionLevelUpdated(x.id);
});

bthread("Cards_idLabels lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_idLabels(x.id);
  updateCards_idLabels(x.id);
  updateCards_idLabels(x.id);
  verifyCards_idLabelsExists(x.id);
  verifyCards_idLabelsUpdated(x.id);
});

bthread("Cards_due lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_due(x.id);
  updateCards_due(x.id);
  updateCards_due(x.id);
  verifyCards_dueExists(x.id);
  verifyCards_dueUpdated(x.id);
});

bthread("Prefs_calendarFeedEnabled lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_calendarFeedEnabled(x.id);
  updatePrefs_calendarFeedEnabled(x.id);
  updatePrefs_calendarFeedEnabled(x.id);
  verifyPrefs_calendarFeedEnabledExists(x.id);
  verifyPrefs_calendarFeedEnabledUpdated(x.id);
});

bthread("Lists lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLists(x.id);
  updateLists(x.id);
  updateLists(x.id);
  verifyListsExists(x.id);
  verifyListsUpdated(x.id);
});

bthread("Lists_moveAllCards lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLists_moveAllCards(x.id);
  updateLists_moveAllCards(x.id);
  updateLists_moveAllCards(x.id);
  verifyLists_moveAllCardsExists(x.id);
  verifyLists_moveAllCardsUpdated(x.id);
});

bthread("Labels_color lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLabels_color(x.id);
  updateLabels_color(x.id);
  updateLabels_color(x.id);
  verifyLabels_colorExists(x.id);
  verifyLabels_colorUpdated(x.id);
});

bthread("MyPrefs_showListGuide lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMyPrefs_showListGuide(x.id);
  updateMyPrefs_showListGuide(x.id);
  updateMyPrefs_showListGuide(x.id);
  verifyMyPrefs_showListGuideExists(x.id);
  verifyMyPrefs_showListGuideUpdated(x.id);
});

bthread("Boards_name lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_name(x.id);
  updateBoards_name(x.id);
  updateBoards_name(x.id);
  verifyBoards_nameExists(x.id);
  verifyBoards_nameUpdated(x.id);
});

bthread("Members_fullName lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_fullName(x.id);
  updateMembers_fullName(x.id);
  updateMembers_fullName(x.id);
  verifyMembers_fullNameExists(x.id);
  verifyMembers_fullNameUpdated(x.id);
});

bthread("Prefs_googleAppsVersion lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_googleAppsVersion(x.id);
  updatePrefs_googleAppsVersion(x.id);
  updatePrefs_googleAppsVersion(x.id);
  verifyPrefs_googleAppsVersionExists(x.id);
  verifyPrefs_googleAppsVersionUpdated(x.id);
});

bthread("Cards_idAttachmentCover lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_idAttachmentCover(x.id);
  updateCards_idAttachmentCover(x.id);
  updateCards_idAttachmentCover(x.id);
  verifyCards_idAttachmentCoverExists(x.id);
  verifyCards_idAttachmentCoverUpdated(x.id);
});

bthread("Cards_desc lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_desc(x.id);
  updateCards_desc(x.id);
  updateCards_desc(x.id);
  verifyCards_descExists(x.id);
  verifyCards_descUpdated(x.id);
});

bthread("MyPrefs_emailPosition lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMyPrefs_emailPosition(x.id);
  updateMyPrefs_emailPosition(x.id);
  updateMyPrefs_emailPosition(x.id);
  verifyMyPrefs_emailPositionExists(x.id);
  verifyMyPrefs_emailPositionUpdated(x.id);
});

bthread("Cards_checklist_checkItem_state lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_checklist_checkItem_state(x.id);
  updateCards_checklist_checkItem_state(x.id);
  updateCards_checklist_checkItem_state(x.id);
  verifyCards_checklist_checkItem_stateExists(x.id);
  verifyCards_checklist_checkItem_stateUpdated(x.id);
});

bthread("Cards_idList lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_idList(x.id);
  updateCards_idList(x.id);
  updateCards_idList(x.id);
  verifyCards_idListExists(x.id);
  verifyCards_idListUpdated(x.id);
});

bthread("Boards_lists lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_lists(x.id);
  updateBoards_lists(x.id);
  updateBoards_lists(x.id);
  verifyBoards_listsExists(x.id);
  verifyBoards_listsUpdated(x.id);
});

bthread("Cards_stickers lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_stickers(x.id);
  updateCards_stickers(x.id);
  updateCards_stickers(x.id);
  verifyCards_stickersExists(x.id);
  verifyCards_stickersUpdated(x.id);
});

bthread("Boards_memberships lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_memberships(x.id);
  updateBoards_memberships(x.id);
  updateBoards_memberships(x.id);
  verifyBoards_membershipsExists(x.id);
  verifyBoards_membershipsUpdated(x.id);
});

bthread("Cards_checklists lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_checklists(x.id);
  updateCards_checklists(x.id);
  updateCards_checklists(x.id);
  verifyCards_checklistsExists(x.id);
  verifyCards_checklistsUpdated(x.id);
});

bthread("Boards_checklists lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_checklists(x.id);
  updateBoards_checklists(x.id);
  updateBoards_checklists(x.id);
  verifyBoards_checklistsExists(x.id);
  verifyBoards_checklistsUpdated(x.id);
});

bthread("Cards_attachments lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_attachments(x.id);
  updateCards_attachments(x.id);
  updateCards_attachments(x.id);
  verifyCards_attachmentsExists(x.id);
  verifyCards_attachmentsUpdated(x.id);
});

bthread("Prefs_locale lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_locale(x.id);
  updatePrefs_locale(x.id);
  updatePrefs_locale(x.id);
  verifyPrefs_localeExists(x.id);
  verifyPrefs_localeUpdated(x.id);
});

bthread("Members_savedSearches_query lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_savedSearches_query(x.id);
  updateMembers_savedSearches_query(x.id);
  updateMembers_savedSearches_query(x.id);
  verifyMembers_savedSearches_queryExists(x.id);
  verifyMembers_savedSearches_queryUpdated(x.id);
});

bthread("Notifications lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNotifications(x.id);
  updateNotifications(x.id);
  updateNotifications(x.id);
  verifyNotificationsExists(x.id);
  verifyNotificationsUpdated(x.id);
});

bthread("LabelNames_green lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLabelNames_green(x.id);
  updateLabelNames_green(x.id);
  updateLabelNames_green(x.id);
  verifyLabelNames_greenExists(x.id);
  verifyLabelNames_greenUpdated(x.id);
});

bthread("LabelNames_yellow lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLabelNames_yellow(x.id);
  updateLabelNames_yellow(x.id);
  updateLabelNames_yellow(x.id);
  verifyLabelNames_yellowExists(x.id);
  verifyLabelNames_yellowUpdated(x.id);
});

bthread("Prefs_colorBlind lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_colorBlind(x.id);
  updatePrefs_colorBlind(x.id);
  updatePrefs_colorBlind(x.id);
  verifyPrefs_colorBlindExists(x.id);
  verifyPrefs_colorBlindUpdated(x.id);
});

bthread("Lists_closed lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLists_closed(x.id);
  updateLists_closed(x.id);
  updateLists_closed(x.id);
  verifyLists_closedExists(x.id);
  verifyLists_closedUpdated(x.id);
});

bthread("Prefs_boardVisibilityRestrict lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_boardVisibilityRestrict(x.id);
  updatePrefs_boardVisibilityRestrict(x.id);
  updatePrefs_boardVisibilityRestrict(x.id);
  verifyPrefs_boardVisibilityRestrictExists(x.id);
  verifyPrefs_boardVisibilityRestrictUpdated(x.id);
});

bthread("Members_boardStars lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_boardStars(x.id);
  updateMembers_boardStars(x.id);
  updateMembers_boardStars(x.id);
  verifyMembers_boardStarsExists(x.id);
  verifyMembers_boardStarsUpdated(x.id);
});

bthread("Prefs_minutesBetweenSummaries lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_minutesBetweenSummaries(x.id);
  updatePrefs_minutesBetweenSummaries(x.id);
  updatePrefs_minutesBetweenSummaries(x.id);
  verifyPrefs_minutesBetweenSummariesExists(x.id);
  verifyPrefs_minutesBetweenSummariesUpdated(x.id);
});

bthread("Cards_subscribed lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_subscribed(x.id);
  updateCards_subscribed(x.id);
  updateCards_subscribed(x.id);
  verifyCards_subscribedExists(x.id);
  verifyCards_subscribedUpdated(x.id);
});

bthread("Webhooks_active lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWebhooks_active(x.id);
  updateWebhooks_active(x.id);
  updateWebhooks_active(x.id);
  verifyWebhooks_activeExists(x.id);
  verifyWebhooks_activeUpdated(x.id);
});

bthread("Members_savedSearches_name lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_savedSearches_name(x.id);
  updateMembers_savedSearches_name(x.id);
  updateMembers_savedSearches_name(x.id);
  verifyMembers_savedSearches_nameExists(x.id);
  verifyMembers_savedSearches_nameUpdated(x.id);
});

bthread("Boards_subscribed lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_subscribed(x.id);
  updateBoards_subscribed(x.id);
  updateBoards_subscribed(x.id);
  verifyBoards_subscribedExists(x.id);
  verifyBoards_subscribedUpdated(x.id);
});

bthread("Notifications_unread lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNotifications_unread(x.id);
  updateNotifications_unread(x.id);
  updateNotifications_unread(x.id);
  verifyNotifications_unreadExists(x.id);
  verifyNotifications_unreadUpdated(x.id);
});

bthread("Webhooks_description lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWebhooks_description(x.id);
  updateWebhooks_description(x.id);
  updateWebhooks_description(x.id);
  verifyWebhooks_descriptionExists(x.id);
  verifyWebhooks_descriptionUpdated(x.id);
});

bthread("Checklists_pos lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addChecklists_pos(x.id);
  updateChecklists_pos(x.id);
  updateChecklists_pos(x.id);
  verifyChecklists_posExists(x.id);
  verifyChecklists_posUpdated(x.id);
});

bthread("Boards lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards(x.id);
  updateBoards(x.id);
  updateBoards(x.id);
  verifyBoardsExists(x.id);
  verifyBoardsUpdated(x.id);
});

bthread("Prefs_background lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefs_background(x.id);
  updatePrefs_background(x.id);
  updatePrefs_background(x.id);
  verifyPrefs_backgroundExists(x.id);
  verifyPrefs_backgroundUpdated(x.id);
});

bthread("Members_customEmoji lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_customEmoji(x.id);
  updateMembers_customEmoji(x.id);
  updateMembers_customEmoji(x.id);
  verifyMembers_customEmojiExists(x.id);
  verifyMembers_customEmojiUpdated(x.id);
});

bthread("Members_username lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_username(x.id);
  updateMembers_username(x.id);
  updateMembers_username(x.id);
  verifyMembers_usernameExists(x.id);
  verifyMembers_usernameUpdated(x.id);
});

bthread("Members_avatar lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_avatar(x.id);
  updateMembers_avatar(x.id);
  updateMembers_avatar(x.id);
  verifyMembers_avatarExists(x.id);
  verifyMembers_avatarUpdated(x.id);
});

bthread("Members_customStickers lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_customStickers(x.id);
  updateMembers_customStickers(x.id);
  updateMembers_customStickers(x.id);
  verifyMembers_customStickersExists(x.id);
  verifyMembers_customStickersUpdated(x.id);
});

bthread("Cards_idBoard lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCards_idBoard(x.id);
  updateCards_idBoard(x.id);
  updateCards_idBoard(x.id);
  verifyCards_idBoardExists(x.id);
  verifyCards_idBoardUpdated(x.id);
});

bthread("Members_oneTimeMessagesDismissed lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMembers_oneTimeMessagesDismissed(x.id);
  updateMembers_oneTimeMessagesDismissed(x.id);
  updateMembers_oneTimeMessagesDismissed(x.id);
  verifyMembers_oneTimeMessagesDismissedExists(x.id);
  verifyMembers_oneTimeMessagesDismissedUpdated(x.id);
});

bthread("Boards_closed lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBoards_closed(x.id);
  updateBoards_closed(x.id);
  updateBoards_closed(x.id);
  verifyBoards_closedExists(x.id);
  verifyBoards_closedUpdated(x.id);
});

// ===== PASSIVE ASSERTIONS =====

bthread("Boards_idOrganization create verification", function () {
  const e = waitForAnyBoards_idOrganizationAdded();
  block(matchDeleteBoards_idOrganization(e.id, ANY), function () {
    verifyBoards_idOrganizationExists(e.id);
  });
});

bthread("Boards_idOrganization update verification", function () {
  const e = waitForAnyBoards_idOrganizationUpdated();
  block(matchDeleteBoards_idOrganization(e.id, ANY), function () {
    verifyBoards_idOrganizationUpdated(e.id);
  });
});

bthread("Boards_idOrganization delete verification", function () {
  const e = waitForAnyBoards_idOrganizationDeleted();
  block(matchAddBoards_idOrganization(e.id, ANY), function () {
    verifyBoards_idOrganizationDoesNotExist(e.id);
  });
});

bthread("Boards_members create verification", function () {
  const e = waitForAnyBoards_membersAdded();
  block(matchDeleteBoards_members(e.id, ANY), function () {
    verifyBoards_membersExists(e.id);
  });
});

bthread("Boards_members update verification", function () {
  const e = waitForAnyBoards_membersUpdated();
  block(matchDeleteBoards_members(e.id, ANY), function () {
    verifyBoards_membersUpdated(e.id);
  });
});

bthread("Boards_members delete verification", function () {
  const e = waitForAnyBoards_membersDeleted();
  block(matchAddBoards_members(e.id, ANY), function () {
    verifyBoards_membersDoesNotExist(e.id);
  });
});

bthread("Lists_name create verification", function () {
  const e = waitForAnyLists_nameAdded();
  block(matchDeleteLists_name(e.id, ANY), function () {
    verifyLists_nameExists(e.id);
  });
});

bthread("Lists_name update verification", function () {
  const e = waitForAnyLists_nameUpdated();
  block(matchDeleteLists_name(e.id, ANY), function () {
    verifyLists_nameUpdated(e.id);
  });
});

bthread("Lists_name delete verification", function () {
  const e = waitForAnyLists_nameDeleted();
  block(matchAddLists_name(e.id, ANY), function () {
    verifyLists_nameDoesNotExist(e.id);
  });
});

bthread("Cards_membersVoted create verification", function () {
  const e = waitForAnyCards_membersVotedAdded();
  block(matchDeleteCards_membersVoted(e.id, ANY), function () {
    verifyCards_membersVotedExists(e.id);
  });
});

bthread("Cards_membersVoted update verification", function () {
  const e = waitForAnyCards_membersVotedUpdated();
  block(matchDeleteCards_membersVoted(e.id, ANY), function () {
    verifyCards_membersVotedUpdated(e.id);
  });
});

bthread("Cards_membersVoted delete verification", function () {
  const e = waitForAnyCards_membersVotedDeleted();
  block(matchAddCards_membersVoted(e.id, ANY), function () {
    verifyCards_membersVotedDoesNotExist(e.id);
  });
});

bthread("Organizations_desc create verification", function () {
  const e = waitForAnyOrganizations_descAdded();
  block(matchDeleteOrganizations_desc(e.id, ANY), function () {
    verifyOrganizations_descExists(e.id);
  });
});

bthread("Organizations_desc update verification", function () {
  const e = waitForAnyOrganizations_descUpdated();
  block(matchDeleteOrganizations_desc(e.id, ANY), function () {
    verifyOrganizations_descUpdated(e.id);
  });
});

bthread("Organizations_desc delete verification", function () {
  const e = waitForAnyOrganizations_descDeleted();
  block(matchAddOrganizations_desc(e.id, ANY), function () {
    verifyOrganizations_descDoesNotExist(e.id);
  });
});

bthread("Labels create verification", function () {
  const e = waitForAnyLabelsAdded();
  block(matchDeleteLabels(e.id, ANY), function () {
    verifyLabelsExists(e.id);
  });
});

bthread("Labels update verification", function () {
  const e = waitForAnyLabelsUpdated();
  block(matchDeleteLabels(e.id, ANY), function () {
    verifyLabelsUpdated(e.id);
  });
});

bthread("Labels delete verification", function () {
  const e = waitForAnyLabelsDeleted();
  block(matchAddLabels(e.id, ANY), function () {
    verifyLabelsDoesNotExist(e.id);
  });
});

bthread("MyPrefs_showSidebarBoardActions create verification", function () {
  const e = waitForAnyMyPrefs_showSidebarBoardActionsAdded();
  block(matchDeleteMyPrefs_showSidebarBoardActions(e.id, ANY), function () {
    verifyMyPrefs_showSidebarBoardActionsExists(e.id);
  });
});

bthread("MyPrefs_showSidebarBoardActions update verification", function () {
  const e = waitForAnyMyPrefs_showSidebarBoardActionsUpdated();
  block(matchDeleteMyPrefs_showSidebarBoardActions(e.id, ANY), function () {
    verifyMyPrefs_showSidebarBoardActionsUpdated(e.id);
  });
});

bthread("MyPrefs_showSidebarBoardActions delete verification", function () {
  const e = waitForAnyMyPrefs_showSidebarBoardActionsDeleted();
  block(matchAddMyPrefs_showSidebarBoardActions(e.id, ANY), function () {
    verifyMyPrefs_showSidebarBoardActionsDoesNotExist(e.id);
  });
});

bthread("Cards_checklist_idChecklistCurrent_checkItem create verification", function () {
  const e = waitForAnyCards_checklist_idChecklistCurrent_checkItemAdded();
  block(matchDeleteCards_checklist_idChecklistCurrent_checkItem(e.id, ANY), function () {
    verifyCards_checklist_idChecklistCurrent_checkItemExists(e.id);
  });
});

bthread("Cards_checklist_idChecklistCurrent_checkItem update verification", function () {
  const e = waitForAnyCards_checklist_idChecklistCurrent_checkItemUpdated();
  block(matchDeleteCards_checklist_idChecklistCurrent_checkItem(e.id, ANY), function () {
    verifyCards_checklist_idChecklistCurrent_checkItemUpdated(e.id);
  });
});

bthread("Cards_checklist_idChecklistCurrent_checkItem delete verification", function () {
  const e = waitForAnyCards_checklist_idChecklistCurrent_checkItemDeleted();
  block(matchAddCards_checklist_idChecklistCurrent_checkItem(e.id, ANY), function () {
    verifyCards_checklist_idChecklistCurrent_checkItemDoesNotExist(e.id);
  });
});

bthread("Organizations_memberships create verification", function () {
  const e = waitForAnyOrganizations_membershipsAdded();
  block(matchDeleteOrganizations_memberships(e.id, ANY), function () {
    verifyOrganizations_membershipsExists(e.id);
  });
});

bthread("Organizations_memberships update verification", function () {
  const e = waitForAnyOrganizations_membershipsUpdated();
  block(matchDeleteOrganizations_memberships(e.id, ANY), function () {
    verifyOrganizations_membershipsUpdated(e.id);
  });
});

bthread("Organizations_memberships delete verification", function () {
  const e = waitForAnyOrganizations_membershipsDeleted();
  block(matchAddOrganizations_memberships(e.id, ANY), function () {
    verifyOrganizations_membershipsDoesNotExist(e.id);
  });
});

bthread("MyPrefs_idEmailList create verification", function () {
  const e = waitForAnyMyPrefs_idEmailListAdded();
  block(matchDeleteMyPrefs_idEmailList(e.id, ANY), function () {
    verifyMyPrefs_idEmailListExists(e.id);
  });
});

bthread("MyPrefs_idEmailList update verification", function () {
  const e = waitForAnyMyPrefs_idEmailListUpdated();
  block(matchDeleteMyPrefs_idEmailList(e.id, ANY), function () {
    verifyMyPrefs_idEmailListUpdated(e.id);
  });
});

bthread("MyPrefs_idEmailList delete verification", function () {
  const e = waitForAnyMyPrefs_idEmailListDeleted();
  block(matchAddMyPrefs_idEmailList(e.id, ANY), function () {
    verifyMyPrefs_idEmailListDoesNotExist(e.id);
  });
});

bthread("Cards_name create verification", function () {
  const e = waitForAnyCards_nameAdded();
  block(matchDeleteCards_name(e.id, ANY), function () {
    verifyCards_nameExists(e.id);
  });
});

bthread("Cards_name update verification", function () {
  const e = waitForAnyCards_nameUpdated();
  block(matchDeleteCards_name(e.id, ANY), function () {
    verifyCards_nameUpdated(e.id);
  });
});

bthread("Cards_name delete verification", function () {
  const e = waitForAnyCards_nameDeleted();
  block(matchAddCards_name(e.id, ANY), function () {
    verifyCards_nameDoesNotExist(e.id);
  });
});

bthread("Boards_desc create verification", function () {
  const e = waitForAnyBoards_descAdded();
  block(matchDeleteBoards_desc(e.id, ANY), function () {
    verifyBoards_descExists(e.id);
  });
});

bthread("Boards_desc update verification", function () {
  const e = waitForAnyBoards_descUpdated();
  block(matchDeleteBoards_desc(e.id, ANY), function () {
    verifyBoards_descUpdated(e.id);
  });
});

bthread("Boards_desc delete verification", function () {
  const e = waitForAnyBoards_descDeleted();
  block(matchAddBoards_desc(e.id, ANY), function () {
    verifyBoards_descDoesNotExist(e.id);
  });
});

bthread("Members_avatarSource create verification", function () {
  const e = waitForAnyMembers_avatarSourceAdded();
  block(matchDeleteMembers_avatarSource(e.id, ANY), function () {
    verifyMembers_avatarSourceExists(e.id);
  });
});

bthread("Members_avatarSource update verification", function () {
  const e = waitForAnyMembers_avatarSourceUpdated();
  block(matchDeleteMembers_avatarSource(e.id, ANY), function () {
    verifyMembers_avatarSourceUpdated(e.id);
  });
});

bthread("Members_avatarSource delete verification", function () {
  const e = waitForAnyMembers_avatarSourceDeleted();
  block(matchAddMembers_avatarSource(e.id, ANY), function () {
    verifyMembers_avatarSourceDoesNotExist(e.id);
  });
});

bthread("Boards_labels create verification", function () {
  const e = waitForAnyBoards_labelsAdded();
  block(matchDeleteBoards_labels(e.id, ANY), function () {
    verifyBoards_labelsExists(e.id);
  });
});

bthread("Boards_labels update verification", function () {
  const e = waitForAnyBoards_labelsUpdated();
  block(matchDeleteBoards_labels(e.id, ANY), function () {
    verifyBoards_labelsUpdated(e.id);
  });
});

bthread("Boards_labels delete verification", function () {
  const e = waitForAnyBoards_labelsDeleted();
  block(matchAddBoards_labels(e.id, ANY), function () {
    verifyBoards_labelsDoesNotExist(e.id);
  });
});

bthread("Cards_pos create verification", function () {
  const e = waitForAnyCards_posAdded();
  block(matchDeleteCards_pos(e.id, ANY), function () {
    verifyCards_posExists(e.id);
  });
});

bthread("Cards_pos update verification", function () {
  const e = waitForAnyCards_posUpdated();
  block(matchDeleteCards_pos(e.id, ANY), function () {
    verifyCards_posUpdated(e.id);
  });
});

bthread("Cards_pos delete verification", function () {
  const e = waitForAnyCards_posDeleted();
  block(matchAddCards_pos(e.id, ANY), function () {
    verifyCards_posDoesNotExist(e.id);
  });
});

bthread("LabelNames_purple create verification", function () {
  const e = waitForAnyLabelNames_purpleAdded();
  block(matchDeleteLabelNames_purple(e.id, ANY), function () {
    verifyLabelNames_purpleExists(e.id);
  });
});

bthread("LabelNames_purple update verification", function () {
  const e = waitForAnyLabelNames_purpleUpdated();
  block(matchDeleteLabelNames_purple(e.id, ANY), function () {
    verifyLabelNames_purpleUpdated(e.id);
  });
});

bthread("LabelNames_purple delete verification", function () {
  const e = waitForAnyLabelNames_purpleDeleted();
  block(matchAddLabelNames_purple(e.id, ANY), function () {
    verifyLabelNames_purpleDoesNotExist(e.id);
  });
});

bthread("Lists_subscribed create verification", function () {
  const e = waitForAnyLists_subscribedAdded();
  block(matchDeleteLists_subscribed(e.id, ANY), function () {
    verifyLists_subscribedExists(e.id);
  });
});

bthread("Lists_subscribed update verification", function () {
  const e = waitForAnyLists_subscribedUpdated();
  block(matchDeleteLists_subscribed(e.id, ANY), function () {
    verifyLists_subscribedUpdated(e.id);
  });
});

bthread("Lists_subscribed delete verification", function () {
  const e = waitForAnyLists_subscribedDeleted();
  block(matchAddLists_subscribed(e.id, ANY), function () {
    verifyLists_subscribedDoesNotExist(e.id);
  });
});

bthread("Organizations create verification", function () {
  const e = waitForAnyOrganizationsAdded();
  block(matchDeleteOrganizations(e.id, ANY), function () {
    verifyOrganizationsExists(e.id);
  });
});

bthread("Organizations update verification", function () {
  const e = waitForAnyOrganizationsUpdated();
  block(matchDeleteOrganizations(e.id, ANY), function () {
    verifyOrganizationsUpdated(e.id);
  });
});

bthread("Organizations delete verification", function () {
  const e = waitForAnyOrganizationsDeleted();
  block(matchAddOrganizations(e.id, ANY), function () {
    verifyOrganizationsDoesNotExist(e.id);
  });
});

bthread("Sessions create verification", function () {
  const e = waitForAnySessionsAdded();
  block(matchDeleteSessions(e.id, ANY), function () {
    verifySessionsExists(e.id);
  });
});

bthread("Sessions update verification", function () {
  const e = waitForAnySessionsUpdated();
  block(matchDeleteSessions(e.id, ANY), function () {
    verifySessionsUpdated(e.id);
  });
});

bthread("Sessions delete verification", function () {
  const e = waitForAnySessionsDeleted();
  block(matchAddSessions(e.id, ANY), function () {
    verifySessionsDoesNotExist(e.id);
  });
});

bthread("Tokens_webhooks create verification", function () {
  const e = waitForAnyTokens_webhooksAdded();
  block(matchDeleteTokens_webhooks(e.id, ANY), function () {
    verifyTokens_webhooksExists(e.id);
  });
});

bthread("Tokens_webhooks update verification", function () {
  const e = waitForAnyTokens_webhooksUpdated();
  block(matchDeleteTokens_webhooks(e.id, ANY), function () {
    verifyTokens_webhooksUpdated(e.id);
  });
});

bthread("Tokens_webhooks delete verification", function () {
  const e = waitForAnyTokens_webhooksDeleted();
  block(matchAddTokens_webhooks(e.id, ANY), function () {
    verifyTokens_webhooksDoesNotExist(e.id);
  });
});

bthread("Webhooks_idModel create verification", function () {
  const e = waitForAnyWebhooks_idModelAdded();
  block(matchDeleteWebhooks_idModel(e.id, ANY), function () {
    verifyWebhooks_idModelExists(e.id);
  });
});

bthread("Webhooks_idModel update verification", function () {
  const e = waitForAnyWebhooks_idModelUpdated();
  block(matchDeleteWebhooks_idModel(e.id, ANY), function () {
    verifyWebhooks_idModelUpdated(e.id);
  });
});

bthread("Webhooks_idModel delete verification", function () {
  const e = waitForAnyWebhooks_idModelDeleted();
  block(matchAddWebhooks_idModel(e.id, ANY), function () {
    verifyWebhooks_idModelDoesNotExist(e.id);
  });
});

bthread("Members_boardBackgrounds create verification", function () {
  const e = waitForAnyMembers_boardBackgroundsAdded();
  block(matchDeleteMembers_boardBackgrounds(e.id, ANY), function () {
    verifyMembers_boardBackgroundsExists(e.id);
  });
});

bthread("Members_boardBackgrounds update verification", function () {
  const e = waitForAnyMembers_boardBackgroundsUpdated();
  block(matchDeleteMembers_boardBackgrounds(e.id, ANY), function () {
    verifyMembers_boardBackgroundsUpdated(e.id);
  });
});

bthread("Members_boardBackgrounds delete verification", function () {
  const e = waitForAnyMembers_boardBackgroundsDeleted();
  block(matchAddMembers_boardBackgrounds(e.id, ANY), function () {
    verifyMembers_boardBackgroundsDoesNotExist(e.id);
  });
});

bthread("Prefs_cardAging create verification", function () {
  const e = waitForAnyPrefs_cardAgingAdded();
  block(matchDeletePrefs_cardAging(e.id, ANY), function () {
    verifyPrefs_cardAgingExists(e.id);
  });
});

bthread("Prefs_cardAging update verification", function () {
  const e = waitForAnyPrefs_cardAgingUpdated();
  block(matchDeletePrefs_cardAging(e.id, ANY), function () {
    verifyPrefs_cardAgingUpdated(e.id);
  });
});

bthread("Prefs_cardAging delete verification", function () {
  const e = waitForAnyPrefs_cardAgingDeleted();
  block(matchAddPrefs_cardAging(e.id, ANY), function () {
    verifyPrefs_cardAgingDoesNotExist(e.id);
  });
});

bthread("Members_savedSearches create verification", function () {
  const e = waitForAnyMembers_savedSearchesAdded();
  block(matchDeleteMembers_savedSearches(e.id, ANY), function () {
    verifyMembers_savedSearchesExists(e.id);
  });
});

bthread("Members_savedSearches update verification", function () {
  const e = waitForAnyMembers_savedSearchesUpdated();
  block(matchDeleteMembers_savedSearches(e.id, ANY), function () {
    verifyMembers_savedSearchesUpdated(e.id);
  });
});

bthread("Members_savedSearches delete verification", function () {
  const e = waitForAnyMembers_savedSearchesDeleted();
  block(matchAddMembers_savedSearches(e.id, ANY), function () {
    verifyMembers_savedSearchesDoesNotExist(e.id);
  });
});

bthread("Labels_name create verification", function () {
  const e = waitForAnyLabels_nameAdded();
  block(matchDeleteLabels_name(e.id, ANY), function () {
    verifyLabels_nameExists(e.id);
  });
});

bthread("Labels_name update verification", function () {
  const e = waitForAnyLabels_nameUpdated();
  block(matchDeleteLabels_name(e.id, ANY), function () {
    verifyLabels_nameUpdated(e.id);
  });
});

bthread("Labels_name delete verification", function () {
  const e = waitForAnyLabels_nameDeleted();
  block(matchAddLabels_name(e.id, ANY), function () {
    verifyLabels_nameDoesNotExist(e.id);
  });
});

bthread("Actions_comments create verification", function () {
  const e = waitForAnyActions_commentsAdded();
  block(matchDeleteActions_comments(e.id, ANY), function () {
    verifyActions_commentsExists(e.id);
  });
});

bthread("Actions_comments update verification", function () {
  const e = waitForAnyActions_commentsUpdated();
  block(matchDeleteActions_comments(e.id, ANY), function () {
    verifyActions_commentsUpdated(e.id);
  });
});

bthread("Actions_comments delete verification", function () {
  const e = waitForAnyActions_commentsDeleted();
  block(matchAddActions_comments(e.id, ANY), function () {
    verifyActions_commentsDoesNotExist(e.id);
  });
});

bthread("Organizations_displayName create verification", function () {
  const e = waitForAnyOrganizations_displayNameAdded();
  block(matchDeleteOrganizations_displayName(e.id, ANY), function () {
    verifyOrganizations_displayNameExists(e.id);
  });
});

bthread("Organizations_displayName update verification", function () {
  const e = waitForAnyOrganizations_displayNameUpdated();
  block(matchDeleteOrganizations_displayName(e.id, ANY), function () {
    verifyOrganizations_displayNameUpdated(e.id);
  });
});

bthread("Organizations_displayName delete verification", function () {
  const e = waitForAnyOrganizations_displayNameDeleted();
  block(matchAddOrganizations_displayName(e.id, ANY), function () {
    verifyOrganizations_displayNameDoesNotExist(e.id);
  });
});

bthread("Lists_pos create verification", function () {
  const e = waitForAnyLists_posAdded();
  block(matchDeleteLists_pos(e.id, ANY), function () {
    verifyLists_posExists(e.id);
  });
});

bthread("Lists_pos update verification", function () {
  const e = waitForAnyLists_posUpdated();
  block(matchDeleteLists_pos(e.id, ANY), function () {
    verifyLists_posUpdated(e.id);
  });
});

bthread("Lists_pos delete verification", function () {
  const e = waitForAnyLists_posDeleted();
  block(matchAddLists_pos(e.id, ANY), function () {
    verifyLists_posDoesNotExist(e.id);
  });
});

bthread("LabelNames_blue create verification", function () {
  const e = waitForAnyLabelNames_blueAdded();
  block(matchDeleteLabelNames_blue(e.id, ANY), function () {
    verifyLabelNames_blueExists(e.id);
  });
});

bthread("LabelNames_blue update verification", function () {
  const e = waitForAnyLabelNames_blueUpdated();
  block(matchDeleteLabelNames_blue(e.id, ANY), function () {
    verifyLabelNames_blueUpdated(e.id);
  });
});

bthread("LabelNames_blue delete verification", function () {
  const e = waitForAnyLabelNames_blueDeleted();
  block(matchAddLabelNames_blue(e.id, ANY), function () {
    verifyLabelNames_blueDoesNotExist(e.id);
  });
});

bthread("Cards_checklist_checkItem_name create verification", function () {
  const e = waitForAnyCards_checklist_checkItem_nameAdded();
  block(matchDeleteCards_checklist_checkItem_name(e.id, ANY), function () {
    verifyCards_checklist_checkItem_nameExists(e.id);
  });
});

bthread("Cards_checklist_checkItem_name update verification", function () {
  const e = waitForAnyCards_checklist_checkItem_nameUpdated();
  block(matchDeleteCards_checklist_checkItem_name(e.id, ANY), function () {
    verifyCards_checklist_checkItem_nameUpdated(e.id);
  });
});

bthread("Cards_checklist_checkItem_name delete verification", function () {
  const e = waitForAnyCards_checklist_checkItem_nameDeleted();
  block(matchAddCards_checklist_checkItem_name(e.id, ANY), function () {
    verifyCards_checklist_checkItem_nameDoesNotExist(e.id);
  });
});

bthread("Prefs_externalMembersDisabled create verification", function () {
  const e = waitForAnyPrefs_externalMembersDisabledAdded();
  block(matchDeletePrefs_externalMembersDisabled(e.id, ANY), function () {
    verifyPrefs_externalMembersDisabledExists(e.id);
  });
});

bthread("Prefs_externalMembersDisabled update verification", function () {
  const e = waitForAnyPrefs_externalMembersDisabledUpdated();
  block(matchDeletePrefs_externalMembersDisabled(e.id, ANY), function () {
    verifyPrefs_externalMembersDisabledUpdated(e.id);
  });
});

bthread("Prefs_externalMembersDisabled delete verification", function () {
  const e = waitForAnyPrefs_externalMembersDisabledDeleted();
  block(matchAddPrefs_externalMembersDisabled(e.id, ANY), function () {
    verifyPrefs_externalMembersDisabledDoesNotExist(e.id);
  });
});

bthread("Checklists_idCard create verification", function () {
  const e = waitForAnyChecklists_idCardAdded();
  block(matchDeleteChecklists_idCard(e.id, ANY), function () {
    verifyChecklists_idCardExists(e.id);
  });
});

bthread("Checklists_idCard update verification", function () {
  const e = waitForAnyChecklists_idCardUpdated();
  block(matchDeleteChecklists_idCard(e.id, ANY), function () {
    verifyChecklists_idCardUpdated(e.id);
  });
});

bthread("Checklists_idCard delete verification", function () {
  const e = waitForAnyChecklists_idCardDeleted();
  block(matchAddChecklists_idCard(e.id, ANY), function () {
    verifyChecklists_idCardDoesNotExist(e.id);
  });
});

bthread("Prefs_orgInviteRestrict create verification", function () {
  const e = waitForAnyPrefs_orgInviteRestrictAdded();
  block(matchDeletePrefs_orgInviteRestrict(e.id, ANY), function () {
    verifyPrefs_orgInviteRestrictExists(e.id);
  });
});

bthread("Prefs_orgInviteRestrict update verification", function () {
  const e = waitForAnyPrefs_orgInviteRestrictUpdated();
  block(matchDeletePrefs_orgInviteRestrict(e.id, ANY), function () {
    verifyPrefs_orgInviteRestrictUpdated(e.id);
  });
});

bthread("Prefs_orgInviteRestrict delete verification", function () {
  const e = waitForAnyPrefs_orgInviteRestrictDeleted();
  block(matchAddPrefs_orgInviteRestrict(e.id, ANY), function () {
    verifyPrefs_orgInviteRestrictDoesNotExist(e.id);
  });
});

bthread("Prefs_voting create verification", function () {
  const e = waitForAnyPrefs_votingAdded();
  block(matchDeletePrefs_voting(e.id, ANY), function () {
    verifyPrefs_votingExists(e.id);
  });
});

bthread("Prefs_voting update verification", function () {
  const e = waitForAnyPrefs_votingUpdated();
  block(matchDeletePrefs_voting(e.id, ANY), function () {
    verifyPrefs_votingUpdated(e.id);
  });
});

bthread("Prefs_voting delete verification", function () {
  const e = waitForAnyPrefs_votingDeleted();
  block(matchAddPrefs_voting(e.id, ANY), function () {
    verifyPrefs_votingDoesNotExist(e.id);
  });
});

bthread("Organizations_logo create verification", function () {
  const e = waitForAnyOrganizations_logoAdded();
  block(matchDeleteOrganizations_logo(e.id, ANY), function () {
    verifyOrganizations_logoExists(e.id);
  });
});

bthread("Organizations_logo update verification", function () {
  const e = waitForAnyOrganizations_logoUpdated();
  block(matchDeleteOrganizations_logo(e.id, ANY), function () {
    verifyOrganizations_logoUpdated(e.id);
  });
});

bthread("Organizations_logo delete verification", function () {
  const e = waitForAnyOrganizations_logoDeleted();
  block(matchAddOrganizations_logo(e.id, ANY), function () {
    verifyOrganizations_logoDoesNotExist(e.id);
  });
});

bthread("MyPrefs_showSidebarActivity create verification", function () {
  const e = waitForAnyMyPrefs_showSidebarActivityAdded();
  block(matchDeleteMyPrefs_showSidebarActivity(e.id, ANY), function () {
    verifyMyPrefs_showSidebarActivityExists(e.id);
  });
});

bthread("MyPrefs_showSidebarActivity update verification", function () {
  const e = waitForAnyMyPrefs_showSidebarActivityUpdated();
  block(matchDeleteMyPrefs_showSidebarActivity(e.id, ANY), function () {
    verifyMyPrefs_showSidebarActivityUpdated(e.id);
  });
});

bthread("MyPrefs_showSidebarActivity delete verification", function () {
  const e = waitForAnyMyPrefs_showSidebarActivityDeleted();
  block(matchAddMyPrefs_showSidebarActivity(e.id, ANY), function () {
    verifyMyPrefs_showSidebarActivityDoesNotExist(e.id);
  });
});

bthread("Members_boardStars_idBoard create verification", function () {
  const e = waitForAnyMembers_boardStars_idBoardAdded();
  block(matchDeleteMembers_boardStars_idBoard(e.id, ANY), function () {
    verifyMembers_boardStars_idBoardExists(e.id);
  });
});

bthread("Members_boardStars_idBoard update verification", function () {
  const e = waitForAnyMembers_boardStars_idBoardUpdated();
  block(matchDeleteMembers_boardStars_idBoard(e.id, ANY), function () {
    verifyMembers_boardStars_idBoardUpdated(e.id);
  });
});

bthread("Members_boardStars_idBoard delete verification", function () {
  const e = waitForAnyMembers_boardStars_idBoardDeleted();
  block(matchAddMembers_boardStars_idBoard(e.id, ANY), function () {
    verifyMembers_boardStars_idBoardDoesNotExist(e.id);
  });
});

bthread("Actions_text create verification", function () {
  const e = waitForAnyActions_textAdded();
  block(matchDeleteActions_text(e.id, ANY), function () {
    verifyActions_textExists(e.id);
  });
});

bthread("Actions_text update verification", function () {
  const e = waitForAnyActions_textUpdated();
  block(matchDeleteActions_text(e.id, ANY), function () {
    verifyActions_textUpdated(e.id);
  });
});

bthread("Actions_text delete verification", function () {
  const e = waitForAnyActions_textDeleted();
  block(matchAddActions_text(e.id, ANY), function () {
    verifyActions_textDoesNotExist(e.id);
  });
});

bthread("Boards_powerUps create verification", function () {
  const e = waitForAnyBoards_powerUpsAdded();
  block(matchDeleteBoards_powerUps(e.id, ANY), function () {
    verifyBoards_powerUpsExists(e.id);
  });
});

bthread("Boards_powerUps update verification", function () {
  const e = waitForAnyBoards_powerUpsUpdated();
  block(matchDeleteBoards_powerUps(e.id, ANY), function () {
    verifyBoards_powerUpsUpdated(e.id);
  });
});

bthread("Boards_powerUps delete verification", function () {
  const e = waitForAnyBoards_powerUpsDeleted();
  block(matchAddBoards_powerUps(e.id, ANY), function () {
    verifyBoards_powerUpsDoesNotExist(e.id);
  });
});

bthread("Members_bio create verification", function () {
  const e = waitForAnyMembers_bioAdded();
  block(matchDeleteMembers_bio(e.id, ANY), function () {
    verifyMembers_bioExists(e.id);
  });
});

bthread("Members_bio update verification", function () {
  const e = waitForAnyMembers_bioUpdated();
  block(matchDeleteMembers_bio(e.id, ANY), function () {
    verifyMembers_bioUpdated(e.id);
  });
});

bthread("Members_bio delete verification", function () {
  const e = waitForAnyMembers_bioDeleted();
  block(matchAddMembers_bio(e.id, ANY), function () {
    verifyMembers_bioDoesNotExist(e.id);
  });
});

bthread("Members_customBoardBackgrounds create verification", function () {
  const e = waitForAnyMembers_customBoardBackgroundsAdded();
  block(matchDeleteMembers_customBoardBackgrounds(e.id, ANY), function () {
    verifyMembers_customBoardBackgroundsExists(e.id);
  });
});

bthread("Members_customBoardBackgrounds update verification", function () {
  const e = waitForAnyMembers_customBoardBackgroundsUpdated();
  block(matchDeleteMembers_customBoardBackgrounds(e.id, ANY), function () {
    verifyMembers_customBoardBackgroundsUpdated(e.id);
  });
});

bthread("Members_customBoardBackgrounds delete verification", function () {
  const e = waitForAnyMembers_customBoardBackgroundsDeleted();
  block(matchAddMembers_customBoardBackgrounds(e.id, ANY), function () {
    verifyMembers_customBoardBackgroundsDoesNotExist(e.id);
  });
});

bthread("Members_boardStars_pos create verification", function () {
  const e = waitForAnyMembers_boardStars_posAdded();
  block(matchDeleteMembers_boardStars_pos(e.id, ANY), function () {
    verifyMembers_boardStars_posExists(e.id);
  });
});

bthread("Members_boardStars_pos update verification", function () {
  const e = waitForAnyMembers_boardStars_posUpdated();
  block(matchDeleteMembers_boardStars_pos(e.id, ANY), function () {
    verifyMembers_boardStars_posUpdated(e.id);
  });
});

bthread("Members_boardStars_pos delete verification", function () {
  const e = waitForAnyMembers_boardStars_posDeleted();
  block(matchAddMembers_boardStars_pos(e.id, ANY), function () {
    verifyMembers_boardStars_posDoesNotExist(e.id);
  });
});

bthread("Sessions_status create verification", function () {
  const e = waitForAnySessions_statusAdded();
  block(matchDeleteSessions_status(e.id, ANY), function () {
    verifySessions_statusExists(e.id);
  });
});

bthread("Sessions_status update verification", function () {
  const e = waitForAnySessions_statusUpdated();
  block(matchDeleteSessions_status(e.id, ANY), function () {
    verifySessions_statusUpdated(e.id);
  });
});

bthread("Sessions_status delete verification", function () {
  const e = waitForAnySessions_statusDeleted();
  block(matchAddSessions_status(e.id, ANY), function () {
    verifySessions_statusDoesNotExist(e.id);
  });
});

bthread("LabelNames_orange create verification", function () {
  const e = waitForAnyLabelNames_orangeAdded();
  block(matchDeleteLabelNames_orange(e.id, ANY), function () {
    verifyLabelNames_orangeExists(e.id);
  });
});

bthread("LabelNames_orange update verification", function () {
  const e = waitForAnyLabelNames_orangeUpdated();
  block(matchDeleteLabelNames_orange(e.id, ANY), function () {
    verifyLabelNames_orangeUpdated(e.id);
  });
});

bthread("LabelNames_orange delete verification", function () {
  const e = waitForAnyLabelNames_orangeDeleted();
  block(matchAddLabelNames_orange(e.id, ANY), function () {
    verifyLabelNames_orangeDoesNotExist(e.id);
  });
});

bthread("Webhooks create verification", function () {
  const e = waitForAnyWebhooksAdded();
  block(matchDeleteWebhooks(e.id, ANY), function () {
    verifyWebhooksExists(e.id);
  });
});

bthread("Webhooks update verification", function () {
  const e = waitForAnyWebhooksUpdated();
  block(matchDeleteWebhooks(e.id, ANY), function () {
    verifyWebhooksUpdated(e.id);
  });
});

bthread("Webhooks delete verification", function () {
  const e = waitForAnyWebhooksDeleted();
  block(matchAddWebhooks(e.id, ANY), function () {
    verifyWebhooksDoesNotExist(e.id);
  });
});

bthread("Organizations_members create verification", function () {
  const e = waitForAnyOrganizations_membersAdded();
  block(matchDeleteOrganizations_members(e.id, ANY), function () {
    verifyOrganizations_membersExists(e.id);
  });
});

bthread("Organizations_members update verification", function () {
  const e = waitForAnyOrganizations_membersUpdated();
  block(matchDeleteOrganizations_members(e.id, ANY), function () {
    verifyOrganizations_membersUpdated(e.id);
  });
});

bthread("Organizations_members delete verification", function () {
  const e = waitForAnyOrganizations_membersDeleted();
  block(matchAddOrganizations_members(e.id, ANY), function () {
    verifyOrganizations_membersDoesNotExist(e.id);
  });
});

bthread("Checklists_name create verification", function () {
  const e = waitForAnyChecklists_nameAdded();
  block(matchDeleteChecklists_name(e.id, ANY), function () {
    verifyChecklists_nameExists(e.id);
  });
});

bthread("Checklists_name update verification", function () {
  const e = waitForAnyChecklists_nameUpdated();
  block(matchDeleteChecklists_name(e.id, ANY), function () {
    verifyChecklists_nameUpdated(e.id);
  });
});

bthread("Checklists_name delete verification", function () {
  const e = waitForAnyChecklists_nameDeleted();
  block(matchAddChecklists_name(e.id, ANY), function () {
    verifyChecklists_nameDoesNotExist(e.id);
  });
});

bthread("Cards_closed create verification", function () {
  const e = waitForAnyCards_closedAdded();
  block(matchDeleteCards_closed(e.id, ANY), function () {
    verifyCards_closedExists(e.id);
  });
});

bthread("Cards_closed update verification", function () {
  const e = waitForAnyCards_closedUpdated();
  block(matchDeleteCards_closed(e.id, ANY), function () {
    verifyCards_closedUpdated(e.id);
  });
});

bthread("Cards_closed delete verification", function () {
  const e = waitForAnyCards_closedDeleted();
  block(matchAddCards_closed(e.id, ANY), function () {
    verifyCards_closedDoesNotExist(e.id);
  });
});

bthread("Organizations_members_deactivated create verification", function () {
  const e = waitForAnyOrganizations_members_deactivatedAdded();
  block(matchDeleteOrganizations_members_deactivated(e.id, ANY), function () {
    verifyOrganizations_members_deactivatedExists(e.id);
  });
});

bthread("Organizations_members_deactivated update verification", function () {
  const e = waitForAnyOrganizations_members_deactivatedUpdated();
  block(matchDeleteOrganizations_members_deactivated(e.id, ANY), function () {
    verifyOrganizations_members_deactivatedUpdated(e.id);
  });
});

bthread("Organizations_members_deactivated delete verification", function () {
  const e = waitForAnyOrganizations_members_deactivatedDeleted();
  block(matchAddOrganizations_members_deactivated(e.id, ANY), function () {
    verifyOrganizations_members_deactivatedDoesNotExist(e.id);
  });
});

bthread("Cards_actions_comments create verification", function () {
  const e = waitForAnyCards_actions_commentsAdded();
  block(matchDeleteCards_actions_comments(e.id, ANY), function () {
    verifyCards_actions_commentsExists(e.id);
  });
});

bthread("Cards_actions_comments update verification", function () {
  const e = waitForAnyCards_actions_commentsUpdated();
  block(matchDeleteCards_actions_comments(e.id, ANY), function () {
    verifyCards_actions_commentsUpdated(e.id);
  });
});

bthread("Cards_actions_comments delete verification", function () {
  const e = waitForAnyCards_actions_commentsDeleted();
  block(matchAddCards_actions_comments(e.id, ANY), function () {
    verifyCards_actions_commentsDoesNotExist(e.id);
  });
});

bthread("Cards_checklist_checkItem create verification", function () {
  const e = waitForAnyCards_checklist_checkItemAdded();
  block(matchDeleteCards_checklist_checkItem(e.id, ANY), function () {
    verifyCards_checklist_checkItemExists(e.id);
  });
});

bthread("Cards_checklist_checkItem update verification", function () {
  const e = waitForAnyCards_checklist_checkItemUpdated();
  block(matchDeleteCards_checklist_checkItem(e.id, ANY), function () {
    verifyCards_checklist_checkItemUpdated(e.id);
  });
});

bthread("Cards_checklist_checkItem delete verification", function () {
  const e = waitForAnyCards_checklist_checkItemDeleted();
  block(matchAddCards_checklist_checkItem(e.id, ANY), function () {
    verifyCards_checklist_checkItemDoesNotExist(e.id);
  });
});

bthread("Organizations_website create verification", function () {
  const e = waitForAnyOrganizations_websiteAdded();
  block(matchDeleteOrganizations_website(e.id, ANY), function () {
    verifyOrganizations_websiteExists(e.id);
  });
});

bthread("Organizations_website update verification", function () {
  const e = waitForAnyOrganizations_websiteUpdated();
  block(matchDeleteOrganizations_website(e.id, ANY), function () {
    verifyOrganizations_websiteUpdated(e.id);
  });
});

bthread("Organizations_website delete verification", function () {
  const e = waitForAnyOrganizations_websiteDeleted();
  block(matchAddOrganizations_website(e.id, ANY), function () {
    verifyOrganizations_websiteDoesNotExist(e.id);
  });
});

bthread("Cards create verification", function () {
  const e = waitForAnyCardsAdded();
  block(matchDeleteCards(e.id, ANY), function () {
    verifyCardsExists(e.id);
  });
});

bthread("Cards update verification", function () {
  const e = waitForAnyCardsUpdated();
  block(matchDeleteCards(e.id, ANY), function () {
    verifyCardsUpdated(e.id);
  });
});

bthread("Cards delete verification", function () {
  const e = waitForAnyCardsDeleted();
  block(matchAddCards(e.id, ANY), function () {
    verifyCardsDoesNotExist(e.id);
  });
});

bthread("Lists_idBoard create verification", function () {
  const e = waitForAnyLists_idBoardAdded();
  block(matchDeleteLists_idBoard(e.id, ANY), function () {
    verifyLists_idBoardExists(e.id);
  });
});

bthread("Lists_idBoard update verification", function () {
  const e = waitForAnyLists_idBoardUpdated();
  block(matchDeleteLists_idBoard(e.id, ANY), function () {
    verifyLists_idBoardUpdated(e.id);
  });
});

bthread("Lists_idBoard delete verification", function () {
  const e = waitForAnyLists_idBoardDeleted();
  block(matchAddLists_idBoard(e.id, ANY), function () {
    verifyLists_idBoardDoesNotExist(e.id);
  });
});

bthread("MyPrefs_showSidebarMembers create verification", function () {
  const e = waitForAnyMyPrefs_showSidebarMembersAdded();
  block(matchDeleteMyPrefs_showSidebarMembers(e.id, ANY), function () {
    verifyMyPrefs_showSidebarMembersExists(e.id);
  });
});

bthread("MyPrefs_showSidebarMembers update verification", function () {
  const e = waitForAnyMyPrefs_showSidebarMembersUpdated();
  block(matchDeleteMyPrefs_showSidebarMembers(e.id, ANY), function () {
    verifyMyPrefs_showSidebarMembersUpdated(e.id);
  });
});

bthread("MyPrefs_showSidebarMembers delete verification", function () {
  const e = waitForAnyMyPrefs_showSidebarMembersDeleted();
  block(matchAddMyPrefs_showSidebarMembers(e.id, ANY), function () {
    verifyMyPrefs_showSidebarMembersDoesNotExist(e.id);
  });
});

bthread("Checklists_checkItems create verification", function () {
  const e = waitForAnyChecklists_checkItemsAdded();
  block(matchDeleteChecklists_checkItems(e.id, ANY), function () {
    verifyChecklists_checkItemsExists(e.id);
  });
});

bthread("Checklists_checkItems update verification", function () {
  const e = waitForAnyChecklists_checkItemsUpdated();
  block(matchDeleteChecklists_checkItems(e.id, ANY), function () {
    verifyChecklists_checkItemsUpdated(e.id);
  });
});

bthread("Checklists_checkItems delete verification", function () {
  const e = waitForAnyChecklists_checkItemsDeleted();
  block(matchAddChecklists_checkItems(e.id, ANY), function () {
    verifyChecklists_checkItemsDoesNotExist(e.id);
  });
});

bthread("Prefs_associatedDomain create verification", function () {
  const e = waitForAnyPrefs_associatedDomainAdded();
  block(matchDeletePrefs_associatedDomain(e.id, ANY), function () {
    verifyPrefs_associatedDomainExists(e.id);
  });
});

bthread("Prefs_associatedDomain update verification", function () {
  const e = waitForAnyPrefs_associatedDomainUpdated();
  block(matchDeletePrefs_associatedDomain(e.id, ANY), function () {
    verifyPrefs_associatedDomainUpdated(e.id);
  });
});

bthread("Prefs_associatedDomain delete verification", function () {
  const e = waitForAnyPrefs_associatedDomainDeleted();
  block(matchAddPrefs_associatedDomain(e.id, ANY), function () {
    verifyPrefs_associatedDomainDoesNotExist(e.id);
  });
});

bthread("Cards_labels create verification", function () {
  const e = waitForAnyCards_labelsAdded();
  block(matchDeleteCards_labels(e.id, ANY), function () {
    verifyCards_labelsExists(e.id);
  });
});

bthread("Cards_labels update verification", function () {
  const e = waitForAnyCards_labelsUpdated();
  block(matchDeleteCards_labels(e.id, ANY), function () {
    verifyCards_labelsUpdated(e.id);
  });
});

bthread("Cards_labels delete verification", function () {
  const e = waitForAnyCards_labelsDeleted();
  block(matchAddCards_labels(e.id, ANY), function () {
    verifyCards_labelsDoesNotExist(e.id);
  });
});

bthread("Lists_cards create verification", function () {
  const e = waitForAnyLists_cardsAdded();
  block(matchDeleteLists_cards(e.id, ANY), function () {
    verifyLists_cardsExists(e.id);
  });
});

bthread("Lists_cards update verification", function () {
  const e = waitForAnyLists_cardsUpdated();
  block(matchDeleteLists_cards(e.id, ANY), function () {
    verifyLists_cardsUpdated(e.id);
  });
});

bthread("Lists_cards delete verification", function () {
  const e = waitForAnyLists_cardsDeleted();
  block(matchAddLists_cards(e.id, ANY), function () {
    verifyLists_cardsDoesNotExist(e.id);
  });
});

bthread("MyPrefs_showSidebar create verification", function () {
  const e = waitForAnyMyPrefs_showSidebarAdded();
  block(matchDeleteMyPrefs_showSidebar(e.id, ANY), function () {
    verifyMyPrefs_showSidebarExists(e.id);
  });
});

bthread("MyPrefs_showSidebar update verification", function () {
  const e = waitForAnyMyPrefs_showSidebarUpdated();
  block(matchDeleteMyPrefs_showSidebar(e.id, ANY), function () {
    verifyMyPrefs_showSidebarUpdated(e.id);
  });
});

bthread("MyPrefs_showSidebar delete verification", function () {
  const e = waitForAnyMyPrefs_showSidebarDeleted();
  block(matchAddMyPrefs_showSidebar(e.id, ANY), function () {
    verifyMyPrefs_showSidebarDoesNotExist(e.id);
  });
});

bthread("Members create verification", function () {
  const e = waitForAnyMembersAdded();
  block(matchDeleteMembers(e.id, ANY), function () {
    verifyMembersExists(e.id);
  });
});

bthread("Members update verification", function () {
  const e = waitForAnyMembersUpdated();
  block(matchDeleteMembers(e.id, ANY), function () {
    verifyMembersUpdated(e.id);
  });
});

bthread("Members delete verification", function () {
  const e = waitForAnyMembersDeleted();
  block(matchAddMembers(e.id, ANY), function () {
    verifyMembersDoesNotExist(e.id);
  });
});

bthread("Prefs_invitations create verification", function () {
  const e = waitForAnyPrefs_invitationsAdded();
  block(matchDeletePrefs_invitations(e.id, ANY), function () {
    verifyPrefs_invitationsExists(e.id);
  });
});

bthread("Prefs_invitations update verification", function () {
  const e = waitForAnyPrefs_invitationsUpdated();
  block(matchDeletePrefs_invitations(e.id, ANY), function () {
    verifyPrefs_invitationsUpdated(e.id);
  });
});

bthread("Prefs_invitations delete verification", function () {
  const e = waitForAnyPrefs_invitationsDeleted();
  block(matchAddPrefs_invitations(e.id, ANY), function () {
    verifyPrefs_invitationsDoesNotExist(e.id);
  });
});

bthread("Cards_idMembers create verification", function () {
  const e = waitForAnyCards_idMembersAdded();
  block(matchDeleteCards_idMembers(e.id, ANY), function () {
    verifyCards_idMembersExists(e.id);
  });
});

bthread("Cards_idMembers update verification", function () {
  const e = waitForAnyCards_idMembersUpdated();
  block(matchDeleteCards_idMembers(e.id, ANY), function () {
    verifyCards_idMembersUpdated(e.id);
  });
});

bthread("Cards_idMembers delete verification", function () {
  const e = waitForAnyCards_idMembersDeleted();
  block(matchAddCards_idMembers(e.id, ANY), function () {
    verifyCards_idMembersDoesNotExist(e.id);
  });
});

bthread("Members_initials create verification", function () {
  const e = waitForAnyMembers_initialsAdded();
  block(matchDeleteMembers_initials(e.id, ANY), function () {
    verifyMembers_initialsExists(e.id);
  });
});

bthread("Members_initials update verification", function () {
  const e = waitForAnyMembers_initialsUpdated();
  block(matchDeleteMembers_initials(e.id, ANY), function () {
    verifyMembers_initialsUpdated(e.id);
  });
});

bthread("Members_initials delete verification", function () {
  const e = waitForAnyMembers_initialsDeleted();
  block(matchAddMembers_initials(e.id, ANY), function () {
    verifyMembers_initialsDoesNotExist(e.id);
  });
});

bthread("Cards_checklist_checkItem_pos create verification", function () {
  const e = waitForAnyCards_checklist_checkItem_posAdded();
  block(matchDeleteCards_checklist_checkItem_pos(e.id, ANY), function () {
    verifyCards_checklist_checkItem_posExists(e.id);
  });
});

bthread("Cards_checklist_checkItem_pos update verification", function () {
  const e = waitForAnyCards_checklist_checkItem_posUpdated();
  block(matchDeleteCards_checklist_checkItem_pos(e.id, ANY), function () {
    verifyCards_checklist_checkItem_posUpdated(e.id);
  });
});

bthread("Cards_checklist_checkItem_pos delete verification", function () {
  const e = waitForAnyCards_checklist_checkItem_posDeleted();
  block(matchAddCards_checklist_checkItem_pos(e.id, ANY), function () {
    verifyCards_checklist_checkItem_posDoesNotExist(e.id);
  });
});

bthread("Prefs_comments create verification", function () {
  const e = waitForAnyPrefs_commentsAdded();
  block(matchDeletePrefs_comments(e.id, ANY), function () {
    verifyPrefs_commentsExists(e.id);
  });
});

bthread("Prefs_comments update verification", function () {
  const e = waitForAnyPrefs_commentsUpdated();
  block(matchDeletePrefs_comments(e.id, ANY), function () {
    verifyPrefs_commentsUpdated(e.id);
  });
});

bthread("Prefs_comments delete verification", function () {
  const e = waitForAnyPrefs_commentsDeleted();
  block(matchAddPrefs_comments(e.id, ANY), function () {
    verifyPrefs_commentsDoesNotExist(e.id);
  });
});

bthread("Prefs_selfJoin create verification", function () {
  const e = waitForAnyPrefs_selfJoinAdded();
  block(matchDeletePrefs_selfJoin(e.id, ANY), function () {
    verifyPrefs_selfJoinExists(e.id);
  });
});

bthread("Prefs_selfJoin update verification", function () {
  const e = waitForAnyPrefs_selfJoinUpdated();
  block(matchDeletePrefs_selfJoin(e.id, ANY), function () {
    verifyPrefs_selfJoinUpdated(e.id);
  });
});

bthread("Prefs_selfJoin delete verification", function () {
  const e = waitForAnyPrefs_selfJoinDeleted();
  block(matchAddPrefs_selfJoin(e.id, ANY), function () {
    verifyPrefs_selfJoinDoesNotExist(e.id);
  });
});

bthread("Prefs_cardCovers create verification", function () {
  const e = waitForAnyPrefs_cardCoversAdded();
  block(matchDeletePrefs_cardCovers(e.id, ANY), function () {
    verifyPrefs_cardCoversExists(e.id);
  });
});

bthread("Prefs_cardCovers update verification", function () {
  const e = waitForAnyPrefs_cardCoversUpdated();
  block(matchDeletePrefs_cardCovers(e.id, ANY), function () {
    verifyPrefs_cardCoversUpdated(e.id);
  });
});

bthread("Prefs_cardCovers delete verification", function () {
  const e = waitForAnyPrefs_cardCoversDeleted();
  block(matchAddPrefs_cardCovers(e.id, ANY), function () {
    verifyPrefs_cardCoversDoesNotExist(e.id);
  });
});

bthread("Actions create verification", function () {
  const e = waitForAnyActionsAdded();
  block(matchDeleteActions(e.id, ANY), function () {
    verifyActionsExists(e.id);
  });
});

bthread("Actions update verification", function () {
  const e = waitForAnyActionsUpdated();
  block(matchDeleteActions(e.id, ANY), function () {
    verifyActionsUpdated(e.id);
  });
});

bthread("Actions delete verification", function () {
  const e = waitForAnyActionsDeleted();
  block(matchAddActions(e.id, ANY), function () {
    verifyActionsDoesNotExist(e.id);
  });
});

bthread("Organizations_name create verification", function () {
  const e = waitForAnyOrganizations_nameAdded();
  block(matchDeleteOrganizations_name(e.id, ANY), function () {
    verifyOrganizations_nameExists(e.id);
  });
});

bthread("Organizations_name update verification", function () {
  const e = waitForAnyOrganizations_nameUpdated();
  block(matchDeleteOrganizations_name(e.id, ANY), function () {
    verifyOrganizations_nameUpdated(e.id);
  });
});

bthread("Organizations_name delete verification", function () {
  const e = waitForAnyOrganizations_nameDeleted();
  block(matchAddOrganizations_name(e.id, ANY), function () {
    verifyOrganizations_nameDoesNotExist(e.id);
  });
});

bthread("Checklists create verification", function () {
  const e = waitForAnyChecklistsAdded();
  block(matchDeleteChecklists(e.id, ANY), function () {
    verifyChecklistsExists(e.id);
  });
});

bthread("Checklists update verification", function () {
  const e = waitForAnyChecklistsUpdated();
  block(matchDeleteChecklists(e.id, ANY), function () {
    verifyChecklistsUpdated(e.id);
  });
});

bthread("Checklists delete verification", function () {
  const e = waitForAnyChecklistsDeleted();
  block(matchAddChecklists(e.id, ANY), function () {
    verifyChecklistsDoesNotExist(e.id);
  });
});

bthread("LabelNames_red create verification", function () {
  const e = waitForAnyLabelNames_redAdded();
  block(matchDeleteLabelNames_red(e.id, ANY), function () {
    verifyLabelNames_redExists(e.id);
  });
});

bthread("LabelNames_red update verification", function () {
  const e = waitForAnyLabelNames_redUpdated();
  block(matchDeleteLabelNames_red(e.id, ANY), function () {
    verifyLabelNames_redUpdated(e.id);
  });
});

bthread("LabelNames_red delete verification", function () {
  const e = waitForAnyLabelNames_redDeleted();
  block(matchAddLabelNames_red(e.id, ANY), function () {
    verifyLabelNames_redDoesNotExist(e.id);
  });
});

bthread("Webhooks_callbackURL create verification", function () {
  const e = waitForAnyWebhooks_callbackURLAdded();
  block(matchDeleteWebhooks_callbackURL(e.id, ANY), function () {
    verifyWebhooks_callbackURLExists(e.id);
  });
});

bthread("Webhooks_callbackURL update verification", function () {
  const e = waitForAnyWebhooks_callbackURLUpdated();
  block(matchDeleteWebhooks_callbackURL(e.id, ANY), function () {
    verifyWebhooks_callbackURLUpdated(e.id);
  });
});

bthread("Webhooks_callbackURL delete verification", function () {
  const e = waitForAnyWebhooks_callbackURLDeleted();
  block(matchAddWebhooks_callbackURL(e.id, ANY), function () {
    verifyWebhooks_callbackURLDoesNotExist(e.id);
  });
});

bthread("Members_savedSearches_pos create verification", function () {
  const e = waitForAnyMembers_savedSearches_posAdded();
  block(matchDeleteMembers_savedSearches_pos(e.id, ANY), function () {
    verifyMembers_savedSearches_posExists(e.id);
  });
});

bthread("Members_savedSearches_pos update verification", function () {
  const e = waitForAnyMembers_savedSearches_posUpdated();
  block(matchDeleteMembers_savedSearches_pos(e.id, ANY), function () {
    verifyMembers_savedSearches_posUpdated(e.id);
  });
});

bthread("Members_savedSearches_pos delete verification", function () {
  const e = waitForAnyMembers_savedSearches_posDeleted();
  block(matchAddMembers_savedSearches_pos(e.id, ANY), function () {
    verifyMembers_savedSearches_posDoesNotExist(e.id);
  });
});

bthread("Prefs_permissionLevel create verification", function () {
  const e = waitForAnyPrefs_permissionLevelAdded();
  block(matchDeletePrefs_permissionLevel(e.id, ANY), function () {
    verifyPrefs_permissionLevelExists(e.id);
  });
});

bthread("Prefs_permissionLevel update verification", function () {
  const e = waitForAnyPrefs_permissionLevelUpdated();
  block(matchDeletePrefs_permissionLevel(e.id, ANY), function () {
    verifyPrefs_permissionLevelUpdated(e.id);
  });
});

bthread("Prefs_permissionLevel delete verification", function () {
  const e = waitForAnyPrefs_permissionLevelDeleted();
  block(matchAddPrefs_permissionLevel(e.id, ANY), function () {
    verifyPrefs_permissionLevelDoesNotExist(e.id);
  });
});

bthread("Cards_idLabels create verification", function () {
  const e = waitForAnyCards_idLabelsAdded();
  block(matchDeleteCards_idLabels(e.id, ANY), function () {
    verifyCards_idLabelsExists(e.id);
  });
});

bthread("Cards_idLabels update verification", function () {
  const e = waitForAnyCards_idLabelsUpdated();
  block(matchDeleteCards_idLabels(e.id, ANY), function () {
    verifyCards_idLabelsUpdated(e.id);
  });
});

bthread("Cards_idLabels delete verification", function () {
  const e = waitForAnyCards_idLabelsDeleted();
  block(matchAddCards_idLabels(e.id, ANY), function () {
    verifyCards_idLabelsDoesNotExist(e.id);
  });
});

bthread("Cards_due create verification", function () {
  const e = waitForAnyCards_dueAdded();
  block(matchDeleteCards_due(e.id, ANY), function () {
    verifyCards_dueExists(e.id);
  });
});

bthread("Cards_due update verification", function () {
  const e = waitForAnyCards_dueUpdated();
  block(matchDeleteCards_due(e.id, ANY), function () {
    verifyCards_dueUpdated(e.id);
  });
});

bthread("Cards_due delete verification", function () {
  const e = waitForAnyCards_dueDeleted();
  block(matchAddCards_due(e.id, ANY), function () {
    verifyCards_dueDoesNotExist(e.id);
  });
});

bthread("Prefs_calendarFeedEnabled create verification", function () {
  const e = waitForAnyPrefs_calendarFeedEnabledAdded();
  block(matchDeletePrefs_calendarFeedEnabled(e.id, ANY), function () {
    verifyPrefs_calendarFeedEnabledExists(e.id);
  });
});

bthread("Prefs_calendarFeedEnabled update verification", function () {
  const e = waitForAnyPrefs_calendarFeedEnabledUpdated();
  block(matchDeletePrefs_calendarFeedEnabled(e.id, ANY), function () {
    verifyPrefs_calendarFeedEnabledUpdated(e.id);
  });
});

bthread("Prefs_calendarFeedEnabled delete verification", function () {
  const e = waitForAnyPrefs_calendarFeedEnabledDeleted();
  block(matchAddPrefs_calendarFeedEnabled(e.id, ANY), function () {
    verifyPrefs_calendarFeedEnabledDoesNotExist(e.id);
  });
});

bthread("Lists create verification", function () {
  const e = waitForAnyListsAdded();
  block(matchDeleteLists(e.id, ANY), function () {
    verifyListsExists(e.id);
  });
});

bthread("Lists update verification", function () {
  const e = waitForAnyListsUpdated();
  block(matchDeleteLists(e.id, ANY), function () {
    verifyListsUpdated(e.id);
  });
});

bthread("Lists delete verification", function () {
  const e = waitForAnyListsDeleted();
  block(matchAddLists(e.id, ANY), function () {
    verifyListsDoesNotExist(e.id);
  });
});

bthread("Lists_moveAllCards create verification", function () {
  const e = waitForAnyLists_moveAllCardsAdded();
  block(matchDeleteLists_moveAllCards(e.id, ANY), function () {
    verifyLists_moveAllCardsExists(e.id);
  });
});

bthread("Lists_moveAllCards update verification", function () {
  const e = waitForAnyLists_moveAllCardsUpdated();
  block(matchDeleteLists_moveAllCards(e.id, ANY), function () {
    verifyLists_moveAllCardsUpdated(e.id);
  });
});

bthread("Lists_moveAllCards delete verification", function () {
  const e = waitForAnyLists_moveAllCardsDeleted();
  block(matchAddLists_moveAllCards(e.id, ANY), function () {
    verifyLists_moveAllCardsDoesNotExist(e.id);
  });
});

bthread("Labels_color create verification", function () {
  const e = waitForAnyLabels_colorAdded();
  block(matchDeleteLabels_color(e.id, ANY), function () {
    verifyLabels_colorExists(e.id);
  });
});

bthread("Labels_color update verification", function () {
  const e = waitForAnyLabels_colorUpdated();
  block(matchDeleteLabels_color(e.id, ANY), function () {
    verifyLabels_colorUpdated(e.id);
  });
});

bthread("Labels_color delete verification", function () {
  const e = waitForAnyLabels_colorDeleted();
  block(matchAddLabels_color(e.id, ANY), function () {
    verifyLabels_colorDoesNotExist(e.id);
  });
});

bthread("MyPrefs_showListGuide create verification", function () {
  const e = waitForAnyMyPrefs_showListGuideAdded();
  block(matchDeleteMyPrefs_showListGuide(e.id, ANY), function () {
    verifyMyPrefs_showListGuideExists(e.id);
  });
});

bthread("MyPrefs_showListGuide update verification", function () {
  const e = waitForAnyMyPrefs_showListGuideUpdated();
  block(matchDeleteMyPrefs_showListGuide(e.id, ANY), function () {
    verifyMyPrefs_showListGuideUpdated(e.id);
  });
});

bthread("MyPrefs_showListGuide delete verification", function () {
  const e = waitForAnyMyPrefs_showListGuideDeleted();
  block(matchAddMyPrefs_showListGuide(e.id, ANY), function () {
    verifyMyPrefs_showListGuideDoesNotExist(e.id);
  });
});

bthread("Boards_name create verification", function () {
  const e = waitForAnyBoards_nameAdded();
  block(matchDeleteBoards_name(e.id, ANY), function () {
    verifyBoards_nameExists(e.id);
  });
});

bthread("Boards_name update verification", function () {
  const e = waitForAnyBoards_nameUpdated();
  block(matchDeleteBoards_name(e.id, ANY), function () {
    verifyBoards_nameUpdated(e.id);
  });
});

bthread("Boards_name delete verification", function () {
  const e = waitForAnyBoards_nameDeleted();
  block(matchAddBoards_name(e.id, ANY), function () {
    verifyBoards_nameDoesNotExist(e.id);
  });
});

bthread("Members_fullName create verification", function () {
  const e = waitForAnyMembers_fullNameAdded();
  block(matchDeleteMembers_fullName(e.id, ANY), function () {
    verifyMembers_fullNameExists(e.id);
  });
});

bthread("Members_fullName update verification", function () {
  const e = waitForAnyMembers_fullNameUpdated();
  block(matchDeleteMembers_fullName(e.id, ANY), function () {
    verifyMembers_fullNameUpdated(e.id);
  });
});

bthread("Members_fullName delete verification", function () {
  const e = waitForAnyMembers_fullNameDeleted();
  block(matchAddMembers_fullName(e.id, ANY), function () {
    verifyMembers_fullNameDoesNotExist(e.id);
  });
});

bthread("Prefs_googleAppsVersion create verification", function () {
  const e = waitForAnyPrefs_googleAppsVersionAdded();
  block(matchDeletePrefs_googleAppsVersion(e.id, ANY), function () {
    verifyPrefs_googleAppsVersionExists(e.id);
  });
});

bthread("Prefs_googleAppsVersion update verification", function () {
  const e = waitForAnyPrefs_googleAppsVersionUpdated();
  block(matchDeletePrefs_googleAppsVersion(e.id, ANY), function () {
    verifyPrefs_googleAppsVersionUpdated(e.id);
  });
});

bthread("Prefs_googleAppsVersion delete verification", function () {
  const e = waitForAnyPrefs_googleAppsVersionDeleted();
  block(matchAddPrefs_googleAppsVersion(e.id, ANY), function () {
    verifyPrefs_googleAppsVersionDoesNotExist(e.id);
  });
});

bthread("Cards_idAttachmentCover create verification", function () {
  const e = waitForAnyCards_idAttachmentCoverAdded();
  block(matchDeleteCards_idAttachmentCover(e.id, ANY), function () {
    verifyCards_idAttachmentCoverExists(e.id);
  });
});

bthread("Cards_idAttachmentCover update verification", function () {
  const e = waitForAnyCards_idAttachmentCoverUpdated();
  block(matchDeleteCards_idAttachmentCover(e.id, ANY), function () {
    verifyCards_idAttachmentCoverUpdated(e.id);
  });
});

bthread("Cards_idAttachmentCover delete verification", function () {
  const e = waitForAnyCards_idAttachmentCoverDeleted();
  block(matchAddCards_idAttachmentCover(e.id, ANY), function () {
    verifyCards_idAttachmentCoverDoesNotExist(e.id);
  });
});

bthread("Cards_desc create verification", function () {
  const e = waitForAnyCards_descAdded();
  block(matchDeleteCards_desc(e.id, ANY), function () {
    verifyCards_descExists(e.id);
  });
});

bthread("Cards_desc update verification", function () {
  const e = waitForAnyCards_descUpdated();
  block(matchDeleteCards_desc(e.id, ANY), function () {
    verifyCards_descUpdated(e.id);
  });
});

bthread("Cards_desc delete verification", function () {
  const e = waitForAnyCards_descDeleted();
  block(matchAddCards_desc(e.id, ANY), function () {
    verifyCards_descDoesNotExist(e.id);
  });
});

bthread("MyPrefs_emailPosition create verification", function () {
  const e = waitForAnyMyPrefs_emailPositionAdded();
  block(matchDeleteMyPrefs_emailPosition(e.id, ANY), function () {
    verifyMyPrefs_emailPositionExists(e.id);
  });
});

bthread("MyPrefs_emailPosition update verification", function () {
  const e = waitForAnyMyPrefs_emailPositionUpdated();
  block(matchDeleteMyPrefs_emailPosition(e.id, ANY), function () {
    verifyMyPrefs_emailPositionUpdated(e.id);
  });
});

bthread("MyPrefs_emailPosition delete verification", function () {
  const e = waitForAnyMyPrefs_emailPositionDeleted();
  block(matchAddMyPrefs_emailPosition(e.id, ANY), function () {
    verifyMyPrefs_emailPositionDoesNotExist(e.id);
  });
});

bthread("Cards_checklist_checkItem_state create verification", function () {
  const e = waitForAnyCards_checklist_checkItem_stateAdded();
  block(matchDeleteCards_checklist_checkItem_state(e.id, ANY), function () {
    verifyCards_checklist_checkItem_stateExists(e.id);
  });
});

bthread("Cards_checklist_checkItem_state update verification", function () {
  const e = waitForAnyCards_checklist_checkItem_stateUpdated();
  block(matchDeleteCards_checklist_checkItem_state(e.id, ANY), function () {
    verifyCards_checklist_checkItem_stateUpdated(e.id);
  });
});

bthread("Cards_checklist_checkItem_state delete verification", function () {
  const e = waitForAnyCards_checklist_checkItem_stateDeleted();
  block(matchAddCards_checklist_checkItem_state(e.id, ANY), function () {
    verifyCards_checklist_checkItem_stateDoesNotExist(e.id);
  });
});

bthread("Cards_idList create verification", function () {
  const e = waitForAnyCards_idListAdded();
  block(matchDeleteCards_idList(e.id, ANY), function () {
    verifyCards_idListExists(e.id);
  });
});

bthread("Cards_idList update verification", function () {
  const e = waitForAnyCards_idListUpdated();
  block(matchDeleteCards_idList(e.id, ANY), function () {
    verifyCards_idListUpdated(e.id);
  });
});

bthread("Cards_idList delete verification", function () {
  const e = waitForAnyCards_idListDeleted();
  block(matchAddCards_idList(e.id, ANY), function () {
    verifyCards_idListDoesNotExist(e.id);
  });
});

bthread("Boards_lists create verification", function () {
  const e = waitForAnyBoards_listsAdded();
  block(matchDeleteBoards_lists(e.id, ANY), function () {
    verifyBoards_listsExists(e.id);
  });
});

bthread("Boards_lists update verification", function () {
  const e = waitForAnyBoards_listsUpdated();
  block(matchDeleteBoards_lists(e.id, ANY), function () {
    verifyBoards_listsUpdated(e.id);
  });
});

bthread("Boards_lists delete verification", function () {
  const e = waitForAnyBoards_listsDeleted();
  block(matchAddBoards_lists(e.id, ANY), function () {
    verifyBoards_listsDoesNotExist(e.id);
  });
});

bthread("Cards_stickers create verification", function () {
  const e = waitForAnyCards_stickersAdded();
  block(matchDeleteCards_stickers(e.id, ANY), function () {
    verifyCards_stickersExists(e.id);
  });
});

bthread("Cards_stickers update verification", function () {
  const e = waitForAnyCards_stickersUpdated();
  block(matchDeleteCards_stickers(e.id, ANY), function () {
    verifyCards_stickersUpdated(e.id);
  });
});

bthread("Cards_stickers delete verification", function () {
  const e = waitForAnyCards_stickersDeleted();
  block(matchAddCards_stickers(e.id, ANY), function () {
    verifyCards_stickersDoesNotExist(e.id);
  });
});

bthread("Boards_memberships create verification", function () {
  const e = waitForAnyBoards_membershipsAdded();
  block(matchDeleteBoards_memberships(e.id, ANY), function () {
    verifyBoards_membershipsExists(e.id);
  });
});

bthread("Boards_memberships update verification", function () {
  const e = waitForAnyBoards_membershipsUpdated();
  block(matchDeleteBoards_memberships(e.id, ANY), function () {
    verifyBoards_membershipsUpdated(e.id);
  });
});

bthread("Boards_memberships delete verification", function () {
  const e = waitForAnyBoards_membershipsDeleted();
  block(matchAddBoards_memberships(e.id, ANY), function () {
    verifyBoards_membershipsDoesNotExist(e.id);
  });
});

bthread("Cards_checklists create verification", function () {
  const e = waitForAnyCards_checklistsAdded();
  block(matchDeleteCards_checklists(e.id, ANY), function () {
    verifyCards_checklistsExists(e.id);
  });
});

bthread("Cards_checklists update verification", function () {
  const e = waitForAnyCards_checklistsUpdated();
  block(matchDeleteCards_checklists(e.id, ANY), function () {
    verifyCards_checklistsUpdated(e.id);
  });
});

bthread("Cards_checklists delete verification", function () {
  const e = waitForAnyCards_checklistsDeleted();
  block(matchAddCards_checklists(e.id, ANY), function () {
    verifyCards_checklistsDoesNotExist(e.id);
  });
});

bthread("Boards_checklists create verification", function () {
  const e = waitForAnyBoards_checklistsAdded();
  block(matchDeleteBoards_checklists(e.id, ANY), function () {
    verifyBoards_checklistsExists(e.id);
  });
});

bthread("Boards_checklists update verification", function () {
  const e = waitForAnyBoards_checklistsUpdated();
  block(matchDeleteBoards_checklists(e.id, ANY), function () {
    verifyBoards_checklistsUpdated(e.id);
  });
});

bthread("Boards_checklists delete verification", function () {
  const e = waitForAnyBoards_checklistsDeleted();
  block(matchAddBoards_checklists(e.id, ANY), function () {
    verifyBoards_checklistsDoesNotExist(e.id);
  });
});

bthread("Cards_attachments create verification", function () {
  const e = waitForAnyCards_attachmentsAdded();
  block(matchDeleteCards_attachments(e.id, ANY), function () {
    verifyCards_attachmentsExists(e.id);
  });
});

bthread("Cards_attachments update verification", function () {
  const e = waitForAnyCards_attachmentsUpdated();
  block(matchDeleteCards_attachments(e.id, ANY), function () {
    verifyCards_attachmentsUpdated(e.id);
  });
});

bthread("Cards_attachments delete verification", function () {
  const e = waitForAnyCards_attachmentsDeleted();
  block(matchAddCards_attachments(e.id, ANY), function () {
    verifyCards_attachmentsDoesNotExist(e.id);
  });
});

bthread("Prefs_locale create verification", function () {
  const e = waitForAnyPrefs_localeAdded();
  block(matchDeletePrefs_locale(e.id, ANY), function () {
    verifyPrefs_localeExists(e.id);
  });
});

bthread("Prefs_locale update verification", function () {
  const e = waitForAnyPrefs_localeUpdated();
  block(matchDeletePrefs_locale(e.id, ANY), function () {
    verifyPrefs_localeUpdated(e.id);
  });
});

bthread("Prefs_locale delete verification", function () {
  const e = waitForAnyPrefs_localeDeleted();
  block(matchAddPrefs_locale(e.id, ANY), function () {
    verifyPrefs_localeDoesNotExist(e.id);
  });
});

bthread("Members_savedSearches_query create verification", function () {
  const e = waitForAnyMembers_savedSearches_queryAdded();
  block(matchDeleteMembers_savedSearches_query(e.id, ANY), function () {
    verifyMembers_savedSearches_queryExists(e.id);
  });
});

bthread("Members_savedSearches_query update verification", function () {
  const e = waitForAnyMembers_savedSearches_queryUpdated();
  block(matchDeleteMembers_savedSearches_query(e.id, ANY), function () {
    verifyMembers_savedSearches_queryUpdated(e.id);
  });
});

bthread("Members_savedSearches_query delete verification", function () {
  const e = waitForAnyMembers_savedSearches_queryDeleted();
  block(matchAddMembers_savedSearches_query(e.id, ANY), function () {
    verifyMembers_savedSearches_queryDoesNotExist(e.id);
  });
});

bthread("Notifications create verification", function () {
  const e = waitForAnyNotificationsAdded();
  block(matchDeleteNotifications(e.id, ANY), function () {
    verifyNotificationsExists(e.id);
  });
});

bthread("Notifications update verification", function () {
  const e = waitForAnyNotificationsUpdated();
  block(matchDeleteNotifications(e.id, ANY), function () {
    verifyNotificationsUpdated(e.id);
  });
});

bthread("Notifications delete verification", function () {
  const e = waitForAnyNotificationsDeleted();
  block(matchAddNotifications(e.id, ANY), function () {
    verifyNotificationsDoesNotExist(e.id);
  });
});

bthread("LabelNames_green create verification", function () {
  const e = waitForAnyLabelNames_greenAdded();
  block(matchDeleteLabelNames_green(e.id, ANY), function () {
    verifyLabelNames_greenExists(e.id);
  });
});

bthread("LabelNames_green update verification", function () {
  const e = waitForAnyLabelNames_greenUpdated();
  block(matchDeleteLabelNames_green(e.id, ANY), function () {
    verifyLabelNames_greenUpdated(e.id);
  });
});

bthread("LabelNames_green delete verification", function () {
  const e = waitForAnyLabelNames_greenDeleted();
  block(matchAddLabelNames_green(e.id, ANY), function () {
    verifyLabelNames_greenDoesNotExist(e.id);
  });
});

bthread("LabelNames_yellow create verification", function () {
  const e = waitForAnyLabelNames_yellowAdded();
  block(matchDeleteLabelNames_yellow(e.id, ANY), function () {
    verifyLabelNames_yellowExists(e.id);
  });
});

bthread("LabelNames_yellow update verification", function () {
  const e = waitForAnyLabelNames_yellowUpdated();
  block(matchDeleteLabelNames_yellow(e.id, ANY), function () {
    verifyLabelNames_yellowUpdated(e.id);
  });
});

bthread("LabelNames_yellow delete verification", function () {
  const e = waitForAnyLabelNames_yellowDeleted();
  block(matchAddLabelNames_yellow(e.id, ANY), function () {
    verifyLabelNames_yellowDoesNotExist(e.id);
  });
});

bthread("Prefs_colorBlind create verification", function () {
  const e = waitForAnyPrefs_colorBlindAdded();
  block(matchDeletePrefs_colorBlind(e.id, ANY), function () {
    verifyPrefs_colorBlindExists(e.id);
  });
});

bthread("Prefs_colorBlind update verification", function () {
  const e = waitForAnyPrefs_colorBlindUpdated();
  block(matchDeletePrefs_colorBlind(e.id, ANY), function () {
    verifyPrefs_colorBlindUpdated(e.id);
  });
});

bthread("Prefs_colorBlind delete verification", function () {
  const e = waitForAnyPrefs_colorBlindDeleted();
  block(matchAddPrefs_colorBlind(e.id, ANY), function () {
    verifyPrefs_colorBlindDoesNotExist(e.id);
  });
});

bthread("Lists_closed create verification", function () {
  const e = waitForAnyLists_closedAdded();
  block(matchDeleteLists_closed(e.id, ANY), function () {
    verifyLists_closedExists(e.id);
  });
});

bthread("Lists_closed update verification", function () {
  const e = waitForAnyLists_closedUpdated();
  block(matchDeleteLists_closed(e.id, ANY), function () {
    verifyLists_closedUpdated(e.id);
  });
});

bthread("Lists_closed delete verification", function () {
  const e = waitForAnyLists_closedDeleted();
  block(matchAddLists_closed(e.id, ANY), function () {
    verifyLists_closedDoesNotExist(e.id);
  });
});

bthread("Prefs_boardVisibilityRestrict create verification", function () {
  const e = waitForAnyPrefs_boardVisibilityRestrictAdded();
  block(matchDeletePrefs_boardVisibilityRestrict(e.id, ANY), function () {
    verifyPrefs_boardVisibilityRestrictExists(e.id);
  });
});

bthread("Prefs_boardVisibilityRestrict update verification", function () {
  const e = waitForAnyPrefs_boardVisibilityRestrictUpdated();
  block(matchDeletePrefs_boardVisibilityRestrict(e.id, ANY), function () {
    verifyPrefs_boardVisibilityRestrictUpdated(e.id);
  });
});

bthread("Prefs_boardVisibilityRestrict delete verification", function () {
  const e = waitForAnyPrefs_boardVisibilityRestrictDeleted();
  block(matchAddPrefs_boardVisibilityRestrict(e.id, ANY), function () {
    verifyPrefs_boardVisibilityRestrictDoesNotExist(e.id);
  });
});

bthread("Members_boardStars create verification", function () {
  const e = waitForAnyMembers_boardStarsAdded();
  block(matchDeleteMembers_boardStars(e.id, ANY), function () {
    verifyMembers_boardStarsExists(e.id);
  });
});

bthread("Members_boardStars update verification", function () {
  const e = waitForAnyMembers_boardStarsUpdated();
  block(matchDeleteMembers_boardStars(e.id, ANY), function () {
    verifyMembers_boardStarsUpdated(e.id);
  });
});

bthread("Members_boardStars delete verification", function () {
  const e = waitForAnyMembers_boardStarsDeleted();
  block(matchAddMembers_boardStars(e.id, ANY), function () {
    verifyMembers_boardStarsDoesNotExist(e.id);
  });
});

bthread("Prefs_minutesBetweenSummaries create verification", function () {
  const e = waitForAnyPrefs_minutesBetweenSummariesAdded();
  block(matchDeletePrefs_minutesBetweenSummaries(e.id, ANY), function () {
    verifyPrefs_minutesBetweenSummariesExists(e.id);
  });
});

bthread("Prefs_minutesBetweenSummaries update verification", function () {
  const e = waitForAnyPrefs_minutesBetweenSummariesUpdated();
  block(matchDeletePrefs_minutesBetweenSummaries(e.id, ANY), function () {
    verifyPrefs_minutesBetweenSummariesUpdated(e.id);
  });
});

bthread("Prefs_minutesBetweenSummaries delete verification", function () {
  const e = waitForAnyPrefs_minutesBetweenSummariesDeleted();
  block(matchAddPrefs_minutesBetweenSummaries(e.id, ANY), function () {
    verifyPrefs_minutesBetweenSummariesDoesNotExist(e.id);
  });
});

bthread("Cards_subscribed create verification", function () {
  const e = waitForAnyCards_subscribedAdded();
  block(matchDeleteCards_subscribed(e.id, ANY), function () {
    verifyCards_subscribedExists(e.id);
  });
});

bthread("Cards_subscribed update verification", function () {
  const e = waitForAnyCards_subscribedUpdated();
  block(matchDeleteCards_subscribed(e.id, ANY), function () {
    verifyCards_subscribedUpdated(e.id);
  });
});

bthread("Cards_subscribed delete verification", function () {
  const e = waitForAnyCards_subscribedDeleted();
  block(matchAddCards_subscribed(e.id, ANY), function () {
    verifyCards_subscribedDoesNotExist(e.id);
  });
});

bthread("Webhooks_active create verification", function () {
  const e = waitForAnyWebhooks_activeAdded();
  block(matchDeleteWebhooks_active(e.id, ANY), function () {
    verifyWebhooks_activeExists(e.id);
  });
});

bthread("Webhooks_active update verification", function () {
  const e = waitForAnyWebhooks_activeUpdated();
  block(matchDeleteWebhooks_active(e.id, ANY), function () {
    verifyWebhooks_activeUpdated(e.id);
  });
});

bthread("Webhooks_active delete verification", function () {
  const e = waitForAnyWebhooks_activeDeleted();
  block(matchAddWebhooks_active(e.id, ANY), function () {
    verifyWebhooks_activeDoesNotExist(e.id);
  });
});

bthread("Members_savedSearches_name create verification", function () {
  const e = waitForAnyMembers_savedSearches_nameAdded();
  block(matchDeleteMembers_savedSearches_name(e.id, ANY), function () {
    verifyMembers_savedSearches_nameExists(e.id);
  });
});

bthread("Members_savedSearches_name update verification", function () {
  const e = waitForAnyMembers_savedSearches_nameUpdated();
  block(matchDeleteMembers_savedSearches_name(e.id, ANY), function () {
    verifyMembers_savedSearches_nameUpdated(e.id);
  });
});

bthread("Members_savedSearches_name delete verification", function () {
  const e = waitForAnyMembers_savedSearches_nameDeleted();
  block(matchAddMembers_savedSearches_name(e.id, ANY), function () {
    verifyMembers_savedSearches_nameDoesNotExist(e.id);
  });
});

bthread("Boards_subscribed create verification", function () {
  const e = waitForAnyBoards_subscribedAdded();
  block(matchDeleteBoards_subscribed(e.id, ANY), function () {
    verifyBoards_subscribedExists(e.id);
  });
});

bthread("Boards_subscribed update verification", function () {
  const e = waitForAnyBoards_subscribedUpdated();
  block(matchDeleteBoards_subscribed(e.id, ANY), function () {
    verifyBoards_subscribedUpdated(e.id);
  });
});

bthread("Boards_subscribed delete verification", function () {
  const e = waitForAnyBoards_subscribedDeleted();
  block(matchAddBoards_subscribed(e.id, ANY), function () {
    verifyBoards_subscribedDoesNotExist(e.id);
  });
});

bthread("Notifications_unread create verification", function () {
  const e = waitForAnyNotifications_unreadAdded();
  block(matchDeleteNotifications_unread(e.id, ANY), function () {
    verifyNotifications_unreadExists(e.id);
  });
});

bthread("Notifications_unread update verification", function () {
  const e = waitForAnyNotifications_unreadUpdated();
  block(matchDeleteNotifications_unread(e.id, ANY), function () {
    verifyNotifications_unreadUpdated(e.id);
  });
});

bthread("Notifications_unread delete verification", function () {
  const e = waitForAnyNotifications_unreadDeleted();
  block(matchAddNotifications_unread(e.id, ANY), function () {
    verifyNotifications_unreadDoesNotExist(e.id);
  });
});

bthread("Webhooks_description create verification", function () {
  const e = waitForAnyWebhooks_descriptionAdded();
  block(matchDeleteWebhooks_description(e.id, ANY), function () {
    verifyWebhooks_descriptionExists(e.id);
  });
});

bthread("Webhooks_description update verification", function () {
  const e = waitForAnyWebhooks_descriptionUpdated();
  block(matchDeleteWebhooks_description(e.id, ANY), function () {
    verifyWebhooks_descriptionUpdated(e.id);
  });
});

bthread("Webhooks_description delete verification", function () {
  const e = waitForAnyWebhooks_descriptionDeleted();
  block(matchAddWebhooks_description(e.id, ANY), function () {
    verifyWebhooks_descriptionDoesNotExist(e.id);
  });
});

bthread("Checklists_pos create verification", function () {
  const e = waitForAnyChecklists_posAdded();
  block(matchDeleteChecklists_pos(e.id, ANY), function () {
    verifyChecklists_posExists(e.id);
  });
});

bthread("Checklists_pos update verification", function () {
  const e = waitForAnyChecklists_posUpdated();
  block(matchDeleteChecklists_pos(e.id, ANY), function () {
    verifyChecklists_posUpdated(e.id);
  });
});

bthread("Checklists_pos delete verification", function () {
  const e = waitForAnyChecklists_posDeleted();
  block(matchAddChecklists_pos(e.id, ANY), function () {
    verifyChecklists_posDoesNotExist(e.id);
  });
});

bthread("Boards create verification", function () {
  const e = waitForAnyBoardsAdded();
  block(matchDeleteBoards(e.id, ANY), function () {
    verifyBoardsExists(e.id);
  });
});

bthread("Boards update verification", function () {
  const e = waitForAnyBoardsUpdated();
  block(matchDeleteBoards(e.id, ANY), function () {
    verifyBoardsUpdated(e.id);
  });
});

bthread("Boards delete verification", function () {
  const e = waitForAnyBoardsDeleted();
  block(matchAddBoards(e.id, ANY), function () {
    verifyBoardsDoesNotExist(e.id);
  });
});

bthread("Prefs_background create verification", function () {
  const e = waitForAnyPrefs_backgroundAdded();
  block(matchDeletePrefs_background(e.id, ANY), function () {
    verifyPrefs_backgroundExists(e.id);
  });
});

bthread("Prefs_background update verification", function () {
  const e = waitForAnyPrefs_backgroundUpdated();
  block(matchDeletePrefs_background(e.id, ANY), function () {
    verifyPrefs_backgroundUpdated(e.id);
  });
});

bthread("Prefs_background delete verification", function () {
  const e = waitForAnyPrefs_backgroundDeleted();
  block(matchAddPrefs_background(e.id, ANY), function () {
    verifyPrefs_backgroundDoesNotExist(e.id);
  });
});

bthread("Members_customEmoji create verification", function () {
  const e = waitForAnyMembers_customEmojiAdded();
  block(matchDeleteMembers_customEmoji(e.id, ANY), function () {
    verifyMembers_customEmojiExists(e.id);
  });
});

bthread("Members_customEmoji update verification", function () {
  const e = waitForAnyMembers_customEmojiUpdated();
  block(matchDeleteMembers_customEmoji(e.id, ANY), function () {
    verifyMembers_customEmojiUpdated(e.id);
  });
});

bthread("Members_customEmoji delete verification", function () {
  const e = waitForAnyMembers_customEmojiDeleted();
  block(matchAddMembers_customEmoji(e.id, ANY), function () {
    verifyMembers_customEmojiDoesNotExist(e.id);
  });
});

bthread("Members_username create verification", function () {
  const e = waitForAnyMembers_usernameAdded();
  block(matchDeleteMembers_username(e.id, ANY), function () {
    verifyMembers_usernameExists(e.id);
  });
});

bthread("Members_username update verification", function () {
  const e = waitForAnyMembers_usernameUpdated();
  block(matchDeleteMembers_username(e.id, ANY), function () {
    verifyMembers_usernameUpdated(e.id);
  });
});

bthread("Members_username delete verification", function () {
  const e = waitForAnyMembers_usernameDeleted();
  block(matchAddMembers_username(e.id, ANY), function () {
    verifyMembers_usernameDoesNotExist(e.id);
  });
});

bthread("Members_avatar create verification", function () {
  const e = waitForAnyMembers_avatarAdded();
  block(matchDeleteMembers_avatar(e.id, ANY), function () {
    verifyMembers_avatarExists(e.id);
  });
});

bthread("Members_avatar update verification", function () {
  const e = waitForAnyMembers_avatarUpdated();
  block(matchDeleteMembers_avatar(e.id, ANY), function () {
    verifyMembers_avatarUpdated(e.id);
  });
});

bthread("Members_avatar delete verification", function () {
  const e = waitForAnyMembers_avatarDeleted();
  block(matchAddMembers_avatar(e.id, ANY), function () {
    verifyMembers_avatarDoesNotExist(e.id);
  });
});

bthread("Members_customStickers create verification", function () {
  const e = waitForAnyMembers_customStickersAdded();
  block(matchDeleteMembers_customStickers(e.id, ANY), function () {
    verifyMembers_customStickersExists(e.id);
  });
});

bthread("Members_customStickers update verification", function () {
  const e = waitForAnyMembers_customStickersUpdated();
  block(matchDeleteMembers_customStickers(e.id, ANY), function () {
    verifyMembers_customStickersUpdated(e.id);
  });
});

bthread("Members_customStickers delete verification", function () {
  const e = waitForAnyMembers_customStickersDeleted();
  block(matchAddMembers_customStickers(e.id, ANY), function () {
    verifyMembers_customStickersDoesNotExist(e.id);
  });
});

bthread("Cards_idBoard create verification", function () {
  const e = waitForAnyCards_idBoardAdded();
  block(matchDeleteCards_idBoard(e.id, ANY), function () {
    verifyCards_idBoardExists(e.id);
  });
});

bthread("Cards_idBoard update verification", function () {
  const e = waitForAnyCards_idBoardUpdated();
  block(matchDeleteCards_idBoard(e.id, ANY), function () {
    verifyCards_idBoardUpdated(e.id);
  });
});

bthread("Cards_idBoard delete verification", function () {
  const e = waitForAnyCards_idBoardDeleted();
  block(matchAddCards_idBoard(e.id, ANY), function () {
    verifyCards_idBoardDoesNotExist(e.id);
  });
});

bthread("Members_oneTimeMessagesDismissed create verification", function () {
  const e = waitForAnyMembers_oneTimeMessagesDismissedAdded();
  block(matchDeleteMembers_oneTimeMessagesDismissed(e.id, ANY), function () {
    verifyMembers_oneTimeMessagesDismissedExists(e.id);
  });
});

bthread("Members_oneTimeMessagesDismissed update verification", function () {
  const e = waitForAnyMembers_oneTimeMessagesDismissedUpdated();
  block(matchDeleteMembers_oneTimeMessagesDismissed(e.id, ANY), function () {
    verifyMembers_oneTimeMessagesDismissedUpdated(e.id);
  });
});

bthread("Members_oneTimeMessagesDismissed delete verification", function () {
  const e = waitForAnyMembers_oneTimeMessagesDismissedDeleted();
  block(matchAddMembers_oneTimeMessagesDismissed(e.id, ANY), function () {
    verifyMembers_oneTimeMessagesDismissedDoesNotExist(e.id);
  });
});

bthread("Boards_closed create verification", function () {
  const e = waitForAnyBoards_closedAdded();
  block(matchDeleteBoards_closed(e.id, ANY), function () {
    verifyBoards_closedExists(e.id);
  });
});

bthread("Boards_closed update verification", function () {
  const e = waitForAnyBoards_closedUpdated();
  block(matchDeleteBoards_closed(e.id, ANY), function () {
    verifyBoards_closedUpdated(e.id);
  });
});

bthread("Boards_closed delete verification", function () {
  const e = waitForAnyBoards_closedDeleted();
  block(matchAddBoards_closed(e.id, ANY), function () {
    verifyBoards_closedDoesNotExist(e.id);
  });
});

// ===== RELATIONSHIP GUARDS =====

// ===== UNIQUENESS GUARDS =====

bthread("Guard: Unique Boards_idOrganization", function () {
  const x = waitForAnyBoards_idOrganizationAdded();
  block(matchAddBoards_idOrganization(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards_members", function () {
  const x = waitForAnyBoards_membersAdded();
  block(matchAddBoards_members(x.id, ANY), function () {});
});

bthread("Guard: Unique Lists_name", function () {
  const x = waitForAnyLists_nameAdded();
  block(matchAddLists_name(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_membersVoted", function () {
  const x = waitForAnyCards_membersVotedAdded();
  block(matchAddCards_membersVoted(x.id, ANY), function () {});
});

bthread("Guard: Unique Organizations_desc", function () {
  const x = waitForAnyOrganizations_descAdded();
  block(matchAddOrganizations_desc(x.id, ANY), function () {});
});

bthread("Guard: Unique Labels", function () {
  const x = waitForAnyLabelsAdded();
  block(matchAddLabels(x.id, ANY), function () {});
});

bthread("Guard: Unique MyPrefs_showSidebarBoardActions", function () {
  const x = waitForAnyMyPrefs_showSidebarBoardActionsAdded();
  block(matchAddMyPrefs_showSidebarBoardActions(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_checklist_idChecklistCurrent_checkItem", function () {
  const x = waitForAnyCards_checklist_idChecklistCurrent_checkItemAdded();
  block(matchAddCards_checklist_idChecklistCurrent_checkItem(x.id, ANY), function () {});
});

bthread("Guard: Unique Organizations_memberships", function () {
  const x = waitForAnyOrganizations_membershipsAdded();
  block(matchAddOrganizations_memberships(x.id, ANY), function () {});
});

bthread("Guard: Unique MyPrefs_idEmailList", function () {
  const x = waitForAnyMyPrefs_idEmailListAdded();
  block(matchAddMyPrefs_idEmailList(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_name", function () {
  const x = waitForAnyCards_nameAdded();
  block(matchAddCards_name(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards_desc", function () {
  const x = waitForAnyBoards_descAdded();
  block(matchAddBoards_desc(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_avatarSource", function () {
  const x = waitForAnyMembers_avatarSourceAdded();
  block(matchAddMembers_avatarSource(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards_labels", function () {
  const x = waitForAnyBoards_labelsAdded();
  block(matchAddBoards_labels(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_pos", function () {
  const x = waitForAnyCards_posAdded();
  block(matchAddCards_pos(x.id, ANY), function () {});
});

bthread("Guard: Unique LabelNames_purple", function () {
  const x = waitForAnyLabelNames_purpleAdded();
  block(matchAddLabelNames_purple(x.id, ANY), function () {});
});

bthread("Guard: Unique Lists_subscribed", function () {
  const x = waitForAnyLists_subscribedAdded();
  block(matchAddLists_subscribed(x.id, ANY), function () {});
});

bthread("Guard: Unique Organizations", function () {
  const x = waitForAnyOrganizationsAdded();
  block(matchAddOrganizations(x.id, ANY), function () {});
});

bthread("Guard: Unique Sessions", function () {
  const x = waitForAnySessionsAdded();
  block(matchAddSessions(x.id, ANY), function () {});
});

bthread("Guard: Unique Tokens_webhooks", function () {
  const x = waitForAnyTokens_webhooksAdded();
  block(matchAddTokens_webhooks(x.id, ANY), function () {});
});

bthread("Guard: Unique Webhooks_idModel", function () {
  const x = waitForAnyWebhooks_idModelAdded();
  block(matchAddWebhooks_idModel(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_boardBackgrounds", function () {
  const x = waitForAnyMembers_boardBackgroundsAdded();
  block(matchAddMembers_boardBackgrounds(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_cardAging", function () {
  const x = waitForAnyPrefs_cardAgingAdded();
  block(matchAddPrefs_cardAging(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_savedSearches", function () {
  const x = waitForAnyMembers_savedSearchesAdded();
  block(matchAddMembers_savedSearches(x.id, ANY), function () {});
});

bthread("Guard: Unique Labels_name", function () {
  const x = waitForAnyLabels_nameAdded();
  block(matchAddLabels_name(x.id, ANY), function () {});
});

bthread("Guard: Unique Actions_comments", function () {
  const x = waitForAnyActions_commentsAdded();
  block(matchAddActions_comments(x.id, ANY), function () {});
});

bthread("Guard: Unique Organizations_displayName", function () {
  const x = waitForAnyOrganizations_displayNameAdded();
  block(matchAddOrganizations_displayName(x.id, ANY), function () {});
});

bthread("Guard: Unique Lists_pos", function () {
  const x = waitForAnyLists_posAdded();
  block(matchAddLists_pos(x.id, ANY), function () {});
});

bthread("Guard: Unique LabelNames_blue", function () {
  const x = waitForAnyLabelNames_blueAdded();
  block(matchAddLabelNames_blue(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_checklist_checkItem_name", function () {
  const x = waitForAnyCards_checklist_checkItem_nameAdded();
  block(matchAddCards_checklist_checkItem_name(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_externalMembersDisabled", function () {
  const x = waitForAnyPrefs_externalMembersDisabledAdded();
  block(matchAddPrefs_externalMembersDisabled(x.id, ANY), function () {});
});

bthread("Guard: Unique Checklists_idCard", function () {
  const x = waitForAnyChecklists_idCardAdded();
  block(matchAddChecklists_idCard(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_orgInviteRestrict", function () {
  const x = waitForAnyPrefs_orgInviteRestrictAdded();
  block(matchAddPrefs_orgInviteRestrict(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_voting", function () {
  const x = waitForAnyPrefs_votingAdded();
  block(matchAddPrefs_voting(x.id, ANY), function () {});
});

bthread("Guard: Unique Organizations_logo", function () {
  const x = waitForAnyOrganizations_logoAdded();
  block(matchAddOrganizations_logo(x.id, ANY), function () {});
});

bthread("Guard: Unique MyPrefs_showSidebarActivity", function () {
  const x = waitForAnyMyPrefs_showSidebarActivityAdded();
  block(matchAddMyPrefs_showSidebarActivity(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_boardStars_idBoard", function () {
  const x = waitForAnyMembers_boardStars_idBoardAdded();
  block(matchAddMembers_boardStars_idBoard(x.id, ANY), function () {});
});

bthread("Guard: Unique Actions_text", function () {
  const x = waitForAnyActions_textAdded();
  block(matchAddActions_text(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards_powerUps", function () {
  const x = waitForAnyBoards_powerUpsAdded();
  block(matchAddBoards_powerUps(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_bio", function () {
  const x = waitForAnyMembers_bioAdded();
  block(matchAddMembers_bio(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_customBoardBackgrounds", function () {
  const x = waitForAnyMembers_customBoardBackgroundsAdded();
  block(matchAddMembers_customBoardBackgrounds(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_boardStars_pos", function () {
  const x = waitForAnyMembers_boardStars_posAdded();
  block(matchAddMembers_boardStars_pos(x.id, ANY), function () {});
});

bthread("Guard: Unique Sessions_status", function () {
  const x = waitForAnySessions_statusAdded();
  block(matchAddSessions_status(x.id, ANY), function () {});
});

bthread("Guard: Unique LabelNames_orange", function () {
  const x = waitForAnyLabelNames_orangeAdded();
  block(matchAddLabelNames_orange(x.id, ANY), function () {});
});

bthread("Guard: Unique Webhooks", function () {
  const x = waitForAnyWebhooksAdded();
  block(matchAddWebhooks(x.id, ANY), function () {});
});

bthread("Guard: Unique Organizations_members", function () {
  const x = waitForAnyOrganizations_membersAdded();
  block(matchAddOrganizations_members(x.id, ANY), function () {});
});

bthread("Guard: Unique Checklists_name", function () {
  const x = waitForAnyChecklists_nameAdded();
  block(matchAddChecklists_name(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_closed", function () {
  const x = waitForAnyCards_closedAdded();
  block(matchAddCards_closed(x.id, ANY), function () {});
});

bthread("Guard: Unique Organizations_members_deactivated", function () {
  const x = waitForAnyOrganizations_members_deactivatedAdded();
  block(matchAddOrganizations_members_deactivated(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_actions_comments", function () {
  const x = waitForAnyCards_actions_commentsAdded();
  block(matchAddCards_actions_comments(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_checklist_checkItem", function () {
  const x = waitForAnyCards_checklist_checkItemAdded();
  block(matchAddCards_checklist_checkItem(x.id, ANY), function () {});
});

bthread("Guard: Unique Organizations_website", function () {
  const x = waitForAnyOrganizations_websiteAdded();
  block(matchAddOrganizations_website(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards", function () {
  const x = waitForAnyCardsAdded();
  block(matchAddCards(x.id, ANY), function () {});
});

bthread("Guard: Unique Lists_idBoard", function () {
  const x = waitForAnyLists_idBoardAdded();
  block(matchAddLists_idBoard(x.id, ANY), function () {});
});

bthread("Guard: Unique MyPrefs_showSidebarMembers", function () {
  const x = waitForAnyMyPrefs_showSidebarMembersAdded();
  block(matchAddMyPrefs_showSidebarMembers(x.id, ANY), function () {});
});

bthread("Guard: Unique Checklists_checkItems", function () {
  const x = waitForAnyChecklists_checkItemsAdded();
  block(matchAddChecklists_checkItems(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_associatedDomain", function () {
  const x = waitForAnyPrefs_associatedDomainAdded();
  block(matchAddPrefs_associatedDomain(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_labels", function () {
  const x = waitForAnyCards_labelsAdded();
  block(matchAddCards_labels(x.id, ANY), function () {});
});

bthread("Guard: Unique Lists_cards", function () {
  const x = waitForAnyLists_cardsAdded();
  block(matchAddLists_cards(x.id, ANY), function () {});
});

bthread("Guard: Unique MyPrefs_showSidebar", function () {
  const x = waitForAnyMyPrefs_showSidebarAdded();
  block(matchAddMyPrefs_showSidebar(x.id, ANY), function () {});
});

bthread("Guard: Unique Members", function () {
  const x = waitForAnyMembersAdded();
  block(matchAddMembers(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_invitations", function () {
  const x = waitForAnyPrefs_invitationsAdded();
  block(matchAddPrefs_invitations(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_idMembers", function () {
  const x = waitForAnyCards_idMembersAdded();
  block(matchAddCards_idMembers(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_initials", function () {
  const x = waitForAnyMembers_initialsAdded();
  block(matchAddMembers_initials(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_checklist_checkItem_pos", function () {
  const x = waitForAnyCards_checklist_checkItem_posAdded();
  block(matchAddCards_checklist_checkItem_pos(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_comments", function () {
  const x = waitForAnyPrefs_commentsAdded();
  block(matchAddPrefs_comments(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_selfJoin", function () {
  const x = waitForAnyPrefs_selfJoinAdded();
  block(matchAddPrefs_selfJoin(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_cardCovers", function () {
  const x = waitForAnyPrefs_cardCoversAdded();
  block(matchAddPrefs_cardCovers(x.id, ANY), function () {});
});

bthread("Guard: Unique Actions", function () {
  const x = waitForAnyActionsAdded();
  block(matchAddActions(x.id, ANY), function () {});
});

bthread("Guard: Unique Organizations_name", function () {
  const x = waitForAnyOrganizations_nameAdded();
  block(matchAddOrganizations_name(x.id, ANY), function () {});
});

bthread("Guard: Unique Checklists", function () {
  const x = waitForAnyChecklistsAdded();
  block(matchAddChecklists(x.id, ANY), function () {});
});

bthread("Guard: Unique LabelNames_red", function () {
  const x = waitForAnyLabelNames_redAdded();
  block(matchAddLabelNames_red(x.id, ANY), function () {});
});

bthread("Guard: Unique Webhooks_callbackURL", function () {
  const x = waitForAnyWebhooks_callbackURLAdded();
  block(matchAddWebhooks_callbackURL(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_savedSearches_pos", function () {
  const x = waitForAnyMembers_savedSearches_posAdded();
  block(matchAddMembers_savedSearches_pos(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_permissionLevel", function () {
  const x = waitForAnyPrefs_permissionLevelAdded();
  block(matchAddPrefs_permissionLevel(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_idLabels", function () {
  const x = waitForAnyCards_idLabelsAdded();
  block(matchAddCards_idLabels(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_due", function () {
  const x = waitForAnyCards_dueAdded();
  block(matchAddCards_due(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_calendarFeedEnabled", function () {
  const x = waitForAnyPrefs_calendarFeedEnabledAdded();
  block(matchAddPrefs_calendarFeedEnabled(x.id, ANY), function () {});
});

bthread("Guard: Unique Lists", function () {
  const x = waitForAnyListsAdded();
  block(matchAddLists(x.id, ANY), function () {});
});

bthread("Guard: Unique Lists_moveAllCards", function () {
  const x = waitForAnyLists_moveAllCardsAdded();
  block(matchAddLists_moveAllCards(x.id, ANY), function () {});
});

bthread("Guard: Unique Labels_color", function () {
  const x = waitForAnyLabels_colorAdded();
  block(matchAddLabels_color(x.id, ANY), function () {});
});

bthread("Guard: Unique MyPrefs_showListGuide", function () {
  const x = waitForAnyMyPrefs_showListGuideAdded();
  block(matchAddMyPrefs_showListGuide(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards_name", function () {
  const x = waitForAnyBoards_nameAdded();
  block(matchAddBoards_name(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_fullName", function () {
  const x = waitForAnyMembers_fullNameAdded();
  block(matchAddMembers_fullName(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_googleAppsVersion", function () {
  const x = waitForAnyPrefs_googleAppsVersionAdded();
  block(matchAddPrefs_googleAppsVersion(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_idAttachmentCover", function () {
  const x = waitForAnyCards_idAttachmentCoverAdded();
  block(matchAddCards_idAttachmentCover(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_desc", function () {
  const x = waitForAnyCards_descAdded();
  block(matchAddCards_desc(x.id, ANY), function () {});
});

bthread("Guard: Unique MyPrefs_emailPosition", function () {
  const x = waitForAnyMyPrefs_emailPositionAdded();
  block(matchAddMyPrefs_emailPosition(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_checklist_checkItem_state", function () {
  const x = waitForAnyCards_checklist_checkItem_stateAdded();
  block(matchAddCards_checklist_checkItem_state(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_idList", function () {
  const x = waitForAnyCards_idListAdded();
  block(matchAddCards_idList(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards_lists", function () {
  const x = waitForAnyBoards_listsAdded();
  block(matchAddBoards_lists(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_stickers", function () {
  const x = waitForAnyCards_stickersAdded();
  block(matchAddCards_stickers(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards_memberships", function () {
  const x = waitForAnyBoards_membershipsAdded();
  block(matchAddBoards_memberships(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_checklists", function () {
  const x = waitForAnyCards_checklistsAdded();
  block(matchAddCards_checklists(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards_checklists", function () {
  const x = waitForAnyBoards_checklistsAdded();
  block(matchAddBoards_checklists(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_attachments", function () {
  const x = waitForAnyCards_attachmentsAdded();
  block(matchAddCards_attachments(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_locale", function () {
  const x = waitForAnyPrefs_localeAdded();
  block(matchAddPrefs_locale(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_savedSearches_query", function () {
  const x = waitForAnyMembers_savedSearches_queryAdded();
  block(matchAddMembers_savedSearches_query(x.id, ANY), function () {});
});

bthread("Guard: Unique Notifications", function () {
  const x = waitForAnyNotificationsAdded();
  block(matchAddNotifications(x.id, ANY), function () {});
});

bthread("Guard: Unique LabelNames_green", function () {
  const x = waitForAnyLabelNames_greenAdded();
  block(matchAddLabelNames_green(x.id, ANY), function () {});
});

bthread("Guard: Unique LabelNames_yellow", function () {
  const x = waitForAnyLabelNames_yellowAdded();
  block(matchAddLabelNames_yellow(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_colorBlind", function () {
  const x = waitForAnyPrefs_colorBlindAdded();
  block(matchAddPrefs_colorBlind(x.id, ANY), function () {});
});

bthread("Guard: Unique Lists_closed", function () {
  const x = waitForAnyLists_closedAdded();
  block(matchAddLists_closed(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_boardVisibilityRestrict", function () {
  const x = waitForAnyPrefs_boardVisibilityRestrictAdded();
  block(matchAddPrefs_boardVisibilityRestrict(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_boardStars", function () {
  const x = waitForAnyMembers_boardStarsAdded();
  block(matchAddMembers_boardStars(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_minutesBetweenSummaries", function () {
  const x = waitForAnyPrefs_minutesBetweenSummariesAdded();
  block(matchAddPrefs_minutesBetweenSummaries(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_subscribed", function () {
  const x = waitForAnyCards_subscribedAdded();
  block(matchAddCards_subscribed(x.id, ANY), function () {});
});

bthread("Guard: Unique Webhooks_active", function () {
  const x = waitForAnyWebhooks_activeAdded();
  block(matchAddWebhooks_active(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_savedSearches_name", function () {
  const x = waitForAnyMembers_savedSearches_nameAdded();
  block(matchAddMembers_savedSearches_name(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards_subscribed", function () {
  const x = waitForAnyBoards_subscribedAdded();
  block(matchAddBoards_subscribed(x.id, ANY), function () {});
});

bthread("Guard: Unique Notifications_unread", function () {
  const x = waitForAnyNotifications_unreadAdded();
  block(matchAddNotifications_unread(x.id, ANY), function () {});
});

bthread("Guard: Unique Webhooks_description", function () {
  const x = waitForAnyWebhooks_descriptionAdded();
  block(matchAddWebhooks_description(x.id, ANY), function () {});
});

bthread("Guard: Unique Checklists_pos", function () {
  const x = waitForAnyChecklists_posAdded();
  block(matchAddChecklists_pos(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards", function () {
  const x = waitForAnyBoardsAdded();
  block(matchAddBoards(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefs_background", function () {
  const x = waitForAnyPrefs_backgroundAdded();
  block(matchAddPrefs_background(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_customEmoji", function () {
  const x = waitForAnyMembers_customEmojiAdded();
  block(matchAddMembers_customEmoji(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_username", function () {
  const x = waitForAnyMembers_usernameAdded();
  block(matchAddMembers_username(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_avatar", function () {
  const x = waitForAnyMembers_avatarAdded();
  block(matchAddMembers_avatar(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_customStickers", function () {
  const x = waitForAnyMembers_customStickersAdded();
  block(matchAddMembers_customStickers(x.id, ANY), function () {});
});

bthread("Guard: Unique Cards_idBoard", function () {
  const x = waitForAnyCards_idBoardAdded();
  block(matchAddCards_idBoard(x.id, ANY), function () {});
});

bthread("Guard: Unique Members_oneTimeMessagesDismissed", function () {
  const x = waitForAnyMembers_oneTimeMessagesDismissedAdded();
  block(matchAddMembers_oneTimeMessagesDismissed(x.id, ANY), function () {});
});

bthread("Guard: Unique Boards_closed", function () {
  const x = waitForAnyBoards_closedAdded();
  block(matchAddBoards_closed(x.id, ANY), function () {});
});

// ===== NEGATIVE/EDGE STATUS GUARDS =====
