// ====================================================================
// Auto-generated garage-style High-Level Stories (HLS)
// SUT: keycloak_admin
// ====================================================================

var ANY = (typeof H !== 'undefined' && H.ANY) ? H.ANY : (typeof ANY !== 'undefined' ? ANY : '*');

// ===== ACTIVE LIFECYCLES =====


bthread("ScopeRepresentation lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addScopeRepresentation(x.id);
  updateScopeRepresentation(x.id);
  updateScopeRepresentation(x.id);
  verifyScopeRepresentationExists(x.id);
  verifyScopeRepresentationUpdated(x.id);
});

bthread("MethodConfig lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMethodConfig(x.id);
  updateMethodConfig(x.id);
  updateMethodConfig(x.id);
  verifyMethodConfigExists(x.id);
  verifyMethodConfigUpdated(x.id);
});

bthread("ResourceRepresentation lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addResourceRepresentation(x.id);
  updateResourceRepresentation(x.id);
  updateResourceRepresentation(x.id);
  verifyResourceRepresentationExists(x.id);
  verifyResourceRepresentationUpdated(x.id);
});

bthread("RolesRepresentation lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRolesRepresentation(x.id);
  updateRolesRepresentation(x.id);
  updateRolesRepresentation(x.id);
  verifyRolesRepresentationExists(x.id);
  verifyRolesRepresentationUpdated(x.id);
});

bthread("ClientPoliciesRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientPoliciesRepresentation(x.id);
  updateClientPoliciesRepresentation(x.id);
  updateClientPoliciesRepresentation(x.id);
  verifyClientPoliciesRepresentationExists(x.id);
  verifyClientPoliciesRepresentationUpdated(x.id);
});

bthread("PathConfig lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPathConfig(x.id);
  updatePathConfig(x.id);
  updatePathConfig(x.id);
  verifyPathConfigExists(x.id);
  verifyPathConfigUpdated(x.id);
});

bthread("GroupRepresentation lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGroupRepresentation(x.id);
  updateGroupRepresentation(x.id);
  updateGroupRepresentation(x.id);
  verifyGroupRepresentationExists(x.id);
  verifyGroupRepresentationUpdated(x.id);
});

bthread("KeyUse lifecycle", function () {
  const x = pick([{id: "K001"}, {id: "K002"}]);
  addKeyUse(x.id);
  updateKeyUse(x.id);
  updateKeyUse(x.id);
  verifyKeyUseExists(x.id);
  verifyKeyUseUpdated(x.id);
});

bthread("ProtocolMapperRepresentation lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addProtocolMapperRepresentation(x.id);
  updateProtocolMapperRepresentation(x.id);
  updateProtocolMapperRepresentation(x.id);
  verifyProtocolMapperRepresentationExists(x.id);
  verifyProtocolMapperRepresentationUpdated(x.id);
});

bthread("KeyMetadataRepresentation lifecycle", function () {
  const x = pick([{id: "K001"}, {id: "K002"}]);
  addKeyMetadataRepresentation(x.id);
  updateKeyMetadataRepresentation(x.id);
  updateKeyMetadataRepresentation(x.id);
  verifyKeyMetadataRepresentationExists(x.id);
  verifyKeyMetadataRepresentationUpdated(x.id);
});

bthread("ClientPolicyRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientPolicyRepresentation(x.id);
  updateClientPolicyRepresentation(x.id);
  updateClientPolicyRepresentation(x.id);
  verifyClientPolicyRepresentationExists(x.id);
  verifyClientPolicyRepresentationUpdated(x.id);
});

bthread("Authorization lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAuthorization(x.id);
  updateAuthorization(x.id);
  updateAuthorization(x.id);
  verifyAuthorizationExists(x.id);
  verifyAuthorizationUpdated(x.id);
});

bthread("CertConf lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCertConf(x.id);
  updateCertConf(x.id);
  updateCertConf(x.id);
  verifyCertConfExists(x.id);
  verifyCertConfUpdated(x.id);
});

bthread("ClientRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientRepresentation(x.id);
  updateClientRepresentation(x.id);
  updateClientRepresentation(x.id);
  verifyClientRepresentationExists(x.id);
  verifyClientRepresentationUpdated(x.id);
});

bthread("InstallationAdapterConfig lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInstallationAdapterConfig(x.id);
  updateInstallationAdapterConfig(x.id);
  updateInstallationAdapterConfig(x.id);
  verifyInstallationAdapterConfigExists(x.id);
  verifyInstallationAdapterConfigUpdated(x.id);
});

bthread("ClientTemplateRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientTemplateRepresentation(x.id);
  updateClientTemplateRepresentation(x.id);
  updateClientTemplateRepresentation(x.id);
  verifyClientTemplateRepresentationExists(x.id);
  verifyClientTemplateRepresentationUpdated(x.id);
});

bthread("PolicyRepresentation lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPolicyRepresentation(x.id);
  updatePolicyRepresentation(x.id);
  updatePolicyRepresentation(x.id);
  verifyPolicyRepresentationExists(x.id);
  verifyPolicyRepresentationUpdated(x.id);
});

bthread("ClientPolicyExecutorRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientPolicyExecutorRepresentation(x.id);
  updateClientPolicyExecutorRepresentation(x.id);
  updateClientPolicyExecutorRepresentation(x.id);
  verifyClientPolicyExecutorRepresentationExists(x.id);
  verifyClientPolicyExecutorRepresentationUpdated(x.id);
});

bthread("UserFederationMapperRepresentation lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserFederationMapperRepresentation(x.id);
  updateUserFederationMapperRepresentation(x.id);
  updateUserFederationMapperRepresentation(x.id);
  verifyUserFederationMapperRepresentationExists(x.id);
  verifyUserFederationMapperRepresentationUpdated(x.id);
});

bthread("AuthenticationFlowRepresentation lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAuthenticationFlowRepresentation(x.id);
  updateAuthenticationFlowRepresentation(x.id);
  updateAuthenticationFlowRepresentation(x.id);
  verifyAuthenticationFlowRepresentationExists(x.id);
  verifyAuthenticationFlowRepresentationUpdated(x.id);
});

bthread("IdentityProviderMapperTypeRepresentation lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIdentityProviderMapperTypeRepresentation(x.id);
  updateIdentityProviderMapperTypeRepresentation(x.id);
  updateIdentityProviderMapperTypeRepresentation(x.id);
  verifyIdentityProviderMapperTypeRepresentationExists(x.id);
  verifyIdentityProviderMapperTypeRepresentationUpdated(x.id);
});

bthread("Permission lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPermission(x.id);
  updatePermission(x.id);
  updatePermission(x.id);
  verifyPermissionExists(x.id);
  verifyPermissionUpdated(x.id);
});

bthread("EnforcementMode lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEnforcementMode(x.id);
  updateEnforcementMode(x.id);
  updateEnforcementMode(x.id);
  verifyEnforcementModeExists(x.id);
  verifyEnforcementModeUpdated(x.id);
});

bthread("KeysMetadataRepresentation lifecycle", function () {
  const x = pick([{id: "K001"}, {id: "K002"}]);
  addKeysMetadataRepresentation(x.id);
  updateKeysMetadataRepresentation(x.id);
  updateKeysMetadataRepresentation(x.id);
  verifyKeysMetadataRepresentationExists(x.id);
  verifyKeysMetadataRepresentationUpdated(x.id);
});

bthread("ManagementPermissionReference lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addManagementPermissionReference(x.id);
  updateManagementPermissionReference(x.id);
  updateManagementPermissionReference(x.id);
  verifyManagementPermissionReferenceExists(x.id);
  verifyManagementPermissionReferenceUpdated(x.id);
});

bthread("AuthenticatorConfigInfoRepresentation lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAuthenticatorConfigInfoRepresentation(x.id);
  updateAuthenticatorConfigInfoRepresentation(x.id);
  updateAuthenticatorConfigInfoRepresentation(x.id);
  verifyAuthenticatorConfigInfoRepresentationExists(x.id);
  verifyAuthenticatorConfigInfoRepresentationUpdated(x.id);
});

bthread("AuthenticatorConfigRepresentation lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAuthenticatorConfigRepresentation(x.id);
  updateAuthenticatorConfigRepresentation(x.id);
  updateAuthenticatorConfigRepresentation(x.id);
  verifyAuthenticatorConfigRepresentationExists(x.id);
  verifyAuthenticatorConfigRepresentationUpdated(x.id);
});

bthread("DecisionStrategy lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDecisionStrategy(x.id);
  updateDecisionStrategy(x.id);
  updateDecisionStrategy(x.id);
  verifyDecisionStrategyExists(x.id);
  verifyDecisionStrategyUpdated(x.id);
});

bthread("Logic lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLogic(x.id);
  updateLogic(x.id);
  updateLogic(x.id);
  verifyLogicExists(x.id);
  verifyLogicUpdated(x.id);
});

bthread("UserRepresentation lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserRepresentation(x.id);
  updateUserRepresentation(x.id);
  updateUserRepresentation(x.id);
  verifyUserRepresentationExists(x.id);
  verifyUserRepresentationUpdated(x.id);
});

bthread("ClientProfilesRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientProfilesRepresentation(x.id);
  updateClientProfilesRepresentation(x.id);
  updateClientProfilesRepresentation(x.id);
  verifyClientProfilesRepresentationExists(x.id);
  verifyClientProfilesRepresentationUpdated(x.id);
});

bthread("KeyStoreConfig lifecycle", function () {
  const x = pick([{id: "K001"}, {id: "K002"}]);
  addKeyStoreConfig(x.id);
  updateKeyStoreConfig(x.id);
  updateKeyStoreConfig(x.id);
  verifyKeyStoreConfigExists(x.id);
  verifyKeyStoreConfigUpdated(x.id);
});

bthread("ComponentRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addComponentRepresentation(x.id);
  updateComponentRepresentation(x.id);
  updateComponentRepresentation(x.id);
  verifyComponentRepresentationExists(x.id);
  verifyComponentRepresentationUpdated(x.id);
});

bthread("PublishedRealmRepresentation lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPublishedRealmRepresentation(x.id);
  updatePublishedRealmRepresentation(x.id);
  updatePublishedRealmRepresentation(x.id);
  verifyPublishedRealmRepresentationExists(x.id);
  verifyPublishedRealmRepresentationUpdated(x.id);
});

bthread("SocialLinkRepresentation lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSocialLinkRepresentation(x.id);
  updateSocialLinkRepresentation(x.id);
  updateSocialLinkRepresentation(x.id);
  verifySocialLinkRepresentationExists(x.id);
  verifySocialLinkRepresentationUpdated(x.id);
});

bthread("AuthenticationExecutionExportRepresentation lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAuthenticationExecutionExportRepresentation(x.id);
  updateAuthenticationExecutionExportRepresentation(x.id);
  updateAuthenticationExecutionExportRepresentation(x.id);
  verifyAuthenticationExecutionExportRepresentationExists(x.id);
  verifyAuthenticationExecutionExportRepresentationUpdated(x.id);
});

bthread("IdentityProviderRepresentation lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIdentityProviderRepresentation(x.id);
  updateIdentityProviderRepresentation(x.id);
  updateIdentityProviderRepresentation(x.id);
  verifyIdentityProviderRepresentationExists(x.id);
  verifyIdentityProviderRepresentationUpdated(x.id);
});

bthread("OAuthClientRepresentation lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOAuthClientRepresentation(x.id);
  updateOAuthClientRepresentation(x.id);
  updateOAuthClientRepresentation(x.id);
  verifyOAuthClientRepresentationExists(x.id);
  verifyOAuthClientRepresentationUpdated(x.id);
});

bthread("Access lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAccess(x.id);
  updateAccess(x.id);
  updateAccess(x.id);
  verifyAccessExists(x.id);
  verifyAccessUpdated(x.id);
});

bthread("ResourceOwnerRepresentation lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addResourceOwnerRepresentation(x.id);
  updateResourceOwnerRepresentation(x.id);
  updateResourceOwnerRepresentation(x.id);
  verifyResourceOwnerRepresentationExists(x.id);
  verifyResourceOwnerRepresentationUpdated(x.id);
});

bthread("ScopeMappingRepresentation lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addScopeMappingRepresentation(x.id);
  updateScopeMappingRepresentation(x.id);
  updateScopeMappingRepresentation(x.id);
  verifyScopeMappingRepresentationExists(x.id);
  verifyScopeMappingRepresentationUpdated(x.id);
});

bthread("Composites lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addComposites(x.id);
  updateComposites(x.id);
  updateComposites(x.id);
  verifyCompositesExists(x.id);
  verifyCompositesUpdated(x.id);
});

bthread("RealmEventsConfigRepresentation lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealmEventsConfigRepresentation(x.id);
  updateRealmEventsConfigRepresentation(x.id);
  updateRealmEventsConfigRepresentation(x.id);
  verifyRealmEventsConfigRepresentationExists(x.id);
  verifyRealmEventsConfigRepresentationUpdated(x.id);
});

bthread("ClientProfileRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientProfileRepresentation(x.id);
  updateClientProfileRepresentation(x.id);
  updateClientProfileRepresentation(x.id);
  verifyClientProfileRepresentationExists(x.id);
  verifyClientProfileRepresentationUpdated(x.id);
});

bthread("ClientInitialAccessPresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientInitialAccessPresentation(x.id);
  updateClientInitialAccessPresentation(x.id);
  updateClientInitialAccessPresentation(x.id);
  verifyClientInitialAccessPresentationExists(x.id);
  verifyClientInitialAccessPresentationUpdated(x.id);
});

bthread("CredentialRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCredentialRepresentation(x.id);
  updateCredentialRepresentation(x.id);
  updateCredentialRepresentation(x.id);
  verifyCredentialRepresentationExists(x.id);
  verifyCredentialRepresentationUpdated(x.id);
});

bthread("ConfigPropertyRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConfigPropertyRepresentation(x.id);
  updateConfigPropertyRepresentation(x.id);
  updateConfigPropertyRepresentation(x.id);
  verifyConfigPropertyRepresentationExists(x.id);
  verifyConfigPropertyRepresentationUpdated(x.id);
});

bthread("PolicyEnforcementMode lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPolicyEnforcementMode(x.id);
  updatePolicyEnforcementMode(x.id);
  updatePolicyEnforcementMode(x.id);
  verifyPolicyEnforcementModeExists(x.id);
  verifyPolicyEnforcementModeUpdated(x.id);
});

bthread("PolicyEnforcerConfig lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPolicyEnforcerConfig(x.id);
  updatePolicyEnforcerConfig(x.id);
  updatePolicyEnforcerConfig(x.id);
  verifyPolicyEnforcerConfigExists(x.id);
  verifyPolicyEnforcerConfigUpdated(x.id);
});

bthread("ResourceRepresentationOwner lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addResourceRepresentationOwner(x.id);
  updateResourceRepresentationOwner(x.id);
  updateResourceRepresentationOwner(x.id);
  verifyResourceRepresentationOwnerExists(x.id);
  verifyResourceRepresentationOwnerUpdated(x.id);
});

bthread("AuthenticationExecutionRepresentation lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAuthenticationExecutionRepresentation(x.id);
  updateAuthenticationExecutionRepresentation(x.id);
  updateAuthenticationExecutionRepresentation(x.id);
  verifyAuthenticationExecutionRepresentationExists(x.id);
  verifyAuthenticationExecutionRepresentationUpdated(x.id);
});

bthread("ApplicationRepresentation lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApplicationRepresentation(x.id);
  updateApplicationRepresentation(x.id);
  updateApplicationRepresentation(x.id);
  verifyApplicationRepresentationExists(x.id);
  verifyApplicationRepresentationUpdated(x.id);
});

bthread("AuthenticationExecutionInfoRepresentation lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAuthenticationExecutionInfoRepresentation(x.id);
  updateAuthenticationExecutionInfoRepresentation(x.id);
  updateAuthenticationExecutionInfoRepresentation(x.id);
  verifyAuthenticationExecutionInfoRepresentationExists(x.id);
  verifyAuthenticationExecutionInfoRepresentationUpdated(x.id);
});

bthread("CertificateRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCertificateRepresentation(x.id);
  updateCertificateRepresentation(x.id);
  updateCertificateRepresentation(x.id);
  verifyCertificateRepresentationExists(x.id);
  verifyCertificateRepresentationUpdated(x.id);
});

bthread("ClientMappingsRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientMappingsRepresentation(x.id);
  updateClientMappingsRepresentation(x.id);
  updateClientMappingsRepresentation(x.id);
  verifyClientMappingsRepresentationExists(x.id);
  verifyClientMappingsRepresentationUpdated(x.id);
});

bthread("PathCacheConfig lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPathCacheConfig(x.id);
  updatePathCacheConfig(x.id);
  updatePathCacheConfig(x.id);
  verifyPathCacheConfigExists(x.id);
  verifyPathCacheConfigUpdated(x.id);
});

bthread("RequiredActionProviderRepresentation lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRequiredActionProviderRepresentation(x.id);
  updateRequiredActionProviderRepresentation(x.id);
  updateRequiredActionProviderRepresentation(x.id);
  verifyRequiredActionProviderRepresentationExists(x.id);
  verifyRequiredActionProviderRepresentationUpdated(x.id);
});

bthread("IdentityProviderMapperRepresentation lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIdentityProviderMapperRepresentation(x.id);
  updateIdentityProviderMapperRepresentation(x.id);
  updateIdentityProviderMapperRepresentation(x.id);
  verifyIdentityProviderMapperRepresentationExists(x.id);
  verifyIdentityProviderMapperRepresentationUpdated(x.id);
});

bthread("RealmRepresentation lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealmRepresentation(x.id);
  updateRealmRepresentation(x.id);
  updateRealmRepresentation(x.id);
  verifyRealmRepresentationExists(x.id);
  verifyRealmRepresentationUpdated(x.id);
});

bthread("ClientInitialAccessCreatePresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientInitialAccessCreatePresentation(x.id);
  updateClientInitialAccessCreatePresentation(x.id);
  updateClientInitialAccessCreatePresentation(x.id);
  verifyClientInitialAccessCreatePresentationExists(x.id);
  verifyClientInitialAccessCreatePresentationUpdated(x.id);
});

bthread("AccessToken lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAccessToken(x.id);
  updateAccessToken(x.id);
  updateAccessToken(x.id);
  verifyAccessTokenExists(x.id);
  verifyAccessTokenUpdated(x.id);
});

bthread("MappingsRepresentation lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMappingsRepresentation(x.id);
  updateMappingsRepresentation(x.id);
  updateMappingsRepresentation(x.id);
  verifyMappingsRepresentationExists(x.id);
  verifyMappingsRepresentationUpdated(x.id);
});

bthread("UserConsentRepresentation lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserConsentRepresentation(x.id);
  updateUserConsentRepresentation(x.id);
  updateUserConsentRepresentation(x.id);
  verifyUserConsentRepresentationExists(x.id);
  verifyUserConsentRepresentationUpdated(x.id);
});

bthread("AddressClaimSet lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAddressClaimSet(x.id);
  updateAddressClaimSet(x.id);
  updateAddressClaimSet(x.id);
  verifyAddressClaimSetExists(x.id);
  verifyAddressClaimSetUpdated(x.id);
});

bthread("UserFederationProviderRepresentation lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserFederationProviderRepresentation(x.id);
  updateUserFederationProviderRepresentation(x.id);
  updateUserFederationProviderRepresentation(x.id);
  verifyUserFederationProviderRepresentationExists(x.id);
  verifyUserFederationProviderRepresentationUpdated(x.id);
});

bthread("ResourceServerRepresentation lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addResourceServerRepresentation(x.id);
  updateResourceServerRepresentation(x.id);
  updateResourceServerRepresentation(x.id);
  verifyResourceServerRepresentationExists(x.id);
  verifyResourceServerRepresentationUpdated(x.id);
});

bthread("RoleRepresentation lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRoleRepresentation(x.id);
  updateRoleRepresentation(x.id);
  updateRoleRepresentation(x.id);
  verifyRoleRepresentationExists(x.id);
  verifyRoleRepresentationUpdated(x.id);
});

bthread("ComponentExportRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addComponentExportRepresentation(x.id);
  updateComponentExportRepresentation(x.id);
  updateComponentExportRepresentation(x.id);
  verifyComponentExportRepresentationExists(x.id);
  verifyComponentExportRepresentationUpdated(x.id);
});

bthread("ScopeEnforcementMode lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addScopeEnforcementMode(x.id);
  updateScopeEnforcementMode(x.id);
  updateScopeEnforcementMode(x.id);
  verifyScopeEnforcementModeExists(x.id);
  verifyScopeEnforcementModeUpdated(x.id);
});

bthread("GlobalRequestResult lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGlobalRequestResult(x.id);
  updateGlobalRequestResult(x.id);
  updateGlobalRequestResult(x.id);
  verifyGlobalRequestResultExists(x.id);
  verifyGlobalRequestResultUpdated(x.id);
});

bthread("ApplicationRepresentationClaims lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApplicationRepresentationClaims(x.id);
  updateApplicationRepresentationClaims(x.id);
  updateApplicationRepresentationClaims(x.id);
  verifyApplicationRepresentationClaimsExists(x.id);
  verifyApplicationRepresentationClaimsUpdated(x.id);
});

bthread("ClientPolicyConditionRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientPolicyConditionRepresentation(x.id);
  updateClientPolicyConditionRepresentation(x.id);
  updateClientPolicyConditionRepresentation(x.id);
  verifyClientPolicyConditionRepresentationExists(x.id);
  verifyClientPolicyConditionRepresentationUpdated(x.id);
});

bthread("FederatedIdentityRepresentation lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFederatedIdentityRepresentation(x.id);
  updateFederatedIdentityRepresentation(x.id);
  updateFederatedIdentityRepresentation(x.id);
  verifyFederatedIdentityRepresentationExists(x.id);
  verifyFederatedIdentityRepresentationUpdated(x.id);
});

bthread("ClientScopeRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClientScopeRepresentation(x.id);
  updateClientScopeRepresentation(x.id);
  updateClientScopeRepresentation(x.id);
  verifyClientScopeRepresentationExists(x.id);
  verifyClientScopeRepresentationUpdated(x.id);
});

bthread("ClaimRepresentation lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClaimRepresentation(x.id);
  updateClaimRepresentation(x.id);
  updateClaimRepresentation(x.id);
  verifyClaimRepresentationExists(x.id);
  verifyClaimRepresentationUpdated(x.id);
});

bthread("IDToken lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIDToken(x.id);
  updateIDToken(x.id);
  updateIDToken(x.id);
  verifyIDTokenExists(x.id);
  verifyIDTokenUpdated(x.id);
});

// ===== PASSIVE ASSERTIONS =====

bthread("ScopeRepresentation create verification", function () {
  const e = waitForAnyScopeRepresentationAdded();
  block(matchDeleteScopeRepresentation(e.id, ANY), function () {
    verifyScopeRepresentationExists(e.id);
  });
});

bthread("ScopeRepresentation update verification", function () {
  const e = waitForAnyScopeRepresentationUpdated();
  block(matchDeleteScopeRepresentation(e.id, ANY), function () {
    verifyScopeRepresentationUpdated(e.id);
  });
});

bthread("ScopeRepresentation delete verification", function () {
  const e = waitForAnyScopeRepresentationDeleted();
  block(matchAddScopeRepresentation(e.id, ANY), function () {
    verifyScopeRepresentationDoesNotExist(e.id);
  });
});

bthread("MethodConfig create verification", function () {
  const e = waitForAnyMethodConfigAdded();
  block(matchDeleteMethodConfig(e.id, ANY), function () {
    verifyMethodConfigExists(e.id);
  });
});

bthread("MethodConfig update verification", function () {
  const e = waitForAnyMethodConfigUpdated();
  block(matchDeleteMethodConfig(e.id, ANY), function () {
    verifyMethodConfigUpdated(e.id);
  });
});

bthread("MethodConfig delete verification", function () {
  const e = waitForAnyMethodConfigDeleted();
  block(matchAddMethodConfig(e.id, ANY), function () {
    verifyMethodConfigDoesNotExist(e.id);
  });
});

bthread("ResourceRepresentation create verification", function () {
  const e = waitForAnyResourceRepresentationAdded();
  block(matchDeleteResourceRepresentation(e.id, ANY), function () {
    verifyResourceRepresentationExists(e.id);
  });
});

bthread("ResourceRepresentation update verification", function () {
  const e = waitForAnyResourceRepresentationUpdated();
  block(matchDeleteResourceRepresentation(e.id, ANY), function () {
    verifyResourceRepresentationUpdated(e.id);
  });
});

bthread("ResourceRepresentation delete verification", function () {
  const e = waitForAnyResourceRepresentationDeleted();
  block(matchAddResourceRepresentation(e.id, ANY), function () {
    verifyResourceRepresentationDoesNotExist(e.id);
  });
});

bthread("RolesRepresentation create verification", function () {
  const e = waitForAnyRolesRepresentationAdded();
  block(matchDeleteRolesRepresentation(e.id, ANY), function () {
    verifyRolesRepresentationExists(e.id);
  });
});

bthread("RolesRepresentation update verification", function () {
  const e = waitForAnyRolesRepresentationUpdated();
  block(matchDeleteRolesRepresentation(e.id, ANY), function () {
    verifyRolesRepresentationUpdated(e.id);
  });
});

bthread("RolesRepresentation delete verification", function () {
  const e = waitForAnyRolesRepresentationDeleted();
  block(matchAddRolesRepresentation(e.id, ANY), function () {
    verifyRolesRepresentationDoesNotExist(e.id);
  });
});

bthread("ClientPoliciesRepresentation create verification", function () {
  const e = waitForAnyClientPoliciesRepresentationAdded();
  block(matchDeleteClientPoliciesRepresentation(e.id, ANY), function () {
    verifyClientPoliciesRepresentationExists(e.id);
  });
});

bthread("ClientPoliciesRepresentation update verification", function () {
  const e = waitForAnyClientPoliciesRepresentationUpdated();
  block(matchDeleteClientPoliciesRepresentation(e.id, ANY), function () {
    verifyClientPoliciesRepresentationUpdated(e.id);
  });
});

bthread("ClientPoliciesRepresentation delete verification", function () {
  const e = waitForAnyClientPoliciesRepresentationDeleted();
  block(matchAddClientPoliciesRepresentation(e.id, ANY), function () {
    verifyClientPoliciesRepresentationDoesNotExist(e.id);
  });
});

bthread("PathConfig create verification", function () {
  const e = waitForAnyPathConfigAdded();
  block(matchDeletePathConfig(e.id, ANY), function () {
    verifyPathConfigExists(e.id);
  });
});

bthread("PathConfig update verification", function () {
  const e = waitForAnyPathConfigUpdated();
  block(matchDeletePathConfig(e.id, ANY), function () {
    verifyPathConfigUpdated(e.id);
  });
});

bthread("PathConfig delete verification", function () {
  const e = waitForAnyPathConfigDeleted();
  block(matchAddPathConfig(e.id, ANY), function () {
    verifyPathConfigDoesNotExist(e.id);
  });
});

bthread("GroupRepresentation create verification", function () {
  const e = waitForAnyGroupRepresentationAdded();
  block(matchDeleteGroupRepresentation(e.id, ANY), function () {
    verifyGroupRepresentationExists(e.id);
  });
});

bthread("GroupRepresentation update verification", function () {
  const e = waitForAnyGroupRepresentationUpdated();
  block(matchDeleteGroupRepresentation(e.id, ANY), function () {
    verifyGroupRepresentationUpdated(e.id);
  });
});

bthread("GroupRepresentation delete verification", function () {
  const e = waitForAnyGroupRepresentationDeleted();
  block(matchAddGroupRepresentation(e.id, ANY), function () {
    verifyGroupRepresentationDoesNotExist(e.id);
  });
});

bthread("KeyUse create verification", function () {
  const e = waitForAnyKeyUseAdded();
  block(matchDeleteKeyUse(e.id, ANY), function () {
    verifyKeyUseExists(e.id);
  });
});

bthread("KeyUse update verification", function () {
  const e = waitForAnyKeyUseUpdated();
  block(matchDeleteKeyUse(e.id, ANY), function () {
    verifyKeyUseUpdated(e.id);
  });
});

bthread("KeyUse delete verification", function () {
  const e = waitForAnyKeyUseDeleted();
  block(matchAddKeyUse(e.id, ANY), function () {
    verifyKeyUseDoesNotExist(e.id);
  });
});

bthread("ProtocolMapperRepresentation create verification", function () {
  const e = waitForAnyProtocolMapperRepresentationAdded();
  block(matchDeleteProtocolMapperRepresentation(e.id, ANY), function () {
    verifyProtocolMapperRepresentationExists(e.id);
  });
});

bthread("ProtocolMapperRepresentation update verification", function () {
  const e = waitForAnyProtocolMapperRepresentationUpdated();
  block(matchDeleteProtocolMapperRepresentation(e.id, ANY), function () {
    verifyProtocolMapperRepresentationUpdated(e.id);
  });
});

bthread("ProtocolMapperRepresentation delete verification", function () {
  const e = waitForAnyProtocolMapperRepresentationDeleted();
  block(matchAddProtocolMapperRepresentation(e.id, ANY), function () {
    verifyProtocolMapperRepresentationDoesNotExist(e.id);
  });
});

bthread("KeyMetadataRepresentation create verification", function () {
  const e = waitForAnyKeyMetadataRepresentationAdded();
  block(matchDeleteKeyMetadataRepresentation(e.id, ANY), function () {
    verifyKeyMetadataRepresentationExists(e.id);
  });
});

bthread("KeyMetadataRepresentation update verification", function () {
  const e = waitForAnyKeyMetadataRepresentationUpdated();
  block(matchDeleteKeyMetadataRepresentation(e.id, ANY), function () {
    verifyKeyMetadataRepresentationUpdated(e.id);
  });
});

bthread("KeyMetadataRepresentation delete verification", function () {
  const e = waitForAnyKeyMetadataRepresentationDeleted();
  block(matchAddKeyMetadataRepresentation(e.id, ANY), function () {
    verifyKeyMetadataRepresentationDoesNotExist(e.id);
  });
});

bthread("ClientPolicyRepresentation create verification", function () {
  const e = waitForAnyClientPolicyRepresentationAdded();
  block(matchDeleteClientPolicyRepresentation(e.id, ANY), function () {
    verifyClientPolicyRepresentationExists(e.id);
  });
});

bthread("ClientPolicyRepresentation update verification", function () {
  const e = waitForAnyClientPolicyRepresentationUpdated();
  block(matchDeleteClientPolicyRepresentation(e.id, ANY), function () {
    verifyClientPolicyRepresentationUpdated(e.id);
  });
});

bthread("ClientPolicyRepresentation delete verification", function () {
  const e = waitForAnyClientPolicyRepresentationDeleted();
  block(matchAddClientPolicyRepresentation(e.id, ANY), function () {
    verifyClientPolicyRepresentationDoesNotExist(e.id);
  });
});

bthread("Authorization create verification", function () {
  const e = waitForAnyAuthorizationAdded();
  block(matchDeleteAuthorization(e.id, ANY), function () {
    verifyAuthorizationExists(e.id);
  });
});

bthread("Authorization update verification", function () {
  const e = waitForAnyAuthorizationUpdated();
  block(matchDeleteAuthorization(e.id, ANY), function () {
    verifyAuthorizationUpdated(e.id);
  });
});

bthread("Authorization delete verification", function () {
  const e = waitForAnyAuthorizationDeleted();
  block(matchAddAuthorization(e.id, ANY), function () {
    verifyAuthorizationDoesNotExist(e.id);
  });
});

bthread("CertConf create verification", function () {
  const e = waitForAnyCertConfAdded();
  block(matchDeleteCertConf(e.id, ANY), function () {
    verifyCertConfExists(e.id);
  });
});

bthread("CertConf update verification", function () {
  const e = waitForAnyCertConfUpdated();
  block(matchDeleteCertConf(e.id, ANY), function () {
    verifyCertConfUpdated(e.id);
  });
});

bthread("CertConf delete verification", function () {
  const e = waitForAnyCertConfDeleted();
  block(matchAddCertConf(e.id, ANY), function () {
    verifyCertConfDoesNotExist(e.id);
  });
});

bthread("ClientRepresentation create verification", function () {
  const e = waitForAnyClientRepresentationAdded();
  block(matchDeleteClientRepresentation(e.id, ANY), function () {
    verifyClientRepresentationExists(e.id);
  });
});

bthread("ClientRepresentation update verification", function () {
  const e = waitForAnyClientRepresentationUpdated();
  block(matchDeleteClientRepresentation(e.id, ANY), function () {
    verifyClientRepresentationUpdated(e.id);
  });
});

bthread("ClientRepresentation delete verification", function () {
  const e = waitForAnyClientRepresentationDeleted();
  block(matchAddClientRepresentation(e.id, ANY), function () {
    verifyClientRepresentationDoesNotExist(e.id);
  });
});

bthread("InstallationAdapterConfig create verification", function () {
  const e = waitForAnyInstallationAdapterConfigAdded();
  block(matchDeleteInstallationAdapterConfig(e.id, ANY), function () {
    verifyInstallationAdapterConfigExists(e.id);
  });
});

bthread("InstallationAdapterConfig update verification", function () {
  const e = waitForAnyInstallationAdapterConfigUpdated();
  block(matchDeleteInstallationAdapterConfig(e.id, ANY), function () {
    verifyInstallationAdapterConfigUpdated(e.id);
  });
});

bthread("InstallationAdapterConfig delete verification", function () {
  const e = waitForAnyInstallationAdapterConfigDeleted();
  block(matchAddInstallationAdapterConfig(e.id, ANY), function () {
    verifyInstallationAdapterConfigDoesNotExist(e.id);
  });
});

bthread("ClientTemplateRepresentation create verification", function () {
  const e = waitForAnyClientTemplateRepresentationAdded();
  block(matchDeleteClientTemplateRepresentation(e.id, ANY), function () {
    verifyClientTemplateRepresentationExists(e.id);
  });
});

bthread("ClientTemplateRepresentation update verification", function () {
  const e = waitForAnyClientTemplateRepresentationUpdated();
  block(matchDeleteClientTemplateRepresentation(e.id, ANY), function () {
    verifyClientTemplateRepresentationUpdated(e.id);
  });
});

bthread("ClientTemplateRepresentation delete verification", function () {
  const e = waitForAnyClientTemplateRepresentationDeleted();
  block(matchAddClientTemplateRepresentation(e.id, ANY), function () {
    verifyClientTemplateRepresentationDoesNotExist(e.id);
  });
});

bthread("PolicyRepresentation create verification", function () {
  const e = waitForAnyPolicyRepresentationAdded();
  block(matchDeletePolicyRepresentation(e.id, ANY), function () {
    verifyPolicyRepresentationExists(e.id);
  });
});

bthread("PolicyRepresentation update verification", function () {
  const e = waitForAnyPolicyRepresentationUpdated();
  block(matchDeletePolicyRepresentation(e.id, ANY), function () {
    verifyPolicyRepresentationUpdated(e.id);
  });
});

bthread("PolicyRepresentation delete verification", function () {
  const e = waitForAnyPolicyRepresentationDeleted();
  block(matchAddPolicyRepresentation(e.id, ANY), function () {
    verifyPolicyRepresentationDoesNotExist(e.id);
  });
});

bthread("ClientPolicyExecutorRepresentation create verification", function () {
  const e = waitForAnyClientPolicyExecutorRepresentationAdded();
  block(matchDeleteClientPolicyExecutorRepresentation(e.id, ANY), function () {
    verifyClientPolicyExecutorRepresentationExists(e.id);
  });
});

bthread("ClientPolicyExecutorRepresentation update verification", function () {
  const e = waitForAnyClientPolicyExecutorRepresentationUpdated();
  block(matchDeleteClientPolicyExecutorRepresentation(e.id, ANY), function () {
    verifyClientPolicyExecutorRepresentationUpdated(e.id);
  });
});

bthread("ClientPolicyExecutorRepresentation delete verification", function () {
  const e = waitForAnyClientPolicyExecutorRepresentationDeleted();
  block(matchAddClientPolicyExecutorRepresentation(e.id, ANY), function () {
    verifyClientPolicyExecutorRepresentationDoesNotExist(e.id);
  });
});

bthread("UserFederationMapperRepresentation create verification", function () {
  const e = waitForAnyUserFederationMapperRepresentationAdded();
  block(matchDeleteUserFederationMapperRepresentation(e.id, ANY), function () {
    verifyUserFederationMapperRepresentationExists(e.id);
  });
});

bthread("UserFederationMapperRepresentation update verification", function () {
  const e = waitForAnyUserFederationMapperRepresentationUpdated();
  block(matchDeleteUserFederationMapperRepresentation(e.id, ANY), function () {
    verifyUserFederationMapperRepresentationUpdated(e.id);
  });
});

bthread("UserFederationMapperRepresentation delete verification", function () {
  const e = waitForAnyUserFederationMapperRepresentationDeleted();
  block(matchAddUserFederationMapperRepresentation(e.id, ANY), function () {
    verifyUserFederationMapperRepresentationDoesNotExist(e.id);
  });
});

bthread("AuthenticationFlowRepresentation create verification", function () {
  const e = waitForAnyAuthenticationFlowRepresentationAdded();
  block(matchDeleteAuthenticationFlowRepresentation(e.id, ANY), function () {
    verifyAuthenticationFlowRepresentationExists(e.id);
  });
});

bthread("AuthenticationFlowRepresentation update verification", function () {
  const e = waitForAnyAuthenticationFlowRepresentationUpdated();
  block(matchDeleteAuthenticationFlowRepresentation(e.id, ANY), function () {
    verifyAuthenticationFlowRepresentationUpdated(e.id);
  });
});

bthread("AuthenticationFlowRepresentation delete verification", function () {
  const e = waitForAnyAuthenticationFlowRepresentationDeleted();
  block(matchAddAuthenticationFlowRepresentation(e.id, ANY), function () {
    verifyAuthenticationFlowRepresentationDoesNotExist(e.id);
  });
});

bthread("IdentityProviderMapperTypeRepresentation create verification", function () {
  const e = waitForAnyIdentityProviderMapperTypeRepresentationAdded();
  block(matchDeleteIdentityProviderMapperTypeRepresentation(e.id, ANY), function () {
    verifyIdentityProviderMapperTypeRepresentationExists(e.id);
  });
});

bthread("IdentityProviderMapperTypeRepresentation update verification", function () {
  const e = waitForAnyIdentityProviderMapperTypeRepresentationUpdated();
  block(matchDeleteIdentityProviderMapperTypeRepresentation(e.id, ANY), function () {
    verifyIdentityProviderMapperTypeRepresentationUpdated(e.id);
  });
});

bthread("IdentityProviderMapperTypeRepresentation delete verification", function () {
  const e = waitForAnyIdentityProviderMapperTypeRepresentationDeleted();
  block(matchAddIdentityProviderMapperTypeRepresentation(e.id, ANY), function () {
    verifyIdentityProviderMapperTypeRepresentationDoesNotExist(e.id);
  });
});

bthread("Permission create verification", function () {
  const e = waitForAnyPermissionAdded();
  block(matchDeletePermission(e.id, ANY), function () {
    verifyPermissionExists(e.id);
  });
});

bthread("Permission update verification", function () {
  const e = waitForAnyPermissionUpdated();
  block(matchDeletePermission(e.id, ANY), function () {
    verifyPermissionUpdated(e.id);
  });
});

bthread("Permission delete verification", function () {
  const e = waitForAnyPermissionDeleted();
  block(matchAddPermission(e.id, ANY), function () {
    verifyPermissionDoesNotExist(e.id);
  });
});

bthread("EnforcementMode create verification", function () {
  const e = waitForAnyEnforcementModeAdded();
  block(matchDeleteEnforcementMode(e.id, ANY), function () {
    verifyEnforcementModeExists(e.id);
  });
});

bthread("EnforcementMode update verification", function () {
  const e = waitForAnyEnforcementModeUpdated();
  block(matchDeleteEnforcementMode(e.id, ANY), function () {
    verifyEnforcementModeUpdated(e.id);
  });
});

bthread("EnforcementMode delete verification", function () {
  const e = waitForAnyEnforcementModeDeleted();
  block(matchAddEnforcementMode(e.id, ANY), function () {
    verifyEnforcementModeDoesNotExist(e.id);
  });
});

bthread("KeysMetadataRepresentation create verification", function () {
  const e = waitForAnyKeysMetadataRepresentationAdded();
  block(matchDeleteKeysMetadataRepresentation(e.id, ANY), function () {
    verifyKeysMetadataRepresentationExists(e.id);
  });
});

bthread("KeysMetadataRepresentation update verification", function () {
  const e = waitForAnyKeysMetadataRepresentationUpdated();
  block(matchDeleteKeysMetadataRepresentation(e.id, ANY), function () {
    verifyKeysMetadataRepresentationUpdated(e.id);
  });
});

bthread("KeysMetadataRepresentation delete verification", function () {
  const e = waitForAnyKeysMetadataRepresentationDeleted();
  block(matchAddKeysMetadataRepresentation(e.id, ANY), function () {
    verifyKeysMetadataRepresentationDoesNotExist(e.id);
  });
});

bthread("ManagementPermissionReference create verification", function () {
  const e = waitForAnyManagementPermissionReferenceAdded();
  block(matchDeleteManagementPermissionReference(e.id, ANY), function () {
    verifyManagementPermissionReferenceExists(e.id);
  });
});

bthread("ManagementPermissionReference update verification", function () {
  const e = waitForAnyManagementPermissionReferenceUpdated();
  block(matchDeleteManagementPermissionReference(e.id, ANY), function () {
    verifyManagementPermissionReferenceUpdated(e.id);
  });
});

bthread("ManagementPermissionReference delete verification", function () {
  const e = waitForAnyManagementPermissionReferenceDeleted();
  block(matchAddManagementPermissionReference(e.id, ANY), function () {
    verifyManagementPermissionReferenceDoesNotExist(e.id);
  });
});

bthread("AuthenticatorConfigInfoRepresentation create verification", function () {
  const e = waitForAnyAuthenticatorConfigInfoRepresentationAdded();
  block(matchDeleteAuthenticatorConfigInfoRepresentation(e.id, ANY), function () {
    verifyAuthenticatorConfigInfoRepresentationExists(e.id);
  });
});

bthread("AuthenticatorConfigInfoRepresentation update verification", function () {
  const e = waitForAnyAuthenticatorConfigInfoRepresentationUpdated();
  block(matchDeleteAuthenticatorConfigInfoRepresentation(e.id, ANY), function () {
    verifyAuthenticatorConfigInfoRepresentationUpdated(e.id);
  });
});

bthread("AuthenticatorConfigInfoRepresentation delete verification", function () {
  const e = waitForAnyAuthenticatorConfigInfoRepresentationDeleted();
  block(matchAddAuthenticatorConfigInfoRepresentation(e.id, ANY), function () {
    verifyAuthenticatorConfigInfoRepresentationDoesNotExist(e.id);
  });
});

bthread("AuthenticatorConfigRepresentation create verification", function () {
  const e = waitForAnyAuthenticatorConfigRepresentationAdded();
  block(matchDeleteAuthenticatorConfigRepresentation(e.id, ANY), function () {
    verifyAuthenticatorConfigRepresentationExists(e.id);
  });
});

bthread("AuthenticatorConfigRepresentation update verification", function () {
  const e = waitForAnyAuthenticatorConfigRepresentationUpdated();
  block(matchDeleteAuthenticatorConfigRepresentation(e.id, ANY), function () {
    verifyAuthenticatorConfigRepresentationUpdated(e.id);
  });
});

bthread("AuthenticatorConfigRepresentation delete verification", function () {
  const e = waitForAnyAuthenticatorConfigRepresentationDeleted();
  block(matchAddAuthenticatorConfigRepresentation(e.id, ANY), function () {
    verifyAuthenticatorConfigRepresentationDoesNotExist(e.id);
  });
});

bthread("DecisionStrategy create verification", function () {
  const e = waitForAnyDecisionStrategyAdded();
  block(matchDeleteDecisionStrategy(e.id, ANY), function () {
    verifyDecisionStrategyExists(e.id);
  });
});

bthread("DecisionStrategy update verification", function () {
  const e = waitForAnyDecisionStrategyUpdated();
  block(matchDeleteDecisionStrategy(e.id, ANY), function () {
    verifyDecisionStrategyUpdated(e.id);
  });
});

bthread("DecisionStrategy delete verification", function () {
  const e = waitForAnyDecisionStrategyDeleted();
  block(matchAddDecisionStrategy(e.id, ANY), function () {
    verifyDecisionStrategyDoesNotExist(e.id);
  });
});

bthread("Logic create verification", function () {
  const e = waitForAnyLogicAdded();
  block(matchDeleteLogic(e.id, ANY), function () {
    verifyLogicExists(e.id);
  });
});

bthread("Logic update verification", function () {
  const e = waitForAnyLogicUpdated();
  block(matchDeleteLogic(e.id, ANY), function () {
    verifyLogicUpdated(e.id);
  });
});

bthread("Logic delete verification", function () {
  const e = waitForAnyLogicDeleted();
  block(matchAddLogic(e.id, ANY), function () {
    verifyLogicDoesNotExist(e.id);
  });
});

bthread("UserRepresentation create verification", function () {
  const e = waitForAnyUserRepresentationAdded();
  block(matchDeleteUserRepresentation(e.id, ANY), function () {
    verifyUserRepresentationExists(e.id);
  });
});

bthread("UserRepresentation update verification", function () {
  const e = waitForAnyUserRepresentationUpdated();
  block(matchDeleteUserRepresentation(e.id, ANY), function () {
    verifyUserRepresentationUpdated(e.id);
  });
});

bthread("UserRepresentation delete verification", function () {
  const e = waitForAnyUserRepresentationDeleted();
  block(matchAddUserRepresentation(e.id, ANY), function () {
    verifyUserRepresentationDoesNotExist(e.id);
  });
});

bthread("ClientProfilesRepresentation create verification", function () {
  const e = waitForAnyClientProfilesRepresentationAdded();
  block(matchDeleteClientProfilesRepresentation(e.id, ANY), function () {
    verifyClientProfilesRepresentationExists(e.id);
  });
});

bthread("ClientProfilesRepresentation update verification", function () {
  const e = waitForAnyClientProfilesRepresentationUpdated();
  block(matchDeleteClientProfilesRepresentation(e.id, ANY), function () {
    verifyClientProfilesRepresentationUpdated(e.id);
  });
});

bthread("ClientProfilesRepresentation delete verification", function () {
  const e = waitForAnyClientProfilesRepresentationDeleted();
  block(matchAddClientProfilesRepresentation(e.id, ANY), function () {
    verifyClientProfilesRepresentationDoesNotExist(e.id);
  });
});

bthread("KeyStoreConfig create verification", function () {
  const e = waitForAnyKeyStoreConfigAdded();
  block(matchDeleteKeyStoreConfig(e.id, ANY), function () {
    verifyKeyStoreConfigExists(e.id);
  });
});

bthread("KeyStoreConfig update verification", function () {
  const e = waitForAnyKeyStoreConfigUpdated();
  block(matchDeleteKeyStoreConfig(e.id, ANY), function () {
    verifyKeyStoreConfigUpdated(e.id);
  });
});

bthread("KeyStoreConfig delete verification", function () {
  const e = waitForAnyKeyStoreConfigDeleted();
  block(matchAddKeyStoreConfig(e.id, ANY), function () {
    verifyKeyStoreConfigDoesNotExist(e.id);
  });
});

bthread("ComponentRepresentation create verification", function () {
  const e = waitForAnyComponentRepresentationAdded();
  block(matchDeleteComponentRepresentation(e.id, ANY), function () {
    verifyComponentRepresentationExists(e.id);
  });
});

bthread("ComponentRepresentation update verification", function () {
  const e = waitForAnyComponentRepresentationUpdated();
  block(matchDeleteComponentRepresentation(e.id, ANY), function () {
    verifyComponentRepresentationUpdated(e.id);
  });
});

bthread("ComponentRepresentation delete verification", function () {
  const e = waitForAnyComponentRepresentationDeleted();
  block(matchAddComponentRepresentation(e.id, ANY), function () {
    verifyComponentRepresentationDoesNotExist(e.id);
  });
});

bthread("PublishedRealmRepresentation create verification", function () {
  const e = waitForAnyPublishedRealmRepresentationAdded();
  block(matchDeletePublishedRealmRepresentation(e.id, ANY), function () {
    verifyPublishedRealmRepresentationExists(e.id);
  });
});

bthread("PublishedRealmRepresentation update verification", function () {
  const e = waitForAnyPublishedRealmRepresentationUpdated();
  block(matchDeletePublishedRealmRepresentation(e.id, ANY), function () {
    verifyPublishedRealmRepresentationUpdated(e.id);
  });
});

bthread("PublishedRealmRepresentation delete verification", function () {
  const e = waitForAnyPublishedRealmRepresentationDeleted();
  block(matchAddPublishedRealmRepresentation(e.id, ANY), function () {
    verifyPublishedRealmRepresentationDoesNotExist(e.id);
  });
});

bthread("SocialLinkRepresentation create verification", function () {
  const e = waitForAnySocialLinkRepresentationAdded();
  block(matchDeleteSocialLinkRepresentation(e.id, ANY), function () {
    verifySocialLinkRepresentationExists(e.id);
  });
});

bthread("SocialLinkRepresentation update verification", function () {
  const e = waitForAnySocialLinkRepresentationUpdated();
  block(matchDeleteSocialLinkRepresentation(e.id, ANY), function () {
    verifySocialLinkRepresentationUpdated(e.id);
  });
});

bthread("SocialLinkRepresentation delete verification", function () {
  const e = waitForAnySocialLinkRepresentationDeleted();
  block(matchAddSocialLinkRepresentation(e.id, ANY), function () {
    verifySocialLinkRepresentationDoesNotExist(e.id);
  });
});

bthread("AuthenticationExecutionExportRepresentation create verification", function () {
  const e = waitForAnyAuthenticationExecutionExportRepresentationAdded();
  block(matchDeleteAuthenticationExecutionExportRepresentation(e.id, ANY), function () {
    verifyAuthenticationExecutionExportRepresentationExists(e.id);
  });
});

bthread("AuthenticationExecutionExportRepresentation update verification", function () {
  const e = waitForAnyAuthenticationExecutionExportRepresentationUpdated();
  block(matchDeleteAuthenticationExecutionExportRepresentation(e.id, ANY), function () {
    verifyAuthenticationExecutionExportRepresentationUpdated(e.id);
  });
});

bthread("AuthenticationExecutionExportRepresentation delete verification", function () {
  const e = waitForAnyAuthenticationExecutionExportRepresentationDeleted();
  block(matchAddAuthenticationExecutionExportRepresentation(e.id, ANY), function () {
    verifyAuthenticationExecutionExportRepresentationDoesNotExist(e.id);
  });
});

bthread("IdentityProviderRepresentation create verification", function () {
  const e = waitForAnyIdentityProviderRepresentationAdded();
  block(matchDeleteIdentityProviderRepresentation(e.id, ANY), function () {
    verifyIdentityProviderRepresentationExists(e.id);
  });
});

bthread("IdentityProviderRepresentation update verification", function () {
  const e = waitForAnyIdentityProviderRepresentationUpdated();
  block(matchDeleteIdentityProviderRepresentation(e.id, ANY), function () {
    verifyIdentityProviderRepresentationUpdated(e.id);
  });
});

bthread("IdentityProviderRepresentation delete verification", function () {
  const e = waitForAnyIdentityProviderRepresentationDeleted();
  block(matchAddIdentityProviderRepresentation(e.id, ANY), function () {
    verifyIdentityProviderRepresentationDoesNotExist(e.id);
  });
});

bthread("OAuthClientRepresentation create verification", function () {
  const e = waitForAnyOAuthClientRepresentationAdded();
  block(matchDeleteOAuthClientRepresentation(e.id, ANY), function () {
    verifyOAuthClientRepresentationExists(e.id);
  });
});

bthread("OAuthClientRepresentation update verification", function () {
  const e = waitForAnyOAuthClientRepresentationUpdated();
  block(matchDeleteOAuthClientRepresentation(e.id, ANY), function () {
    verifyOAuthClientRepresentationUpdated(e.id);
  });
});

bthread("OAuthClientRepresentation delete verification", function () {
  const e = waitForAnyOAuthClientRepresentationDeleted();
  block(matchAddOAuthClientRepresentation(e.id, ANY), function () {
    verifyOAuthClientRepresentationDoesNotExist(e.id);
  });
});

bthread("Access create verification", function () {
  const e = waitForAnyAccessAdded();
  block(matchDeleteAccess(e.id, ANY), function () {
    verifyAccessExists(e.id);
  });
});

bthread("Access update verification", function () {
  const e = waitForAnyAccessUpdated();
  block(matchDeleteAccess(e.id, ANY), function () {
    verifyAccessUpdated(e.id);
  });
});

bthread("Access delete verification", function () {
  const e = waitForAnyAccessDeleted();
  block(matchAddAccess(e.id, ANY), function () {
    verifyAccessDoesNotExist(e.id);
  });
});

bthread("ResourceOwnerRepresentation create verification", function () {
  const e = waitForAnyResourceOwnerRepresentationAdded();
  block(matchDeleteResourceOwnerRepresentation(e.id, ANY), function () {
    verifyResourceOwnerRepresentationExists(e.id);
  });
});

bthread("ResourceOwnerRepresentation update verification", function () {
  const e = waitForAnyResourceOwnerRepresentationUpdated();
  block(matchDeleteResourceOwnerRepresentation(e.id, ANY), function () {
    verifyResourceOwnerRepresentationUpdated(e.id);
  });
});

bthread("ResourceOwnerRepresentation delete verification", function () {
  const e = waitForAnyResourceOwnerRepresentationDeleted();
  block(matchAddResourceOwnerRepresentation(e.id, ANY), function () {
    verifyResourceOwnerRepresentationDoesNotExist(e.id);
  });
});

bthread("ScopeMappingRepresentation create verification", function () {
  const e = waitForAnyScopeMappingRepresentationAdded();
  block(matchDeleteScopeMappingRepresentation(e.id, ANY), function () {
    verifyScopeMappingRepresentationExists(e.id);
  });
});

bthread("ScopeMappingRepresentation update verification", function () {
  const e = waitForAnyScopeMappingRepresentationUpdated();
  block(matchDeleteScopeMappingRepresentation(e.id, ANY), function () {
    verifyScopeMappingRepresentationUpdated(e.id);
  });
});

bthread("ScopeMappingRepresentation delete verification", function () {
  const e = waitForAnyScopeMappingRepresentationDeleted();
  block(matchAddScopeMappingRepresentation(e.id, ANY), function () {
    verifyScopeMappingRepresentationDoesNotExist(e.id);
  });
});

bthread("Composites create verification", function () {
  const e = waitForAnyCompositesAdded();
  block(matchDeleteComposites(e.id, ANY), function () {
    verifyCompositesExists(e.id);
  });
});

bthread("Composites update verification", function () {
  const e = waitForAnyCompositesUpdated();
  block(matchDeleteComposites(e.id, ANY), function () {
    verifyCompositesUpdated(e.id);
  });
});

bthread("Composites delete verification", function () {
  const e = waitForAnyCompositesDeleted();
  block(matchAddComposites(e.id, ANY), function () {
    verifyCompositesDoesNotExist(e.id);
  });
});

bthread("RealmEventsConfigRepresentation create verification", function () {
  const e = waitForAnyRealmEventsConfigRepresentationAdded();
  block(matchDeleteRealmEventsConfigRepresentation(e.id, ANY), function () {
    verifyRealmEventsConfigRepresentationExists(e.id);
  });
});

bthread("RealmEventsConfigRepresentation update verification", function () {
  const e = waitForAnyRealmEventsConfigRepresentationUpdated();
  block(matchDeleteRealmEventsConfigRepresentation(e.id, ANY), function () {
    verifyRealmEventsConfigRepresentationUpdated(e.id);
  });
});

bthread("RealmEventsConfigRepresentation delete verification", function () {
  const e = waitForAnyRealmEventsConfigRepresentationDeleted();
  block(matchAddRealmEventsConfigRepresentation(e.id, ANY), function () {
    verifyRealmEventsConfigRepresentationDoesNotExist(e.id);
  });
});

bthread("ClientProfileRepresentation create verification", function () {
  const e = waitForAnyClientProfileRepresentationAdded();
  block(matchDeleteClientProfileRepresentation(e.id, ANY), function () {
    verifyClientProfileRepresentationExists(e.id);
  });
});

bthread("ClientProfileRepresentation update verification", function () {
  const e = waitForAnyClientProfileRepresentationUpdated();
  block(matchDeleteClientProfileRepresentation(e.id, ANY), function () {
    verifyClientProfileRepresentationUpdated(e.id);
  });
});

bthread("ClientProfileRepresentation delete verification", function () {
  const e = waitForAnyClientProfileRepresentationDeleted();
  block(matchAddClientProfileRepresentation(e.id, ANY), function () {
    verifyClientProfileRepresentationDoesNotExist(e.id);
  });
});

bthread("ClientInitialAccessPresentation create verification", function () {
  const e = waitForAnyClientInitialAccessPresentationAdded();
  block(matchDeleteClientInitialAccessPresentation(e.id, ANY), function () {
    verifyClientInitialAccessPresentationExists(e.id);
  });
});

bthread("ClientInitialAccessPresentation update verification", function () {
  const e = waitForAnyClientInitialAccessPresentationUpdated();
  block(matchDeleteClientInitialAccessPresentation(e.id, ANY), function () {
    verifyClientInitialAccessPresentationUpdated(e.id);
  });
});

bthread("ClientInitialAccessPresentation delete verification", function () {
  const e = waitForAnyClientInitialAccessPresentationDeleted();
  block(matchAddClientInitialAccessPresentation(e.id, ANY), function () {
    verifyClientInitialAccessPresentationDoesNotExist(e.id);
  });
});

bthread("CredentialRepresentation create verification", function () {
  const e = waitForAnyCredentialRepresentationAdded();
  block(matchDeleteCredentialRepresentation(e.id, ANY), function () {
    verifyCredentialRepresentationExists(e.id);
  });
});

bthread("CredentialRepresentation update verification", function () {
  const e = waitForAnyCredentialRepresentationUpdated();
  block(matchDeleteCredentialRepresentation(e.id, ANY), function () {
    verifyCredentialRepresentationUpdated(e.id);
  });
});

bthread("CredentialRepresentation delete verification", function () {
  const e = waitForAnyCredentialRepresentationDeleted();
  block(matchAddCredentialRepresentation(e.id, ANY), function () {
    verifyCredentialRepresentationDoesNotExist(e.id);
  });
});

bthread("ConfigPropertyRepresentation create verification", function () {
  const e = waitForAnyConfigPropertyRepresentationAdded();
  block(matchDeleteConfigPropertyRepresentation(e.id, ANY), function () {
    verifyConfigPropertyRepresentationExists(e.id);
  });
});

bthread("ConfigPropertyRepresentation update verification", function () {
  const e = waitForAnyConfigPropertyRepresentationUpdated();
  block(matchDeleteConfigPropertyRepresentation(e.id, ANY), function () {
    verifyConfigPropertyRepresentationUpdated(e.id);
  });
});

bthread("ConfigPropertyRepresentation delete verification", function () {
  const e = waitForAnyConfigPropertyRepresentationDeleted();
  block(matchAddConfigPropertyRepresentation(e.id, ANY), function () {
    verifyConfigPropertyRepresentationDoesNotExist(e.id);
  });
});

bthread("PolicyEnforcementMode create verification", function () {
  const e = waitForAnyPolicyEnforcementModeAdded();
  block(matchDeletePolicyEnforcementMode(e.id, ANY), function () {
    verifyPolicyEnforcementModeExists(e.id);
  });
});

bthread("PolicyEnforcementMode update verification", function () {
  const e = waitForAnyPolicyEnforcementModeUpdated();
  block(matchDeletePolicyEnforcementMode(e.id, ANY), function () {
    verifyPolicyEnforcementModeUpdated(e.id);
  });
});

bthread("PolicyEnforcementMode delete verification", function () {
  const e = waitForAnyPolicyEnforcementModeDeleted();
  block(matchAddPolicyEnforcementMode(e.id, ANY), function () {
    verifyPolicyEnforcementModeDoesNotExist(e.id);
  });
});

bthread("PolicyEnforcerConfig create verification", function () {
  const e = waitForAnyPolicyEnforcerConfigAdded();
  block(matchDeletePolicyEnforcerConfig(e.id, ANY), function () {
    verifyPolicyEnforcerConfigExists(e.id);
  });
});

bthread("PolicyEnforcerConfig update verification", function () {
  const e = waitForAnyPolicyEnforcerConfigUpdated();
  block(matchDeletePolicyEnforcerConfig(e.id, ANY), function () {
    verifyPolicyEnforcerConfigUpdated(e.id);
  });
});

bthread("PolicyEnforcerConfig delete verification", function () {
  const e = waitForAnyPolicyEnforcerConfigDeleted();
  block(matchAddPolicyEnforcerConfig(e.id, ANY), function () {
    verifyPolicyEnforcerConfigDoesNotExist(e.id);
  });
});

bthread("ResourceRepresentationOwner create verification", function () {
  const e = waitForAnyResourceRepresentationOwnerAdded();
  block(matchDeleteResourceRepresentationOwner(e.id, ANY), function () {
    verifyResourceRepresentationOwnerExists(e.id);
  });
});

bthread("ResourceRepresentationOwner update verification", function () {
  const e = waitForAnyResourceRepresentationOwnerUpdated();
  block(matchDeleteResourceRepresentationOwner(e.id, ANY), function () {
    verifyResourceRepresentationOwnerUpdated(e.id);
  });
});

bthread("ResourceRepresentationOwner delete verification", function () {
  const e = waitForAnyResourceRepresentationOwnerDeleted();
  block(matchAddResourceRepresentationOwner(e.id, ANY), function () {
    verifyResourceRepresentationOwnerDoesNotExist(e.id);
  });
});

bthread("AuthenticationExecutionRepresentation create verification", function () {
  const e = waitForAnyAuthenticationExecutionRepresentationAdded();
  block(matchDeleteAuthenticationExecutionRepresentation(e.id, ANY), function () {
    verifyAuthenticationExecutionRepresentationExists(e.id);
  });
});

bthread("AuthenticationExecutionRepresentation update verification", function () {
  const e = waitForAnyAuthenticationExecutionRepresentationUpdated();
  block(matchDeleteAuthenticationExecutionRepresentation(e.id, ANY), function () {
    verifyAuthenticationExecutionRepresentationUpdated(e.id);
  });
});

bthread("AuthenticationExecutionRepresentation delete verification", function () {
  const e = waitForAnyAuthenticationExecutionRepresentationDeleted();
  block(matchAddAuthenticationExecutionRepresentation(e.id, ANY), function () {
    verifyAuthenticationExecutionRepresentationDoesNotExist(e.id);
  });
});

bthread("ApplicationRepresentation create verification", function () {
  const e = waitForAnyApplicationRepresentationAdded();
  block(matchDeleteApplicationRepresentation(e.id, ANY), function () {
    verifyApplicationRepresentationExists(e.id);
  });
});

bthread("ApplicationRepresentation update verification", function () {
  const e = waitForAnyApplicationRepresentationUpdated();
  block(matchDeleteApplicationRepresentation(e.id, ANY), function () {
    verifyApplicationRepresentationUpdated(e.id);
  });
});

bthread("ApplicationRepresentation delete verification", function () {
  const e = waitForAnyApplicationRepresentationDeleted();
  block(matchAddApplicationRepresentation(e.id, ANY), function () {
    verifyApplicationRepresentationDoesNotExist(e.id);
  });
});

bthread("AuthenticationExecutionInfoRepresentation create verification", function () {
  const e = waitForAnyAuthenticationExecutionInfoRepresentationAdded();
  block(matchDeleteAuthenticationExecutionInfoRepresentation(e.id, ANY), function () {
    verifyAuthenticationExecutionInfoRepresentationExists(e.id);
  });
});

bthread("AuthenticationExecutionInfoRepresentation update verification", function () {
  const e = waitForAnyAuthenticationExecutionInfoRepresentationUpdated();
  block(matchDeleteAuthenticationExecutionInfoRepresentation(e.id, ANY), function () {
    verifyAuthenticationExecutionInfoRepresentationUpdated(e.id);
  });
});

bthread("AuthenticationExecutionInfoRepresentation delete verification", function () {
  const e = waitForAnyAuthenticationExecutionInfoRepresentationDeleted();
  block(matchAddAuthenticationExecutionInfoRepresentation(e.id, ANY), function () {
    verifyAuthenticationExecutionInfoRepresentationDoesNotExist(e.id);
  });
});

bthread("CertificateRepresentation create verification", function () {
  const e = waitForAnyCertificateRepresentationAdded();
  block(matchDeleteCertificateRepresentation(e.id, ANY), function () {
    verifyCertificateRepresentationExists(e.id);
  });
});

bthread("CertificateRepresentation update verification", function () {
  const e = waitForAnyCertificateRepresentationUpdated();
  block(matchDeleteCertificateRepresentation(e.id, ANY), function () {
    verifyCertificateRepresentationUpdated(e.id);
  });
});

bthread("CertificateRepresentation delete verification", function () {
  const e = waitForAnyCertificateRepresentationDeleted();
  block(matchAddCertificateRepresentation(e.id, ANY), function () {
    verifyCertificateRepresentationDoesNotExist(e.id);
  });
});

bthread("ClientMappingsRepresentation create verification", function () {
  const e = waitForAnyClientMappingsRepresentationAdded();
  block(matchDeleteClientMappingsRepresentation(e.id, ANY), function () {
    verifyClientMappingsRepresentationExists(e.id);
  });
});

bthread("ClientMappingsRepresentation update verification", function () {
  const e = waitForAnyClientMappingsRepresentationUpdated();
  block(matchDeleteClientMappingsRepresentation(e.id, ANY), function () {
    verifyClientMappingsRepresentationUpdated(e.id);
  });
});

bthread("ClientMappingsRepresentation delete verification", function () {
  const e = waitForAnyClientMappingsRepresentationDeleted();
  block(matchAddClientMappingsRepresentation(e.id, ANY), function () {
    verifyClientMappingsRepresentationDoesNotExist(e.id);
  });
});

bthread("PathCacheConfig create verification", function () {
  const e = waitForAnyPathCacheConfigAdded();
  block(matchDeletePathCacheConfig(e.id, ANY), function () {
    verifyPathCacheConfigExists(e.id);
  });
});

bthread("PathCacheConfig update verification", function () {
  const e = waitForAnyPathCacheConfigUpdated();
  block(matchDeletePathCacheConfig(e.id, ANY), function () {
    verifyPathCacheConfigUpdated(e.id);
  });
});

bthread("PathCacheConfig delete verification", function () {
  const e = waitForAnyPathCacheConfigDeleted();
  block(matchAddPathCacheConfig(e.id, ANY), function () {
    verifyPathCacheConfigDoesNotExist(e.id);
  });
});

bthread("RequiredActionProviderRepresentation create verification", function () {
  const e = waitForAnyRequiredActionProviderRepresentationAdded();
  block(matchDeleteRequiredActionProviderRepresentation(e.id, ANY), function () {
    verifyRequiredActionProviderRepresentationExists(e.id);
  });
});

bthread("RequiredActionProviderRepresentation update verification", function () {
  const e = waitForAnyRequiredActionProviderRepresentationUpdated();
  block(matchDeleteRequiredActionProviderRepresentation(e.id, ANY), function () {
    verifyRequiredActionProviderRepresentationUpdated(e.id);
  });
});

bthread("RequiredActionProviderRepresentation delete verification", function () {
  const e = waitForAnyRequiredActionProviderRepresentationDeleted();
  block(matchAddRequiredActionProviderRepresentation(e.id, ANY), function () {
    verifyRequiredActionProviderRepresentationDoesNotExist(e.id);
  });
});

bthread("IdentityProviderMapperRepresentation create verification", function () {
  const e = waitForAnyIdentityProviderMapperRepresentationAdded();
  block(matchDeleteIdentityProviderMapperRepresentation(e.id, ANY), function () {
    verifyIdentityProviderMapperRepresentationExists(e.id);
  });
});

bthread("IdentityProviderMapperRepresentation update verification", function () {
  const e = waitForAnyIdentityProviderMapperRepresentationUpdated();
  block(matchDeleteIdentityProviderMapperRepresentation(e.id, ANY), function () {
    verifyIdentityProviderMapperRepresentationUpdated(e.id);
  });
});

bthread("IdentityProviderMapperRepresentation delete verification", function () {
  const e = waitForAnyIdentityProviderMapperRepresentationDeleted();
  block(matchAddIdentityProviderMapperRepresentation(e.id, ANY), function () {
    verifyIdentityProviderMapperRepresentationDoesNotExist(e.id);
  });
});

bthread("RealmRepresentation create verification", function () {
  const e = waitForAnyRealmRepresentationAdded();
  block(matchDeleteRealmRepresentation(e.id, ANY), function () {
    verifyRealmRepresentationExists(e.id);
  });
});

bthread("RealmRepresentation update verification", function () {
  const e = waitForAnyRealmRepresentationUpdated();
  block(matchDeleteRealmRepresentation(e.id, ANY), function () {
    verifyRealmRepresentationUpdated(e.id);
  });
});

bthread("RealmRepresentation delete verification", function () {
  const e = waitForAnyRealmRepresentationDeleted();
  block(matchAddRealmRepresentation(e.id, ANY), function () {
    verifyRealmRepresentationDoesNotExist(e.id);
  });
});

bthread("ClientInitialAccessCreatePresentation create verification", function () {
  const e = waitForAnyClientInitialAccessCreatePresentationAdded();
  block(matchDeleteClientInitialAccessCreatePresentation(e.id, ANY), function () {
    verifyClientInitialAccessCreatePresentationExists(e.id);
  });
});

bthread("ClientInitialAccessCreatePresentation update verification", function () {
  const e = waitForAnyClientInitialAccessCreatePresentationUpdated();
  block(matchDeleteClientInitialAccessCreatePresentation(e.id, ANY), function () {
    verifyClientInitialAccessCreatePresentationUpdated(e.id);
  });
});

bthread("ClientInitialAccessCreatePresentation delete verification", function () {
  const e = waitForAnyClientInitialAccessCreatePresentationDeleted();
  block(matchAddClientInitialAccessCreatePresentation(e.id, ANY), function () {
    verifyClientInitialAccessCreatePresentationDoesNotExist(e.id);
  });
});

bthread("AccessToken create verification", function () {
  const e = waitForAnyAccessTokenAdded();
  block(matchDeleteAccessToken(e.id, ANY), function () {
    verifyAccessTokenExists(e.id);
  });
});

bthread("AccessToken update verification", function () {
  const e = waitForAnyAccessTokenUpdated();
  block(matchDeleteAccessToken(e.id, ANY), function () {
    verifyAccessTokenUpdated(e.id);
  });
});

bthread("AccessToken delete verification", function () {
  const e = waitForAnyAccessTokenDeleted();
  block(matchAddAccessToken(e.id, ANY), function () {
    verifyAccessTokenDoesNotExist(e.id);
  });
});

bthread("MappingsRepresentation create verification", function () {
  const e = waitForAnyMappingsRepresentationAdded();
  block(matchDeleteMappingsRepresentation(e.id, ANY), function () {
    verifyMappingsRepresentationExists(e.id);
  });
});

bthread("MappingsRepresentation update verification", function () {
  const e = waitForAnyMappingsRepresentationUpdated();
  block(matchDeleteMappingsRepresentation(e.id, ANY), function () {
    verifyMappingsRepresentationUpdated(e.id);
  });
});

bthread("MappingsRepresentation delete verification", function () {
  const e = waitForAnyMappingsRepresentationDeleted();
  block(matchAddMappingsRepresentation(e.id, ANY), function () {
    verifyMappingsRepresentationDoesNotExist(e.id);
  });
});

bthread("UserConsentRepresentation create verification", function () {
  const e = waitForAnyUserConsentRepresentationAdded();
  block(matchDeleteUserConsentRepresentation(e.id, ANY), function () {
    verifyUserConsentRepresentationExists(e.id);
  });
});

bthread("UserConsentRepresentation update verification", function () {
  const e = waitForAnyUserConsentRepresentationUpdated();
  block(matchDeleteUserConsentRepresentation(e.id, ANY), function () {
    verifyUserConsentRepresentationUpdated(e.id);
  });
});

bthread("UserConsentRepresentation delete verification", function () {
  const e = waitForAnyUserConsentRepresentationDeleted();
  block(matchAddUserConsentRepresentation(e.id, ANY), function () {
    verifyUserConsentRepresentationDoesNotExist(e.id);
  });
});

bthread("AddressClaimSet create verification", function () {
  const e = waitForAnyAddressClaimSetAdded();
  block(matchDeleteAddressClaimSet(e.id, ANY), function () {
    verifyAddressClaimSetExists(e.id);
  });
});

bthread("AddressClaimSet update verification", function () {
  const e = waitForAnyAddressClaimSetUpdated();
  block(matchDeleteAddressClaimSet(e.id, ANY), function () {
    verifyAddressClaimSetUpdated(e.id);
  });
});

bthread("AddressClaimSet delete verification", function () {
  const e = waitForAnyAddressClaimSetDeleted();
  block(matchAddAddressClaimSet(e.id, ANY), function () {
    verifyAddressClaimSetDoesNotExist(e.id);
  });
});

bthread("UserFederationProviderRepresentation create verification", function () {
  const e = waitForAnyUserFederationProviderRepresentationAdded();
  block(matchDeleteUserFederationProviderRepresentation(e.id, ANY), function () {
    verifyUserFederationProviderRepresentationExists(e.id);
  });
});

bthread("UserFederationProviderRepresentation update verification", function () {
  const e = waitForAnyUserFederationProviderRepresentationUpdated();
  block(matchDeleteUserFederationProviderRepresentation(e.id, ANY), function () {
    verifyUserFederationProviderRepresentationUpdated(e.id);
  });
});

bthread("UserFederationProviderRepresentation delete verification", function () {
  const e = waitForAnyUserFederationProviderRepresentationDeleted();
  block(matchAddUserFederationProviderRepresentation(e.id, ANY), function () {
    verifyUserFederationProviderRepresentationDoesNotExist(e.id);
  });
});

bthread("ResourceServerRepresentation create verification", function () {
  const e = waitForAnyResourceServerRepresentationAdded();
  block(matchDeleteResourceServerRepresentation(e.id, ANY), function () {
    verifyResourceServerRepresentationExists(e.id);
  });
});

bthread("ResourceServerRepresentation update verification", function () {
  const e = waitForAnyResourceServerRepresentationUpdated();
  block(matchDeleteResourceServerRepresentation(e.id, ANY), function () {
    verifyResourceServerRepresentationUpdated(e.id);
  });
});

bthread("ResourceServerRepresentation delete verification", function () {
  const e = waitForAnyResourceServerRepresentationDeleted();
  block(matchAddResourceServerRepresentation(e.id, ANY), function () {
    verifyResourceServerRepresentationDoesNotExist(e.id);
  });
});

bthread("RoleRepresentation create verification", function () {
  const e = waitForAnyRoleRepresentationAdded();
  block(matchDeleteRoleRepresentation(e.id, ANY), function () {
    verifyRoleRepresentationExists(e.id);
  });
});

bthread("RoleRepresentation update verification", function () {
  const e = waitForAnyRoleRepresentationUpdated();
  block(matchDeleteRoleRepresentation(e.id, ANY), function () {
    verifyRoleRepresentationUpdated(e.id);
  });
});

bthread("RoleRepresentation delete verification", function () {
  const e = waitForAnyRoleRepresentationDeleted();
  block(matchAddRoleRepresentation(e.id, ANY), function () {
    verifyRoleRepresentationDoesNotExist(e.id);
  });
});

bthread("ComponentExportRepresentation create verification", function () {
  const e = waitForAnyComponentExportRepresentationAdded();
  block(matchDeleteComponentExportRepresentation(e.id, ANY), function () {
    verifyComponentExportRepresentationExists(e.id);
  });
});

bthread("ComponentExportRepresentation update verification", function () {
  const e = waitForAnyComponentExportRepresentationUpdated();
  block(matchDeleteComponentExportRepresentation(e.id, ANY), function () {
    verifyComponentExportRepresentationUpdated(e.id);
  });
});

bthread("ComponentExportRepresentation delete verification", function () {
  const e = waitForAnyComponentExportRepresentationDeleted();
  block(matchAddComponentExportRepresentation(e.id, ANY), function () {
    verifyComponentExportRepresentationDoesNotExist(e.id);
  });
});

bthread("ScopeEnforcementMode create verification", function () {
  const e = waitForAnyScopeEnforcementModeAdded();
  block(matchDeleteScopeEnforcementMode(e.id, ANY), function () {
    verifyScopeEnforcementModeExists(e.id);
  });
});

bthread("ScopeEnforcementMode update verification", function () {
  const e = waitForAnyScopeEnforcementModeUpdated();
  block(matchDeleteScopeEnforcementMode(e.id, ANY), function () {
    verifyScopeEnforcementModeUpdated(e.id);
  });
});

bthread("ScopeEnforcementMode delete verification", function () {
  const e = waitForAnyScopeEnforcementModeDeleted();
  block(matchAddScopeEnforcementMode(e.id, ANY), function () {
    verifyScopeEnforcementModeDoesNotExist(e.id);
  });
});

bthread("GlobalRequestResult create verification", function () {
  const e = waitForAnyGlobalRequestResultAdded();
  block(matchDeleteGlobalRequestResult(e.id, ANY), function () {
    verifyGlobalRequestResultExists(e.id);
  });
});

bthread("GlobalRequestResult update verification", function () {
  const e = waitForAnyGlobalRequestResultUpdated();
  block(matchDeleteGlobalRequestResult(e.id, ANY), function () {
    verifyGlobalRequestResultUpdated(e.id);
  });
});

bthread("GlobalRequestResult delete verification", function () {
  const e = waitForAnyGlobalRequestResultDeleted();
  block(matchAddGlobalRequestResult(e.id, ANY), function () {
    verifyGlobalRequestResultDoesNotExist(e.id);
  });
});

bthread("ApplicationRepresentationClaims create verification", function () {
  const e = waitForAnyApplicationRepresentationClaimsAdded();
  block(matchDeleteApplicationRepresentationClaims(e.id, ANY), function () {
    verifyApplicationRepresentationClaimsExists(e.id);
  });
});

bthread("ApplicationRepresentationClaims update verification", function () {
  const e = waitForAnyApplicationRepresentationClaimsUpdated();
  block(matchDeleteApplicationRepresentationClaims(e.id, ANY), function () {
    verifyApplicationRepresentationClaimsUpdated(e.id);
  });
});

bthread("ApplicationRepresentationClaims delete verification", function () {
  const e = waitForAnyApplicationRepresentationClaimsDeleted();
  block(matchAddApplicationRepresentationClaims(e.id, ANY), function () {
    verifyApplicationRepresentationClaimsDoesNotExist(e.id);
  });
});

bthread("ClientPolicyConditionRepresentation create verification", function () {
  const e = waitForAnyClientPolicyConditionRepresentationAdded();
  block(matchDeleteClientPolicyConditionRepresentation(e.id, ANY), function () {
    verifyClientPolicyConditionRepresentationExists(e.id);
  });
});

bthread("ClientPolicyConditionRepresentation update verification", function () {
  const e = waitForAnyClientPolicyConditionRepresentationUpdated();
  block(matchDeleteClientPolicyConditionRepresentation(e.id, ANY), function () {
    verifyClientPolicyConditionRepresentationUpdated(e.id);
  });
});

bthread("ClientPolicyConditionRepresentation delete verification", function () {
  const e = waitForAnyClientPolicyConditionRepresentationDeleted();
  block(matchAddClientPolicyConditionRepresentation(e.id, ANY), function () {
    verifyClientPolicyConditionRepresentationDoesNotExist(e.id);
  });
});

bthread("FederatedIdentityRepresentation create verification", function () {
  const e = waitForAnyFederatedIdentityRepresentationAdded();
  block(matchDeleteFederatedIdentityRepresentation(e.id, ANY), function () {
    verifyFederatedIdentityRepresentationExists(e.id);
  });
});

bthread("FederatedIdentityRepresentation update verification", function () {
  const e = waitForAnyFederatedIdentityRepresentationUpdated();
  block(matchDeleteFederatedIdentityRepresentation(e.id, ANY), function () {
    verifyFederatedIdentityRepresentationUpdated(e.id);
  });
});

bthread("FederatedIdentityRepresentation delete verification", function () {
  const e = waitForAnyFederatedIdentityRepresentationDeleted();
  block(matchAddFederatedIdentityRepresentation(e.id, ANY), function () {
    verifyFederatedIdentityRepresentationDoesNotExist(e.id);
  });
});

bthread("ClientScopeRepresentation create verification", function () {
  const e = waitForAnyClientScopeRepresentationAdded();
  block(matchDeleteClientScopeRepresentation(e.id, ANY), function () {
    verifyClientScopeRepresentationExists(e.id);
  });
});

bthread("ClientScopeRepresentation update verification", function () {
  const e = waitForAnyClientScopeRepresentationUpdated();
  block(matchDeleteClientScopeRepresentation(e.id, ANY), function () {
    verifyClientScopeRepresentationUpdated(e.id);
  });
});

bthread("ClientScopeRepresentation delete verification", function () {
  const e = waitForAnyClientScopeRepresentationDeleted();
  block(matchAddClientScopeRepresentation(e.id, ANY), function () {
    verifyClientScopeRepresentationDoesNotExist(e.id);
  });
});

bthread("ClaimRepresentation create verification", function () {
  const e = waitForAnyClaimRepresentationAdded();
  block(matchDeleteClaimRepresentation(e.id, ANY), function () {
    verifyClaimRepresentationExists(e.id);
  });
});

bthread("ClaimRepresentation update verification", function () {
  const e = waitForAnyClaimRepresentationUpdated();
  block(matchDeleteClaimRepresentation(e.id, ANY), function () {
    verifyClaimRepresentationUpdated(e.id);
  });
});

bthread("ClaimRepresentation delete verification", function () {
  const e = waitForAnyClaimRepresentationDeleted();
  block(matchAddClaimRepresentation(e.id, ANY), function () {
    verifyClaimRepresentationDoesNotExist(e.id);
  });
});

bthread("IDToken create verification", function () {
  const e = waitForAnyIDTokenAdded();
  block(matchDeleteIDToken(e.id, ANY), function () {
    verifyIDTokenExists(e.id);
  });
});

bthread("IDToken update verification", function () {
  const e = waitForAnyIDTokenUpdated();
  block(matchDeleteIDToken(e.id, ANY), function () {
    verifyIDTokenUpdated(e.id);
  });
});

bthread("IDToken delete verification", function () {
  const e = waitForAnyIDTokenDeleted();
  block(matchAddIDToken(e.id, ANY), function () {
    verifyIDTokenDoesNotExist(e.id);
  });
});

// ===== RELATIONSHIP GUARDS =====

// ===== UNIQUENESS GUARDS =====

bthread("Guard: Unique ScopeRepresentation", function () {
  const x = waitForAnyScopeRepresentationAdded();
  block(matchAddScopeRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique MethodConfig", function () {
  const x = waitForAnyMethodConfigAdded();
  block(matchAddMethodConfig(x.id, ANY), function () {});
});

bthread("Guard: Unique ResourceRepresentation", function () {
  const x = waitForAnyResourceRepresentationAdded();
  block(matchAddResourceRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique RolesRepresentation", function () {
  const x = waitForAnyRolesRepresentationAdded();
  block(matchAddRolesRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientPoliciesRepresentation", function () {
  const x = waitForAnyClientPoliciesRepresentationAdded();
  block(matchAddClientPoliciesRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique PathConfig", function () {
  const x = waitForAnyPathConfigAdded();
  block(matchAddPathConfig(x.id, ANY), function () {});
});

bthread("Guard: Unique GroupRepresentation", function () {
  const x = waitForAnyGroupRepresentationAdded();
  block(matchAddGroupRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique KeyUse", function () {
  const x = waitForAnyKeyUseAdded();
  block(matchAddKeyUse(x.id, ANY), function () {});
});

bthread("Guard: Unique ProtocolMapperRepresentation", function () {
  const x = waitForAnyProtocolMapperRepresentationAdded();
  block(matchAddProtocolMapperRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique KeyMetadataRepresentation", function () {
  const x = waitForAnyKeyMetadataRepresentationAdded();
  block(matchAddKeyMetadataRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientPolicyRepresentation", function () {
  const x = waitForAnyClientPolicyRepresentationAdded();
  block(matchAddClientPolicyRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique Authorization", function () {
  const x = waitForAnyAuthorizationAdded();
  block(matchAddAuthorization(x.id, ANY), function () {});
});

bthread("Guard: Unique CertConf", function () {
  const x = waitForAnyCertConfAdded();
  block(matchAddCertConf(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientRepresentation", function () {
  const x = waitForAnyClientRepresentationAdded();
  block(matchAddClientRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique InstallationAdapterConfig", function () {
  const x = waitForAnyInstallationAdapterConfigAdded();
  block(matchAddInstallationAdapterConfig(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientTemplateRepresentation", function () {
  const x = waitForAnyClientTemplateRepresentationAdded();
  block(matchAddClientTemplateRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique PolicyRepresentation", function () {
  const x = waitForAnyPolicyRepresentationAdded();
  block(matchAddPolicyRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientPolicyExecutorRepresentation", function () {
  const x = waitForAnyClientPolicyExecutorRepresentationAdded();
  block(matchAddClientPolicyExecutorRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique UserFederationMapperRepresentation", function () {
  const x = waitForAnyUserFederationMapperRepresentationAdded();
  block(matchAddUserFederationMapperRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique AuthenticationFlowRepresentation", function () {
  const x = waitForAnyAuthenticationFlowRepresentationAdded();
  block(matchAddAuthenticationFlowRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique IdentityProviderMapperTypeRepresentation", function () {
  const x = waitForAnyIdentityProviderMapperTypeRepresentationAdded();
  block(matchAddIdentityProviderMapperTypeRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique Permission", function () {
  const x = waitForAnyPermissionAdded();
  block(matchAddPermission(x.id, ANY), function () {});
});

bthread("Guard: Unique EnforcementMode", function () {
  const x = waitForAnyEnforcementModeAdded();
  block(matchAddEnforcementMode(x.id, ANY), function () {});
});

bthread("Guard: Unique KeysMetadataRepresentation", function () {
  const x = waitForAnyKeysMetadataRepresentationAdded();
  block(matchAddKeysMetadataRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ManagementPermissionReference", function () {
  const x = waitForAnyManagementPermissionReferenceAdded();
  block(matchAddManagementPermissionReference(x.id, ANY), function () {});
});

bthread("Guard: Unique AuthenticatorConfigInfoRepresentation", function () {
  const x = waitForAnyAuthenticatorConfigInfoRepresentationAdded();
  block(matchAddAuthenticatorConfigInfoRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique AuthenticatorConfigRepresentation", function () {
  const x = waitForAnyAuthenticatorConfigRepresentationAdded();
  block(matchAddAuthenticatorConfigRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique DecisionStrategy", function () {
  const x = waitForAnyDecisionStrategyAdded();
  block(matchAddDecisionStrategy(x.id, ANY), function () {});
});

bthread("Guard: Unique Logic", function () {
  const x = waitForAnyLogicAdded();
  block(matchAddLogic(x.id, ANY), function () {});
});

bthread("Guard: Unique UserRepresentation", function () {
  const x = waitForAnyUserRepresentationAdded();
  block(matchAddUserRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientProfilesRepresentation", function () {
  const x = waitForAnyClientProfilesRepresentationAdded();
  block(matchAddClientProfilesRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique KeyStoreConfig", function () {
  const x = waitForAnyKeyStoreConfigAdded();
  block(matchAddKeyStoreConfig(x.id, ANY), function () {});
});

bthread("Guard: Unique ComponentRepresentation", function () {
  const x = waitForAnyComponentRepresentationAdded();
  block(matchAddComponentRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique PublishedRealmRepresentation", function () {
  const x = waitForAnyPublishedRealmRepresentationAdded();
  block(matchAddPublishedRealmRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique SocialLinkRepresentation", function () {
  const x = waitForAnySocialLinkRepresentationAdded();
  block(matchAddSocialLinkRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique AuthenticationExecutionExportRepresentation", function () {
  const x = waitForAnyAuthenticationExecutionExportRepresentationAdded();
  block(matchAddAuthenticationExecutionExportRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique IdentityProviderRepresentation", function () {
  const x = waitForAnyIdentityProviderRepresentationAdded();
  block(matchAddIdentityProviderRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique OAuthClientRepresentation", function () {
  const x = waitForAnyOAuthClientRepresentationAdded();
  block(matchAddOAuthClientRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique Access", function () {
  const x = waitForAnyAccessAdded();
  block(matchAddAccess(x.id, ANY), function () {});
});

bthread("Guard: Unique ResourceOwnerRepresentation", function () {
  const x = waitForAnyResourceOwnerRepresentationAdded();
  block(matchAddResourceOwnerRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ScopeMappingRepresentation", function () {
  const x = waitForAnyScopeMappingRepresentationAdded();
  block(matchAddScopeMappingRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique Composites", function () {
  const x = waitForAnyCompositesAdded();
  block(matchAddComposites(x.id, ANY), function () {});
});

bthread("Guard: Unique RealmEventsConfigRepresentation", function () {
  const x = waitForAnyRealmEventsConfigRepresentationAdded();
  block(matchAddRealmEventsConfigRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientProfileRepresentation", function () {
  const x = waitForAnyClientProfileRepresentationAdded();
  block(matchAddClientProfileRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientInitialAccessPresentation", function () {
  const x = waitForAnyClientInitialAccessPresentationAdded();
  block(matchAddClientInitialAccessPresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique CredentialRepresentation", function () {
  const x = waitForAnyCredentialRepresentationAdded();
  block(matchAddCredentialRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ConfigPropertyRepresentation", function () {
  const x = waitForAnyConfigPropertyRepresentationAdded();
  block(matchAddConfigPropertyRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique PolicyEnforcementMode", function () {
  const x = waitForAnyPolicyEnforcementModeAdded();
  block(matchAddPolicyEnforcementMode(x.id, ANY), function () {});
});

bthread("Guard: Unique PolicyEnforcerConfig", function () {
  const x = waitForAnyPolicyEnforcerConfigAdded();
  block(matchAddPolicyEnforcerConfig(x.id, ANY), function () {});
});

bthread("Guard: Unique ResourceRepresentationOwner", function () {
  const x = waitForAnyResourceRepresentationOwnerAdded();
  block(matchAddResourceRepresentationOwner(x.id, ANY), function () {});
});

bthread("Guard: Unique AuthenticationExecutionRepresentation", function () {
  const x = waitForAnyAuthenticationExecutionRepresentationAdded();
  block(matchAddAuthenticationExecutionRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ApplicationRepresentation", function () {
  const x = waitForAnyApplicationRepresentationAdded();
  block(matchAddApplicationRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique AuthenticationExecutionInfoRepresentation", function () {
  const x = waitForAnyAuthenticationExecutionInfoRepresentationAdded();
  block(matchAddAuthenticationExecutionInfoRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique CertificateRepresentation", function () {
  const x = waitForAnyCertificateRepresentationAdded();
  block(matchAddCertificateRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientMappingsRepresentation", function () {
  const x = waitForAnyClientMappingsRepresentationAdded();
  block(matchAddClientMappingsRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique PathCacheConfig", function () {
  const x = waitForAnyPathCacheConfigAdded();
  block(matchAddPathCacheConfig(x.id, ANY), function () {});
});

bthread("Guard: Unique RequiredActionProviderRepresentation", function () {
  const x = waitForAnyRequiredActionProviderRepresentationAdded();
  block(matchAddRequiredActionProviderRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique IdentityProviderMapperRepresentation", function () {
  const x = waitForAnyIdentityProviderMapperRepresentationAdded();
  block(matchAddIdentityProviderMapperRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique RealmRepresentation", function () {
  const x = waitForAnyRealmRepresentationAdded();
  block(matchAddRealmRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientInitialAccessCreatePresentation", function () {
  const x = waitForAnyClientInitialAccessCreatePresentationAdded();
  block(matchAddClientInitialAccessCreatePresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique AccessToken", function () {
  const x = waitForAnyAccessTokenAdded();
  block(matchAddAccessToken(x.id, ANY), function () {});
});

bthread("Guard: Unique MappingsRepresentation", function () {
  const x = waitForAnyMappingsRepresentationAdded();
  block(matchAddMappingsRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique UserConsentRepresentation", function () {
  const x = waitForAnyUserConsentRepresentationAdded();
  block(matchAddUserConsentRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique AddressClaimSet", function () {
  const x = waitForAnyAddressClaimSetAdded();
  block(matchAddAddressClaimSet(x.id, ANY), function () {});
});

bthread("Guard: Unique UserFederationProviderRepresentation", function () {
  const x = waitForAnyUserFederationProviderRepresentationAdded();
  block(matchAddUserFederationProviderRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ResourceServerRepresentation", function () {
  const x = waitForAnyResourceServerRepresentationAdded();
  block(matchAddResourceServerRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique RoleRepresentation", function () {
  const x = waitForAnyRoleRepresentationAdded();
  block(matchAddRoleRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ComponentExportRepresentation", function () {
  const x = waitForAnyComponentExportRepresentationAdded();
  block(matchAddComponentExportRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ScopeEnforcementMode", function () {
  const x = waitForAnyScopeEnforcementModeAdded();
  block(matchAddScopeEnforcementMode(x.id, ANY), function () {});
});

bthread("Guard: Unique GlobalRequestResult", function () {
  const x = waitForAnyGlobalRequestResultAdded();
  block(matchAddGlobalRequestResult(x.id, ANY), function () {});
});

bthread("Guard: Unique ApplicationRepresentationClaims", function () {
  const x = waitForAnyApplicationRepresentationClaimsAdded();
  block(matchAddApplicationRepresentationClaims(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientPolicyConditionRepresentation", function () {
  const x = waitForAnyClientPolicyConditionRepresentationAdded();
  block(matchAddClientPolicyConditionRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique FederatedIdentityRepresentation", function () {
  const x = waitForAnyFederatedIdentityRepresentationAdded();
  block(matchAddFederatedIdentityRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ClientScopeRepresentation", function () {
  const x = waitForAnyClientScopeRepresentationAdded();
  block(matchAddClientScopeRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique ClaimRepresentation", function () {
  const x = waitForAnyClaimRepresentationAdded();
  block(matchAddClaimRepresentation(x.id, ANY), function () {});
});

bthread("Guard: Unique IDToken", function () {
  const x = waitForAnyIDTokenAdded();
  block(matchAddIDToken(x.id, ANY), function () {});
});

// ===== NEGATIVE/EDGE STATUS GUARDS =====
