@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem Usage: emit_stories_for_list.bat [path\to\list.txt]
if "%~1"=="" ( set "LIST=config\suts_and_rw.txt" ) else ( set "LIST=%~1" )

set "SELF_DIR=%~dp0"
for %%# in ("%SELF_DIR%\..\..\") do set "ROOT=%%~f#"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"

set "ONE=%SELF_DIR%emit_stories_one.bat"

echo ============================================
echo STORIES from list: "%LIST%"
echo CWD  : %CD%
echo ROOT : %ROOT%
echo ONE  : %ONE%
echo ============================================

if not exist "%ONE%" (
  echo [ERR ] Missing helper: %ONE%
  exit /b 2
)

for %%# in ("%LIST%") do set "LIST=%%~f#"
if not exist "%LIST%" (
  echo [ERR ] List file not found: %LIST%
  exit /b 3
)

if defined HLS_DEBUG (
  echo [DBG] Dumping list with line numbers:
  for /f "usebackq tokens=1,* delims=:" %%N in (`findstr /n "^" "%LIST%"`) do (
    echo   [DBG] %%N: %%O
  )
)

echo [DBG] Entering loop...

for /f "usebackq tokens=* delims=" %%L in ("%LIST%") do (
  set "LINE=%%L"
  set "TRIM=!LINE: =!"
  set "FIRST=!LINE:~0,1!"
  if not "!TRIM!"=="" if not "!FIRST!"==";" if not "!FIRST!"=="#" (
    echo [CALL] !LINE!
    call "%ONE%" "!LINE!"
    echo [RC  ] !LINE! -> errorlevel=!errorlevel!
  )
)

echo [DONE] emit_stories_for_list.bat finished successfully.
exit /b 0
