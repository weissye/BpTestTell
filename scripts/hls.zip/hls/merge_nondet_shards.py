#!/usr/bin/env python
import argparse, glob, json, os, sys
from typing import List, Union

def load_stories(path: str) -> List[dict]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    # Accept either: {"stories": [...]} or just [...]
    if isinstance(data, dict) and "stories" in data and isinstance(data["stories"], list):
        return data["stories"]
    if isinstance(data, list):
        return data
    raise ValueError(f"{path}: unsupported JSON shape")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, help="output merged JSON path")
    ap.add_argument("--glob", default=None, help="glob for shard files (e.g., artifacts\\...\\hls_nondet_gold.json.shard*.json)")
    ap.add_argument("--inputs", nargs="*", help="explicit list of shard files")
    ap.add_argument("--wrap", choices=["auto","dict","list"], default="auto",
                    help="output shape: auto = dict with 'stories' if any input was dict-shaped; else list")
    args = ap.parse_args()

    inputs: List[str] = []
    if args.glob:
        inputs = sorted(glob.glob(args.glob))
    if args.inputs:
        inputs.extend(args.inputs)
    inputs = [p for p in inputs if os.path.isfile(p)]

    if not inputs:
        print("[ERR] no shard files matched", file=sys.stderr)
        sys.exit(2)

    total = 0
    merged: List[dict] = []
    saw_dict = False

    # Detect if any input is dict-shaped
    for p in inputs:
        with open(p, "r", encoding="utf-8") as f:
            first = json.load(f)
        if isinstance(first, dict) and "stories" in first and isinstance(first["stories"], list):
            saw_dict = True
        # reload via loader to normalize
        stories = first["stories"] if isinstance(first, dict) and "stories" in first else (first if isinstance(first, list) else [])
        merged.extend(stories)
        total += len(stories)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)

    # Output shape
    if args.wrap == "dict" or (args.wrap == "auto" and saw_dict):
        out_obj: Union[dict, list] = {"stories": merged}
    else:
        out_obj = merged

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out_obj, f, ensure_ascii=False, indent=2)

    print(f"[OK] merged {len(inputs)} shards -> {args.out} (stories={len(merged)})")

if __name__ == "__main__":
    main()
