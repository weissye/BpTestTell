# scripts/readable/emit_hls_all_in_one.py
# Deterministic emitter for HLS readables, unified structure:
#   if (mode === "MODEL") { ACTIVE lifecycles (>=3 per entity) ; PASSIVE assertions & guards }
# Inputs:
#   --gold   path to (det|nondet) gold json  ({"stories":[...]} or [...])
#   --active optional active-samples json    ({"samples":[...]} or [...])  - seeds ACTIVE lifecycles
#   --out    output JS path
#   --name   SUT name (for headings / comments)
#
# Notes:
# - We DO NOT ask the model here. Structure is deterministic.
# - We build generic ACTIVE flows using available stories + scaffolds.
# - PASSIVE includes Add/Update/Delete verifiers per entity + cross-entity generic guards.

import argparse, json, sys
from pathlib import Path
from collections import defaultdict

ANY = "ANY"

def load_any(path: Path):
    j = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(j, dict):
        return j.get("stories") or j.get("samples") or j.get("data") or []
    return j

def pick_three(vals):
    res = []
    for v in vals:
        if len(res) >= 3: break
        res.append(v)
    # pad with repeats if too few
    while len(res) < 3 and res:
        res.append(res[-1])
    return res

def js_escape(s: str) -> str:
    return s.replace("\\","\\\\").replace('"','\\"')

def fmt_params(params: dict) -> str:
    # render as JS object literal with simple primitives/ids
    parts = []
    for k,v in (params or {}).items():
        if isinstance(v, str):
            parts.append(f'{k}: "{js_escape(v)}"')
        else:
            parts.append(f'{k}: {json.dumps(v)}')
    return "{ " + ", ".join(parts) + " }"

def group_by_entity(stories):
    g = defaultdict(list)
    for s in stories:
        e = s.get("entity")
        if not isinstance(s, dict) or not e:
            continue
        g[e].append(s)
    return g

def find_ops_for_entity(stories, entity):
    ops = defaultdict(list)
    for s in stories:
        if s.get("entity") == entity:
            ops[s.get("op")].append(s)
    return ops

def guess_id_param(params: dict):
    # common id keys
    for k in ("id", "userId","bookId","loanId","customerId","vehicleId","workOrderId","invoiceId","paymentId","accountId","orderId"):
        if k in (params or {}):
            return k
    # fallback: any key ending with Id
    for k in (params or {}):
        if k.lower().endswith("id"):
            return k
    return None

def render_active_for_entity(entity, stories_for_entity):
    ops = find_ops_for_entity(stories_for_entity, entity)
    adds = ops.get("add", [])
    updates = ops.get("update", [])
    deletes = ops.get("delete", [])

    # choose up to 3 different param sets from adds; fallback to any stories
    seeds = pick_three([a.get("params") or {} for a in adds] or [s.get("params") or {} for s in stories_for_entity][:3])
    bts = []

    idx = 0
    for params in seeds:
        idx += 1
        id_key = guess_id_param(params) or "id"
        id_expr = f'{id_key}: "{js_escape((params.get(id_key) or f"{entity.lower()}-{idx:03d}"))}"'
        # construct lifecycle: add -> (one or two updates if defined) -> guarded delete
        upd1 = updates[0].get("params") if updates else None
        upd2 = (updates[1].get("params") if len(updates) > 1 else None)

        bt = []
        bt.append(f'bthread("{entity} Lifecycle #{idx}", function () {{')
        # ADD
        bt.append(f'  const e{idx} = waitFor(add{entity}({fmt_params(params)}));')
        bt.append(f'  block(delete{entity}({{ {id_expr} }}));')
        bt.append(f'  verify{entity}Exists({{ {id_expr} }});')

        # UPDATE(s)
        if upd1:
            bt.append(f'  waitFor(update{entity}({fmt_params(upd1)}));')
            bt.append(f'  verify{entity}Updated({{ {id_expr} }});')
        if upd2:
            bt.append(f'  waitFor(update{entity}({fmt_params(upd2)}));')
            bt.append(f'  verify{entity}Updated({{ {id_expr} }});')

        # allow delete at the end
        bt.append(f'  waitFor(delete{entity}({{ {id_expr} }}));')
        bt.append(f'  verify{entity}DoesNotExist({{ {id_expr} }});')
        bt.append('});')
        bts.append("\n".join(bt))

    return "\n\n".join(bts)

def render_passive_triplet(entity):
    lines = []
    # ADD verifier
    lines.append(f'bthread("{entity} Add Verification", function () {{')
    lines.append(f'  const ev = waitFor(add{entity}({{ {ANY}: {ANY} }}));')
    lines.append(f'  block(delete{entity}({{ {ANY}: {ANY} }}));')
    lines.append(f'  verify{entity}Exists({{ {ANY}: {ANY} }});')
    lines.append('});')

    # UPDATE verifier
    lines.append(f'bthread("{entity} Update Verification", function () {{')
    lines.append(f'  const ev = waitFor(update{entity}({{ {ANY}: {ANY} }}));')
    lines.append(f'  block(delete{entity}({{ {ANY}: {ANY} }}));')
    lines.append(f'  verify{entity}Updated({{ {ANY}: {ANY} }});')
    lines.append('});')

    # DELETE verifier
    lines.append(f'bthread("{entity} Delete Verification", function () {{')
    lines.append(f'  const ev = waitFor(delete{entity}({{ {ANY}: {ANY} }}));')
    lines.append(f'  block(add{entity}({{ {ANY}: {ANY} }}));')
    lines.append(f'  verify{entity}DoesNotExist({{ {ANY}: {ANY} }});')
    lines.append('});')
    return "\n\n".join(lines)

def render_generic_guards(entities, relations):
    # Minimal cross-entity guards using relation hints:
    # - No delete parent when children exist
    # - Requires parent for child add
    out = []
    for (child, parent, via) in relations:
        # parent delete guard
        out.append(f'bthread("Guard: No delete {parent} with existing {child}", function () {{')
        out.append(f'  const p = waitFor(delete{parent}({{ {ANY}: {ANY} }}));')
        out.append(f'  block(delete{parent}({{ {ANY}: {ANY} }}));')
        out.append(f'  verifyNo{child}sFor{parent}({{ {ANY}: {ANY} }});')
        out.append('});')
        # child add requires parent
        out.append(f'bthread("Guard: {child} add requires {parent}", function () {{')
        out.append(f'  const c = waitFor(add{child}({{ {ANY}: {ANY} }}));')
        out.append(f'  verify{parent}Exists({{ {ANY}: {ANY} }});')
        out.append('});')
    return "\n\n".join(out)

def infer_relations_from_params(stories):
    # crude relation guessing: <OtherEntity>Id params ⇒ child->parent
    pairs = set()
    for s in stories:
        e = s.get("entity")
        params = s.get("params") or {}
        for k in params.keys():
            if k.endswith("Id") and len(k) > 2:
                parent = k[:-2]
                if parent and parent[0].islower():
                    parent = parent[0].upper() + parent[1:]
                if parent != e:
                    pairs.add((e, parent, k))
    return sorted(pairs)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gold", required=True)
    ap.add_argument("--active", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--name", default=None)
    args = ap.parse_args()

    gold_p = Path(args.gold)
    stories = load_any(gold_p)

    # Optional active samples (not required)
    active_p = Path(args.active) if args.active else None
    active_samples = []
    if active_p and active_p.exists():
        active_samples = load_any(active_p)

    # Group stories by entity
    grouped = group_by_entity(stories)
    entities = list(grouped.keys())

    # Try inferring basic relations from params (child -> parent)
    rels = infer_relations_from_params(stories)

    # ==== Build JS ====
    lines = []
    # lines.append('if (mode === "MODEL") {')
    lines.append("")
    if args.name:
        lines.append(f'  // HLS Readable for "{args.name}"')
    lines.append('  // ===== ACTIVE LIFECYCLES (>=3 examples per entity) =====')
    lines.append('')

    # ACTIVE lifecycles per entity
    for ent in entities:
        lines.append(f'  // --- ACTIVE: {ent} ---')
        # Use stories for the entity; if no add found, still scaffold with what we have
        act_block = render_active_for_entity(ent, grouped[ent])
        # indent
        if act_block.strip():
            for ln in act_block.splitlines():
                lines.append("  " + ln)
        lines.append("")

    # PASSIVE ASSERTIONS
    lines.append('  // ===== PASSIVE ASSERTIONS =====')
    lines.append("")
    for ent in entities:
        lines.append(f'  // --- PASSIVE: {ent} ---')
        trip = render_passive_triplet(ent)
        for ln in trip.splitlines():
            lines.append("  " + ln)
        lines.append("")

    # Generic guards from relations (lightweight; deterministic)
    if rels:
        lines.append('  // --- PASSIVE: Cross-Entity Guards ---')
        g = render_generic_guards(entities, rels)
        for ln in g.splitlines():
            lines.append("  " + ln)
        lines.append("")

    # lines.append('} // end if mode === "MODEL"')
    out_p = Path(args.out)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    out_p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[OK] {out_p}")

if __name__ == "__main__":
    main()
