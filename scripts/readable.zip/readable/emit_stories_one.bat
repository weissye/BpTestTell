@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem Usage: emit_stories_one.bat SUT
if "%~1"=="" ( echo Usage: emit_stories_one.bat SUT & exit /b 2 )

set "SUT=%~1"
set "SELF_DIR=%~dp0"
for %%# in ("%SELF_DIR%\..\..\") do set "ROOT=%%~f#"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"

set "RUNNER=%SELF_DIR%emit_stories_from_gold.bat"

set "NONDET_7=%ROOT%\artifacts\hls_nondet\7_suts_llm_provider\%SUT%\hls_nondet_gold.json"
set "NONDET_RW=%ROOT%\artifacts\hls_nondet\real_world_llm_provider\%SUT%\hls_nondet_gold.json"
set "DET_7=%ROOT%\artifacts\hls_det\7_suts_llm_provider\%SUT%\hls_det_gold.json"
set "DET_RW=%ROOT%\artifacts\hls_det\real_world_llm_provider\%SUT%\hls_det_gold.json"

echo --------------------------------------------
echo [ENTR] emit_stories_one.bat
echo [DBG ]   SUT   = %SUT%
echo [DBG ]   ROOT  = %ROOT%
echo [DBG ]   Runner= %RUNNER%
echo [DBG ]   GOLD presence:
if exist "%NONDET_7%"  echo [DBG ]     NONDET 7_suts : yes
if not exist "%NONDET_7%" echo [DBG ]     NONDET 7_suts : no
if exist "%DET_7%"     echo [DBG ]     DET    7_suts : yes
if not exist "%DET_7%"   echo [DBG ]     DET    7_suts : no
if exist "%NONDET_RW%" echo [DBG ]     NONDET real_w : yes
if not exist "%NONDET_RW%" echo [DBG ]     NONDET real_w : no
if exist "%DET_RW%"    echo [DBG ]     DET    real_w : yes
if not exist "%DET_RW%"  echo [DBG ]     DET    real_w : no
echo --------------------------------------------

set "ANY=0"

rem SUTs provider
if exist "%NONDET_7%" (
  call "%RUNNER%" NONDET "%SUT%" 7_suts_llm_provider
  set "ANY=1"
)
if exist "%DET_7%" (
  call "%RUNNER%" DET "%SUT%" 7_suts_llm_provider
  set "ANY=1"
)

rem Real-world provider
if exist "%NONDET_RW%" (
  call "%RUNNER%" NONDET "%SUT%" real_world_llm_provider
  set "ANY=1"
)
if exist "%DET_RW%" (
  call "%RUNNER%" DET "%SUT%" real_world_llm_provider
  set "ANY=1"
)

if "%ANY%"=="0" (
  echo [WARN] No GOLDs found for %SUT% under either provider. Skipping.
  exit /b 6
)

exit /b 0
