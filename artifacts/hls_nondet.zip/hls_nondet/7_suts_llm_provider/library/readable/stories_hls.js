// ====================================================================
// Auto-generated garage-style High-Level Stories (HLS)
// SUT: library
// ====================================================================

var ANY = (typeof H !== 'undefined' && H.ANY) ? H.ANY : (typeof ANY !== 'undefined' ? ANY : '*');

// ===== ACTIVE LIFECYCLES =====


bthread("HoldCreate lifecycle", function () {
  const x = pick([{id: "H001"}, {id: "H002"}]);
  addHoldCreate(x.id);
  updateHoldCreate(x.id);
  updateHoldCreate(x.id);
  verifyHoldCreateExists(x.id);
  verifyHoldCreateUpdated(x.id);
});

bthread("UserCreate lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserCreate(x.id);
  updateUserCreate(x.id);
  updateUserCreate(x.id);
  verifyUserCreateExists(x.id);
  verifyUserCreateUpdated(x.id);
});

bthread("Hold lifecycle", function () {
  const x = pick([{id: "H001"}, {id: "H002"}]);
  addHold(x.id);
  updateHold(x.id);
  updateHold(x.id);
  verifyHoldExists(x.id);
  verifyHoldUpdated(x.id);
});

bthread("BookCreate lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBookCreate(x.id);
  updateBookCreate(x.id);
  updateBookCreate(x.id);
  verifyBookCreateExists(x.id);
  verifyBookCreateUpdated(x.id);
});

bthread("User lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUser(x.id);
  updateUser(x.id);
  updateUser(x.id);
  verifyUserExists(x.id);
  verifyUserUpdated(x.id);
});

bthread("Book lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBook(x.id);
  updateBook(x.id);
  updateBook(x.id);
  verifyBookExists(x.id);
  verifyBookUpdated(x.id);
});

bthread("Loan lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLoan(x.id);
  updateLoan(x.id);
  updateLoan(x.id);
  verifyLoanExists(x.id);
  verifyLoanUpdated(x.id);
});

bthread("LoanCreate lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLoanCreate(x.id);
  updateLoanCreate(x.id);
  updateLoanCreate(x.id);
  verifyLoanCreateExists(x.id);
  verifyLoanCreateUpdated(x.id);
});

// ===== PASSIVE ASSERTIONS =====

bthread("HoldCreate create verification", function () {
  const e = waitForAnyHoldCreateAdded();
  block(matchDeleteHoldCreate(e.id, ANY), function () {
    verifyHoldCreateExists(e.id);
  });
});

bthread("HoldCreate update verification", function () {
  const e = waitForAnyHoldCreateUpdated();
  block(matchDeleteHoldCreate(e.id, ANY), function () {
    verifyHoldCreateUpdated(e.id);
  });
});

bthread("HoldCreate delete verification", function () {
  const e = waitForAnyHoldCreateDeleted();
  block(matchAddHoldCreate(e.id, ANY), function () {
    verifyHoldCreateDoesNotExist(e.id);
  });
});

bthread("UserCreate create verification", function () {
  const e = waitForAnyUserCreateAdded();
  block(matchDeleteUserCreate(e.id, ANY), function () {
    verifyUserCreateExists(e.id);
  });
});

bthread("UserCreate update verification", function () {
  const e = waitForAnyUserCreateUpdated();
  block(matchDeleteUserCreate(e.id, ANY), function () {
    verifyUserCreateUpdated(e.id);
  });
});

bthread("UserCreate delete verification", function () {
  const e = waitForAnyUserCreateDeleted();
  block(matchAddUserCreate(e.id, ANY), function () {
    verifyUserCreateDoesNotExist(e.id);
  });
});

bthread("Hold create verification", function () {
  const e = waitForAnyHoldAdded();
  block(matchDeleteHold(e.id, ANY), function () {
    verifyHoldExists(e.id);
  });
});

bthread("Hold update verification", function () {
  const e = waitForAnyHoldUpdated();
  block(matchDeleteHold(e.id, ANY), function () {
    verifyHoldUpdated(e.id);
  });
});

bthread("Hold delete verification", function () {
  const e = waitForAnyHoldDeleted();
  block(matchAddHold(e.id, ANY), function () {
    verifyHoldDoesNotExist(e.id);
  });
});

bthread("BookCreate create verification", function () {
  const e = waitForAnyBookCreateAdded();
  block(matchDeleteBookCreate(e.id, ANY), function () {
    verifyBookCreateExists(e.id);
  });
});

bthread("BookCreate update verification", function () {
  const e = waitForAnyBookCreateUpdated();
  block(matchDeleteBookCreate(e.id, ANY), function () {
    verifyBookCreateUpdated(e.id);
  });
});

bthread("BookCreate delete verification", function () {
  const e = waitForAnyBookCreateDeleted();
  block(matchAddBookCreate(e.id, ANY), function () {
    verifyBookCreateDoesNotExist(e.id);
  });
});

bthread("User create verification", function () {
  const e = waitForAnyUserAdded();
  block(matchDeleteUser(e.id, ANY), function () {
    verifyUserExists(e.id);
  });
});

bthread("User update verification", function () {
  const e = waitForAnyUserUpdated();
  block(matchDeleteUser(e.id, ANY), function () {
    verifyUserUpdated(e.id);
  });
});

bthread("User delete verification", function () {
  const e = waitForAnyUserDeleted();
  block(matchAddUser(e.id, ANY), function () {
    verifyUserDoesNotExist(e.id);
  });
});

bthread("Book create verification", function () {
  const e = waitForAnyBookAdded();
  block(matchDeleteBook(e.id, ANY), function () {
    verifyBookExists(e.id);
  });
});

bthread("Book update verification", function () {
  const e = waitForAnyBookUpdated();
  block(matchDeleteBook(e.id, ANY), function () {
    verifyBookUpdated(e.id);
  });
});

bthread("Book delete verification", function () {
  const e = waitForAnyBookDeleted();
  block(matchAddBook(e.id, ANY), function () {
    verifyBookDoesNotExist(e.id);
  });
});

bthread("Loan create verification", function () {
  const e = waitForAnyLoanAdded();
  block(matchDeleteLoan(e.id, ANY), function () {
    verifyLoanExists(e.id);
  });
});

bthread("Loan update verification", function () {
  const e = waitForAnyLoanUpdated();
  block(matchDeleteLoan(e.id, ANY), function () {
    verifyLoanUpdated(e.id);
  });
});

bthread("Loan delete verification", function () {
  const e = waitForAnyLoanDeleted();
  block(matchAddLoan(e.id, ANY), function () {
    verifyLoanDoesNotExist(e.id);
  });
});

bthread("LoanCreate create verification", function () {
  const e = waitForAnyLoanCreateAdded();
  block(matchDeleteLoanCreate(e.id, ANY), function () {
    verifyLoanCreateExists(e.id);
  });
});

bthread("LoanCreate update verification", function () {
  const e = waitForAnyLoanCreateUpdated();
  block(matchDeleteLoanCreate(e.id, ANY), function () {
    verifyLoanCreateUpdated(e.id);
  });
});

bthread("LoanCreate delete verification", function () {
  const e = waitForAnyLoanCreateDeleted();
  block(matchAddLoanCreate(e.id, ANY), function () {
    verifyLoanCreateDoesNotExist(e.id);
  });
});

// ===== RELATIONSHIP GUARDS =====

// ===== UNIQUENESS GUARDS =====

bthread("Guard: Unique HoldCreate", function () {
  const x = waitForAnyHoldCreateAdded();
  block(matchAddHoldCreate(x.id, ANY), function () {});
});

bthread("Guard: Unique UserCreate", function () {
  const x = waitForAnyUserCreateAdded();
  block(matchAddUserCreate(x.id, ANY), function () {});
});

bthread("Guard: Unique Hold", function () {
  const x = waitForAnyHoldAdded();
  block(matchAddHold(x.id, ANY), function () {});
});

bthread("Guard: Unique BookCreate", function () {
  const x = waitForAnyBookCreateAdded();
  block(matchAddBookCreate(x.id, ANY), function () {});
});

bthread("Guard: Unique User", function () {
  const x = waitForAnyUserAdded();
  block(matchAddUser(x.id, ANY), function () {});
});

bthread("Guard: Unique Book", function () {
  const x = waitForAnyBookAdded();
  block(matchAddBook(x.id, ANY), function () {});
});

bthread("Guard: Unique Loan", function () {
  const x = waitForAnyLoanAdded();
  block(matchAddLoan(x.id, ANY), function () {});
});

bthread("Guard: Unique LoanCreate", function () {
  const x = waitForAnyLoanCreateAdded();
  block(matchAddLoanCreate(x.id, ANY), function () {});
});

// ===== NEGATIVE/EDGE STATUS GUARDS =====
