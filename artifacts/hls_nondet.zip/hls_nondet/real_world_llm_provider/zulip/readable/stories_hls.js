// ====================================================================
// Auto-generated garage-style High-Level Stories (HLS)
// SUT: zulip
// ====================================================================

var ANY = (typeof H !== 'undefined' && H.ANY) ? H.ANY : (typeof ANY !== 'undefined' ? ANY : '*');

// ===== ACTIVE LIFECYCLES =====


bthread("EmojiReaction lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEmojiReaction(x.id);
  updateEmojiReaction(x.id);
  updateEmojiReaction(x.id);
  verifyEmojiReactionExists(x.id);
  verifyEmojiReactionUpdated(x.id);
});

bthread("UserNotAuthorizedError lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserNotAuthorizedError(x.id);
  updateUserNotAuthorizedError(x.id);
  updateUserNotAuthorizedError(x.id);
  verifyUserNotAuthorizedErrorExists(x.id);
  verifyUserNotAuthorizedErrorUpdated(x.id);
});

bthread("CanRemoveSubscribersGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCanRemoveSubscribersGroup(x.id);
  updateCanRemoveSubscribersGroup(x.id);
  updateCanRemoveSubscribersGroup(x.id);
  verifyCanRemoveSubscribersGroupExists(x.id);
  verifyCanRemoveSubscribersGroupUpdated(x.id);
});

bthread("InvalidApiKeyError lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInvalidApiKeyError(x.id);
  updateInvalidApiKeyError(x.id);
  updateInvalidApiKeyError(x.id);
  verifyInvalidApiKeyErrorExists(x.id);
  verifyInvalidApiKeyErrorUpdated(x.id);
});

bthread("ReactionType lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addReactionType(x.id);
  updateReactionType(x.id);
  updateReactionType(x.id);
  verifyReactionTypeExists(x.id);
  verifyReactionTypeUpdated(x.id);
});

bthread("NonExistingChannelIdError lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNonExistingChannelIdError(x.id);
  updateNonExistingChannelIdError(x.id);
  updateNonExistingChannelIdError(x.id);
  verifyNonExistingChannelIdErrorExists(x.id);
  verifyNonExistingChannelIdErrorUpdated(x.id);
});

bthread("RealmExport lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealmExport(x.id);
  updateRealmExport(x.id);
  updateRealmExport(x.id);
  verifyRealmExportExists(x.id);
  verifyRealmExportUpdated(x.id);
});

bthread("SavedSnippet lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSavedSnippet(x.id);
  updateSavedSnippet(x.id);
  updateSavedSnippet(x.id);
  verifySavedSnippetExists(x.id);
  verifySavedSnippetUpdated(x.id);
});

bthread("InvalidChannelError lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInvalidChannelError(x.id);
  updateInvalidChannelError(x.id);
  updateInvalidChannelError(x.id);
  verifyInvalidChannelErrorExists(x.id);
  verifyInvalidChannelErrorUpdated(x.id);
});

bthread("AllPublicChannels lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAllPublicChannels(x.id);
  updateAllPublicChannels(x.id);
  updateAllPublicChannels(x.id);
  verifyAllPublicChannelsExists(x.id);
  verifyAllPublicChannelsUpdated(x.id);
});

bthread("BasicChannel lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBasicChannel(x.id);
  updateBasicChannel(x.id);
  updateBasicChannel(x.id);
  verifyBasicChannelExists(x.id);
  verifyBasicChannelUpdated(x.id);
});

bthread("Attachment lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAttachment(x.id);
  updateAttachment(x.id);
  updateAttachment(x.id);
  verifyAttachmentExists(x.id);
  verifyAttachmentUpdated(x.id);
});

bthread("NavigationView lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNavigationView(x.id);
  updateNavigationView(x.id);
  updateNavigationView(x.id);
  verifyNavigationViewExists(x.id);
  verifyNavigationViewUpdated(x.id);
});

bthread("EmojiCode lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEmojiCode(x.id);
  updateEmojiCode(x.id);
  updateEmojiCode(x.id);
  verifyEmojiCodeExists(x.id);
  verifyEmojiCodeUpdated(x.id);
});

bthread("Profile_data lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addProfile_data(x.id);
  updateProfile_data(x.id);
  updateProfile_data(x.id);
  verifyProfile_dataExists(x.id);
  verifyProfile_dataUpdated(x.id);
});

bthread("CodedErrorBase lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCodedErrorBase(x.id);
  updateCodedErrorBase(x.id);
  updateCodedErrorBase(x.id);
  verifyCodedErrorBaseExists(x.id);
  verifyCodedErrorBaseUpdated(x.id);
});

bthread("PushNotificationAdminActionRequiredError lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPushNotificationAdminActionRequiredError(x.id);
  updatePushNotificationAdminActionRequiredError(x.id);
  updatePushNotificationAdminActionRequiredError(x.id);
  verifyPushNotificationAdminActionRequiredErrorExists(x.id);
  verifyPushNotificationAdminActionRequiredErrorUpdated(x.id);
});

bthread("BasicBotBase lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBasicBotBase(x.id);
  updateBasicBotBase(x.id);
  updateBasicBotBase(x.id);
  verifyBasicBotBaseExists(x.id);
  verifyBasicBotBaseUpdated(x.id);
});

bthread("Narrow lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNarrow(x.id);
  updateNarrow(x.id);
  updateNarrow(x.id);
  verifyNarrowExists(x.id);
  verifyNarrowUpdated(x.id);
});

bthread("JsonSuccess lifecycle", function () {
  const x = pick([{id: "J001"}, {id: "J002"}]);
  addJsonSuccess(x.id);
  updateJsonSuccess(x.id);
  updateJsonSuccess(x.id);
  verifyJsonSuccessExists(x.id);
  verifyJsonSuccessUpdated(x.id);
});

bthread("LegacyPresenceFormat lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLegacyPresenceFormat(x.id);
  updateLegacyPresenceFormat(x.id);
  updateLegacyPresenceFormat(x.id);
  verifyLegacyPresenceFormatExists(x.id);
  verifyLegacyPresenceFormatUpdated(x.id);
});

bthread("InternalBouncerServerError lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInternalBouncerServerError(x.id);
  updateInternalBouncerServerError(x.id);
  updateInternalBouncerServerError(x.id);
  verifyInternalBouncerServerErrorExists(x.id);
  verifyInternalBouncerServerErrorUpdated(x.id);
});

bthread("IgnoredParametersUnsupported lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIgnoredParametersUnsupported(x.id);
  updateIgnoredParametersUnsupported(x.id);
  updateIgnoredParametersUnsupported(x.id);
  verifyIgnoredParametersUnsupportedExists(x.id);
  verifyIgnoredParametersUnsupportedUpdated(x.id);
});

bthread("Anchor lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAnchor(x.id);
  updateAnchor(x.id);
  updateAnchor(x.id);
  verifyAnchorExists(x.id);
  verifyAnchorUpdated(x.id);
});

bthread("EventTypeSchema lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEventTypeSchema(x.id);
  updateEventTypeSchema(x.id);
  updateEventTypeSchema(x.id);
  verifyEventTypeSchemaExists(x.id);
  verifyEventTypeSchemaUpdated(x.id);
});

bthread("MessagesEvent lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessagesEvent(x.id);
  updateMessagesEvent(x.id);
  updateMessagesEvent(x.id);
  verifyMessagesEventExists(x.id);
  verifyMessagesEventUpdated(x.id);
});

bthread("LinkifierURLTemplate lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLinkifierURLTemplate(x.id);
  updateLinkifierURLTemplate(x.id);
  updateLinkifierURLTemplate(x.id);
  verifyLinkifierURLTemplateExists(x.id);
  verifyLinkifierURLTemplateUpdated(x.id);
});

bthread("ChannelFolder lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addChannelFolder(x.id);
  updateChannelFolder(x.id);
  updateChannelFolder(x.id);
  verifyChannelFolderExists(x.id);
  verifyChannelFolderUpdated(x.id);
});

bthread("Invite lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInvite(x.id);
  updateInvite(x.id);
  updateInvite(x.id);
  verifyInviteExists(x.id);
  verifyInviteUpdated(x.id);
});

bthread("CanSubscribeGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCanSubscribeGroup(x.id);
  updateCanSubscribeGroup(x.id);
  updateCanSubscribeGroup(x.id);
  verifyCanSubscribeGroupExists(x.id);
  verifyCanSubscribeGroupUpdated(x.id);
});

bthread("JsonSuccessBase lifecycle", function () {
  const x = pick([{id: "J001"}, {id: "J002"}]);
  addJsonSuccessBase(x.id);
  updateJsonSuccessBase(x.id);
  updateJsonSuccessBase(x.id);
  verifyJsonSuccessBaseExists(x.id);
  verifyJsonSuccessBaseUpdated(x.id);
});

bthread("EmojiBase lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEmojiBase(x.id);
  updateEmojiBase(x.id);
  updateEmojiBase(x.id);
  verifyEmojiBaseExists(x.id);
  verifyEmojiBaseUpdated(x.id);
});

bthread("User lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUser(x.id);
  updateUser(x.id);
  updateUser(x.id);
  verifyUserExists(x.id);
  verifyUserUpdated(x.id);
});

bthread("MissingArgumentError lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMissingArgumentError(x.id);
  updateMissingArgumentError(x.id);
  updateMissingArgumentError(x.id);
  verifyMissingArgumentErrorExists(x.id);
  verifyMissingArgumentErrorUpdated(x.id);
});

bthread("NonExistingChannelNameError lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNonExistingChannelNameError(x.id);
  updateNonExistingChannelNameError(x.id);
  updateNonExistingChannelNameError(x.id);
  verifyNonExistingChannelNameErrorExists(x.id);
  verifyNonExistingChannelNameErrorUpdated(x.id);
});

bthread("Principals lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrincipals(x.id);
  updatePrincipals(x.id);
  updatePrincipals(x.id);
  verifyPrincipalsExists(x.id);
  verifyPrincipalsUpdated(x.id);
});

bthread("InvalidPushDeviceTokenError lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInvalidPushDeviceTokenError(x.id);
  updateInvalidPushDeviceTokenError(x.id);
  updateInvalidPushDeviceTokenError(x.id);
  verifyInvalidPushDeviceTokenErrorExists(x.id);
  verifyInvalidPushDeviceTokenErrorUpdated(x.id);
});

bthread("RealmEmoji lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealmEmoji(x.id);
  updateRealmEmoji(x.id);
  updateRealmEmoji(x.id);
  verifyRealmEmojiExists(x.id);
  verifyRealmEmojiUpdated(x.id);
});

bthread("FailedToConnectBouncerError lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFailedToConnectBouncerError(x.id);
  updateFailedToConnectBouncerError(x.id);
  updateFailedToConnectBouncerError(x.id);
  verifyFailedToConnectBouncerErrorExists(x.id);
  verifyFailedToConnectBouncerErrorUpdated(x.id);
});

bthread("CanAdministerChannelGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCanAdministerChannelGroup(x.id);
  updateCanAdministerChannelGroup(x.id);
  updateCanAdministerChannelGroup(x.id);
  verifyCanAdministerChannelGroupExists(x.id);
  verifyCanAdministerChannelGroupUpdated(x.id);
});

bthread("OptionalContent lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOptionalContent(x.id);
  updateOptionalContent(x.id);
  updateOptionalContent(x.id);
  verifyOptionalContentExists(x.id);
  verifyOptionalContentUpdated(x.id);
});

bthread("WebhookConfigOption lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWebhookConfigOption(x.id);
  updateWebhookConfigOption(x.id);
  updateWebhookConfigOption(x.id);
  verifyWebhookConfigOptionExists(x.id);
  verifyWebhookConfigOptionUpdated(x.id);
});

bthread("RequiredContent lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRequiredContent(x.id);
  updateRequiredContent(x.id);
  updateRequiredContent(x.id);
  verifyRequiredContentExists(x.id);
  verifyRequiredContentUpdated(x.id);
});

bthread("InvalidMessageError lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInvalidMessageError(x.id);
  updateInvalidMessageError(x.id);
  updateInvalidMessageError(x.id);
  verifyInvalidMessageErrorExists(x.id);
  verifyInvalidMessageErrorUpdated(x.id);
});

bthread("UserBase lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserBase(x.id);
  updateUserBase(x.id);
  updateUserBase(x.id);
  verifyUserBaseExists(x.id);
  verifyUserBaseUpdated(x.id);
});

bthread("CanMoveMessagesOutOfChannelGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCanMoveMessagesOutOfChannelGroup(x.id);
  updateCanMoveMessagesOutOfChannelGroup(x.id);
  updateCanMoveMessagesOutOfChannelGroup(x.id);
  verifyCanMoveMessagesOutOfChannelGroupExists(x.id);
  verifyCanMoveMessagesOutOfChannelGroupUpdated(x.id);
});

bthread("LinkifierPattern lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLinkifierPattern(x.id);
  updateLinkifierPattern(x.id);
  updateLinkifierPattern(x.id);
  verifyLinkifierPatternExists(x.id);
  verifyLinkifierPatternUpdated(x.id);
});

bthread("MessagesBase lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessagesBase(x.id);
  updateMessagesBase(x.id);
  updateMessagesBase(x.id);
  verifyMessagesBaseExists(x.id);
  verifyMessagesBaseUpdated(x.id);
});

bthread("EmailAddressVisibility lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEmailAddressVisibility(x.id);
  updateEmailAddressVisibility(x.id);
  updateEmailAddressVisibility(x.id);
  verifyEmailAddressVisibilityExists(x.id);
  verifyEmailAddressVisibilityUpdated(x.id);
});

bthread("ModernPresenceFormat lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModernPresenceFormat(x.id);
  updateModernPresenceFormat(x.id);
  updateModernPresenceFormat(x.id);
  verifyModernPresenceFormatExists(x.id);
  verifyModernPresenceFormatUpdated(x.id);
});

bthread("BasicBot lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBasicBot(x.id);
  updateBasicBot(x.id);
  updateBasicBot(x.id);
  verifyBasicBotExists(x.id);
  verifyBasicBotUpdated(x.id);
});

bthread("BasicChannelBase lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBasicChannelBase(x.id);
  updateBasicChannelBase(x.id);
  updateBasicChannelBase(x.id);
  verifyBasicChannelBaseExists(x.id);
  verifyBasicChannelBaseUpdated(x.id);
});

bthread("UserGroup lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserGroup(x.id);
  updateUserGroup(x.id);
  updateUserGroup(x.id);
  verifyUserGroupExists(x.id);
  verifyUserGroupUpdated(x.id);
});

bthread("InviteRoleParameter lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInviteRoleParameter(x.id);
  updateInviteRoleParameter(x.id);
  updateInviteRoleParameter(x.id);
  verifyInviteRoleParameterExists(x.id);
  verifyInviteRoleParameterUpdated(x.id);
});

bthread("RealmDeactivatedError lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealmDeactivatedError(x.id);
  updateRealmDeactivatedError(x.id);
  updateRealmDeactivatedError(x.id);
  verifyRealmDeactivatedErrorExists(x.id);
  verifyRealmDeactivatedErrorUpdated(x.id);
});

bthread("NoActivePushDeviceError lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNoActivePushDeviceError(x.id);
  updateNoActivePushDeviceError(x.id);
  updateNoActivePushDeviceError(x.id);
  verifyNoActivePushDeviceErrorExists(x.id);
  verifyNoActivePushDeviceErrorUpdated(x.id);
});

bthread("EmojiReactionEvent lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEmojiReactionEvent(x.id);
  updateEmojiReactionEvent(x.id);
  updateEmojiReactionEvent(x.id);
  verifyEmojiReactionEventExists(x.id);
  verifyEmojiReactionEventUpdated(x.id);
});

bthread("BadEventQueueIdError lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBadEventQueueIdError(x.id);
  updateBadEventQueueIdError(x.id);
  updateBadEventQueueIdError(x.id);
  verifyBadEventQueueIdErrorExists(x.id);
  verifyBadEventQueueIdErrorUpdated(x.id);
});

bthread("GroupSettingValue lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGroupSettingValue(x.id);
  updateGroupSettingValue(x.id);
  updateGroupSettingValue(x.id);
  verifyGroupSettingValueExists(x.id);
  verifyGroupSettingValueUpdated(x.id);
});

bthread("Event_types lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEvent_types(x.id);
  updateEvent_types(x.id);
  updateEvent_types(x.id);
  verifyEvent_typesExists(x.id);
  verifyEvent_typesUpdated(x.id);
});

bthread("RealmPlayground lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealmPlayground(x.id);
  updateRealmPlayground(x.id);
  updateRealmPlayground(x.id);
  verifyRealmPlaygroundExists(x.id);
  verifyRealmPlaygroundUpdated(x.id);
});

bthread("InviteExpirationParameter lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInviteExpirationParameter(x.id);
  updateInviteExpirationParameter(x.id);
  updateInviteExpirationParameter(x.id);
  verifyInviteExpirationParameterExists(x.id);
  verifyInviteExpirationParameterUpdated(x.id);
});

bthread("RateLimitedError lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRateLimitedError(x.id);
  updateRateLimitedError(x.id);
  updateRateLimitedError(x.id);
  verifyRateLimitedErrorExists(x.id);
  verifyRateLimitedErrorUpdated(x.id);
});

bthread("ChannelCanAddSubscribersGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addChannelCanAddSubscribersGroup(x.id);
  updateChannelCanAddSubscribersGroup(x.id);
  updateChannelCanAddSubscribersGroup(x.id);
  verifyChannelCanAddSubscribersGroupExists(x.id);
  verifyChannelCanAddSubscribersGroupUpdated(x.id);
});

bthread("WebhookUrlOption lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWebhookUrlOption(x.id);
  updateWebhookUrlOption(x.id);
  updateWebhookUrlOption(x.id);
  verifyWebhookUrlOptionExists(x.id);
  verifyWebhookUrlOptionUpdated(x.id);
});

bthread("InvitationFailedError lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInvitationFailedError(x.id);
  updateInvitationFailedError(x.id);
  updateInvitationFailedError(x.id);
  verifyInvitationFailedErrorExists(x.id);
  verifyInvitationFailedErrorUpdated(x.id);
});

bthread("ScheduledMessage lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addScheduledMessage(x.id);
  updateScheduledMessage(x.id);
  updateScheduledMessage(x.id);
  verifyScheduledMessageExists(x.id);
  verifyScheduledMessageUpdated(x.id);
});

bthread("HistoryPublicToSubscribers lifecycle", function () {
  const x = pick([{id: "H001"}, {id: "H002"}]);
  addHistoryPublicToSubscribers(x.id);
  updateHistoryPublicToSubscribers(x.id);
  updateHistoryPublicToSubscribers(x.id);
  verifyHistoryPublicToSubscribersExists(x.id);
  verifyHistoryPublicToSubscribersUpdated(x.id);
});

bthread("UserStatus lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserStatus(x.id);
  updateUserStatus(x.id);
  updateUserStatus(x.id);
  verifyUserStatusExists(x.id);
  verifyUserStatusUpdated(x.id);
});

bthread("DefaultChannelGroup lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDefaultChannelGroup(x.id);
  updateDefaultChannelGroup(x.id);
  updateDefaultChannelGroup(x.id);
  verifyDefaultChannelGroupExists(x.id);
  verifyDefaultChannelGroupUpdated(x.id);
});

bthread("Bot lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBot(x.id);
  updateBot(x.id);
  updateBot(x.id);
  verifyBotExists(x.id);
  verifyBotUpdated(x.id);
});

bthread("IgnoredParametersSuccess lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIgnoredParametersSuccess(x.id);
  updateIgnoredParametersSuccess(x.id);
  updateIgnoredParametersSuccess(x.id);
  verifyIgnoredParametersSuccessExists(x.id);
  verifyIgnoredParametersSuccessUpdated(x.id);
});

bthread("JsonResponseBase lifecycle", function () {
  const x = pick([{id: "J001"}, {id: "J002"}]);
  addJsonResponseBase(x.id);
  updateJsonResponseBase(x.id);
  updateJsonResponseBase(x.id);
  verifyJsonResponseBaseExists(x.id);
  verifyJsonResponseBaseUpdated(x.id);
});

bthread("MessageRetentionDays lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessageRetentionDays(x.id);
  updateMessageRetentionDays(x.id);
  updateMessageRetentionDays(x.id);
  verifyMessageRetentionDaysExists(x.id);
  verifyMessageRetentionDaysUpdated(x.id);
});

bthread("GroupSettingValueUpdate lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGroupSettingValueUpdate(x.id);
  updateGroupSettingValueUpdate(x.id);
  updateGroupSettingValueUpdate(x.id);
  verifyGroupSettingValueUpdateExists(x.id);
  verifyGroupSettingValueUpdateUpdated(x.id);
});

bthread("IncompatibleParametersError lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncompatibleParametersError(x.id);
  updateIncompatibleParametersError(x.id);
  updateIncompatibleParametersError(x.id);
  verifyIncompatibleParametersErrorExists(x.id);
  verifyIncompatibleParametersErrorUpdated(x.id);
});

bthread("IgnoredParametersBase lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIgnoredParametersBase(x.id);
  updateIgnoredParametersBase(x.id);
  updateIgnoredParametersBase(x.id);
  verifyIgnoredParametersBaseExists(x.id);
  verifyIgnoredParametersBaseUpdated(x.id);
});

bthread("CanDeleteAnyMessageGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCanDeleteAnyMessageGroup(x.id);
  updateCanDeleteAnyMessageGroup(x.id);
  updateCanDeleteAnyMessageGroup(x.id);
  verifyCanDeleteAnyMessageGroupExists(x.id);
  verifyCanDeleteAnyMessageGroupUpdated(x.id);
});

bthread("CustomProfileField lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomProfileField(x.id);
  updateCustomProfileField(x.id);
  updateCustomProfileField(x.id);
  verifyCustomProfileFieldExists(x.id);
  verifyCustomProfileFieldUpdated(x.id);
});

bthread("CanMoveMessagesWithinChannelGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCanMoveMessagesWithinChannelGroup(x.id);
  updateCanMoveMessagesWithinChannelGroup(x.id);
  updateCanMoveMessagesWithinChannelGroup(x.id);
  verifyCanMoveMessagesWithinChannelGroupExists(x.id);
  verifyCanMoveMessagesWithinChannelGroupUpdated(x.id);
});

bthread("Subscription lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSubscription(x.id);
  updateSubscription(x.id);
  updateSubscription(x.id);
  verifySubscriptionExists(x.id);
  verifySubscriptionUpdated(x.id);
});

bthread("CodedError lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCodedError(x.id);
  updateCodedError(x.id);
  updateCodedError(x.id);
  verifyCodedErrorExists(x.id);
  verifyCodedErrorUpdated(x.id);
});

bthread("CanResolveTopicsGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCanResolveTopicsGroup(x.id);
  updateCanResolveTopicsGroup(x.id);
  updateCanResolveTopicsGroup(x.id);
  verifyCanResolveTopicsGroupExists(x.id);
  verifyCanResolveTopicsGroupUpdated(x.id);
});

bthread("SendNewSubscriptionMessages lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSendNewSubscriptionMessages(x.id);
  updateSendNewSubscriptionMessages(x.id);
  updateSendNewSubscriptionMessages(x.id);
  verifySendNewSubscriptionMessagesExists(x.id);
  verifySendNewSubscriptionMessagesUpdated(x.id);
});

bthread("RealmAuthenticationMethod lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealmAuthenticationMethod(x.id);
  updateRealmAuthenticationMethod(x.id);
  updateRealmAuthenticationMethod(x.id);
  verifyRealmAuthenticationMethodExists(x.id);
  verifyRealmAuthenticationMethodUpdated(x.id);
});

bthread("CanSendMessageGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCanSendMessageGroup(x.id);
  updateCanSendMessageGroup(x.id);
  updateCanSendMessageGroup(x.id);
  verifyCanSendMessageGroupExists(x.id);
  verifyCanSendMessageGroupUpdated(x.id);
});

bthread("Reminder lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addReminder(x.id);
  updateReminder(x.id);
  updateReminder(x.id);
  verifyReminderExists(x.id);
  verifyReminderUpdated(x.id);
});

bthread("OnboardingStep lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOnboardingStep(x.id);
  updateOnboardingStep(x.id);
  updateOnboardingStep(x.id);
  verifyOnboardingStepExists(x.id);
  verifyOnboardingStepUpdated(x.id);
});

bthread("Draft lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDraft(x.id);
  updateDraft(x.id);
  updateDraft(x.id);
  verifyDraftExists(x.id);
  verifyDraftUpdated(x.id);
});

bthread("InvalidRemotePushDeviceTokenError lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInvalidRemotePushDeviceTokenError(x.id);
  updateInvalidRemotePushDeviceTokenError(x.id);
  updateInvalidRemotePushDeviceTokenError(x.id);
  verifyInvalidRemotePushDeviceTokenErrorExists(x.id);
  verifyInvalidRemotePushDeviceTokenErrorUpdated(x.id);
});

bthread("ApiKeyResponse lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApiKeyResponse(x.id);
  updateApiKeyResponse(x.id);
  updateApiKeyResponse(x.id);
  verifyApiKeyResponseExists(x.id);
  verifyApiKeyResponseUpdated(x.id);
});

bthread("UserDeactivatedError lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserDeactivatedError(x.id);
  updateUserDeactivatedError(x.id);
  updateUserDeactivatedError(x.id);
  verifyUserDeactivatedErrorExists(x.id);
  verifyUserDeactivatedErrorUpdated(x.id);
});

bthread("CanDeleteOwnMessageGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCanDeleteOwnMessageGroup(x.id);
  updateCanDeleteOwnMessageGroup(x.id);
  updateCanDeleteOwnMessageGroup(x.id);
  verifyCanDeleteOwnMessageGroupExists(x.id);
  verifyCanDeleteOwnMessageGroupUpdated(x.id);
});

bthread("GroupPermissionSetting lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGroupPermissionSetting(x.id);
  updateGroupPermissionSetting(x.id);
  updateGroupPermissionSetting(x.id);
  verifyGroupPermissionSettingExists(x.id);
  verifyGroupPermissionSettingUpdated(x.id);
});

bthread("BotConfiguration lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBotConfiguration(x.id);
  updateBotConfiguration(x.id);
  updateBotConfiguration(x.id);
  verifyBotConfigurationExists(x.id);
  verifyBotConfigurationUpdated(x.id);
});

bthread("FolderId lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFolderId(x.id);
  updateFolderId(x.id);
  updateFolderId(x.id);
  verifyFolderIdExists(x.id);
  verifyFolderIdUpdated(x.id);
});

bthread("ScheduledMessageBase lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addScheduledMessageBase(x.id);
  updateScheduledMessageBase(x.id);
  updateScheduledMessageBase(x.id);
  verifyScheduledMessageBaseExists(x.id);
  verifyScheduledMessageBaseUpdated(x.id);
});

bthread("EventIdSchema lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEventIdSchema(x.id);
  updateEventIdSchema(x.id);
  updateEventIdSchema(x.id);
  verifyEventIdSchemaExists(x.id);
  verifyEventIdSchemaUpdated(x.id);
});

bthread("TopicsPolicy lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTopicsPolicy(x.id);
  updateTopicsPolicy(x.id);
  updateTopicsPolicy(x.id);
  verifyTopicsPolicyExists(x.id);
  verifyTopicsPolicyUpdated(x.id);
});

bthread("RealmDomain lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealmDomain(x.id);
  updateRealmDomain(x.id);
  updateRealmDomain(x.id);
  verifyRealmDomainExists(x.id);
  verifyRealmDomainUpdated(x.id);
});

// ===== PASSIVE ASSERTIONS =====

bthread("EmojiReaction create verification", function () {
  const e = waitForAnyEmojiReactionAdded();
  block(matchDeleteEmojiReaction(e.id, ANY), function () {
    verifyEmojiReactionExists(e.id);
  });
});

bthread("EmojiReaction update verification", function () {
  const e = waitForAnyEmojiReactionUpdated();
  block(matchDeleteEmojiReaction(e.id, ANY), function () {
    verifyEmojiReactionUpdated(e.id);
  });
});

bthread("EmojiReaction delete verification", function () {
  const e = waitForAnyEmojiReactionDeleted();
  block(matchAddEmojiReaction(e.id, ANY), function () {
    verifyEmojiReactionDoesNotExist(e.id);
  });
});

bthread("UserNotAuthorizedError create verification", function () {
  const e = waitForAnyUserNotAuthorizedErrorAdded();
  block(matchDeleteUserNotAuthorizedError(e.id, ANY), function () {
    verifyUserNotAuthorizedErrorExists(e.id);
  });
});

bthread("UserNotAuthorizedError update verification", function () {
  const e = waitForAnyUserNotAuthorizedErrorUpdated();
  block(matchDeleteUserNotAuthorizedError(e.id, ANY), function () {
    verifyUserNotAuthorizedErrorUpdated(e.id);
  });
});

bthread("UserNotAuthorizedError delete verification", function () {
  const e = waitForAnyUserNotAuthorizedErrorDeleted();
  block(matchAddUserNotAuthorizedError(e.id, ANY), function () {
    verifyUserNotAuthorizedErrorDoesNotExist(e.id);
  });
});

bthread("CanRemoveSubscribersGroup create verification", function () {
  const e = waitForAnyCanRemoveSubscribersGroupAdded();
  block(matchDeleteCanRemoveSubscribersGroup(e.id, ANY), function () {
    verifyCanRemoveSubscribersGroupExists(e.id);
  });
});

bthread("CanRemoveSubscribersGroup update verification", function () {
  const e = waitForAnyCanRemoveSubscribersGroupUpdated();
  block(matchDeleteCanRemoveSubscribersGroup(e.id, ANY), function () {
    verifyCanRemoveSubscribersGroupUpdated(e.id);
  });
});

bthread("CanRemoveSubscribersGroup delete verification", function () {
  const e = waitForAnyCanRemoveSubscribersGroupDeleted();
  block(matchAddCanRemoveSubscribersGroup(e.id, ANY), function () {
    verifyCanRemoveSubscribersGroupDoesNotExist(e.id);
  });
});

bthread("InvalidApiKeyError create verification", function () {
  const e = waitForAnyInvalidApiKeyErrorAdded();
  block(matchDeleteInvalidApiKeyError(e.id, ANY), function () {
    verifyInvalidApiKeyErrorExists(e.id);
  });
});

bthread("InvalidApiKeyError update verification", function () {
  const e = waitForAnyInvalidApiKeyErrorUpdated();
  block(matchDeleteInvalidApiKeyError(e.id, ANY), function () {
    verifyInvalidApiKeyErrorUpdated(e.id);
  });
});

bthread("InvalidApiKeyError delete verification", function () {
  const e = waitForAnyInvalidApiKeyErrorDeleted();
  block(matchAddInvalidApiKeyError(e.id, ANY), function () {
    verifyInvalidApiKeyErrorDoesNotExist(e.id);
  });
});

bthread("ReactionType create verification", function () {
  const e = waitForAnyReactionTypeAdded();
  block(matchDeleteReactionType(e.id, ANY), function () {
    verifyReactionTypeExists(e.id);
  });
});

bthread("ReactionType update verification", function () {
  const e = waitForAnyReactionTypeUpdated();
  block(matchDeleteReactionType(e.id, ANY), function () {
    verifyReactionTypeUpdated(e.id);
  });
});

bthread("ReactionType delete verification", function () {
  const e = waitForAnyReactionTypeDeleted();
  block(matchAddReactionType(e.id, ANY), function () {
    verifyReactionTypeDoesNotExist(e.id);
  });
});

bthread("NonExistingChannelIdError create verification", function () {
  const e = waitForAnyNonExistingChannelIdErrorAdded();
  block(matchDeleteNonExistingChannelIdError(e.id, ANY), function () {
    verifyNonExistingChannelIdErrorExists(e.id);
  });
});

bthread("NonExistingChannelIdError update verification", function () {
  const e = waitForAnyNonExistingChannelIdErrorUpdated();
  block(matchDeleteNonExistingChannelIdError(e.id, ANY), function () {
    verifyNonExistingChannelIdErrorUpdated(e.id);
  });
});

bthread("NonExistingChannelIdError delete verification", function () {
  const e = waitForAnyNonExistingChannelIdErrorDeleted();
  block(matchAddNonExistingChannelIdError(e.id, ANY), function () {
    verifyNonExistingChannelIdErrorDoesNotExist(e.id);
  });
});

bthread("RealmExport create verification", function () {
  const e = waitForAnyRealmExportAdded();
  block(matchDeleteRealmExport(e.id, ANY), function () {
    verifyRealmExportExists(e.id);
  });
});

bthread("RealmExport update verification", function () {
  const e = waitForAnyRealmExportUpdated();
  block(matchDeleteRealmExport(e.id, ANY), function () {
    verifyRealmExportUpdated(e.id);
  });
});

bthread("RealmExport delete verification", function () {
  const e = waitForAnyRealmExportDeleted();
  block(matchAddRealmExport(e.id, ANY), function () {
    verifyRealmExportDoesNotExist(e.id);
  });
});

bthread("SavedSnippet create verification", function () {
  const e = waitForAnySavedSnippetAdded();
  block(matchDeleteSavedSnippet(e.id, ANY), function () {
    verifySavedSnippetExists(e.id);
  });
});

bthread("SavedSnippet update verification", function () {
  const e = waitForAnySavedSnippetUpdated();
  block(matchDeleteSavedSnippet(e.id, ANY), function () {
    verifySavedSnippetUpdated(e.id);
  });
});

bthread("SavedSnippet delete verification", function () {
  const e = waitForAnySavedSnippetDeleted();
  block(matchAddSavedSnippet(e.id, ANY), function () {
    verifySavedSnippetDoesNotExist(e.id);
  });
});

bthread("InvalidChannelError create verification", function () {
  const e = waitForAnyInvalidChannelErrorAdded();
  block(matchDeleteInvalidChannelError(e.id, ANY), function () {
    verifyInvalidChannelErrorExists(e.id);
  });
});

bthread("InvalidChannelError update verification", function () {
  const e = waitForAnyInvalidChannelErrorUpdated();
  block(matchDeleteInvalidChannelError(e.id, ANY), function () {
    verifyInvalidChannelErrorUpdated(e.id);
  });
});

bthread("InvalidChannelError delete verification", function () {
  const e = waitForAnyInvalidChannelErrorDeleted();
  block(matchAddInvalidChannelError(e.id, ANY), function () {
    verifyInvalidChannelErrorDoesNotExist(e.id);
  });
});

bthread("AllPublicChannels create verification", function () {
  const e = waitForAnyAllPublicChannelsAdded();
  block(matchDeleteAllPublicChannels(e.id, ANY), function () {
    verifyAllPublicChannelsExists(e.id);
  });
});

bthread("AllPublicChannels update verification", function () {
  const e = waitForAnyAllPublicChannelsUpdated();
  block(matchDeleteAllPublicChannels(e.id, ANY), function () {
    verifyAllPublicChannelsUpdated(e.id);
  });
});

bthread("AllPublicChannels delete verification", function () {
  const e = waitForAnyAllPublicChannelsDeleted();
  block(matchAddAllPublicChannels(e.id, ANY), function () {
    verifyAllPublicChannelsDoesNotExist(e.id);
  });
});

bthread("BasicChannel create verification", function () {
  const e = waitForAnyBasicChannelAdded();
  block(matchDeleteBasicChannel(e.id, ANY), function () {
    verifyBasicChannelExists(e.id);
  });
});

bthread("BasicChannel update verification", function () {
  const e = waitForAnyBasicChannelUpdated();
  block(matchDeleteBasicChannel(e.id, ANY), function () {
    verifyBasicChannelUpdated(e.id);
  });
});

bthread("BasicChannel delete verification", function () {
  const e = waitForAnyBasicChannelDeleted();
  block(matchAddBasicChannel(e.id, ANY), function () {
    verifyBasicChannelDoesNotExist(e.id);
  });
});

bthread("Attachment create verification", function () {
  const e = waitForAnyAttachmentAdded();
  block(matchDeleteAttachment(e.id, ANY), function () {
    verifyAttachmentExists(e.id);
  });
});

bthread("Attachment update verification", function () {
  const e = waitForAnyAttachmentUpdated();
  block(matchDeleteAttachment(e.id, ANY), function () {
    verifyAttachmentUpdated(e.id);
  });
});

bthread("Attachment delete verification", function () {
  const e = waitForAnyAttachmentDeleted();
  block(matchAddAttachment(e.id, ANY), function () {
    verifyAttachmentDoesNotExist(e.id);
  });
});

bthread("NavigationView create verification", function () {
  const e = waitForAnyNavigationViewAdded();
  block(matchDeleteNavigationView(e.id, ANY), function () {
    verifyNavigationViewExists(e.id);
  });
});

bthread("NavigationView update verification", function () {
  const e = waitForAnyNavigationViewUpdated();
  block(matchDeleteNavigationView(e.id, ANY), function () {
    verifyNavigationViewUpdated(e.id);
  });
});

bthread("NavigationView delete verification", function () {
  const e = waitForAnyNavigationViewDeleted();
  block(matchAddNavigationView(e.id, ANY), function () {
    verifyNavigationViewDoesNotExist(e.id);
  });
});

bthread("EmojiCode create verification", function () {
  const e = waitForAnyEmojiCodeAdded();
  block(matchDeleteEmojiCode(e.id, ANY), function () {
    verifyEmojiCodeExists(e.id);
  });
});

bthread("EmojiCode update verification", function () {
  const e = waitForAnyEmojiCodeUpdated();
  block(matchDeleteEmojiCode(e.id, ANY), function () {
    verifyEmojiCodeUpdated(e.id);
  });
});

bthread("EmojiCode delete verification", function () {
  const e = waitForAnyEmojiCodeDeleted();
  block(matchAddEmojiCode(e.id, ANY), function () {
    verifyEmojiCodeDoesNotExist(e.id);
  });
});

bthread("Profile_data create verification", function () {
  const e = waitForAnyProfile_dataAdded();
  block(matchDeleteProfile_data(e.id, ANY), function () {
    verifyProfile_dataExists(e.id);
  });
});

bthread("Profile_data update verification", function () {
  const e = waitForAnyProfile_dataUpdated();
  block(matchDeleteProfile_data(e.id, ANY), function () {
    verifyProfile_dataUpdated(e.id);
  });
});

bthread("Profile_data delete verification", function () {
  const e = waitForAnyProfile_dataDeleted();
  block(matchAddProfile_data(e.id, ANY), function () {
    verifyProfile_dataDoesNotExist(e.id);
  });
});

bthread("CodedErrorBase create verification", function () {
  const e = waitForAnyCodedErrorBaseAdded();
  block(matchDeleteCodedErrorBase(e.id, ANY), function () {
    verifyCodedErrorBaseExists(e.id);
  });
});

bthread("CodedErrorBase update verification", function () {
  const e = waitForAnyCodedErrorBaseUpdated();
  block(matchDeleteCodedErrorBase(e.id, ANY), function () {
    verifyCodedErrorBaseUpdated(e.id);
  });
});

bthread("CodedErrorBase delete verification", function () {
  const e = waitForAnyCodedErrorBaseDeleted();
  block(matchAddCodedErrorBase(e.id, ANY), function () {
    verifyCodedErrorBaseDoesNotExist(e.id);
  });
});

bthread("PushNotificationAdminActionRequiredError create verification", function () {
  const e = waitForAnyPushNotificationAdminActionRequiredErrorAdded();
  block(matchDeletePushNotificationAdminActionRequiredError(e.id, ANY), function () {
    verifyPushNotificationAdminActionRequiredErrorExists(e.id);
  });
});

bthread("PushNotificationAdminActionRequiredError update verification", function () {
  const e = waitForAnyPushNotificationAdminActionRequiredErrorUpdated();
  block(matchDeletePushNotificationAdminActionRequiredError(e.id, ANY), function () {
    verifyPushNotificationAdminActionRequiredErrorUpdated(e.id);
  });
});

bthread("PushNotificationAdminActionRequiredError delete verification", function () {
  const e = waitForAnyPushNotificationAdminActionRequiredErrorDeleted();
  block(matchAddPushNotificationAdminActionRequiredError(e.id, ANY), function () {
    verifyPushNotificationAdminActionRequiredErrorDoesNotExist(e.id);
  });
});

bthread("BasicBotBase create verification", function () {
  const e = waitForAnyBasicBotBaseAdded();
  block(matchDeleteBasicBotBase(e.id, ANY), function () {
    verifyBasicBotBaseExists(e.id);
  });
});

bthread("BasicBotBase update verification", function () {
  const e = waitForAnyBasicBotBaseUpdated();
  block(matchDeleteBasicBotBase(e.id, ANY), function () {
    verifyBasicBotBaseUpdated(e.id);
  });
});

bthread("BasicBotBase delete verification", function () {
  const e = waitForAnyBasicBotBaseDeleted();
  block(matchAddBasicBotBase(e.id, ANY), function () {
    verifyBasicBotBaseDoesNotExist(e.id);
  });
});

bthread("Narrow create verification", function () {
  const e = waitForAnyNarrowAdded();
  block(matchDeleteNarrow(e.id, ANY), function () {
    verifyNarrowExists(e.id);
  });
});

bthread("Narrow update verification", function () {
  const e = waitForAnyNarrowUpdated();
  block(matchDeleteNarrow(e.id, ANY), function () {
    verifyNarrowUpdated(e.id);
  });
});

bthread("Narrow delete verification", function () {
  const e = waitForAnyNarrowDeleted();
  block(matchAddNarrow(e.id, ANY), function () {
    verifyNarrowDoesNotExist(e.id);
  });
});

bthread("JsonSuccess create verification", function () {
  const e = waitForAnyJsonSuccessAdded();
  block(matchDeleteJsonSuccess(e.id, ANY), function () {
    verifyJsonSuccessExists(e.id);
  });
});

bthread("JsonSuccess update verification", function () {
  const e = waitForAnyJsonSuccessUpdated();
  block(matchDeleteJsonSuccess(e.id, ANY), function () {
    verifyJsonSuccessUpdated(e.id);
  });
});

bthread("JsonSuccess delete verification", function () {
  const e = waitForAnyJsonSuccessDeleted();
  block(matchAddJsonSuccess(e.id, ANY), function () {
    verifyJsonSuccessDoesNotExist(e.id);
  });
});

bthread("LegacyPresenceFormat create verification", function () {
  const e = waitForAnyLegacyPresenceFormatAdded();
  block(matchDeleteLegacyPresenceFormat(e.id, ANY), function () {
    verifyLegacyPresenceFormatExists(e.id);
  });
});

bthread("LegacyPresenceFormat update verification", function () {
  const e = waitForAnyLegacyPresenceFormatUpdated();
  block(matchDeleteLegacyPresenceFormat(e.id, ANY), function () {
    verifyLegacyPresenceFormatUpdated(e.id);
  });
});

bthread("LegacyPresenceFormat delete verification", function () {
  const e = waitForAnyLegacyPresenceFormatDeleted();
  block(matchAddLegacyPresenceFormat(e.id, ANY), function () {
    verifyLegacyPresenceFormatDoesNotExist(e.id);
  });
});

bthread("InternalBouncerServerError create verification", function () {
  const e = waitForAnyInternalBouncerServerErrorAdded();
  block(matchDeleteInternalBouncerServerError(e.id, ANY), function () {
    verifyInternalBouncerServerErrorExists(e.id);
  });
});

bthread("InternalBouncerServerError update verification", function () {
  const e = waitForAnyInternalBouncerServerErrorUpdated();
  block(matchDeleteInternalBouncerServerError(e.id, ANY), function () {
    verifyInternalBouncerServerErrorUpdated(e.id);
  });
});

bthread("InternalBouncerServerError delete verification", function () {
  const e = waitForAnyInternalBouncerServerErrorDeleted();
  block(matchAddInternalBouncerServerError(e.id, ANY), function () {
    verifyInternalBouncerServerErrorDoesNotExist(e.id);
  });
});

bthread("IgnoredParametersUnsupported create verification", function () {
  const e = waitForAnyIgnoredParametersUnsupportedAdded();
  block(matchDeleteIgnoredParametersUnsupported(e.id, ANY), function () {
    verifyIgnoredParametersUnsupportedExists(e.id);
  });
});

bthread("IgnoredParametersUnsupported update verification", function () {
  const e = waitForAnyIgnoredParametersUnsupportedUpdated();
  block(matchDeleteIgnoredParametersUnsupported(e.id, ANY), function () {
    verifyIgnoredParametersUnsupportedUpdated(e.id);
  });
});

bthread("IgnoredParametersUnsupported delete verification", function () {
  const e = waitForAnyIgnoredParametersUnsupportedDeleted();
  block(matchAddIgnoredParametersUnsupported(e.id, ANY), function () {
    verifyIgnoredParametersUnsupportedDoesNotExist(e.id);
  });
});

bthread("Anchor create verification", function () {
  const e = waitForAnyAnchorAdded();
  block(matchDeleteAnchor(e.id, ANY), function () {
    verifyAnchorExists(e.id);
  });
});

bthread("Anchor update verification", function () {
  const e = waitForAnyAnchorUpdated();
  block(matchDeleteAnchor(e.id, ANY), function () {
    verifyAnchorUpdated(e.id);
  });
});

bthread("Anchor delete verification", function () {
  const e = waitForAnyAnchorDeleted();
  block(matchAddAnchor(e.id, ANY), function () {
    verifyAnchorDoesNotExist(e.id);
  });
});

bthread("EventTypeSchema create verification", function () {
  const e = waitForAnyEventTypeSchemaAdded();
  block(matchDeleteEventTypeSchema(e.id, ANY), function () {
    verifyEventTypeSchemaExists(e.id);
  });
});

bthread("EventTypeSchema update verification", function () {
  const e = waitForAnyEventTypeSchemaUpdated();
  block(matchDeleteEventTypeSchema(e.id, ANY), function () {
    verifyEventTypeSchemaUpdated(e.id);
  });
});

bthread("EventTypeSchema delete verification", function () {
  const e = waitForAnyEventTypeSchemaDeleted();
  block(matchAddEventTypeSchema(e.id, ANY), function () {
    verifyEventTypeSchemaDoesNotExist(e.id);
  });
});

bthread("MessagesEvent create verification", function () {
  const e = waitForAnyMessagesEventAdded();
  block(matchDeleteMessagesEvent(e.id, ANY), function () {
    verifyMessagesEventExists(e.id);
  });
});

bthread("MessagesEvent update verification", function () {
  const e = waitForAnyMessagesEventUpdated();
  block(matchDeleteMessagesEvent(e.id, ANY), function () {
    verifyMessagesEventUpdated(e.id);
  });
});

bthread("MessagesEvent delete verification", function () {
  const e = waitForAnyMessagesEventDeleted();
  block(matchAddMessagesEvent(e.id, ANY), function () {
    verifyMessagesEventDoesNotExist(e.id);
  });
});

bthread("LinkifierURLTemplate create verification", function () {
  const e = waitForAnyLinkifierURLTemplateAdded();
  block(matchDeleteLinkifierURLTemplate(e.id, ANY), function () {
    verifyLinkifierURLTemplateExists(e.id);
  });
});

bthread("LinkifierURLTemplate update verification", function () {
  const e = waitForAnyLinkifierURLTemplateUpdated();
  block(matchDeleteLinkifierURLTemplate(e.id, ANY), function () {
    verifyLinkifierURLTemplateUpdated(e.id);
  });
});

bthread("LinkifierURLTemplate delete verification", function () {
  const e = waitForAnyLinkifierURLTemplateDeleted();
  block(matchAddLinkifierURLTemplate(e.id, ANY), function () {
    verifyLinkifierURLTemplateDoesNotExist(e.id);
  });
});

bthread("ChannelFolder create verification", function () {
  const e = waitForAnyChannelFolderAdded();
  block(matchDeleteChannelFolder(e.id, ANY), function () {
    verifyChannelFolderExists(e.id);
  });
});

bthread("ChannelFolder update verification", function () {
  const e = waitForAnyChannelFolderUpdated();
  block(matchDeleteChannelFolder(e.id, ANY), function () {
    verifyChannelFolderUpdated(e.id);
  });
});

bthread("ChannelFolder delete verification", function () {
  const e = waitForAnyChannelFolderDeleted();
  block(matchAddChannelFolder(e.id, ANY), function () {
    verifyChannelFolderDoesNotExist(e.id);
  });
});

bthread("Invite create verification", function () {
  const e = waitForAnyInviteAdded();
  block(matchDeleteInvite(e.id, ANY), function () {
    verifyInviteExists(e.id);
  });
});

bthread("Invite update verification", function () {
  const e = waitForAnyInviteUpdated();
  block(matchDeleteInvite(e.id, ANY), function () {
    verifyInviteUpdated(e.id);
  });
});

bthread("Invite delete verification", function () {
  const e = waitForAnyInviteDeleted();
  block(matchAddInvite(e.id, ANY), function () {
    verifyInviteDoesNotExist(e.id);
  });
});

bthread("CanSubscribeGroup create verification", function () {
  const e = waitForAnyCanSubscribeGroupAdded();
  block(matchDeleteCanSubscribeGroup(e.id, ANY), function () {
    verifyCanSubscribeGroupExists(e.id);
  });
});

bthread("CanSubscribeGroup update verification", function () {
  const e = waitForAnyCanSubscribeGroupUpdated();
  block(matchDeleteCanSubscribeGroup(e.id, ANY), function () {
    verifyCanSubscribeGroupUpdated(e.id);
  });
});

bthread("CanSubscribeGroup delete verification", function () {
  const e = waitForAnyCanSubscribeGroupDeleted();
  block(matchAddCanSubscribeGroup(e.id, ANY), function () {
    verifyCanSubscribeGroupDoesNotExist(e.id);
  });
});

bthread("JsonSuccessBase create verification", function () {
  const e = waitForAnyJsonSuccessBaseAdded();
  block(matchDeleteJsonSuccessBase(e.id, ANY), function () {
    verifyJsonSuccessBaseExists(e.id);
  });
});

bthread("JsonSuccessBase update verification", function () {
  const e = waitForAnyJsonSuccessBaseUpdated();
  block(matchDeleteJsonSuccessBase(e.id, ANY), function () {
    verifyJsonSuccessBaseUpdated(e.id);
  });
});

bthread("JsonSuccessBase delete verification", function () {
  const e = waitForAnyJsonSuccessBaseDeleted();
  block(matchAddJsonSuccessBase(e.id, ANY), function () {
    verifyJsonSuccessBaseDoesNotExist(e.id);
  });
});

bthread("EmojiBase create verification", function () {
  const e = waitForAnyEmojiBaseAdded();
  block(matchDeleteEmojiBase(e.id, ANY), function () {
    verifyEmojiBaseExists(e.id);
  });
});

bthread("EmojiBase update verification", function () {
  const e = waitForAnyEmojiBaseUpdated();
  block(matchDeleteEmojiBase(e.id, ANY), function () {
    verifyEmojiBaseUpdated(e.id);
  });
});

bthread("EmojiBase delete verification", function () {
  const e = waitForAnyEmojiBaseDeleted();
  block(matchAddEmojiBase(e.id, ANY), function () {
    verifyEmojiBaseDoesNotExist(e.id);
  });
});

bthread("User create verification", function () {
  const e = waitForAnyUserAdded();
  block(matchDeleteUser(e.id, ANY), function () {
    verifyUserExists(e.id);
  });
});

bthread("User update verification", function () {
  const e = waitForAnyUserUpdated();
  block(matchDeleteUser(e.id, ANY), function () {
    verifyUserUpdated(e.id);
  });
});

bthread("User delete verification", function () {
  const e = waitForAnyUserDeleted();
  block(matchAddUser(e.id, ANY), function () {
    verifyUserDoesNotExist(e.id);
  });
});

bthread("MissingArgumentError create verification", function () {
  const e = waitForAnyMissingArgumentErrorAdded();
  block(matchDeleteMissingArgumentError(e.id, ANY), function () {
    verifyMissingArgumentErrorExists(e.id);
  });
});

bthread("MissingArgumentError update verification", function () {
  const e = waitForAnyMissingArgumentErrorUpdated();
  block(matchDeleteMissingArgumentError(e.id, ANY), function () {
    verifyMissingArgumentErrorUpdated(e.id);
  });
});

bthread("MissingArgumentError delete verification", function () {
  const e = waitForAnyMissingArgumentErrorDeleted();
  block(matchAddMissingArgumentError(e.id, ANY), function () {
    verifyMissingArgumentErrorDoesNotExist(e.id);
  });
});

bthread("NonExistingChannelNameError create verification", function () {
  const e = waitForAnyNonExistingChannelNameErrorAdded();
  block(matchDeleteNonExistingChannelNameError(e.id, ANY), function () {
    verifyNonExistingChannelNameErrorExists(e.id);
  });
});

bthread("NonExistingChannelNameError update verification", function () {
  const e = waitForAnyNonExistingChannelNameErrorUpdated();
  block(matchDeleteNonExistingChannelNameError(e.id, ANY), function () {
    verifyNonExistingChannelNameErrorUpdated(e.id);
  });
});

bthread("NonExistingChannelNameError delete verification", function () {
  const e = waitForAnyNonExistingChannelNameErrorDeleted();
  block(matchAddNonExistingChannelNameError(e.id, ANY), function () {
    verifyNonExistingChannelNameErrorDoesNotExist(e.id);
  });
});

bthread("Principals create verification", function () {
  const e = waitForAnyPrincipalsAdded();
  block(matchDeletePrincipals(e.id, ANY), function () {
    verifyPrincipalsExists(e.id);
  });
});

bthread("Principals update verification", function () {
  const e = waitForAnyPrincipalsUpdated();
  block(matchDeletePrincipals(e.id, ANY), function () {
    verifyPrincipalsUpdated(e.id);
  });
});

bthread("Principals delete verification", function () {
  const e = waitForAnyPrincipalsDeleted();
  block(matchAddPrincipals(e.id, ANY), function () {
    verifyPrincipalsDoesNotExist(e.id);
  });
});

bthread("InvalidPushDeviceTokenError create verification", function () {
  const e = waitForAnyInvalidPushDeviceTokenErrorAdded();
  block(matchDeleteInvalidPushDeviceTokenError(e.id, ANY), function () {
    verifyInvalidPushDeviceTokenErrorExists(e.id);
  });
});

bthread("InvalidPushDeviceTokenError update verification", function () {
  const e = waitForAnyInvalidPushDeviceTokenErrorUpdated();
  block(matchDeleteInvalidPushDeviceTokenError(e.id, ANY), function () {
    verifyInvalidPushDeviceTokenErrorUpdated(e.id);
  });
});

bthread("InvalidPushDeviceTokenError delete verification", function () {
  const e = waitForAnyInvalidPushDeviceTokenErrorDeleted();
  block(matchAddInvalidPushDeviceTokenError(e.id, ANY), function () {
    verifyInvalidPushDeviceTokenErrorDoesNotExist(e.id);
  });
});

bthread("RealmEmoji create verification", function () {
  const e = waitForAnyRealmEmojiAdded();
  block(matchDeleteRealmEmoji(e.id, ANY), function () {
    verifyRealmEmojiExists(e.id);
  });
});

bthread("RealmEmoji update verification", function () {
  const e = waitForAnyRealmEmojiUpdated();
  block(matchDeleteRealmEmoji(e.id, ANY), function () {
    verifyRealmEmojiUpdated(e.id);
  });
});

bthread("RealmEmoji delete verification", function () {
  const e = waitForAnyRealmEmojiDeleted();
  block(matchAddRealmEmoji(e.id, ANY), function () {
    verifyRealmEmojiDoesNotExist(e.id);
  });
});

bthread("FailedToConnectBouncerError create verification", function () {
  const e = waitForAnyFailedToConnectBouncerErrorAdded();
  block(matchDeleteFailedToConnectBouncerError(e.id, ANY), function () {
    verifyFailedToConnectBouncerErrorExists(e.id);
  });
});

bthread("FailedToConnectBouncerError update verification", function () {
  const e = waitForAnyFailedToConnectBouncerErrorUpdated();
  block(matchDeleteFailedToConnectBouncerError(e.id, ANY), function () {
    verifyFailedToConnectBouncerErrorUpdated(e.id);
  });
});

bthread("FailedToConnectBouncerError delete verification", function () {
  const e = waitForAnyFailedToConnectBouncerErrorDeleted();
  block(matchAddFailedToConnectBouncerError(e.id, ANY), function () {
    verifyFailedToConnectBouncerErrorDoesNotExist(e.id);
  });
});

bthread("CanAdministerChannelGroup create verification", function () {
  const e = waitForAnyCanAdministerChannelGroupAdded();
  block(matchDeleteCanAdministerChannelGroup(e.id, ANY), function () {
    verifyCanAdministerChannelGroupExists(e.id);
  });
});

bthread("CanAdministerChannelGroup update verification", function () {
  const e = waitForAnyCanAdministerChannelGroupUpdated();
  block(matchDeleteCanAdministerChannelGroup(e.id, ANY), function () {
    verifyCanAdministerChannelGroupUpdated(e.id);
  });
});

bthread("CanAdministerChannelGroup delete verification", function () {
  const e = waitForAnyCanAdministerChannelGroupDeleted();
  block(matchAddCanAdministerChannelGroup(e.id, ANY), function () {
    verifyCanAdministerChannelGroupDoesNotExist(e.id);
  });
});

bthread("OptionalContent create verification", function () {
  const e = waitForAnyOptionalContentAdded();
  block(matchDeleteOptionalContent(e.id, ANY), function () {
    verifyOptionalContentExists(e.id);
  });
});

bthread("OptionalContent update verification", function () {
  const e = waitForAnyOptionalContentUpdated();
  block(matchDeleteOptionalContent(e.id, ANY), function () {
    verifyOptionalContentUpdated(e.id);
  });
});

bthread("OptionalContent delete verification", function () {
  const e = waitForAnyOptionalContentDeleted();
  block(matchAddOptionalContent(e.id, ANY), function () {
    verifyOptionalContentDoesNotExist(e.id);
  });
});

bthread("WebhookConfigOption create verification", function () {
  const e = waitForAnyWebhookConfigOptionAdded();
  block(matchDeleteWebhookConfigOption(e.id, ANY), function () {
    verifyWebhookConfigOptionExists(e.id);
  });
});

bthread("WebhookConfigOption update verification", function () {
  const e = waitForAnyWebhookConfigOptionUpdated();
  block(matchDeleteWebhookConfigOption(e.id, ANY), function () {
    verifyWebhookConfigOptionUpdated(e.id);
  });
});

bthread("WebhookConfigOption delete verification", function () {
  const e = waitForAnyWebhookConfigOptionDeleted();
  block(matchAddWebhookConfigOption(e.id, ANY), function () {
    verifyWebhookConfigOptionDoesNotExist(e.id);
  });
});

bthread("RequiredContent create verification", function () {
  const e = waitForAnyRequiredContentAdded();
  block(matchDeleteRequiredContent(e.id, ANY), function () {
    verifyRequiredContentExists(e.id);
  });
});

bthread("RequiredContent update verification", function () {
  const e = waitForAnyRequiredContentUpdated();
  block(matchDeleteRequiredContent(e.id, ANY), function () {
    verifyRequiredContentUpdated(e.id);
  });
});

bthread("RequiredContent delete verification", function () {
  const e = waitForAnyRequiredContentDeleted();
  block(matchAddRequiredContent(e.id, ANY), function () {
    verifyRequiredContentDoesNotExist(e.id);
  });
});

bthread("InvalidMessageError create verification", function () {
  const e = waitForAnyInvalidMessageErrorAdded();
  block(matchDeleteInvalidMessageError(e.id, ANY), function () {
    verifyInvalidMessageErrorExists(e.id);
  });
});

bthread("InvalidMessageError update verification", function () {
  const e = waitForAnyInvalidMessageErrorUpdated();
  block(matchDeleteInvalidMessageError(e.id, ANY), function () {
    verifyInvalidMessageErrorUpdated(e.id);
  });
});

bthread("InvalidMessageError delete verification", function () {
  const e = waitForAnyInvalidMessageErrorDeleted();
  block(matchAddInvalidMessageError(e.id, ANY), function () {
    verifyInvalidMessageErrorDoesNotExist(e.id);
  });
});

bthread("UserBase create verification", function () {
  const e = waitForAnyUserBaseAdded();
  block(matchDeleteUserBase(e.id, ANY), function () {
    verifyUserBaseExists(e.id);
  });
});

bthread("UserBase update verification", function () {
  const e = waitForAnyUserBaseUpdated();
  block(matchDeleteUserBase(e.id, ANY), function () {
    verifyUserBaseUpdated(e.id);
  });
});

bthread("UserBase delete verification", function () {
  const e = waitForAnyUserBaseDeleted();
  block(matchAddUserBase(e.id, ANY), function () {
    verifyUserBaseDoesNotExist(e.id);
  });
});

bthread("CanMoveMessagesOutOfChannelGroup create verification", function () {
  const e = waitForAnyCanMoveMessagesOutOfChannelGroupAdded();
  block(matchDeleteCanMoveMessagesOutOfChannelGroup(e.id, ANY), function () {
    verifyCanMoveMessagesOutOfChannelGroupExists(e.id);
  });
});

bthread("CanMoveMessagesOutOfChannelGroup update verification", function () {
  const e = waitForAnyCanMoveMessagesOutOfChannelGroupUpdated();
  block(matchDeleteCanMoveMessagesOutOfChannelGroup(e.id, ANY), function () {
    verifyCanMoveMessagesOutOfChannelGroupUpdated(e.id);
  });
});

bthread("CanMoveMessagesOutOfChannelGroup delete verification", function () {
  const e = waitForAnyCanMoveMessagesOutOfChannelGroupDeleted();
  block(matchAddCanMoveMessagesOutOfChannelGroup(e.id, ANY), function () {
    verifyCanMoveMessagesOutOfChannelGroupDoesNotExist(e.id);
  });
});

bthread("LinkifierPattern create verification", function () {
  const e = waitForAnyLinkifierPatternAdded();
  block(matchDeleteLinkifierPattern(e.id, ANY), function () {
    verifyLinkifierPatternExists(e.id);
  });
});

bthread("LinkifierPattern update verification", function () {
  const e = waitForAnyLinkifierPatternUpdated();
  block(matchDeleteLinkifierPattern(e.id, ANY), function () {
    verifyLinkifierPatternUpdated(e.id);
  });
});

bthread("LinkifierPattern delete verification", function () {
  const e = waitForAnyLinkifierPatternDeleted();
  block(matchAddLinkifierPattern(e.id, ANY), function () {
    verifyLinkifierPatternDoesNotExist(e.id);
  });
});

bthread("MessagesBase create verification", function () {
  const e = waitForAnyMessagesBaseAdded();
  block(matchDeleteMessagesBase(e.id, ANY), function () {
    verifyMessagesBaseExists(e.id);
  });
});

bthread("MessagesBase update verification", function () {
  const e = waitForAnyMessagesBaseUpdated();
  block(matchDeleteMessagesBase(e.id, ANY), function () {
    verifyMessagesBaseUpdated(e.id);
  });
});

bthread("MessagesBase delete verification", function () {
  const e = waitForAnyMessagesBaseDeleted();
  block(matchAddMessagesBase(e.id, ANY), function () {
    verifyMessagesBaseDoesNotExist(e.id);
  });
});

bthread("EmailAddressVisibility create verification", function () {
  const e = waitForAnyEmailAddressVisibilityAdded();
  block(matchDeleteEmailAddressVisibility(e.id, ANY), function () {
    verifyEmailAddressVisibilityExists(e.id);
  });
});

bthread("EmailAddressVisibility update verification", function () {
  const e = waitForAnyEmailAddressVisibilityUpdated();
  block(matchDeleteEmailAddressVisibility(e.id, ANY), function () {
    verifyEmailAddressVisibilityUpdated(e.id);
  });
});

bthread("EmailAddressVisibility delete verification", function () {
  const e = waitForAnyEmailAddressVisibilityDeleted();
  block(matchAddEmailAddressVisibility(e.id, ANY), function () {
    verifyEmailAddressVisibilityDoesNotExist(e.id);
  });
});

bthread("ModernPresenceFormat create verification", function () {
  const e = waitForAnyModernPresenceFormatAdded();
  block(matchDeleteModernPresenceFormat(e.id, ANY), function () {
    verifyModernPresenceFormatExists(e.id);
  });
});

bthread("ModernPresenceFormat update verification", function () {
  const e = waitForAnyModernPresenceFormatUpdated();
  block(matchDeleteModernPresenceFormat(e.id, ANY), function () {
    verifyModernPresenceFormatUpdated(e.id);
  });
});

bthread("ModernPresenceFormat delete verification", function () {
  const e = waitForAnyModernPresenceFormatDeleted();
  block(matchAddModernPresenceFormat(e.id, ANY), function () {
    verifyModernPresenceFormatDoesNotExist(e.id);
  });
});

bthread("BasicBot create verification", function () {
  const e = waitForAnyBasicBotAdded();
  block(matchDeleteBasicBot(e.id, ANY), function () {
    verifyBasicBotExists(e.id);
  });
});

bthread("BasicBot update verification", function () {
  const e = waitForAnyBasicBotUpdated();
  block(matchDeleteBasicBot(e.id, ANY), function () {
    verifyBasicBotUpdated(e.id);
  });
});

bthread("BasicBot delete verification", function () {
  const e = waitForAnyBasicBotDeleted();
  block(matchAddBasicBot(e.id, ANY), function () {
    verifyBasicBotDoesNotExist(e.id);
  });
});

bthread("BasicChannelBase create verification", function () {
  const e = waitForAnyBasicChannelBaseAdded();
  block(matchDeleteBasicChannelBase(e.id, ANY), function () {
    verifyBasicChannelBaseExists(e.id);
  });
});

bthread("BasicChannelBase update verification", function () {
  const e = waitForAnyBasicChannelBaseUpdated();
  block(matchDeleteBasicChannelBase(e.id, ANY), function () {
    verifyBasicChannelBaseUpdated(e.id);
  });
});

bthread("BasicChannelBase delete verification", function () {
  const e = waitForAnyBasicChannelBaseDeleted();
  block(matchAddBasicChannelBase(e.id, ANY), function () {
    verifyBasicChannelBaseDoesNotExist(e.id);
  });
});

bthread("UserGroup create verification", function () {
  const e = waitForAnyUserGroupAdded();
  block(matchDeleteUserGroup(e.id, ANY), function () {
    verifyUserGroupExists(e.id);
  });
});

bthread("UserGroup update verification", function () {
  const e = waitForAnyUserGroupUpdated();
  block(matchDeleteUserGroup(e.id, ANY), function () {
    verifyUserGroupUpdated(e.id);
  });
});

bthread("UserGroup delete verification", function () {
  const e = waitForAnyUserGroupDeleted();
  block(matchAddUserGroup(e.id, ANY), function () {
    verifyUserGroupDoesNotExist(e.id);
  });
});

bthread("InviteRoleParameter create verification", function () {
  const e = waitForAnyInviteRoleParameterAdded();
  block(matchDeleteInviteRoleParameter(e.id, ANY), function () {
    verifyInviteRoleParameterExists(e.id);
  });
});

bthread("InviteRoleParameter update verification", function () {
  const e = waitForAnyInviteRoleParameterUpdated();
  block(matchDeleteInviteRoleParameter(e.id, ANY), function () {
    verifyInviteRoleParameterUpdated(e.id);
  });
});

bthread("InviteRoleParameter delete verification", function () {
  const e = waitForAnyInviteRoleParameterDeleted();
  block(matchAddInviteRoleParameter(e.id, ANY), function () {
    verifyInviteRoleParameterDoesNotExist(e.id);
  });
});

bthread("RealmDeactivatedError create verification", function () {
  const e = waitForAnyRealmDeactivatedErrorAdded();
  block(matchDeleteRealmDeactivatedError(e.id, ANY), function () {
    verifyRealmDeactivatedErrorExists(e.id);
  });
});

bthread("RealmDeactivatedError update verification", function () {
  const e = waitForAnyRealmDeactivatedErrorUpdated();
  block(matchDeleteRealmDeactivatedError(e.id, ANY), function () {
    verifyRealmDeactivatedErrorUpdated(e.id);
  });
});

bthread("RealmDeactivatedError delete verification", function () {
  const e = waitForAnyRealmDeactivatedErrorDeleted();
  block(matchAddRealmDeactivatedError(e.id, ANY), function () {
    verifyRealmDeactivatedErrorDoesNotExist(e.id);
  });
});

bthread("NoActivePushDeviceError create verification", function () {
  const e = waitForAnyNoActivePushDeviceErrorAdded();
  block(matchDeleteNoActivePushDeviceError(e.id, ANY), function () {
    verifyNoActivePushDeviceErrorExists(e.id);
  });
});

bthread("NoActivePushDeviceError update verification", function () {
  const e = waitForAnyNoActivePushDeviceErrorUpdated();
  block(matchDeleteNoActivePushDeviceError(e.id, ANY), function () {
    verifyNoActivePushDeviceErrorUpdated(e.id);
  });
});

bthread("NoActivePushDeviceError delete verification", function () {
  const e = waitForAnyNoActivePushDeviceErrorDeleted();
  block(matchAddNoActivePushDeviceError(e.id, ANY), function () {
    verifyNoActivePushDeviceErrorDoesNotExist(e.id);
  });
});

bthread("EmojiReactionEvent create verification", function () {
  const e = waitForAnyEmojiReactionEventAdded();
  block(matchDeleteEmojiReactionEvent(e.id, ANY), function () {
    verifyEmojiReactionEventExists(e.id);
  });
});

bthread("EmojiReactionEvent update verification", function () {
  const e = waitForAnyEmojiReactionEventUpdated();
  block(matchDeleteEmojiReactionEvent(e.id, ANY), function () {
    verifyEmojiReactionEventUpdated(e.id);
  });
});

bthread("EmojiReactionEvent delete verification", function () {
  const e = waitForAnyEmojiReactionEventDeleted();
  block(matchAddEmojiReactionEvent(e.id, ANY), function () {
    verifyEmojiReactionEventDoesNotExist(e.id);
  });
});

bthread("BadEventQueueIdError create verification", function () {
  const e = waitForAnyBadEventQueueIdErrorAdded();
  block(matchDeleteBadEventQueueIdError(e.id, ANY), function () {
    verifyBadEventQueueIdErrorExists(e.id);
  });
});

bthread("BadEventQueueIdError update verification", function () {
  const e = waitForAnyBadEventQueueIdErrorUpdated();
  block(matchDeleteBadEventQueueIdError(e.id, ANY), function () {
    verifyBadEventQueueIdErrorUpdated(e.id);
  });
});

bthread("BadEventQueueIdError delete verification", function () {
  const e = waitForAnyBadEventQueueIdErrorDeleted();
  block(matchAddBadEventQueueIdError(e.id, ANY), function () {
    verifyBadEventQueueIdErrorDoesNotExist(e.id);
  });
});

bthread("GroupSettingValue create verification", function () {
  const e = waitForAnyGroupSettingValueAdded();
  block(matchDeleteGroupSettingValue(e.id, ANY), function () {
    verifyGroupSettingValueExists(e.id);
  });
});

bthread("GroupSettingValue update verification", function () {
  const e = waitForAnyGroupSettingValueUpdated();
  block(matchDeleteGroupSettingValue(e.id, ANY), function () {
    verifyGroupSettingValueUpdated(e.id);
  });
});

bthread("GroupSettingValue delete verification", function () {
  const e = waitForAnyGroupSettingValueDeleted();
  block(matchAddGroupSettingValue(e.id, ANY), function () {
    verifyGroupSettingValueDoesNotExist(e.id);
  });
});

bthread("Event_types create verification", function () {
  const e = waitForAnyEvent_typesAdded();
  block(matchDeleteEvent_types(e.id, ANY), function () {
    verifyEvent_typesExists(e.id);
  });
});

bthread("Event_types update verification", function () {
  const e = waitForAnyEvent_typesUpdated();
  block(matchDeleteEvent_types(e.id, ANY), function () {
    verifyEvent_typesUpdated(e.id);
  });
});

bthread("Event_types delete verification", function () {
  const e = waitForAnyEvent_typesDeleted();
  block(matchAddEvent_types(e.id, ANY), function () {
    verifyEvent_typesDoesNotExist(e.id);
  });
});

bthread("RealmPlayground create verification", function () {
  const e = waitForAnyRealmPlaygroundAdded();
  block(matchDeleteRealmPlayground(e.id, ANY), function () {
    verifyRealmPlaygroundExists(e.id);
  });
});

bthread("RealmPlayground update verification", function () {
  const e = waitForAnyRealmPlaygroundUpdated();
  block(matchDeleteRealmPlayground(e.id, ANY), function () {
    verifyRealmPlaygroundUpdated(e.id);
  });
});

bthread("RealmPlayground delete verification", function () {
  const e = waitForAnyRealmPlaygroundDeleted();
  block(matchAddRealmPlayground(e.id, ANY), function () {
    verifyRealmPlaygroundDoesNotExist(e.id);
  });
});

bthread("InviteExpirationParameter create verification", function () {
  const e = waitForAnyInviteExpirationParameterAdded();
  block(matchDeleteInviteExpirationParameter(e.id, ANY), function () {
    verifyInviteExpirationParameterExists(e.id);
  });
});

bthread("InviteExpirationParameter update verification", function () {
  const e = waitForAnyInviteExpirationParameterUpdated();
  block(matchDeleteInviteExpirationParameter(e.id, ANY), function () {
    verifyInviteExpirationParameterUpdated(e.id);
  });
});

bthread("InviteExpirationParameter delete verification", function () {
  const e = waitForAnyInviteExpirationParameterDeleted();
  block(matchAddInviteExpirationParameter(e.id, ANY), function () {
    verifyInviteExpirationParameterDoesNotExist(e.id);
  });
});

bthread("RateLimitedError create verification", function () {
  const e = waitForAnyRateLimitedErrorAdded();
  block(matchDeleteRateLimitedError(e.id, ANY), function () {
    verifyRateLimitedErrorExists(e.id);
  });
});

bthread("RateLimitedError update verification", function () {
  const e = waitForAnyRateLimitedErrorUpdated();
  block(matchDeleteRateLimitedError(e.id, ANY), function () {
    verifyRateLimitedErrorUpdated(e.id);
  });
});

bthread("RateLimitedError delete verification", function () {
  const e = waitForAnyRateLimitedErrorDeleted();
  block(matchAddRateLimitedError(e.id, ANY), function () {
    verifyRateLimitedErrorDoesNotExist(e.id);
  });
});

bthread("ChannelCanAddSubscribersGroup create verification", function () {
  const e = waitForAnyChannelCanAddSubscribersGroupAdded();
  block(matchDeleteChannelCanAddSubscribersGroup(e.id, ANY), function () {
    verifyChannelCanAddSubscribersGroupExists(e.id);
  });
});

bthread("ChannelCanAddSubscribersGroup update verification", function () {
  const e = waitForAnyChannelCanAddSubscribersGroupUpdated();
  block(matchDeleteChannelCanAddSubscribersGroup(e.id, ANY), function () {
    verifyChannelCanAddSubscribersGroupUpdated(e.id);
  });
});

bthread("ChannelCanAddSubscribersGroup delete verification", function () {
  const e = waitForAnyChannelCanAddSubscribersGroupDeleted();
  block(matchAddChannelCanAddSubscribersGroup(e.id, ANY), function () {
    verifyChannelCanAddSubscribersGroupDoesNotExist(e.id);
  });
});

bthread("WebhookUrlOption create verification", function () {
  const e = waitForAnyWebhookUrlOptionAdded();
  block(matchDeleteWebhookUrlOption(e.id, ANY), function () {
    verifyWebhookUrlOptionExists(e.id);
  });
});

bthread("WebhookUrlOption update verification", function () {
  const e = waitForAnyWebhookUrlOptionUpdated();
  block(matchDeleteWebhookUrlOption(e.id, ANY), function () {
    verifyWebhookUrlOptionUpdated(e.id);
  });
});

bthread("WebhookUrlOption delete verification", function () {
  const e = waitForAnyWebhookUrlOptionDeleted();
  block(matchAddWebhookUrlOption(e.id, ANY), function () {
    verifyWebhookUrlOptionDoesNotExist(e.id);
  });
});

bthread("InvitationFailedError create verification", function () {
  const e = waitForAnyInvitationFailedErrorAdded();
  block(matchDeleteInvitationFailedError(e.id, ANY), function () {
    verifyInvitationFailedErrorExists(e.id);
  });
});

bthread("InvitationFailedError update verification", function () {
  const e = waitForAnyInvitationFailedErrorUpdated();
  block(matchDeleteInvitationFailedError(e.id, ANY), function () {
    verifyInvitationFailedErrorUpdated(e.id);
  });
});

bthread("InvitationFailedError delete verification", function () {
  const e = waitForAnyInvitationFailedErrorDeleted();
  block(matchAddInvitationFailedError(e.id, ANY), function () {
    verifyInvitationFailedErrorDoesNotExist(e.id);
  });
});

bthread("ScheduledMessage create verification", function () {
  const e = waitForAnyScheduledMessageAdded();
  block(matchDeleteScheduledMessage(e.id, ANY), function () {
    verifyScheduledMessageExists(e.id);
  });
});

bthread("ScheduledMessage update verification", function () {
  const e = waitForAnyScheduledMessageUpdated();
  block(matchDeleteScheduledMessage(e.id, ANY), function () {
    verifyScheduledMessageUpdated(e.id);
  });
});

bthread("ScheduledMessage delete verification", function () {
  const e = waitForAnyScheduledMessageDeleted();
  block(matchAddScheduledMessage(e.id, ANY), function () {
    verifyScheduledMessageDoesNotExist(e.id);
  });
});

bthread("HistoryPublicToSubscribers create verification", function () {
  const e = waitForAnyHistoryPublicToSubscribersAdded();
  block(matchDeleteHistoryPublicToSubscribers(e.id, ANY), function () {
    verifyHistoryPublicToSubscribersExists(e.id);
  });
});

bthread("HistoryPublicToSubscribers update verification", function () {
  const e = waitForAnyHistoryPublicToSubscribersUpdated();
  block(matchDeleteHistoryPublicToSubscribers(e.id, ANY), function () {
    verifyHistoryPublicToSubscribersUpdated(e.id);
  });
});

bthread("HistoryPublicToSubscribers delete verification", function () {
  const e = waitForAnyHistoryPublicToSubscribersDeleted();
  block(matchAddHistoryPublicToSubscribers(e.id, ANY), function () {
    verifyHistoryPublicToSubscribersDoesNotExist(e.id);
  });
});

bthread("UserStatus create verification", function () {
  const e = waitForAnyUserStatusAdded();
  block(matchDeleteUserStatus(e.id, ANY), function () {
    verifyUserStatusExists(e.id);
  });
});

bthread("UserStatus update verification", function () {
  const e = waitForAnyUserStatusUpdated();
  block(matchDeleteUserStatus(e.id, ANY), function () {
    verifyUserStatusUpdated(e.id);
  });
});

bthread("UserStatus delete verification", function () {
  const e = waitForAnyUserStatusDeleted();
  block(matchAddUserStatus(e.id, ANY), function () {
    verifyUserStatusDoesNotExist(e.id);
  });
});

bthread("DefaultChannelGroup create verification", function () {
  const e = waitForAnyDefaultChannelGroupAdded();
  block(matchDeleteDefaultChannelGroup(e.id, ANY), function () {
    verifyDefaultChannelGroupExists(e.id);
  });
});

bthread("DefaultChannelGroup update verification", function () {
  const e = waitForAnyDefaultChannelGroupUpdated();
  block(matchDeleteDefaultChannelGroup(e.id, ANY), function () {
    verifyDefaultChannelGroupUpdated(e.id);
  });
});

bthread("DefaultChannelGroup delete verification", function () {
  const e = waitForAnyDefaultChannelGroupDeleted();
  block(matchAddDefaultChannelGroup(e.id, ANY), function () {
    verifyDefaultChannelGroupDoesNotExist(e.id);
  });
});

bthread("Bot create verification", function () {
  const e = waitForAnyBotAdded();
  block(matchDeleteBot(e.id, ANY), function () {
    verifyBotExists(e.id);
  });
});

bthread("Bot update verification", function () {
  const e = waitForAnyBotUpdated();
  block(matchDeleteBot(e.id, ANY), function () {
    verifyBotUpdated(e.id);
  });
});

bthread("Bot delete verification", function () {
  const e = waitForAnyBotDeleted();
  block(matchAddBot(e.id, ANY), function () {
    verifyBotDoesNotExist(e.id);
  });
});

bthread("IgnoredParametersSuccess create verification", function () {
  const e = waitForAnyIgnoredParametersSuccessAdded();
  block(matchDeleteIgnoredParametersSuccess(e.id, ANY), function () {
    verifyIgnoredParametersSuccessExists(e.id);
  });
});

bthread("IgnoredParametersSuccess update verification", function () {
  const e = waitForAnyIgnoredParametersSuccessUpdated();
  block(matchDeleteIgnoredParametersSuccess(e.id, ANY), function () {
    verifyIgnoredParametersSuccessUpdated(e.id);
  });
});

bthread("IgnoredParametersSuccess delete verification", function () {
  const e = waitForAnyIgnoredParametersSuccessDeleted();
  block(matchAddIgnoredParametersSuccess(e.id, ANY), function () {
    verifyIgnoredParametersSuccessDoesNotExist(e.id);
  });
});

bthread("JsonResponseBase create verification", function () {
  const e = waitForAnyJsonResponseBaseAdded();
  block(matchDeleteJsonResponseBase(e.id, ANY), function () {
    verifyJsonResponseBaseExists(e.id);
  });
});

bthread("JsonResponseBase update verification", function () {
  const e = waitForAnyJsonResponseBaseUpdated();
  block(matchDeleteJsonResponseBase(e.id, ANY), function () {
    verifyJsonResponseBaseUpdated(e.id);
  });
});

bthread("JsonResponseBase delete verification", function () {
  const e = waitForAnyJsonResponseBaseDeleted();
  block(matchAddJsonResponseBase(e.id, ANY), function () {
    verifyJsonResponseBaseDoesNotExist(e.id);
  });
});

bthread("MessageRetentionDays create verification", function () {
  const e = waitForAnyMessageRetentionDaysAdded();
  block(matchDeleteMessageRetentionDays(e.id, ANY), function () {
    verifyMessageRetentionDaysExists(e.id);
  });
});

bthread("MessageRetentionDays update verification", function () {
  const e = waitForAnyMessageRetentionDaysUpdated();
  block(matchDeleteMessageRetentionDays(e.id, ANY), function () {
    verifyMessageRetentionDaysUpdated(e.id);
  });
});

bthread("MessageRetentionDays delete verification", function () {
  const e = waitForAnyMessageRetentionDaysDeleted();
  block(matchAddMessageRetentionDays(e.id, ANY), function () {
    verifyMessageRetentionDaysDoesNotExist(e.id);
  });
});

bthread("GroupSettingValueUpdate create verification", function () {
  const e = waitForAnyGroupSettingValueUpdateAdded();
  block(matchDeleteGroupSettingValueUpdate(e.id, ANY), function () {
    verifyGroupSettingValueUpdateExists(e.id);
  });
});

bthread("GroupSettingValueUpdate update verification", function () {
  const e = waitForAnyGroupSettingValueUpdateUpdated();
  block(matchDeleteGroupSettingValueUpdate(e.id, ANY), function () {
    verifyGroupSettingValueUpdateUpdated(e.id);
  });
});

bthread("GroupSettingValueUpdate delete verification", function () {
  const e = waitForAnyGroupSettingValueUpdateDeleted();
  block(matchAddGroupSettingValueUpdate(e.id, ANY), function () {
    verifyGroupSettingValueUpdateDoesNotExist(e.id);
  });
});

bthread("IncompatibleParametersError create verification", function () {
  const e = waitForAnyIncompatibleParametersErrorAdded();
  block(matchDeleteIncompatibleParametersError(e.id, ANY), function () {
    verifyIncompatibleParametersErrorExists(e.id);
  });
});

bthread("IncompatibleParametersError update verification", function () {
  const e = waitForAnyIncompatibleParametersErrorUpdated();
  block(matchDeleteIncompatibleParametersError(e.id, ANY), function () {
    verifyIncompatibleParametersErrorUpdated(e.id);
  });
});

bthread("IncompatibleParametersError delete verification", function () {
  const e = waitForAnyIncompatibleParametersErrorDeleted();
  block(matchAddIncompatibleParametersError(e.id, ANY), function () {
    verifyIncompatibleParametersErrorDoesNotExist(e.id);
  });
});

bthread("IgnoredParametersBase create verification", function () {
  const e = waitForAnyIgnoredParametersBaseAdded();
  block(matchDeleteIgnoredParametersBase(e.id, ANY), function () {
    verifyIgnoredParametersBaseExists(e.id);
  });
});

bthread("IgnoredParametersBase update verification", function () {
  const e = waitForAnyIgnoredParametersBaseUpdated();
  block(matchDeleteIgnoredParametersBase(e.id, ANY), function () {
    verifyIgnoredParametersBaseUpdated(e.id);
  });
});

bthread("IgnoredParametersBase delete verification", function () {
  const e = waitForAnyIgnoredParametersBaseDeleted();
  block(matchAddIgnoredParametersBase(e.id, ANY), function () {
    verifyIgnoredParametersBaseDoesNotExist(e.id);
  });
});

bthread("CanDeleteAnyMessageGroup create verification", function () {
  const e = waitForAnyCanDeleteAnyMessageGroupAdded();
  block(matchDeleteCanDeleteAnyMessageGroup(e.id, ANY), function () {
    verifyCanDeleteAnyMessageGroupExists(e.id);
  });
});

bthread("CanDeleteAnyMessageGroup update verification", function () {
  const e = waitForAnyCanDeleteAnyMessageGroupUpdated();
  block(matchDeleteCanDeleteAnyMessageGroup(e.id, ANY), function () {
    verifyCanDeleteAnyMessageGroupUpdated(e.id);
  });
});

bthread("CanDeleteAnyMessageGroup delete verification", function () {
  const e = waitForAnyCanDeleteAnyMessageGroupDeleted();
  block(matchAddCanDeleteAnyMessageGroup(e.id, ANY), function () {
    verifyCanDeleteAnyMessageGroupDoesNotExist(e.id);
  });
});

bthread("CustomProfileField create verification", function () {
  const e = waitForAnyCustomProfileFieldAdded();
  block(matchDeleteCustomProfileField(e.id, ANY), function () {
    verifyCustomProfileFieldExists(e.id);
  });
});

bthread("CustomProfileField update verification", function () {
  const e = waitForAnyCustomProfileFieldUpdated();
  block(matchDeleteCustomProfileField(e.id, ANY), function () {
    verifyCustomProfileFieldUpdated(e.id);
  });
});

bthread("CustomProfileField delete verification", function () {
  const e = waitForAnyCustomProfileFieldDeleted();
  block(matchAddCustomProfileField(e.id, ANY), function () {
    verifyCustomProfileFieldDoesNotExist(e.id);
  });
});

bthread("CanMoveMessagesWithinChannelGroup create verification", function () {
  const e = waitForAnyCanMoveMessagesWithinChannelGroupAdded();
  block(matchDeleteCanMoveMessagesWithinChannelGroup(e.id, ANY), function () {
    verifyCanMoveMessagesWithinChannelGroupExists(e.id);
  });
});

bthread("CanMoveMessagesWithinChannelGroup update verification", function () {
  const e = waitForAnyCanMoveMessagesWithinChannelGroupUpdated();
  block(matchDeleteCanMoveMessagesWithinChannelGroup(e.id, ANY), function () {
    verifyCanMoveMessagesWithinChannelGroupUpdated(e.id);
  });
});

bthread("CanMoveMessagesWithinChannelGroup delete verification", function () {
  const e = waitForAnyCanMoveMessagesWithinChannelGroupDeleted();
  block(matchAddCanMoveMessagesWithinChannelGroup(e.id, ANY), function () {
    verifyCanMoveMessagesWithinChannelGroupDoesNotExist(e.id);
  });
});

bthread("Subscription create verification", function () {
  const e = waitForAnySubscriptionAdded();
  block(matchDeleteSubscription(e.id, ANY), function () {
    verifySubscriptionExists(e.id);
  });
});

bthread("Subscription update verification", function () {
  const e = waitForAnySubscriptionUpdated();
  block(matchDeleteSubscription(e.id, ANY), function () {
    verifySubscriptionUpdated(e.id);
  });
});

bthread("Subscription delete verification", function () {
  const e = waitForAnySubscriptionDeleted();
  block(matchAddSubscription(e.id, ANY), function () {
    verifySubscriptionDoesNotExist(e.id);
  });
});

bthread("CodedError create verification", function () {
  const e = waitForAnyCodedErrorAdded();
  block(matchDeleteCodedError(e.id, ANY), function () {
    verifyCodedErrorExists(e.id);
  });
});

bthread("CodedError update verification", function () {
  const e = waitForAnyCodedErrorUpdated();
  block(matchDeleteCodedError(e.id, ANY), function () {
    verifyCodedErrorUpdated(e.id);
  });
});

bthread("CodedError delete verification", function () {
  const e = waitForAnyCodedErrorDeleted();
  block(matchAddCodedError(e.id, ANY), function () {
    verifyCodedErrorDoesNotExist(e.id);
  });
});

bthread("CanResolveTopicsGroup create verification", function () {
  const e = waitForAnyCanResolveTopicsGroupAdded();
  block(matchDeleteCanResolveTopicsGroup(e.id, ANY), function () {
    verifyCanResolveTopicsGroupExists(e.id);
  });
});

bthread("CanResolveTopicsGroup update verification", function () {
  const e = waitForAnyCanResolveTopicsGroupUpdated();
  block(matchDeleteCanResolveTopicsGroup(e.id, ANY), function () {
    verifyCanResolveTopicsGroupUpdated(e.id);
  });
});

bthread("CanResolveTopicsGroup delete verification", function () {
  const e = waitForAnyCanResolveTopicsGroupDeleted();
  block(matchAddCanResolveTopicsGroup(e.id, ANY), function () {
    verifyCanResolveTopicsGroupDoesNotExist(e.id);
  });
});

bthread("SendNewSubscriptionMessages create verification", function () {
  const e = waitForAnySendNewSubscriptionMessagesAdded();
  block(matchDeleteSendNewSubscriptionMessages(e.id, ANY), function () {
    verifySendNewSubscriptionMessagesExists(e.id);
  });
});

bthread("SendNewSubscriptionMessages update verification", function () {
  const e = waitForAnySendNewSubscriptionMessagesUpdated();
  block(matchDeleteSendNewSubscriptionMessages(e.id, ANY), function () {
    verifySendNewSubscriptionMessagesUpdated(e.id);
  });
});

bthread("SendNewSubscriptionMessages delete verification", function () {
  const e = waitForAnySendNewSubscriptionMessagesDeleted();
  block(matchAddSendNewSubscriptionMessages(e.id, ANY), function () {
    verifySendNewSubscriptionMessagesDoesNotExist(e.id);
  });
});

bthread("RealmAuthenticationMethod create verification", function () {
  const e = waitForAnyRealmAuthenticationMethodAdded();
  block(matchDeleteRealmAuthenticationMethod(e.id, ANY), function () {
    verifyRealmAuthenticationMethodExists(e.id);
  });
});

bthread("RealmAuthenticationMethod update verification", function () {
  const e = waitForAnyRealmAuthenticationMethodUpdated();
  block(matchDeleteRealmAuthenticationMethod(e.id, ANY), function () {
    verifyRealmAuthenticationMethodUpdated(e.id);
  });
});

bthread("RealmAuthenticationMethod delete verification", function () {
  const e = waitForAnyRealmAuthenticationMethodDeleted();
  block(matchAddRealmAuthenticationMethod(e.id, ANY), function () {
    verifyRealmAuthenticationMethodDoesNotExist(e.id);
  });
});

bthread("CanSendMessageGroup create verification", function () {
  const e = waitForAnyCanSendMessageGroupAdded();
  block(matchDeleteCanSendMessageGroup(e.id, ANY), function () {
    verifyCanSendMessageGroupExists(e.id);
  });
});

bthread("CanSendMessageGroup update verification", function () {
  const e = waitForAnyCanSendMessageGroupUpdated();
  block(matchDeleteCanSendMessageGroup(e.id, ANY), function () {
    verifyCanSendMessageGroupUpdated(e.id);
  });
});

bthread("CanSendMessageGroup delete verification", function () {
  const e = waitForAnyCanSendMessageGroupDeleted();
  block(matchAddCanSendMessageGroup(e.id, ANY), function () {
    verifyCanSendMessageGroupDoesNotExist(e.id);
  });
});

bthread("Reminder create verification", function () {
  const e = waitForAnyReminderAdded();
  block(matchDeleteReminder(e.id, ANY), function () {
    verifyReminderExists(e.id);
  });
});

bthread("Reminder update verification", function () {
  const e = waitForAnyReminderUpdated();
  block(matchDeleteReminder(e.id, ANY), function () {
    verifyReminderUpdated(e.id);
  });
});

bthread("Reminder delete verification", function () {
  const e = waitForAnyReminderDeleted();
  block(matchAddReminder(e.id, ANY), function () {
    verifyReminderDoesNotExist(e.id);
  });
});

bthread("OnboardingStep create verification", function () {
  const e = waitForAnyOnboardingStepAdded();
  block(matchDeleteOnboardingStep(e.id, ANY), function () {
    verifyOnboardingStepExists(e.id);
  });
});

bthread("OnboardingStep update verification", function () {
  const e = waitForAnyOnboardingStepUpdated();
  block(matchDeleteOnboardingStep(e.id, ANY), function () {
    verifyOnboardingStepUpdated(e.id);
  });
});

bthread("OnboardingStep delete verification", function () {
  const e = waitForAnyOnboardingStepDeleted();
  block(matchAddOnboardingStep(e.id, ANY), function () {
    verifyOnboardingStepDoesNotExist(e.id);
  });
});

bthread("Draft create verification", function () {
  const e = waitForAnyDraftAdded();
  block(matchDeleteDraft(e.id, ANY), function () {
    verifyDraftExists(e.id);
  });
});

bthread("Draft update verification", function () {
  const e = waitForAnyDraftUpdated();
  block(matchDeleteDraft(e.id, ANY), function () {
    verifyDraftUpdated(e.id);
  });
});

bthread("Draft delete verification", function () {
  const e = waitForAnyDraftDeleted();
  block(matchAddDraft(e.id, ANY), function () {
    verifyDraftDoesNotExist(e.id);
  });
});

bthread("InvalidRemotePushDeviceTokenError create verification", function () {
  const e = waitForAnyInvalidRemotePushDeviceTokenErrorAdded();
  block(matchDeleteInvalidRemotePushDeviceTokenError(e.id, ANY), function () {
    verifyInvalidRemotePushDeviceTokenErrorExists(e.id);
  });
});

bthread("InvalidRemotePushDeviceTokenError update verification", function () {
  const e = waitForAnyInvalidRemotePushDeviceTokenErrorUpdated();
  block(matchDeleteInvalidRemotePushDeviceTokenError(e.id, ANY), function () {
    verifyInvalidRemotePushDeviceTokenErrorUpdated(e.id);
  });
});

bthread("InvalidRemotePushDeviceTokenError delete verification", function () {
  const e = waitForAnyInvalidRemotePushDeviceTokenErrorDeleted();
  block(matchAddInvalidRemotePushDeviceTokenError(e.id, ANY), function () {
    verifyInvalidRemotePushDeviceTokenErrorDoesNotExist(e.id);
  });
});

bthread("ApiKeyResponse create verification", function () {
  const e = waitForAnyApiKeyResponseAdded();
  block(matchDeleteApiKeyResponse(e.id, ANY), function () {
    verifyApiKeyResponseExists(e.id);
  });
});

bthread("ApiKeyResponse update verification", function () {
  const e = waitForAnyApiKeyResponseUpdated();
  block(matchDeleteApiKeyResponse(e.id, ANY), function () {
    verifyApiKeyResponseUpdated(e.id);
  });
});

bthread("ApiKeyResponse delete verification", function () {
  const e = waitForAnyApiKeyResponseDeleted();
  block(matchAddApiKeyResponse(e.id, ANY), function () {
    verifyApiKeyResponseDoesNotExist(e.id);
  });
});

bthread("UserDeactivatedError create verification", function () {
  const e = waitForAnyUserDeactivatedErrorAdded();
  block(matchDeleteUserDeactivatedError(e.id, ANY), function () {
    verifyUserDeactivatedErrorExists(e.id);
  });
});

bthread("UserDeactivatedError update verification", function () {
  const e = waitForAnyUserDeactivatedErrorUpdated();
  block(matchDeleteUserDeactivatedError(e.id, ANY), function () {
    verifyUserDeactivatedErrorUpdated(e.id);
  });
});

bthread("UserDeactivatedError delete verification", function () {
  const e = waitForAnyUserDeactivatedErrorDeleted();
  block(matchAddUserDeactivatedError(e.id, ANY), function () {
    verifyUserDeactivatedErrorDoesNotExist(e.id);
  });
});

bthread("CanDeleteOwnMessageGroup create verification", function () {
  const e = waitForAnyCanDeleteOwnMessageGroupAdded();
  block(matchDeleteCanDeleteOwnMessageGroup(e.id, ANY), function () {
    verifyCanDeleteOwnMessageGroupExists(e.id);
  });
});

bthread("CanDeleteOwnMessageGroup update verification", function () {
  const e = waitForAnyCanDeleteOwnMessageGroupUpdated();
  block(matchDeleteCanDeleteOwnMessageGroup(e.id, ANY), function () {
    verifyCanDeleteOwnMessageGroupUpdated(e.id);
  });
});

bthread("CanDeleteOwnMessageGroup delete verification", function () {
  const e = waitForAnyCanDeleteOwnMessageGroupDeleted();
  block(matchAddCanDeleteOwnMessageGroup(e.id, ANY), function () {
    verifyCanDeleteOwnMessageGroupDoesNotExist(e.id);
  });
});

bthread("GroupPermissionSetting create verification", function () {
  const e = waitForAnyGroupPermissionSettingAdded();
  block(matchDeleteGroupPermissionSetting(e.id, ANY), function () {
    verifyGroupPermissionSettingExists(e.id);
  });
});

bthread("GroupPermissionSetting update verification", function () {
  const e = waitForAnyGroupPermissionSettingUpdated();
  block(matchDeleteGroupPermissionSetting(e.id, ANY), function () {
    verifyGroupPermissionSettingUpdated(e.id);
  });
});

bthread("GroupPermissionSetting delete verification", function () {
  const e = waitForAnyGroupPermissionSettingDeleted();
  block(matchAddGroupPermissionSetting(e.id, ANY), function () {
    verifyGroupPermissionSettingDoesNotExist(e.id);
  });
});

bthread("BotConfiguration create verification", function () {
  const e = waitForAnyBotConfigurationAdded();
  block(matchDeleteBotConfiguration(e.id, ANY), function () {
    verifyBotConfigurationExists(e.id);
  });
});

bthread("BotConfiguration update verification", function () {
  const e = waitForAnyBotConfigurationUpdated();
  block(matchDeleteBotConfiguration(e.id, ANY), function () {
    verifyBotConfigurationUpdated(e.id);
  });
});

bthread("BotConfiguration delete verification", function () {
  const e = waitForAnyBotConfigurationDeleted();
  block(matchAddBotConfiguration(e.id, ANY), function () {
    verifyBotConfigurationDoesNotExist(e.id);
  });
});

bthread("FolderId create verification", function () {
  const e = waitForAnyFolderIdAdded();
  block(matchDeleteFolderId(e.id, ANY), function () {
    verifyFolderIdExists(e.id);
  });
});

bthread("FolderId update verification", function () {
  const e = waitForAnyFolderIdUpdated();
  block(matchDeleteFolderId(e.id, ANY), function () {
    verifyFolderIdUpdated(e.id);
  });
});

bthread("FolderId delete verification", function () {
  const e = waitForAnyFolderIdDeleted();
  block(matchAddFolderId(e.id, ANY), function () {
    verifyFolderIdDoesNotExist(e.id);
  });
});

bthread("ScheduledMessageBase create verification", function () {
  const e = waitForAnyScheduledMessageBaseAdded();
  block(matchDeleteScheduledMessageBase(e.id, ANY), function () {
    verifyScheduledMessageBaseExists(e.id);
  });
});

bthread("ScheduledMessageBase update verification", function () {
  const e = waitForAnyScheduledMessageBaseUpdated();
  block(matchDeleteScheduledMessageBase(e.id, ANY), function () {
    verifyScheduledMessageBaseUpdated(e.id);
  });
});

bthread("ScheduledMessageBase delete verification", function () {
  const e = waitForAnyScheduledMessageBaseDeleted();
  block(matchAddScheduledMessageBase(e.id, ANY), function () {
    verifyScheduledMessageBaseDoesNotExist(e.id);
  });
});

bthread("EventIdSchema create verification", function () {
  const e = waitForAnyEventIdSchemaAdded();
  block(matchDeleteEventIdSchema(e.id, ANY), function () {
    verifyEventIdSchemaExists(e.id);
  });
});

bthread("EventIdSchema update verification", function () {
  const e = waitForAnyEventIdSchemaUpdated();
  block(matchDeleteEventIdSchema(e.id, ANY), function () {
    verifyEventIdSchemaUpdated(e.id);
  });
});

bthread("EventIdSchema delete verification", function () {
  const e = waitForAnyEventIdSchemaDeleted();
  block(matchAddEventIdSchema(e.id, ANY), function () {
    verifyEventIdSchemaDoesNotExist(e.id);
  });
});

bthread("TopicsPolicy create verification", function () {
  const e = waitForAnyTopicsPolicyAdded();
  block(matchDeleteTopicsPolicy(e.id, ANY), function () {
    verifyTopicsPolicyExists(e.id);
  });
});

bthread("TopicsPolicy update verification", function () {
  const e = waitForAnyTopicsPolicyUpdated();
  block(matchDeleteTopicsPolicy(e.id, ANY), function () {
    verifyTopicsPolicyUpdated(e.id);
  });
});

bthread("TopicsPolicy delete verification", function () {
  const e = waitForAnyTopicsPolicyDeleted();
  block(matchAddTopicsPolicy(e.id, ANY), function () {
    verifyTopicsPolicyDoesNotExist(e.id);
  });
});

bthread("RealmDomain create verification", function () {
  const e = waitForAnyRealmDomainAdded();
  block(matchDeleteRealmDomain(e.id, ANY), function () {
    verifyRealmDomainExists(e.id);
  });
});

bthread("RealmDomain update verification", function () {
  const e = waitForAnyRealmDomainUpdated();
  block(matchDeleteRealmDomain(e.id, ANY), function () {
    verifyRealmDomainUpdated(e.id);
  });
});

bthread("RealmDomain delete verification", function () {
  const e = waitForAnyRealmDomainDeleted();
  block(matchAddRealmDomain(e.id, ANY), function () {
    verifyRealmDomainDoesNotExist(e.id);
  });
});

// ===== RELATIONSHIP GUARDS =====

// ===== UNIQUENESS GUARDS =====

bthread("Guard: Unique EmojiReaction", function () {
  const x = waitForAnyEmojiReactionAdded();
  block(matchAddEmojiReaction(x.id, ANY), function () {});
});

bthread("Guard: Unique UserNotAuthorizedError", function () {
  const x = waitForAnyUserNotAuthorizedErrorAdded();
  block(matchAddUserNotAuthorizedError(x.id, ANY), function () {});
});

bthread("Guard: Unique CanRemoveSubscribersGroup", function () {
  const x = waitForAnyCanRemoveSubscribersGroupAdded();
  block(matchAddCanRemoveSubscribersGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique InvalidApiKeyError", function () {
  const x = waitForAnyInvalidApiKeyErrorAdded();
  block(matchAddInvalidApiKeyError(x.id, ANY), function () {});
});

bthread("Guard: Unique ReactionType", function () {
  const x = waitForAnyReactionTypeAdded();
  block(matchAddReactionType(x.id, ANY), function () {});
});

bthread("Guard: Unique NonExistingChannelIdError", function () {
  const x = waitForAnyNonExistingChannelIdErrorAdded();
  block(matchAddNonExistingChannelIdError(x.id, ANY), function () {});
});

bthread("Guard: Unique RealmExport", function () {
  const x = waitForAnyRealmExportAdded();
  block(matchAddRealmExport(x.id, ANY), function () {});
});

bthread("Guard: Unique SavedSnippet", function () {
  const x = waitForAnySavedSnippetAdded();
  block(matchAddSavedSnippet(x.id, ANY), function () {});
});

bthread("Guard: Unique InvalidChannelError", function () {
  const x = waitForAnyInvalidChannelErrorAdded();
  block(matchAddInvalidChannelError(x.id, ANY), function () {});
});

bthread("Guard: Unique AllPublicChannels", function () {
  const x = waitForAnyAllPublicChannelsAdded();
  block(matchAddAllPublicChannels(x.id, ANY), function () {});
});

bthread("Guard: Unique BasicChannel", function () {
  const x = waitForAnyBasicChannelAdded();
  block(matchAddBasicChannel(x.id, ANY), function () {});
});

bthread("Guard: Unique Attachment", function () {
  const x = waitForAnyAttachmentAdded();
  block(matchAddAttachment(x.id, ANY), function () {});
});

bthread("Guard: Unique NavigationView", function () {
  const x = waitForAnyNavigationViewAdded();
  block(matchAddNavigationView(x.id, ANY), function () {});
});

bthread("Guard: Unique EmojiCode", function () {
  const x = waitForAnyEmojiCodeAdded();
  block(matchAddEmojiCode(x.id, ANY), function () {});
});

bthread("Guard: Unique Profile_data", function () {
  const x = waitForAnyProfile_dataAdded();
  block(matchAddProfile_data(x.id, ANY), function () {});
});

bthread("Guard: Unique CodedErrorBase", function () {
  const x = waitForAnyCodedErrorBaseAdded();
  block(matchAddCodedErrorBase(x.id, ANY), function () {});
});

bthread("Guard: Unique PushNotificationAdminActionRequiredError", function () {
  const x = waitForAnyPushNotificationAdminActionRequiredErrorAdded();
  block(matchAddPushNotificationAdminActionRequiredError(x.id, ANY), function () {});
});

bthread("Guard: Unique BasicBotBase", function () {
  const x = waitForAnyBasicBotBaseAdded();
  block(matchAddBasicBotBase(x.id, ANY), function () {});
});

bthread("Guard: Unique Narrow", function () {
  const x = waitForAnyNarrowAdded();
  block(matchAddNarrow(x.id, ANY), function () {});
});

bthread("Guard: Unique JsonSuccess", function () {
  const x = waitForAnyJsonSuccessAdded();
  block(matchAddJsonSuccess(x.id, ANY), function () {});
});

bthread("Guard: Unique LegacyPresenceFormat", function () {
  const x = waitForAnyLegacyPresenceFormatAdded();
  block(matchAddLegacyPresenceFormat(x.id, ANY), function () {});
});

bthread("Guard: Unique InternalBouncerServerError", function () {
  const x = waitForAnyInternalBouncerServerErrorAdded();
  block(matchAddInternalBouncerServerError(x.id, ANY), function () {});
});

bthread("Guard: Unique IgnoredParametersUnsupported", function () {
  const x = waitForAnyIgnoredParametersUnsupportedAdded();
  block(matchAddIgnoredParametersUnsupported(x.id, ANY), function () {});
});

bthread("Guard: Unique Anchor", function () {
  const x = waitForAnyAnchorAdded();
  block(matchAddAnchor(x.id, ANY), function () {});
});

bthread("Guard: Unique EventTypeSchema", function () {
  const x = waitForAnyEventTypeSchemaAdded();
  block(matchAddEventTypeSchema(x.id, ANY), function () {});
});

bthread("Guard: Unique MessagesEvent", function () {
  const x = waitForAnyMessagesEventAdded();
  block(matchAddMessagesEvent(x.id, ANY), function () {});
});

bthread("Guard: Unique LinkifierURLTemplate", function () {
  const x = waitForAnyLinkifierURLTemplateAdded();
  block(matchAddLinkifierURLTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique ChannelFolder", function () {
  const x = waitForAnyChannelFolderAdded();
  block(matchAddChannelFolder(x.id, ANY), function () {});
});

bthread("Guard: Unique Invite", function () {
  const x = waitForAnyInviteAdded();
  block(matchAddInvite(x.id, ANY), function () {});
});

bthread("Guard: Unique CanSubscribeGroup", function () {
  const x = waitForAnyCanSubscribeGroupAdded();
  block(matchAddCanSubscribeGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique JsonSuccessBase", function () {
  const x = waitForAnyJsonSuccessBaseAdded();
  block(matchAddJsonSuccessBase(x.id, ANY), function () {});
});

bthread("Guard: Unique EmojiBase", function () {
  const x = waitForAnyEmojiBaseAdded();
  block(matchAddEmojiBase(x.id, ANY), function () {});
});

bthread("Guard: Unique User", function () {
  const x = waitForAnyUserAdded();
  block(matchAddUser(x.id, ANY), function () {});
});

bthread("Guard: Unique MissingArgumentError", function () {
  const x = waitForAnyMissingArgumentErrorAdded();
  block(matchAddMissingArgumentError(x.id, ANY), function () {});
});

bthread("Guard: Unique NonExistingChannelNameError", function () {
  const x = waitForAnyNonExistingChannelNameErrorAdded();
  block(matchAddNonExistingChannelNameError(x.id, ANY), function () {});
});

bthread("Guard: Unique Principals", function () {
  const x = waitForAnyPrincipalsAdded();
  block(matchAddPrincipals(x.id, ANY), function () {});
});

bthread("Guard: Unique InvalidPushDeviceTokenError", function () {
  const x = waitForAnyInvalidPushDeviceTokenErrorAdded();
  block(matchAddInvalidPushDeviceTokenError(x.id, ANY), function () {});
});

bthread("Guard: Unique RealmEmoji", function () {
  const x = waitForAnyRealmEmojiAdded();
  block(matchAddRealmEmoji(x.id, ANY), function () {});
});

bthread("Guard: Unique FailedToConnectBouncerError", function () {
  const x = waitForAnyFailedToConnectBouncerErrorAdded();
  block(matchAddFailedToConnectBouncerError(x.id, ANY), function () {});
});

bthread("Guard: Unique CanAdministerChannelGroup", function () {
  const x = waitForAnyCanAdministerChannelGroupAdded();
  block(matchAddCanAdministerChannelGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique OptionalContent", function () {
  const x = waitForAnyOptionalContentAdded();
  block(matchAddOptionalContent(x.id, ANY), function () {});
});

bthread("Guard: Unique WebhookConfigOption", function () {
  const x = waitForAnyWebhookConfigOptionAdded();
  block(matchAddWebhookConfigOption(x.id, ANY), function () {});
});

bthread("Guard: Unique RequiredContent", function () {
  const x = waitForAnyRequiredContentAdded();
  block(matchAddRequiredContent(x.id, ANY), function () {});
});

bthread("Guard: Unique InvalidMessageError", function () {
  const x = waitForAnyInvalidMessageErrorAdded();
  block(matchAddInvalidMessageError(x.id, ANY), function () {});
});

bthread("Guard: Unique UserBase", function () {
  const x = waitForAnyUserBaseAdded();
  block(matchAddUserBase(x.id, ANY), function () {});
});

bthread("Guard: Unique CanMoveMessagesOutOfChannelGroup", function () {
  const x = waitForAnyCanMoveMessagesOutOfChannelGroupAdded();
  block(matchAddCanMoveMessagesOutOfChannelGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique LinkifierPattern", function () {
  const x = waitForAnyLinkifierPatternAdded();
  block(matchAddLinkifierPattern(x.id, ANY), function () {});
});

bthread("Guard: Unique MessagesBase", function () {
  const x = waitForAnyMessagesBaseAdded();
  block(matchAddMessagesBase(x.id, ANY), function () {});
});

bthread("Guard: Unique EmailAddressVisibility", function () {
  const x = waitForAnyEmailAddressVisibilityAdded();
  block(matchAddEmailAddressVisibility(x.id, ANY), function () {});
});

bthread("Guard: Unique ModernPresenceFormat", function () {
  const x = waitForAnyModernPresenceFormatAdded();
  block(matchAddModernPresenceFormat(x.id, ANY), function () {});
});

bthread("Guard: Unique BasicBot", function () {
  const x = waitForAnyBasicBotAdded();
  block(matchAddBasicBot(x.id, ANY), function () {});
});

bthread("Guard: Unique BasicChannelBase", function () {
  const x = waitForAnyBasicChannelBaseAdded();
  block(matchAddBasicChannelBase(x.id, ANY), function () {});
});

bthread("Guard: Unique UserGroup", function () {
  const x = waitForAnyUserGroupAdded();
  block(matchAddUserGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique InviteRoleParameter", function () {
  const x = waitForAnyInviteRoleParameterAdded();
  block(matchAddInviteRoleParameter(x.id, ANY), function () {});
});

bthread("Guard: Unique RealmDeactivatedError", function () {
  const x = waitForAnyRealmDeactivatedErrorAdded();
  block(matchAddRealmDeactivatedError(x.id, ANY), function () {});
});

bthread("Guard: Unique NoActivePushDeviceError", function () {
  const x = waitForAnyNoActivePushDeviceErrorAdded();
  block(matchAddNoActivePushDeviceError(x.id, ANY), function () {});
});

bthread("Guard: Unique EmojiReactionEvent", function () {
  const x = waitForAnyEmojiReactionEventAdded();
  block(matchAddEmojiReactionEvent(x.id, ANY), function () {});
});

bthread("Guard: Unique BadEventQueueIdError", function () {
  const x = waitForAnyBadEventQueueIdErrorAdded();
  block(matchAddBadEventQueueIdError(x.id, ANY), function () {});
});

bthread("Guard: Unique GroupSettingValue", function () {
  const x = waitForAnyGroupSettingValueAdded();
  block(matchAddGroupSettingValue(x.id, ANY), function () {});
});

bthread("Guard: Unique Event_types", function () {
  const x = waitForAnyEvent_typesAdded();
  block(matchAddEvent_types(x.id, ANY), function () {});
});

bthread("Guard: Unique RealmPlayground", function () {
  const x = waitForAnyRealmPlaygroundAdded();
  block(matchAddRealmPlayground(x.id, ANY), function () {});
});

bthread("Guard: Unique InviteExpirationParameter", function () {
  const x = waitForAnyInviteExpirationParameterAdded();
  block(matchAddInviteExpirationParameter(x.id, ANY), function () {});
});

bthread("Guard: Unique RateLimitedError", function () {
  const x = waitForAnyRateLimitedErrorAdded();
  block(matchAddRateLimitedError(x.id, ANY), function () {});
});

bthread("Guard: Unique ChannelCanAddSubscribersGroup", function () {
  const x = waitForAnyChannelCanAddSubscribersGroupAdded();
  block(matchAddChannelCanAddSubscribersGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique WebhookUrlOption", function () {
  const x = waitForAnyWebhookUrlOptionAdded();
  block(matchAddWebhookUrlOption(x.id, ANY), function () {});
});

bthread("Guard: Unique InvitationFailedError", function () {
  const x = waitForAnyInvitationFailedErrorAdded();
  block(matchAddInvitationFailedError(x.id, ANY), function () {});
});

bthread("Guard: Unique ScheduledMessage", function () {
  const x = waitForAnyScheduledMessageAdded();
  block(matchAddScheduledMessage(x.id, ANY), function () {});
});

bthread("Guard: Unique HistoryPublicToSubscribers", function () {
  const x = waitForAnyHistoryPublicToSubscribersAdded();
  block(matchAddHistoryPublicToSubscribers(x.id, ANY), function () {});
});

bthread("Guard: Unique UserStatus", function () {
  const x = waitForAnyUserStatusAdded();
  block(matchAddUserStatus(x.id, ANY), function () {});
});

bthread("Guard: Unique DefaultChannelGroup", function () {
  const x = waitForAnyDefaultChannelGroupAdded();
  block(matchAddDefaultChannelGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique Bot", function () {
  const x = waitForAnyBotAdded();
  block(matchAddBot(x.id, ANY), function () {});
});

bthread("Guard: Unique IgnoredParametersSuccess", function () {
  const x = waitForAnyIgnoredParametersSuccessAdded();
  block(matchAddIgnoredParametersSuccess(x.id, ANY), function () {});
});

bthread("Guard: Unique JsonResponseBase", function () {
  const x = waitForAnyJsonResponseBaseAdded();
  block(matchAddJsonResponseBase(x.id, ANY), function () {});
});

bthread("Guard: Unique MessageRetentionDays", function () {
  const x = waitForAnyMessageRetentionDaysAdded();
  block(matchAddMessageRetentionDays(x.id, ANY), function () {});
});

bthread("Guard: Unique GroupSettingValueUpdate", function () {
  const x = waitForAnyGroupSettingValueUpdateAdded();
  block(matchAddGroupSettingValueUpdate(x.id, ANY), function () {});
});

bthread("Guard: Unique IncompatibleParametersError", function () {
  const x = waitForAnyIncompatibleParametersErrorAdded();
  block(matchAddIncompatibleParametersError(x.id, ANY), function () {});
});

bthread("Guard: Unique IgnoredParametersBase", function () {
  const x = waitForAnyIgnoredParametersBaseAdded();
  block(matchAddIgnoredParametersBase(x.id, ANY), function () {});
});

bthread("Guard: Unique CanDeleteAnyMessageGroup", function () {
  const x = waitForAnyCanDeleteAnyMessageGroupAdded();
  block(matchAddCanDeleteAnyMessageGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique CustomProfileField", function () {
  const x = waitForAnyCustomProfileFieldAdded();
  block(matchAddCustomProfileField(x.id, ANY), function () {});
});

bthread("Guard: Unique CanMoveMessagesWithinChannelGroup", function () {
  const x = waitForAnyCanMoveMessagesWithinChannelGroupAdded();
  block(matchAddCanMoveMessagesWithinChannelGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique Subscription", function () {
  const x = waitForAnySubscriptionAdded();
  block(matchAddSubscription(x.id, ANY), function () {});
});

bthread("Guard: Unique CodedError", function () {
  const x = waitForAnyCodedErrorAdded();
  block(matchAddCodedError(x.id, ANY), function () {});
});

bthread("Guard: Unique CanResolveTopicsGroup", function () {
  const x = waitForAnyCanResolveTopicsGroupAdded();
  block(matchAddCanResolveTopicsGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique SendNewSubscriptionMessages", function () {
  const x = waitForAnySendNewSubscriptionMessagesAdded();
  block(matchAddSendNewSubscriptionMessages(x.id, ANY), function () {});
});

bthread("Guard: Unique RealmAuthenticationMethod", function () {
  const x = waitForAnyRealmAuthenticationMethodAdded();
  block(matchAddRealmAuthenticationMethod(x.id, ANY), function () {});
});

bthread("Guard: Unique CanSendMessageGroup", function () {
  const x = waitForAnyCanSendMessageGroupAdded();
  block(matchAddCanSendMessageGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique Reminder", function () {
  const x = waitForAnyReminderAdded();
  block(matchAddReminder(x.id, ANY), function () {});
});

bthread("Guard: Unique OnboardingStep", function () {
  const x = waitForAnyOnboardingStepAdded();
  block(matchAddOnboardingStep(x.id, ANY), function () {});
});

bthread("Guard: Unique Draft", function () {
  const x = waitForAnyDraftAdded();
  block(matchAddDraft(x.id, ANY), function () {});
});

bthread("Guard: Unique InvalidRemotePushDeviceTokenError", function () {
  const x = waitForAnyInvalidRemotePushDeviceTokenErrorAdded();
  block(matchAddInvalidRemotePushDeviceTokenError(x.id, ANY), function () {});
});

bthread("Guard: Unique ApiKeyResponse", function () {
  const x = waitForAnyApiKeyResponseAdded();
  block(matchAddApiKeyResponse(x.id, ANY), function () {});
});

bthread("Guard: Unique UserDeactivatedError", function () {
  const x = waitForAnyUserDeactivatedErrorAdded();
  block(matchAddUserDeactivatedError(x.id, ANY), function () {});
});

bthread("Guard: Unique CanDeleteOwnMessageGroup", function () {
  const x = waitForAnyCanDeleteOwnMessageGroupAdded();
  block(matchAddCanDeleteOwnMessageGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique GroupPermissionSetting", function () {
  const x = waitForAnyGroupPermissionSettingAdded();
  block(matchAddGroupPermissionSetting(x.id, ANY), function () {});
});

bthread("Guard: Unique BotConfiguration", function () {
  const x = waitForAnyBotConfigurationAdded();
  block(matchAddBotConfiguration(x.id, ANY), function () {});
});

bthread("Guard: Unique FolderId", function () {
  const x = waitForAnyFolderIdAdded();
  block(matchAddFolderId(x.id, ANY), function () {});
});

bthread("Guard: Unique ScheduledMessageBase", function () {
  const x = waitForAnyScheduledMessageBaseAdded();
  block(matchAddScheduledMessageBase(x.id, ANY), function () {});
});

bthread("Guard: Unique EventIdSchema", function () {
  const x = waitForAnyEventIdSchemaAdded();
  block(matchAddEventIdSchema(x.id, ANY), function () {});
});

bthread("Guard: Unique TopicsPolicy", function () {
  const x = waitForAnyTopicsPolicyAdded();
  block(matchAddTopicsPolicy(x.id, ANY), function () {});
});

bthread("Guard: Unique RealmDomain", function () {
  const x = waitForAnyRealmDomainAdded();
  block(matchAddRealmDomain(x.id, ANY), function () {});
});

// ===== NEGATIVE/EDGE STATUS GUARDS =====
