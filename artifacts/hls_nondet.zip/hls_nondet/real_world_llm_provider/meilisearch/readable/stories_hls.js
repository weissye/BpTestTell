// ====================================================================
// Auto-generated garage-style High-Level Stories (HLS)
// SUT: meilisearch
// ====================================================================

var ANY = (typeof H !== 'undefined' && H.ANY) ? H.ANY : (typeof ANY !== 'undefined' ? ANY : '*');

// ===== ACTIVE LIFECYCLES =====


bthread("SearchableAttributes lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSearchableAttributes(x.id);
  updateSearchableAttributes(x.id);
  updateSearchableAttributes(x.id);
  verifySearchableAttributesExists(x.id);
  verifySearchableAttributesUpdated(x.id);
});

bthread("Faceting lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFaceting(x.id);
  updateFaceting(x.id);
  updateFaceting(x.id);
  verifyFacetingExists(x.id);
  verifyFacetingUpdated(x.id);
});

bthread("Stats lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addStats(x.id);
  updateStats(x.id);
  updateStats(x.id);
  verifyStatsExists(x.id);
  verifyStatsUpdated(x.id);
});

bthread("TypoTolerance lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTypoTolerance(x.id);
  updateTypoTolerance(x.id);
  updateTypoTolerance(x.id);
  verifyTypoToleranceExists(x.id);
  verifyTypoToleranceUpdated(x.id);
});

bthread("Timestamp lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTimestamp(x.id);
  updateTimestamp(x.id);
  updateTimestamp(x.id);
  verifyTimestampExists(x.id);
  verifyTimestampUpdated(x.id);
});

bthread("Task lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTask(x.id);
  updateTask(x.id);
  updateTask(x.id);
  verifyTaskExists(x.id);
  verifyTaskUpdated(x.id);
});

bthread("MatchesPosition lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMatchesPosition(x.id);
  updateMatchesPosition(x.id);
  updateMatchesPosition(x.id);
  verifyMatchesPositionExists(x.id);
  verifyMatchesPositionUpdated(x.id);
});

bthread("SearchQuery lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSearchQuery(x.id);
  updateSearchQuery(x.id);
  updateSearchQuery(x.id);
  verifySearchQueryExists(x.id);
  verifySearchQueryUpdated(x.id);
});

bthread("SummarizedTask lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSummarizedTask(x.id);
  updateSummarizedTask(x.id);
  updateSummarizedTask(x.id);
  verifySummarizedTaskExists(x.id);
  verifySummarizedTaskUpdated(x.id);
});

bthread("Limit lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLimit(x.id);
  updateLimit(x.id);
  updateLimit(x.id);
  verifyLimitExists(x.id);
  verifyLimitUpdated(x.id);
});

bthread("From lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFrom(x.id);
  updateFrom(x.id);
  updateFrom(x.id);
  verifyFromExists(x.id);
  verifyFromUpdated(x.id);
});

bthread("SwapIndexes lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSwapIndexes(x.id);
  updateSwapIndexes(x.id);
  updateSwapIndexes(x.id);
  verifySwapIndexesExists(x.id);
  verifySwapIndexesUpdated(x.id);
});

bthread("Offset lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOffset(x.id);
  updateOffset(x.id);
  updateOffset(x.id);
  verifyOffsetExists(x.id);
  verifyOffsetUpdated(x.id);
});

bthread("NonSeparatorTokens lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNonSeparatorTokens(x.id);
  updateNonSeparatorTokens(x.id);
  updateNonSeparatorTokens(x.id);
  verifyNonSeparatorTokensExists(x.id);
  verifyNonSeparatorTokensUpdated(x.id);
});

bthread("DisplayedAttributes lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDisplayedAttributes(x.id);
  updateDisplayedAttributes(x.id);
  updateDisplayedAttributes(x.id);
  verifyDisplayedAttributesExists(x.id);
  verifyDisplayedAttributesUpdated(x.id);
});

bthread("Key lifecycle", function () {
  const x = pick([{id: "K001"}, {id: "K002"}]);
  addKey(x.id);
  updateKey(x.id);
  updateKey(x.id);
  verifyKeyExists(x.id);
  verifyKeyUpdated(x.id);
});

bthread("HitsPerPage lifecycle", function () {
  const x = pick([{id: "H001"}, {id: "H002"}]);
  addHitsPerPage(x.id);
  updateHitsPerPage(x.id);
  updateHitsPerPage(x.id);
  verifyHitsPerPageExists(x.id);
  verifyHitsPerPageUpdated(x.id);
});

bthread("StopWords lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addStopWords(x.id);
  updateStopWords(x.id);
  updateStopWords(x.id);
  verifyStopWordsExists(x.id);
  verifyStopWordsUpdated(x.id);
});

bthread("Dictionary lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDictionary(x.id);
  updateDictionary(x.id);
  updateDictionary(x.id);
  verifyDictionaryExists(x.id);
  verifyDictionaryUpdated(x.id);
});

bthread("Settings lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSettings(x.id);
  updateSettings(x.id);
  updateSettings(x.id);
  verifySettingsExists(x.id);
  verifySettingsUpdated(x.id);
});

bthread("Score lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addScore(x.id);
  updateScore(x.id);
  updateScore(x.id);
  verifyScoreExists(x.id);
  verifyScoreUpdated(x.id);
});

bthread("RankingScoreDetails lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRankingScoreDetails(x.id);
  updateRankingScoreDetails(x.id);
  updateRankingScoreDetails(x.id);
  verifyRankingScoreDetailsExists(x.id);
  verifyRankingScoreDetailsUpdated(x.id);
});

bthread("SeparatorTokens lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSeparatorTokens(x.id);
  updateSeparatorTokens(x.id);
  updateSeparatorTokens(x.id);
  verifySeparatorTokensExists(x.id);
  verifySeparatorTokensUpdated(x.id);
});

bthread("Page lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPage(x.id);
  updatePage(x.id);
  updatePage(x.id);
  verifyPageExists(x.id);
  verifyPageUpdated(x.id);
});

bthread("SwapOperation lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSwapOperation(x.id);
  updateSwapOperation(x.id);
  updateSwapOperation(x.id);
  verifySwapOperationExists(x.id);
  verifySwapOperationUpdated(x.id);
});

bthread("DocumentId lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDocumentId(x.id);
  updateDocumentId(x.id);
  updateDocumentId(x.id);
  verifyDocumentIdExists(x.id);
  verifyDocumentIdUpdated(x.id);
});

bthread("RankingRules lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRankingRules(x.id);
  updateRankingRules(x.id);
  updateRankingRules(x.id);
  verifyRankingRulesExists(x.id);
  verifyRankingRulesUpdated(x.id);
});

bthread("Filter lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFilter(x.id);
  updateFilter(x.id);
  updateFilter(x.id);
  verifyFilterExists(x.id);
  verifyFilterUpdated(x.id);
});

bthread("FacetHit lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFacetHit(x.id);
  updateFacetHit(x.id);
  updateFacetHit(x.id);
  verifyFacetHitExists(x.id);
  verifyFacetHitUpdated(x.id);
});

bthread("Pagination lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPagination(x.id);
  updatePagination(x.id);
  updatePagination(x.id);
  verifyPaginationExists(x.id);
  verifyPaginationUpdated(x.id);
});

bthread("Total lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTotal(x.id);
  updateTotal(x.id);
  updateTotal(x.id);
  verifyTotalExists(x.id);
  verifyTotalUpdated(x.id);
});

bthread("Hit lifecycle", function () {
  const x = pick([{id: "H001"}, {id: "H002"}]);
  addHit(x.id);
  updateHit(x.id);
  updateHit(x.id);
  verifyHitExists(x.id);
  verifyHitUpdated(x.id);
});

bthread("Error lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addError(x.id);
  updateError(x.id);
  updateError(x.id);
  verifyErrorExists(x.id);
  verifyErrorUpdated(x.id);
});

bthread("FilterableAttributes lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFilterableAttributes(x.id);
  updateFilterableAttributes(x.id);
  updateFilterableAttributes(x.id);
  verifyFilterableAttributesExists(x.id);
  verifyFilterableAttributesUpdated(x.id);
});

bthread("Index lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIndex(x.id);
  updateIndex(x.id);
  updateIndex(x.id);
  verifyIndexExists(x.id);
  verifyIndexUpdated(x.id);
});

bthread("FacetSearchResponse lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFacetSearchResponse(x.id);
  updateFacetSearchResponse(x.id);
  updateFacetSearchResponse(x.id);
  verifyFacetSearchResponseExists(x.id);
  verifyFacetSearchResponseUpdated(x.id);
});

bthread("SortableAttributes lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSortableAttributes(x.id);
  updateSortableAttributes(x.id);
  updateSortableAttributes(x.id);
  verifySortableAttributesExists(x.id);
  verifySortableAttributesUpdated(x.id);
});

bthread("CustomRankingRuleDetails lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomRankingRuleDetails(x.id);
  updateCustomRankingRuleDetails(x.id);
  updateCustomRankingRuleDetails(x.id);
  verifyCustomRankingRuleDetailsExists(x.id);
  verifyCustomRankingRuleDetailsUpdated(x.id);
});

bthread("Sort lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSort(x.id);
  updateSort(x.id);
  updateSort(x.id);
  verifySortExists(x.id);
  verifySortUpdated(x.id);
});

bthread("Order lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOrder(x.id);
  updateOrder(x.id);
  updateOrder(x.id);
  verifyOrderExists(x.id);
  verifyOrderUpdated(x.id);
});

bthread("DistinctAttribute lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDistinctAttribute(x.id);
  updateDistinctAttribute(x.id);
  updateDistinctAttribute(x.id);
  verifyDistinctAttributeExists(x.id);
  verifyDistinctAttributeUpdated(x.id);
});

bthread("SearchResponse lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSearchResponse(x.id);
  updateSearchResponse(x.id);
  updateSearchResponse(x.id);
  verifySearchResponseExists(x.id);
  verifySearchResponseUpdated(x.id);
});

bthread("Next lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNext(x.id);
  updateNext(x.id);
  updateNext(x.id);
  verifyNextExists(x.id);
  verifyNextUpdated(x.id);
});

bthread("Document lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDocument(x.id);
  updateDocument(x.id);
  updateDocument(x.id);
  verifyDocumentExists(x.id);
  verifyDocumentUpdated(x.id);
});

bthread("FacetSearchQuery lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFacetSearchQuery(x.id);
  updateFacetSearchQuery(x.id);
  updateFacetSearchQuery(x.id);
  verifyFacetSearchQueryExists(x.id);
  verifyFacetSearchQueryUpdated(x.id);
});

bthread("TotalHits lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTotalHits(x.id);
  updateTotalHits(x.id);
  updateTotalHits(x.id);
  verifyTotalHitsExists(x.id);
  verifyTotalHitsUpdated(x.id);
});

bthread("TotalPages lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTotalPages(x.id);
  updateTotalPages(x.id);
  updateTotalPages(x.id);
  verifyTotalPagesExists(x.id);
  verifyTotalPagesUpdated(x.id);
});

bthread("Synonyms lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSynonyms(x.id);
  updateSynonyms(x.id);
  updateSynonyms(x.id);
  verifySynonymsExists(x.id);
  verifySynonymsUpdated(x.id);
});

// ===== PASSIVE ASSERTIONS =====

bthread("SearchableAttributes create verification", function () {
  const e = waitForAnySearchableAttributesAdded();
  block(matchDeleteSearchableAttributes(e.id, ANY), function () {
    verifySearchableAttributesExists(e.id);
  });
});

bthread("SearchableAttributes update verification", function () {
  const e = waitForAnySearchableAttributesUpdated();
  block(matchDeleteSearchableAttributes(e.id, ANY), function () {
    verifySearchableAttributesUpdated(e.id);
  });
});

bthread("SearchableAttributes delete verification", function () {
  const e = waitForAnySearchableAttributesDeleted();
  block(matchAddSearchableAttributes(e.id, ANY), function () {
    verifySearchableAttributesDoesNotExist(e.id);
  });
});

bthread("Faceting create verification", function () {
  const e = waitForAnyFacetingAdded();
  block(matchDeleteFaceting(e.id, ANY), function () {
    verifyFacetingExists(e.id);
  });
});

bthread("Faceting update verification", function () {
  const e = waitForAnyFacetingUpdated();
  block(matchDeleteFaceting(e.id, ANY), function () {
    verifyFacetingUpdated(e.id);
  });
});

bthread("Faceting delete verification", function () {
  const e = waitForAnyFacetingDeleted();
  block(matchAddFaceting(e.id, ANY), function () {
    verifyFacetingDoesNotExist(e.id);
  });
});

bthread("Stats create verification", function () {
  const e = waitForAnyStatsAdded();
  block(matchDeleteStats(e.id, ANY), function () {
    verifyStatsExists(e.id);
  });
});

bthread("Stats update verification", function () {
  const e = waitForAnyStatsUpdated();
  block(matchDeleteStats(e.id, ANY), function () {
    verifyStatsUpdated(e.id);
  });
});

bthread("Stats delete verification", function () {
  const e = waitForAnyStatsDeleted();
  block(matchAddStats(e.id, ANY), function () {
    verifyStatsDoesNotExist(e.id);
  });
});

bthread("TypoTolerance create verification", function () {
  const e = waitForAnyTypoToleranceAdded();
  block(matchDeleteTypoTolerance(e.id, ANY), function () {
    verifyTypoToleranceExists(e.id);
  });
});

bthread("TypoTolerance update verification", function () {
  const e = waitForAnyTypoToleranceUpdated();
  block(matchDeleteTypoTolerance(e.id, ANY), function () {
    verifyTypoToleranceUpdated(e.id);
  });
});

bthread("TypoTolerance delete verification", function () {
  const e = waitForAnyTypoToleranceDeleted();
  block(matchAddTypoTolerance(e.id, ANY), function () {
    verifyTypoToleranceDoesNotExist(e.id);
  });
});

bthread("Timestamp create verification", function () {
  const e = waitForAnyTimestampAdded();
  block(matchDeleteTimestamp(e.id, ANY), function () {
    verifyTimestampExists(e.id);
  });
});

bthread("Timestamp update verification", function () {
  const e = waitForAnyTimestampUpdated();
  block(matchDeleteTimestamp(e.id, ANY), function () {
    verifyTimestampUpdated(e.id);
  });
});

bthread("Timestamp delete verification", function () {
  const e = waitForAnyTimestampDeleted();
  block(matchAddTimestamp(e.id, ANY), function () {
    verifyTimestampDoesNotExist(e.id);
  });
});

bthread("Task create verification", function () {
  const e = waitForAnyTaskAdded();
  block(matchDeleteTask(e.id, ANY), function () {
    verifyTaskExists(e.id);
  });
});

bthread("Task update verification", function () {
  const e = waitForAnyTaskUpdated();
  block(matchDeleteTask(e.id, ANY), function () {
    verifyTaskUpdated(e.id);
  });
});

bthread("Task delete verification", function () {
  const e = waitForAnyTaskDeleted();
  block(matchAddTask(e.id, ANY), function () {
    verifyTaskDoesNotExist(e.id);
  });
});

bthread("MatchesPosition create verification", function () {
  const e = waitForAnyMatchesPositionAdded();
  block(matchDeleteMatchesPosition(e.id, ANY), function () {
    verifyMatchesPositionExists(e.id);
  });
});

bthread("MatchesPosition update verification", function () {
  const e = waitForAnyMatchesPositionUpdated();
  block(matchDeleteMatchesPosition(e.id, ANY), function () {
    verifyMatchesPositionUpdated(e.id);
  });
});

bthread("MatchesPosition delete verification", function () {
  const e = waitForAnyMatchesPositionDeleted();
  block(matchAddMatchesPosition(e.id, ANY), function () {
    verifyMatchesPositionDoesNotExist(e.id);
  });
});

bthread("SearchQuery create verification", function () {
  const e = waitForAnySearchQueryAdded();
  block(matchDeleteSearchQuery(e.id, ANY), function () {
    verifySearchQueryExists(e.id);
  });
});

bthread("SearchQuery update verification", function () {
  const e = waitForAnySearchQueryUpdated();
  block(matchDeleteSearchQuery(e.id, ANY), function () {
    verifySearchQueryUpdated(e.id);
  });
});

bthread("SearchQuery delete verification", function () {
  const e = waitForAnySearchQueryDeleted();
  block(matchAddSearchQuery(e.id, ANY), function () {
    verifySearchQueryDoesNotExist(e.id);
  });
});

bthread("SummarizedTask create verification", function () {
  const e = waitForAnySummarizedTaskAdded();
  block(matchDeleteSummarizedTask(e.id, ANY), function () {
    verifySummarizedTaskExists(e.id);
  });
});

bthread("SummarizedTask update verification", function () {
  const e = waitForAnySummarizedTaskUpdated();
  block(matchDeleteSummarizedTask(e.id, ANY), function () {
    verifySummarizedTaskUpdated(e.id);
  });
});

bthread("SummarizedTask delete verification", function () {
  const e = waitForAnySummarizedTaskDeleted();
  block(matchAddSummarizedTask(e.id, ANY), function () {
    verifySummarizedTaskDoesNotExist(e.id);
  });
});

bthread("Limit create verification", function () {
  const e = waitForAnyLimitAdded();
  block(matchDeleteLimit(e.id, ANY), function () {
    verifyLimitExists(e.id);
  });
});

bthread("Limit update verification", function () {
  const e = waitForAnyLimitUpdated();
  block(matchDeleteLimit(e.id, ANY), function () {
    verifyLimitUpdated(e.id);
  });
});

bthread("Limit delete verification", function () {
  const e = waitForAnyLimitDeleted();
  block(matchAddLimit(e.id, ANY), function () {
    verifyLimitDoesNotExist(e.id);
  });
});

bthread("From create verification", function () {
  const e = waitForAnyFromAdded();
  block(matchDeleteFrom(e.id, ANY), function () {
    verifyFromExists(e.id);
  });
});

bthread("From update verification", function () {
  const e = waitForAnyFromUpdated();
  block(matchDeleteFrom(e.id, ANY), function () {
    verifyFromUpdated(e.id);
  });
});

bthread("From delete verification", function () {
  const e = waitForAnyFromDeleted();
  block(matchAddFrom(e.id, ANY), function () {
    verifyFromDoesNotExist(e.id);
  });
});

bthread("SwapIndexes create verification", function () {
  const e = waitForAnySwapIndexesAdded();
  block(matchDeleteSwapIndexes(e.id, ANY), function () {
    verifySwapIndexesExists(e.id);
  });
});

bthread("SwapIndexes update verification", function () {
  const e = waitForAnySwapIndexesUpdated();
  block(matchDeleteSwapIndexes(e.id, ANY), function () {
    verifySwapIndexesUpdated(e.id);
  });
});

bthread("SwapIndexes delete verification", function () {
  const e = waitForAnySwapIndexesDeleted();
  block(matchAddSwapIndexes(e.id, ANY), function () {
    verifySwapIndexesDoesNotExist(e.id);
  });
});

bthread("Offset create verification", function () {
  const e = waitForAnyOffsetAdded();
  block(matchDeleteOffset(e.id, ANY), function () {
    verifyOffsetExists(e.id);
  });
});

bthread("Offset update verification", function () {
  const e = waitForAnyOffsetUpdated();
  block(matchDeleteOffset(e.id, ANY), function () {
    verifyOffsetUpdated(e.id);
  });
});

bthread("Offset delete verification", function () {
  const e = waitForAnyOffsetDeleted();
  block(matchAddOffset(e.id, ANY), function () {
    verifyOffsetDoesNotExist(e.id);
  });
});

bthread("NonSeparatorTokens create verification", function () {
  const e = waitForAnyNonSeparatorTokensAdded();
  block(matchDeleteNonSeparatorTokens(e.id, ANY), function () {
    verifyNonSeparatorTokensExists(e.id);
  });
});

bthread("NonSeparatorTokens update verification", function () {
  const e = waitForAnyNonSeparatorTokensUpdated();
  block(matchDeleteNonSeparatorTokens(e.id, ANY), function () {
    verifyNonSeparatorTokensUpdated(e.id);
  });
});

bthread("NonSeparatorTokens delete verification", function () {
  const e = waitForAnyNonSeparatorTokensDeleted();
  block(matchAddNonSeparatorTokens(e.id, ANY), function () {
    verifyNonSeparatorTokensDoesNotExist(e.id);
  });
});

bthread("DisplayedAttributes create verification", function () {
  const e = waitForAnyDisplayedAttributesAdded();
  block(matchDeleteDisplayedAttributes(e.id, ANY), function () {
    verifyDisplayedAttributesExists(e.id);
  });
});

bthread("DisplayedAttributes update verification", function () {
  const e = waitForAnyDisplayedAttributesUpdated();
  block(matchDeleteDisplayedAttributes(e.id, ANY), function () {
    verifyDisplayedAttributesUpdated(e.id);
  });
});

bthread("DisplayedAttributes delete verification", function () {
  const e = waitForAnyDisplayedAttributesDeleted();
  block(matchAddDisplayedAttributes(e.id, ANY), function () {
    verifyDisplayedAttributesDoesNotExist(e.id);
  });
});

bthread("Key create verification", function () {
  const e = waitForAnyKeyAdded();
  block(matchDeleteKey(e.id, ANY), function () {
    verifyKeyExists(e.id);
  });
});

bthread("Key update verification", function () {
  const e = waitForAnyKeyUpdated();
  block(matchDeleteKey(e.id, ANY), function () {
    verifyKeyUpdated(e.id);
  });
});

bthread("Key delete verification", function () {
  const e = waitForAnyKeyDeleted();
  block(matchAddKey(e.id, ANY), function () {
    verifyKeyDoesNotExist(e.id);
  });
});

bthread("HitsPerPage create verification", function () {
  const e = waitForAnyHitsPerPageAdded();
  block(matchDeleteHitsPerPage(e.id, ANY), function () {
    verifyHitsPerPageExists(e.id);
  });
});

bthread("HitsPerPage update verification", function () {
  const e = waitForAnyHitsPerPageUpdated();
  block(matchDeleteHitsPerPage(e.id, ANY), function () {
    verifyHitsPerPageUpdated(e.id);
  });
});

bthread("HitsPerPage delete verification", function () {
  const e = waitForAnyHitsPerPageDeleted();
  block(matchAddHitsPerPage(e.id, ANY), function () {
    verifyHitsPerPageDoesNotExist(e.id);
  });
});

bthread("StopWords create verification", function () {
  const e = waitForAnyStopWordsAdded();
  block(matchDeleteStopWords(e.id, ANY), function () {
    verifyStopWordsExists(e.id);
  });
});

bthread("StopWords update verification", function () {
  const e = waitForAnyStopWordsUpdated();
  block(matchDeleteStopWords(e.id, ANY), function () {
    verifyStopWordsUpdated(e.id);
  });
});

bthread("StopWords delete verification", function () {
  const e = waitForAnyStopWordsDeleted();
  block(matchAddStopWords(e.id, ANY), function () {
    verifyStopWordsDoesNotExist(e.id);
  });
});

bthread("Dictionary create verification", function () {
  const e = waitForAnyDictionaryAdded();
  block(matchDeleteDictionary(e.id, ANY), function () {
    verifyDictionaryExists(e.id);
  });
});

bthread("Dictionary update verification", function () {
  const e = waitForAnyDictionaryUpdated();
  block(matchDeleteDictionary(e.id, ANY), function () {
    verifyDictionaryUpdated(e.id);
  });
});

bthread("Dictionary delete verification", function () {
  const e = waitForAnyDictionaryDeleted();
  block(matchAddDictionary(e.id, ANY), function () {
    verifyDictionaryDoesNotExist(e.id);
  });
});

bthread("Settings create verification", function () {
  const e = waitForAnySettingsAdded();
  block(matchDeleteSettings(e.id, ANY), function () {
    verifySettingsExists(e.id);
  });
});

bthread("Settings update verification", function () {
  const e = waitForAnySettingsUpdated();
  block(matchDeleteSettings(e.id, ANY), function () {
    verifySettingsUpdated(e.id);
  });
});

bthread("Settings delete verification", function () {
  const e = waitForAnySettingsDeleted();
  block(matchAddSettings(e.id, ANY), function () {
    verifySettingsDoesNotExist(e.id);
  });
});

bthread("Score create verification", function () {
  const e = waitForAnyScoreAdded();
  block(matchDeleteScore(e.id, ANY), function () {
    verifyScoreExists(e.id);
  });
});

bthread("Score update verification", function () {
  const e = waitForAnyScoreUpdated();
  block(matchDeleteScore(e.id, ANY), function () {
    verifyScoreUpdated(e.id);
  });
});

bthread("Score delete verification", function () {
  const e = waitForAnyScoreDeleted();
  block(matchAddScore(e.id, ANY), function () {
    verifyScoreDoesNotExist(e.id);
  });
});

bthread("RankingScoreDetails create verification", function () {
  const e = waitForAnyRankingScoreDetailsAdded();
  block(matchDeleteRankingScoreDetails(e.id, ANY), function () {
    verifyRankingScoreDetailsExists(e.id);
  });
});

bthread("RankingScoreDetails update verification", function () {
  const e = waitForAnyRankingScoreDetailsUpdated();
  block(matchDeleteRankingScoreDetails(e.id, ANY), function () {
    verifyRankingScoreDetailsUpdated(e.id);
  });
});

bthread("RankingScoreDetails delete verification", function () {
  const e = waitForAnyRankingScoreDetailsDeleted();
  block(matchAddRankingScoreDetails(e.id, ANY), function () {
    verifyRankingScoreDetailsDoesNotExist(e.id);
  });
});

bthread("SeparatorTokens create verification", function () {
  const e = waitForAnySeparatorTokensAdded();
  block(matchDeleteSeparatorTokens(e.id, ANY), function () {
    verifySeparatorTokensExists(e.id);
  });
});

bthread("SeparatorTokens update verification", function () {
  const e = waitForAnySeparatorTokensUpdated();
  block(matchDeleteSeparatorTokens(e.id, ANY), function () {
    verifySeparatorTokensUpdated(e.id);
  });
});

bthread("SeparatorTokens delete verification", function () {
  const e = waitForAnySeparatorTokensDeleted();
  block(matchAddSeparatorTokens(e.id, ANY), function () {
    verifySeparatorTokensDoesNotExist(e.id);
  });
});

bthread("Page create verification", function () {
  const e = waitForAnyPageAdded();
  block(matchDeletePage(e.id, ANY), function () {
    verifyPageExists(e.id);
  });
});

bthread("Page update verification", function () {
  const e = waitForAnyPageUpdated();
  block(matchDeletePage(e.id, ANY), function () {
    verifyPageUpdated(e.id);
  });
});

bthread("Page delete verification", function () {
  const e = waitForAnyPageDeleted();
  block(matchAddPage(e.id, ANY), function () {
    verifyPageDoesNotExist(e.id);
  });
});

bthread("SwapOperation create verification", function () {
  const e = waitForAnySwapOperationAdded();
  block(matchDeleteSwapOperation(e.id, ANY), function () {
    verifySwapOperationExists(e.id);
  });
});

bthread("SwapOperation update verification", function () {
  const e = waitForAnySwapOperationUpdated();
  block(matchDeleteSwapOperation(e.id, ANY), function () {
    verifySwapOperationUpdated(e.id);
  });
});

bthread("SwapOperation delete verification", function () {
  const e = waitForAnySwapOperationDeleted();
  block(matchAddSwapOperation(e.id, ANY), function () {
    verifySwapOperationDoesNotExist(e.id);
  });
});

bthread("DocumentId create verification", function () {
  const e = waitForAnyDocumentIdAdded();
  block(matchDeleteDocumentId(e.id, ANY), function () {
    verifyDocumentIdExists(e.id);
  });
});

bthread("DocumentId update verification", function () {
  const e = waitForAnyDocumentIdUpdated();
  block(matchDeleteDocumentId(e.id, ANY), function () {
    verifyDocumentIdUpdated(e.id);
  });
});

bthread("DocumentId delete verification", function () {
  const e = waitForAnyDocumentIdDeleted();
  block(matchAddDocumentId(e.id, ANY), function () {
    verifyDocumentIdDoesNotExist(e.id);
  });
});

bthread("RankingRules create verification", function () {
  const e = waitForAnyRankingRulesAdded();
  block(matchDeleteRankingRules(e.id, ANY), function () {
    verifyRankingRulesExists(e.id);
  });
});

bthread("RankingRules update verification", function () {
  const e = waitForAnyRankingRulesUpdated();
  block(matchDeleteRankingRules(e.id, ANY), function () {
    verifyRankingRulesUpdated(e.id);
  });
});

bthread("RankingRules delete verification", function () {
  const e = waitForAnyRankingRulesDeleted();
  block(matchAddRankingRules(e.id, ANY), function () {
    verifyRankingRulesDoesNotExist(e.id);
  });
});

bthread("Filter create verification", function () {
  const e = waitForAnyFilterAdded();
  block(matchDeleteFilter(e.id, ANY), function () {
    verifyFilterExists(e.id);
  });
});

bthread("Filter update verification", function () {
  const e = waitForAnyFilterUpdated();
  block(matchDeleteFilter(e.id, ANY), function () {
    verifyFilterUpdated(e.id);
  });
});

bthread("Filter delete verification", function () {
  const e = waitForAnyFilterDeleted();
  block(matchAddFilter(e.id, ANY), function () {
    verifyFilterDoesNotExist(e.id);
  });
});

bthread("FacetHit create verification", function () {
  const e = waitForAnyFacetHitAdded();
  block(matchDeleteFacetHit(e.id, ANY), function () {
    verifyFacetHitExists(e.id);
  });
});

bthread("FacetHit update verification", function () {
  const e = waitForAnyFacetHitUpdated();
  block(matchDeleteFacetHit(e.id, ANY), function () {
    verifyFacetHitUpdated(e.id);
  });
});

bthread("FacetHit delete verification", function () {
  const e = waitForAnyFacetHitDeleted();
  block(matchAddFacetHit(e.id, ANY), function () {
    verifyFacetHitDoesNotExist(e.id);
  });
});

bthread("Pagination create verification", function () {
  const e = waitForAnyPaginationAdded();
  block(matchDeletePagination(e.id, ANY), function () {
    verifyPaginationExists(e.id);
  });
});

bthread("Pagination update verification", function () {
  const e = waitForAnyPaginationUpdated();
  block(matchDeletePagination(e.id, ANY), function () {
    verifyPaginationUpdated(e.id);
  });
});

bthread("Pagination delete verification", function () {
  const e = waitForAnyPaginationDeleted();
  block(matchAddPagination(e.id, ANY), function () {
    verifyPaginationDoesNotExist(e.id);
  });
});

bthread("Total create verification", function () {
  const e = waitForAnyTotalAdded();
  block(matchDeleteTotal(e.id, ANY), function () {
    verifyTotalExists(e.id);
  });
});

bthread("Total update verification", function () {
  const e = waitForAnyTotalUpdated();
  block(matchDeleteTotal(e.id, ANY), function () {
    verifyTotalUpdated(e.id);
  });
});

bthread("Total delete verification", function () {
  const e = waitForAnyTotalDeleted();
  block(matchAddTotal(e.id, ANY), function () {
    verifyTotalDoesNotExist(e.id);
  });
});

bthread("Hit create verification", function () {
  const e = waitForAnyHitAdded();
  block(matchDeleteHit(e.id, ANY), function () {
    verifyHitExists(e.id);
  });
});

bthread("Hit update verification", function () {
  const e = waitForAnyHitUpdated();
  block(matchDeleteHit(e.id, ANY), function () {
    verifyHitUpdated(e.id);
  });
});

bthread("Hit delete verification", function () {
  const e = waitForAnyHitDeleted();
  block(matchAddHit(e.id, ANY), function () {
    verifyHitDoesNotExist(e.id);
  });
});

bthread("Error create verification", function () {
  const e = waitForAnyErrorAdded();
  block(matchDeleteError(e.id, ANY), function () {
    verifyErrorExists(e.id);
  });
});

bthread("Error update verification", function () {
  const e = waitForAnyErrorUpdated();
  block(matchDeleteError(e.id, ANY), function () {
    verifyErrorUpdated(e.id);
  });
});

bthread("Error delete verification", function () {
  const e = waitForAnyErrorDeleted();
  block(matchAddError(e.id, ANY), function () {
    verifyErrorDoesNotExist(e.id);
  });
});

bthread("FilterableAttributes create verification", function () {
  const e = waitForAnyFilterableAttributesAdded();
  block(matchDeleteFilterableAttributes(e.id, ANY), function () {
    verifyFilterableAttributesExists(e.id);
  });
});

bthread("FilterableAttributes update verification", function () {
  const e = waitForAnyFilterableAttributesUpdated();
  block(matchDeleteFilterableAttributes(e.id, ANY), function () {
    verifyFilterableAttributesUpdated(e.id);
  });
});

bthread("FilterableAttributes delete verification", function () {
  const e = waitForAnyFilterableAttributesDeleted();
  block(matchAddFilterableAttributes(e.id, ANY), function () {
    verifyFilterableAttributesDoesNotExist(e.id);
  });
});

bthread("Index create verification", function () {
  const e = waitForAnyIndexAdded();
  block(matchDeleteIndex(e.id, ANY), function () {
    verifyIndexExists(e.id);
  });
});

bthread("Index update verification", function () {
  const e = waitForAnyIndexUpdated();
  block(matchDeleteIndex(e.id, ANY), function () {
    verifyIndexUpdated(e.id);
  });
});

bthread("Index delete verification", function () {
  const e = waitForAnyIndexDeleted();
  block(matchAddIndex(e.id, ANY), function () {
    verifyIndexDoesNotExist(e.id);
  });
});

bthread("FacetSearchResponse create verification", function () {
  const e = waitForAnyFacetSearchResponseAdded();
  block(matchDeleteFacetSearchResponse(e.id, ANY), function () {
    verifyFacetSearchResponseExists(e.id);
  });
});

bthread("FacetSearchResponse update verification", function () {
  const e = waitForAnyFacetSearchResponseUpdated();
  block(matchDeleteFacetSearchResponse(e.id, ANY), function () {
    verifyFacetSearchResponseUpdated(e.id);
  });
});

bthread("FacetSearchResponse delete verification", function () {
  const e = waitForAnyFacetSearchResponseDeleted();
  block(matchAddFacetSearchResponse(e.id, ANY), function () {
    verifyFacetSearchResponseDoesNotExist(e.id);
  });
});

bthread("SortableAttributes create verification", function () {
  const e = waitForAnySortableAttributesAdded();
  block(matchDeleteSortableAttributes(e.id, ANY), function () {
    verifySortableAttributesExists(e.id);
  });
});

bthread("SortableAttributes update verification", function () {
  const e = waitForAnySortableAttributesUpdated();
  block(matchDeleteSortableAttributes(e.id, ANY), function () {
    verifySortableAttributesUpdated(e.id);
  });
});

bthread("SortableAttributes delete verification", function () {
  const e = waitForAnySortableAttributesDeleted();
  block(matchAddSortableAttributes(e.id, ANY), function () {
    verifySortableAttributesDoesNotExist(e.id);
  });
});

bthread("CustomRankingRuleDetails create verification", function () {
  const e = waitForAnyCustomRankingRuleDetailsAdded();
  block(matchDeleteCustomRankingRuleDetails(e.id, ANY), function () {
    verifyCustomRankingRuleDetailsExists(e.id);
  });
});

bthread("CustomRankingRuleDetails update verification", function () {
  const e = waitForAnyCustomRankingRuleDetailsUpdated();
  block(matchDeleteCustomRankingRuleDetails(e.id, ANY), function () {
    verifyCustomRankingRuleDetailsUpdated(e.id);
  });
});

bthread("CustomRankingRuleDetails delete verification", function () {
  const e = waitForAnyCustomRankingRuleDetailsDeleted();
  block(matchAddCustomRankingRuleDetails(e.id, ANY), function () {
    verifyCustomRankingRuleDetailsDoesNotExist(e.id);
  });
});

bthread("Sort create verification", function () {
  const e = waitForAnySortAdded();
  block(matchDeleteSort(e.id, ANY), function () {
    verifySortExists(e.id);
  });
});

bthread("Sort update verification", function () {
  const e = waitForAnySortUpdated();
  block(matchDeleteSort(e.id, ANY), function () {
    verifySortUpdated(e.id);
  });
});

bthread("Sort delete verification", function () {
  const e = waitForAnySortDeleted();
  block(matchAddSort(e.id, ANY), function () {
    verifySortDoesNotExist(e.id);
  });
});

bthread("Order create verification", function () {
  const e = waitForAnyOrderAdded();
  block(matchDeleteOrder(e.id, ANY), function () {
    verifyOrderExists(e.id);
  });
});

bthread("Order update verification", function () {
  const e = waitForAnyOrderUpdated();
  block(matchDeleteOrder(e.id, ANY), function () {
    verifyOrderUpdated(e.id);
  });
});

bthread("Order delete verification", function () {
  const e = waitForAnyOrderDeleted();
  block(matchAddOrder(e.id, ANY), function () {
    verifyOrderDoesNotExist(e.id);
  });
});

bthread("DistinctAttribute create verification", function () {
  const e = waitForAnyDistinctAttributeAdded();
  block(matchDeleteDistinctAttribute(e.id, ANY), function () {
    verifyDistinctAttributeExists(e.id);
  });
});

bthread("DistinctAttribute update verification", function () {
  const e = waitForAnyDistinctAttributeUpdated();
  block(matchDeleteDistinctAttribute(e.id, ANY), function () {
    verifyDistinctAttributeUpdated(e.id);
  });
});

bthread("DistinctAttribute delete verification", function () {
  const e = waitForAnyDistinctAttributeDeleted();
  block(matchAddDistinctAttribute(e.id, ANY), function () {
    verifyDistinctAttributeDoesNotExist(e.id);
  });
});

bthread("SearchResponse create verification", function () {
  const e = waitForAnySearchResponseAdded();
  block(matchDeleteSearchResponse(e.id, ANY), function () {
    verifySearchResponseExists(e.id);
  });
});

bthread("SearchResponse update verification", function () {
  const e = waitForAnySearchResponseUpdated();
  block(matchDeleteSearchResponse(e.id, ANY), function () {
    verifySearchResponseUpdated(e.id);
  });
});

bthread("SearchResponse delete verification", function () {
  const e = waitForAnySearchResponseDeleted();
  block(matchAddSearchResponse(e.id, ANY), function () {
    verifySearchResponseDoesNotExist(e.id);
  });
});

bthread("Next create verification", function () {
  const e = waitForAnyNextAdded();
  block(matchDeleteNext(e.id, ANY), function () {
    verifyNextExists(e.id);
  });
});

bthread("Next update verification", function () {
  const e = waitForAnyNextUpdated();
  block(matchDeleteNext(e.id, ANY), function () {
    verifyNextUpdated(e.id);
  });
});

bthread("Next delete verification", function () {
  const e = waitForAnyNextDeleted();
  block(matchAddNext(e.id, ANY), function () {
    verifyNextDoesNotExist(e.id);
  });
});

bthread("Document create verification", function () {
  const e = waitForAnyDocumentAdded();
  block(matchDeleteDocument(e.id, ANY), function () {
    verifyDocumentExists(e.id);
  });
});

bthread("Document update verification", function () {
  const e = waitForAnyDocumentUpdated();
  block(matchDeleteDocument(e.id, ANY), function () {
    verifyDocumentUpdated(e.id);
  });
});

bthread("Document delete verification", function () {
  const e = waitForAnyDocumentDeleted();
  block(matchAddDocument(e.id, ANY), function () {
    verifyDocumentDoesNotExist(e.id);
  });
});

bthread("FacetSearchQuery create verification", function () {
  const e = waitForAnyFacetSearchQueryAdded();
  block(matchDeleteFacetSearchQuery(e.id, ANY), function () {
    verifyFacetSearchQueryExists(e.id);
  });
});

bthread("FacetSearchQuery update verification", function () {
  const e = waitForAnyFacetSearchQueryUpdated();
  block(matchDeleteFacetSearchQuery(e.id, ANY), function () {
    verifyFacetSearchQueryUpdated(e.id);
  });
});

bthread("FacetSearchQuery delete verification", function () {
  const e = waitForAnyFacetSearchQueryDeleted();
  block(matchAddFacetSearchQuery(e.id, ANY), function () {
    verifyFacetSearchQueryDoesNotExist(e.id);
  });
});

bthread("TotalHits create verification", function () {
  const e = waitForAnyTotalHitsAdded();
  block(matchDeleteTotalHits(e.id, ANY), function () {
    verifyTotalHitsExists(e.id);
  });
});

bthread("TotalHits update verification", function () {
  const e = waitForAnyTotalHitsUpdated();
  block(matchDeleteTotalHits(e.id, ANY), function () {
    verifyTotalHitsUpdated(e.id);
  });
});

bthread("TotalHits delete verification", function () {
  const e = waitForAnyTotalHitsDeleted();
  block(matchAddTotalHits(e.id, ANY), function () {
    verifyTotalHitsDoesNotExist(e.id);
  });
});

bthread("TotalPages create verification", function () {
  const e = waitForAnyTotalPagesAdded();
  block(matchDeleteTotalPages(e.id, ANY), function () {
    verifyTotalPagesExists(e.id);
  });
});

bthread("TotalPages update verification", function () {
  const e = waitForAnyTotalPagesUpdated();
  block(matchDeleteTotalPages(e.id, ANY), function () {
    verifyTotalPagesUpdated(e.id);
  });
});

bthread("TotalPages delete verification", function () {
  const e = waitForAnyTotalPagesDeleted();
  block(matchAddTotalPages(e.id, ANY), function () {
    verifyTotalPagesDoesNotExist(e.id);
  });
});

bthread("Synonyms create verification", function () {
  const e = waitForAnySynonymsAdded();
  block(matchDeleteSynonyms(e.id, ANY), function () {
    verifySynonymsExists(e.id);
  });
});

bthread("Synonyms update verification", function () {
  const e = waitForAnySynonymsUpdated();
  block(matchDeleteSynonyms(e.id, ANY), function () {
    verifySynonymsUpdated(e.id);
  });
});

bthread("Synonyms delete verification", function () {
  const e = waitForAnySynonymsDeleted();
  block(matchAddSynonyms(e.id, ANY), function () {
    verifySynonymsDoesNotExist(e.id);
  });
});

// ===== RELATIONSHIP GUARDS =====

// ===== UNIQUENESS GUARDS =====

bthread("Guard: Unique SearchableAttributes", function () {
  const x = waitForAnySearchableAttributesAdded();
  block(matchAddSearchableAttributes(x.id, ANY), function () {});
});

bthread("Guard: Unique Faceting", function () {
  const x = waitForAnyFacetingAdded();
  block(matchAddFaceting(x.id, ANY), function () {});
});

bthread("Guard: Unique Stats", function () {
  const x = waitForAnyStatsAdded();
  block(matchAddStats(x.id, ANY), function () {});
});

bthread("Guard: Unique TypoTolerance", function () {
  const x = waitForAnyTypoToleranceAdded();
  block(matchAddTypoTolerance(x.id, ANY), function () {});
});

bthread("Guard: Unique Timestamp", function () {
  const x = waitForAnyTimestampAdded();
  block(matchAddTimestamp(x.id, ANY), function () {});
});

bthread("Guard: Unique Task", function () {
  const x = waitForAnyTaskAdded();
  block(matchAddTask(x.id, ANY), function () {});
});

bthread("Guard: Unique MatchesPosition", function () {
  const x = waitForAnyMatchesPositionAdded();
  block(matchAddMatchesPosition(x.id, ANY), function () {});
});

bthread("Guard: Unique SearchQuery", function () {
  const x = waitForAnySearchQueryAdded();
  block(matchAddSearchQuery(x.id, ANY), function () {});
});

bthread("Guard: Unique SummarizedTask", function () {
  const x = waitForAnySummarizedTaskAdded();
  block(matchAddSummarizedTask(x.id, ANY), function () {});
});

bthread("Guard: Unique Limit", function () {
  const x = waitForAnyLimitAdded();
  block(matchAddLimit(x.id, ANY), function () {});
});

bthread("Guard: Unique From", function () {
  const x = waitForAnyFromAdded();
  block(matchAddFrom(x.id, ANY), function () {});
});

bthread("Guard: Unique SwapIndexes", function () {
  const x = waitForAnySwapIndexesAdded();
  block(matchAddSwapIndexes(x.id, ANY), function () {});
});

bthread("Guard: Unique Offset", function () {
  const x = waitForAnyOffsetAdded();
  block(matchAddOffset(x.id, ANY), function () {});
});

bthread("Guard: Unique NonSeparatorTokens", function () {
  const x = waitForAnyNonSeparatorTokensAdded();
  block(matchAddNonSeparatorTokens(x.id, ANY), function () {});
});

bthread("Guard: Unique DisplayedAttributes", function () {
  const x = waitForAnyDisplayedAttributesAdded();
  block(matchAddDisplayedAttributes(x.id, ANY), function () {});
});

bthread("Guard: Unique Key", function () {
  const x = waitForAnyKeyAdded();
  block(matchAddKey(x.id, ANY), function () {});
});

bthread("Guard: Unique HitsPerPage", function () {
  const x = waitForAnyHitsPerPageAdded();
  block(matchAddHitsPerPage(x.id, ANY), function () {});
});

bthread("Guard: Unique StopWords", function () {
  const x = waitForAnyStopWordsAdded();
  block(matchAddStopWords(x.id, ANY), function () {});
});

bthread("Guard: Unique Dictionary", function () {
  const x = waitForAnyDictionaryAdded();
  block(matchAddDictionary(x.id, ANY), function () {});
});

bthread("Guard: Unique Settings", function () {
  const x = waitForAnySettingsAdded();
  block(matchAddSettings(x.id, ANY), function () {});
});

bthread("Guard: Unique Score", function () {
  const x = waitForAnyScoreAdded();
  block(matchAddScore(x.id, ANY), function () {});
});

bthread("Guard: Unique RankingScoreDetails", function () {
  const x = waitForAnyRankingScoreDetailsAdded();
  block(matchAddRankingScoreDetails(x.id, ANY), function () {});
});

bthread("Guard: Unique SeparatorTokens", function () {
  const x = waitForAnySeparatorTokensAdded();
  block(matchAddSeparatorTokens(x.id, ANY), function () {});
});

bthread("Guard: Unique Page", function () {
  const x = waitForAnyPageAdded();
  block(matchAddPage(x.id, ANY), function () {});
});

bthread("Guard: Unique SwapOperation", function () {
  const x = waitForAnySwapOperationAdded();
  block(matchAddSwapOperation(x.id, ANY), function () {});
});

bthread("Guard: Unique DocumentId", function () {
  const x = waitForAnyDocumentIdAdded();
  block(matchAddDocumentId(x.id, ANY), function () {});
});

bthread("Guard: Unique RankingRules", function () {
  const x = waitForAnyRankingRulesAdded();
  block(matchAddRankingRules(x.id, ANY), function () {});
});

bthread("Guard: Unique Filter", function () {
  const x = waitForAnyFilterAdded();
  block(matchAddFilter(x.id, ANY), function () {});
});

bthread("Guard: Unique FacetHit", function () {
  const x = waitForAnyFacetHitAdded();
  block(matchAddFacetHit(x.id, ANY), function () {});
});

bthread("Guard: Unique Pagination", function () {
  const x = waitForAnyPaginationAdded();
  block(matchAddPagination(x.id, ANY), function () {});
});

bthread("Guard: Unique Total", function () {
  const x = waitForAnyTotalAdded();
  block(matchAddTotal(x.id, ANY), function () {});
});

bthread("Guard: Unique Hit", function () {
  const x = waitForAnyHitAdded();
  block(matchAddHit(x.id, ANY), function () {});
});

bthread("Guard: Unique Error", function () {
  const x = waitForAnyErrorAdded();
  block(matchAddError(x.id, ANY), function () {});
});

bthread("Guard: Unique FilterableAttributes", function () {
  const x = waitForAnyFilterableAttributesAdded();
  block(matchAddFilterableAttributes(x.id, ANY), function () {});
});

bthread("Guard: Unique Index", function () {
  const x = waitForAnyIndexAdded();
  block(matchAddIndex(x.id, ANY), function () {});
});

bthread("Guard: Unique FacetSearchResponse", function () {
  const x = waitForAnyFacetSearchResponseAdded();
  block(matchAddFacetSearchResponse(x.id, ANY), function () {});
});

bthread("Guard: Unique SortableAttributes", function () {
  const x = waitForAnySortableAttributesAdded();
  block(matchAddSortableAttributes(x.id, ANY), function () {});
});

bthread("Guard: Unique CustomRankingRuleDetails", function () {
  const x = waitForAnyCustomRankingRuleDetailsAdded();
  block(matchAddCustomRankingRuleDetails(x.id, ANY), function () {});
});

bthread("Guard: Unique Sort", function () {
  const x = waitForAnySortAdded();
  block(matchAddSort(x.id, ANY), function () {});
});

bthread("Guard: Unique Order", function () {
  const x = waitForAnyOrderAdded();
  block(matchAddOrder(x.id, ANY), function () {});
});

bthread("Guard: Unique DistinctAttribute", function () {
  const x = waitForAnyDistinctAttributeAdded();
  block(matchAddDistinctAttribute(x.id, ANY), function () {});
});

bthread("Guard: Unique SearchResponse", function () {
  const x = waitForAnySearchResponseAdded();
  block(matchAddSearchResponse(x.id, ANY), function () {});
});

bthread("Guard: Unique Next", function () {
  const x = waitForAnyNextAdded();
  block(matchAddNext(x.id, ANY), function () {});
});

bthread("Guard: Unique Document", function () {
  const x = waitForAnyDocumentAdded();
  block(matchAddDocument(x.id, ANY), function () {});
});

bthread("Guard: Unique FacetSearchQuery", function () {
  const x = waitForAnyFacetSearchQueryAdded();
  block(matchAddFacetSearchQuery(x.id, ANY), function () {});
});

bthread("Guard: Unique TotalHits", function () {
  const x = waitForAnyTotalHitsAdded();
  block(matchAddTotalHits(x.id, ANY), function () {});
});

bthread("Guard: Unique TotalPages", function () {
  const x = waitForAnyTotalPagesAdded();
  block(matchAddTotalPages(x.id, ANY), function () {});
});

bthread("Guard: Unique Synonyms", function () {
  const x = waitForAnySynonymsAdded();
  block(matchAddSynonyms(x.id, ANY), function () {});
});

// ===== NEGATIVE/EDGE STATUS GUARDS =====
