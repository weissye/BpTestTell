// ====================================================================
// Auto-generated garage-style High-Level Stories (HLS)
// SUT: netbox
// ====================================================================

var ANY = (typeof H !== 'undefined' && H.ANY) ? H.ANY : (typeof ANY !== 'undefined' ? ANY : '*');

// ===== ACTIVE LIFECYCLES =====


bthread("PaginatedFrontPortTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedFrontPortTemplateList(x.id);
  updatePaginatedFrontPortTemplateList(x.id);
  updatePaginatedFrontPortTemplateList(x.id);
  verifyPaginatedFrontPortTemplateListExists(x.id);
  verifyPaginatedFrontPortTemplateListUpdated(x.id);
});

bthread("BriefDataSourceRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefDataSourceRequest(x.id);
  updateBriefDataSourceRequest(x.id);
  updateBriefDataSourceRequest(x.id);
  verifyBriefDataSourceRequestExists(x.id);
  verifyBriefDataSourceRequestUpdated(x.id);
});

bthread("PaginatedASNRangeList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedASNRangeList(x.id);
  updatePaginatedASNRangeList(x.id);
  updatePaginatedASNRangeList(x.id);
  verifyPaginatedASNRangeListExists(x.id);
  verifyPaginatedASNRangeListUpdated(x.id);
});

bthread("PatchedNotificationGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedNotificationGroupRequest(x.id);
  updatePatchedNotificationGroupRequest(x.id);
  updatePatchedNotificationGroupRequest(x.id);
  verifyPatchedNotificationGroupRequestExists(x.id);
  verifyPatchedNotificationGroupRequestUpdated(x.id);
});

bthread("RearPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRearPortTemplateRequest(x.id);
  updateRearPortTemplateRequest(x.id);
  updateRearPortTemplateRequest(x.id);
  verifyRearPortTemplateRequestExists(x.id);
  verifyRearPortTemplateRequestUpdated(x.id);
});

bthread("IPAddressRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIPAddressRequest(x.id);
  updateIPAddressRequest(x.id);
  updateIPAddressRequest(x.id);
  verifyIPAddressRequestExists(x.id);
  verifyIPAddressRequestUpdated(x.id);
});

bthread("ProviderNetworkRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addProviderNetworkRequest(x.id);
  updateProviderNetworkRequest(x.id);
  updateProviderNetworkRequest(x.id);
  verifyProviderNetworkRequestExists(x.id);
  verifyProviderNetworkRequestUpdated(x.id);
});

bthread("BriefL2VPNTerminationRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefL2VPNTerminationRequest(x.id);
  updateBriefL2VPNTerminationRequest(x.id);
  updateBriefL2VPNTerminationRequest(x.id);
  verifyBriefL2VPNTerminationRequestExists(x.id);
  verifyBriefL2VPNTerminationRequestUpdated(x.id);
});

bthread("ObjectPermission lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addObjectPermission(x.id);
  updateObjectPermission(x.id);
  updateObjectPermission(x.id);
  verifyObjectPermissionExists(x.id);
  verifyObjectPermissionUpdated(x.id);
});

bthread("PaginatedIPAddressList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedIPAddressList(x.id);
  updatePaginatedIPAddressList(x.id);
  updatePaginatedIPAddressList(x.id);
  verifyPaginatedIPAddressListExists(x.id);
  verifyPaginatedIPAddressListUpdated(x.id);
});

bthread("FrontPortRearPort lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFrontPortRearPort(x.id);
  updateFrontPortRearPort(x.id);
  updateFrontPortRearPort(x.id);
  verifyFrontPortRearPortExists(x.id);
  verifyFrontPortRearPortUpdated(x.id);
});

bthread("PatchedWritableEventRuleRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableEventRuleRequest(x.id);
  updatePatchedWritableEventRuleRequest(x.id);
  updatePatchedWritableEventRuleRequest(x.id);
  verifyPatchedWritableEventRuleRequestExists(x.id);
  verifyPatchedWritableEventRuleRequestUpdated(x.id);
});

bthread("BriefRackRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRackRequest(x.id);
  updateBriefRackRequest(x.id);
  updateBriefRackRequest(x.id);
  verifyBriefRackRequestExists(x.id);
  verifyBriefRackRequestUpdated(x.id);
});

bthread("CustomLinkRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomLinkRequest(x.id);
  updateCustomLinkRequest(x.id);
  updateCustomLinkRequest(x.id);
  verifyCustomLinkRequestExists(x.id);
  verifyCustomLinkRequestUpdated(x.id);
});

bthread("ConsoleServerPort lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConsoleServerPort(x.id);
  updateConsoleServerPort(x.id);
  updateConsoleServerPort(x.id);
  verifyConsoleServerPortExists(x.id);
  verifyConsoleServerPortUpdated(x.id);
});

bthread("PatchedCircuitTypeRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedCircuitTypeRequest(x.id);
  updatePatchedCircuitTypeRequest(x.id);
  updatePatchedCircuitTypeRequest(x.id);
  verifyPatchedCircuitTypeRequestExists(x.id);
  verifyPatchedCircuitTypeRequestUpdated(x.id);
});

bthread("BriefVirtualChassis lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVirtualChassis(x.id);
  updateBriefVirtualChassis(x.id);
  updateBriefVirtualChassis(x.id);
  verifyBriefVirtualChassisExists(x.id);
  verifyBriefVirtualChassisUpdated(x.id);
});

bthread("BriefMACAddressRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefMACAddressRequest(x.id);
  updateBriefMACAddressRequest(x.id);
  updateBriefMACAddressRequest(x.id);
  verifyBriefMACAddressRequestExists(x.id);
  verifyBriefMACAddressRequestUpdated(x.id);
});

bthread("IPSecPolicy lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIPSecPolicy(x.id);
  updateIPSecPolicy(x.id);
  updateIPSecPolicy(x.id);
  verifyIPSecPolicyExists(x.id);
  verifyIPSecPolicyUpdated(x.id);
});

bthread("IPRangeRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIPRangeRequest(x.id);
  updateIPRangeRequest(x.id);
  updateIPRangeRequest(x.id);
  verifyIPRangeRequestExists(x.id);
  verifyIPRangeRequestUpdated(x.id);
});

bthread("WritablePowerPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritablePowerPortTemplateRequest(x.id);
  updateWritablePowerPortTemplateRequest(x.id);
  updateWritablePowerPortTemplateRequest(x.id);
  verifyWritablePowerPortTemplateRequestExists(x.id);
  verifyWritablePowerPortTemplateRequestUpdated(x.id);
});

bthread("PaginatedCircuitGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedCircuitGroupList(x.id);
  updatePaginatedCircuitGroupList(x.id);
  updatePaginatedCircuitGroupList(x.id);
  verifyPaginatedCircuitGroupListExists(x.id);
  verifyPaginatedCircuitGroupListUpdated(x.id);
});

bthread("BriefModuleTypeProfile lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefModuleTypeProfile(x.id);
  updateBriefModuleTypeProfile(x.id);
  updateBriefModuleTypeProfile(x.id);
  verifyBriefModuleTypeProfileExists(x.id);
  verifyBriefModuleTypeProfileUpdated(x.id);
});

bthread("BriefVRF lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVRF(x.id);
  updateBriefVRF(x.id);
  updateBriefVRF(x.id);
  verifyBriefVRFExists(x.id);
  verifyBriefVRFUpdated(x.id);
});

bthread("FrontPortRequest lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFrontPortRequest(x.id);
  updateFrontPortRequest(x.id);
  updateFrontPortRequest(x.id);
  verifyFrontPortRequestExists(x.id);
  verifyFrontPortRequestUpdated(x.id);
});

bthread("PaginatedConsoleServerPortList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedConsoleServerPortList(x.id);
  updatePaginatedConsoleServerPortList(x.id);
  updatePaginatedConsoleServerPortList(x.id);
  verifyPaginatedConsoleServerPortListExists(x.id);
  verifyPaginatedConsoleServerPortListUpdated(x.id);
});

bthread("BriefTunnelGroup lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefTunnelGroup(x.id);
  updateBriefTunnelGroup(x.id);
  updateBriefTunnelGroup(x.id);
  verifyBriefTunnelGroupExists(x.id);
  verifyBriefTunnelGroupUpdated(x.id);
});

bthread("WritableVirtualMachineWithConfigContextRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableVirtualMachineWithConfigContextRequest(x.id);
  updateWritableVirtualMachineWithConfigContextRequest(x.id);
  updateWritableVirtualMachineWithConfigContextRequest(x.id);
  verifyWritableVirtualMachineWithConfigContextRequestExists(x.id);
  verifyWritableVirtualMachineWithConfigContextRequestUpdated(x.id);
});

bthread("PatchedWritableRackReservationRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableRackReservationRequest(x.id);
  updatePatchedWritableRackReservationRequest(x.id);
  updatePatchedWritableRackReservationRequest(x.id);
  verifyPatchedWritableRackReservationRequestExists(x.id);
  verifyPatchedWritableRackReservationRequestUpdated(x.id);
});

bthread("ConsoleServerPortRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConsoleServerPortRequest(x.id);
  updateConsoleServerPortRequest(x.id);
  updateConsoleServerPortRequest(x.id);
  verifyConsoleServerPortRequestExists(x.id);
  verifyConsoleServerPortRequestUpdated(x.id);
});

bthread("WritableWirelessLinkRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableWirelessLinkRequest(x.id);
  updateWritableWirelessLinkRequest(x.id);
  updateWritableWirelessLinkRequest(x.id);
  verifyWritableWirelessLinkRequestExists(x.id);
  verifyWritableWirelessLinkRequestUpdated(x.id);
});

bthread("WritableVirtualDeviceContextRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableVirtualDeviceContextRequest(x.id);
  updateWritableVirtualDeviceContextRequest(x.id);
  updateWritableVirtualDeviceContextRequest(x.id);
  verifyWritableVirtualDeviceContextRequestExists(x.id);
  verifyWritableVirtualDeviceContextRequestUpdated(x.id);
});

bthread("BriefLocation lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefLocation(x.id);
  updateBriefLocation(x.id);
  updateBriefLocation(x.id);
  verifyBriefLocationExists(x.id);
  verifyBriefLocationUpdated(x.id);
});

bthread("WritableInterfaceTemplateRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableInterfaceTemplateRequest(x.id);
  updateWritableInterfaceTemplateRequest(x.id);
  updateWritableInterfaceTemplateRequest(x.id);
  verifyWritableInterfaceTemplateRequestExists(x.id);
  verifyWritableInterfaceTemplateRequestUpdated(x.id);
});

bthread("PatchedWritablePowerPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritablePowerPortTemplateRequest(x.id);
  updatePatchedWritablePowerPortTemplateRequest(x.id);
  updatePatchedWritablePowerPortTemplateRequest(x.id);
  verifyPatchedWritablePowerPortTemplateRequestExists(x.id);
  verifyPatchedWritablePowerPortTemplateRequestUpdated(x.id);
});

bthread("PatchedWritableConsolePortRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableConsolePortRequest(x.id);
  updatePatchedWritableConsolePortRequest(x.id);
  updatePatchedWritableConsolePortRequest(x.id);
  verifyPatchedWritableConsolePortRequestExists(x.id);
  verifyPatchedWritableConsolePortRequestUpdated(x.id);
});

bthread("NestedVMInterfaceRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedVMInterfaceRequest(x.id);
  updateNestedVMInterfaceRequest(x.id);
  updateNestedVMInterfaceRequest(x.id);
  verifyNestedVMInterfaceRequestExists(x.id);
  verifyNestedVMInterfaceRequestUpdated(x.id);
});

bthread("BriefCustomFieldChoiceSetRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCustomFieldChoiceSetRequest(x.id);
  updateBriefCustomFieldChoiceSetRequest(x.id);
  updateBriefCustomFieldChoiceSetRequest(x.id);
  verifyBriefCustomFieldChoiceSetRequestExists(x.id);
  verifyBriefCustomFieldChoiceSetRequestUpdated(x.id);
});

bthread("WritableIPRangeRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableIPRangeRequest(x.id);
  updateWritableIPRangeRequest(x.id);
  updateWritableIPRangeRequest(x.id);
  verifyWritableIPRangeRequestExists(x.id);
  verifyWritableIPRangeRequestUpdated(x.id);
});

bthread("DeviceRole lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDeviceRole(x.id);
  updateDeviceRole(x.id);
  updateDeviceRole(x.id);
  verifyDeviceRoleExists(x.id);
  verifyDeviceRoleUpdated(x.id);
});

bthread("ConfigContextRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConfigContextRequest(x.id);
  updateConfigContextRequest(x.id);
  updateConfigContextRequest(x.id);
  verifyConfigContextRequestExists(x.id);
  verifyConfigContextRequestUpdated(x.id);
});

bthread("RackReservation lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRackReservation(x.id);
  updateRackReservation(x.id);
  updateRackReservation(x.id);
  verifyRackReservationExists(x.id);
  verifyRackReservationUpdated(x.id);
});

bthread("NestedVMInterface lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedVMInterface(x.id);
  updateNestedVMInterface(x.id);
  updateNestedVMInterface(x.id);
  verifyNestedVMInterfaceExists(x.id);
  verifyNestedVMInterfaceUpdated(x.id);
});

bthread("BriefRackRoleRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRackRoleRequest(x.id);
  updateBriefRackRoleRequest(x.id);
  updateBriefRackRoleRequest(x.id);
  verifyBriefRackRoleRequestExists(x.id);
  verifyBriefRackRoleRequestUpdated(x.id);
});

bthread("PaginatedVLANList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVLANList(x.id);
  updatePaginatedVLANList(x.id);
  updatePaginatedVLANList(x.id);
  verifyPaginatedVLANListExists(x.id);
  verifyPaginatedVLANListUpdated(x.id);
});

bthread("VLANRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVLANRequest(x.id);
  updateVLANRequest(x.id);
  updateVLANRequest(x.id);
  verifyVLANRequestExists(x.id);
  verifyVLANRequestUpdated(x.id);
});

bthread("TunnelRequest lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTunnelRequest(x.id);
  updateTunnelRequest(x.id);
  updateTunnelRequest(x.id);
  verifyTunnelRequestExists(x.id);
  verifyTunnelRequestUpdated(x.id);
});

bthread("PaginatedConsolePortTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedConsolePortTemplateList(x.id);
  updatePaginatedConsolePortTemplateList(x.id);
  updatePaginatedConsolePortTemplateList(x.id);
  verifyPaginatedConsolePortTemplateListExists(x.id);
  verifyPaginatedConsolePortTemplateListUpdated(x.id);
});

bthread("ServiceTemplateRequest lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addServiceTemplateRequest(x.id);
  updateServiceTemplateRequest(x.id);
  updateServiceTemplateRequest(x.id);
  verifyServiceTemplateRequestExists(x.id);
  verifyServiceTemplateRequestUpdated(x.id);
});

bthread("Script lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addScript(x.id);
  updateScript(x.id);
  updateScript(x.id);
  verifyScriptExists(x.id);
  verifyScriptUpdated(x.id);
});

bthread("PatchedVirtualDiskRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedVirtualDiskRequest(x.id);
  updatePatchedVirtualDiskRequest(x.id);
  updatePatchedVirtualDiskRequest(x.id);
  verifyPatchedVirtualDiskRequestExists(x.id);
  verifyPatchedVirtualDiskRequestUpdated(x.id);
});

bthread("SubscriptionRequest lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSubscriptionRequest(x.id);
  updateSubscriptionRequest(x.id);
  updateSubscriptionRequest(x.id);
  verifySubscriptionRequestExists(x.id);
  verifySubscriptionRequestUpdated(x.id);
});

bthread("InventoryItemTemplate lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInventoryItemTemplate(x.id);
  updateInventoryItemTemplate(x.id);
  updateInventoryItemTemplate(x.id);
  verifyInventoryItemTemplateExists(x.id);
  verifyInventoryItemTemplateUpdated(x.id);
});

bthread("PaginatedVirtualDiskList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVirtualDiskList(x.id);
  updatePaginatedVirtualDiskList(x.id);
  updatePaginatedVirtualDiskList(x.id);
  verifyPaginatedVirtualDiskListExists(x.id);
  verifyPaginatedVirtualDiskListUpdated(x.id);
});

bthread("PatchedCircuitTerminationRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedCircuitTerminationRequest(x.id);
  updatePatchedCircuitTerminationRequest(x.id);
  updatePatchedCircuitTerminationRequest(x.id);
  verifyPatchedCircuitTerminationRequestExists(x.id);
  verifyPatchedCircuitTerminationRequestUpdated(x.id);
});

bthread("PaginatedRegionList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRegionList(x.id);
  updatePaginatedRegionList(x.id);
  updatePaginatedRegionList(x.id);
  verifyPaginatedRegionListExists(x.id);
  verifyPaginatedRegionListUpdated(x.id);
});

bthread("CableTermination lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCableTermination(x.id);
  updateCableTermination(x.id);
  updateCableTermination(x.id);
  verifyCableTerminationExists(x.id);
  verifyCableTerminationUpdated(x.id);
});

bthread("CircuitTerminationRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitTerminationRequest(x.id);
  updateCircuitTerminationRequest(x.id);
  updateCircuitTerminationRequest(x.id);
  verifyCircuitTerminationRequestExists(x.id);
  verifyCircuitTerminationRequestUpdated(x.id);
});

bthread("PaginatedIPSecProfileList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedIPSecProfileList(x.id);
  updatePaginatedIPSecProfileList(x.id);
  updatePaginatedIPSecProfileList(x.id);
  verifyPaginatedIPSecProfileListExists(x.id);
  verifyPaginatedIPSecProfileListUpdated(x.id);
});

bthread("VLANTranslationPolicyRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVLANTranslationPolicyRequest(x.id);
  updateVLANTranslationPolicyRequest(x.id);
  updateVLANTranslationPolicyRequest(x.id);
  verifyVLANTranslationPolicyRequestExists(x.id);
  verifyVLANTranslationPolicyRequestUpdated(x.id);
});

bthread("WritableJournalEntryRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableJournalEntryRequest(x.id);
  updateWritableJournalEntryRequest(x.id);
  updateWritableJournalEntryRequest(x.id);
  verifyWritableJournalEntryRequestExists(x.id);
  verifyWritableJournalEntryRequestUpdated(x.id);
});

bthread("Prefix lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefix(x.id);
  updatePrefix(x.id);
  updatePrefix(x.id);
  verifyPrefixExists(x.id);
  verifyPrefixUpdated(x.id);
});

bthread("PatchedWritableWirelessLANRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableWirelessLANRequest(x.id);
  updatePatchedWritableWirelessLANRequest(x.id);
  updatePatchedWritableWirelessLANRequest(x.id);
  verifyPatchedWritableWirelessLANRequestExists(x.id);
  verifyPatchedWritableWirelessLANRequestUpdated(x.id);
});

bthread("CircuitType lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitType(x.id);
  updateCircuitType(x.id);
  updateCircuitType(x.id);
  verifyCircuitTypeExists(x.id);
  verifyCircuitTypeUpdated(x.id);
});

bthread("WritableCircuitGroupAssignmentRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableCircuitGroupAssignmentRequest(x.id);
  updateWritableCircuitGroupAssignmentRequest(x.id);
  updateWritableCircuitGroupAssignmentRequest(x.id);
  verifyWritableCircuitGroupAssignmentRequestExists(x.id);
  verifyWritableCircuitGroupAssignmentRequestUpdated(x.id);
});

bthread("NestedWirelessLANGroupRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedWirelessLANGroupRequest(x.id);
  updateNestedWirelessLANGroupRequest(x.id);
  updateNestedWirelessLANGroupRequest(x.id);
  verifyNestedWirelessLANGroupRequestExists(x.id);
  verifyNestedWirelessLANGroupRequestUpdated(x.id);
});

bthread("PaginatedRackTypeList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRackTypeList(x.id);
  updatePaginatedRackTypeList(x.id);
  updatePaginatedRackTypeList(x.id);
  verifyPaginatedRackTypeListExists(x.id);
  verifyPaginatedRackTypeListUpdated(x.id);
});

bthread("PaginatedWebhookList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedWebhookList(x.id);
  updatePaginatedWebhookList(x.id);
  updatePaginatedWebhookList(x.id);
  verifyPaginatedWebhookListExists(x.id);
  verifyPaginatedWebhookListUpdated(x.id);
});

bthread("PatchedVLANTranslationPolicyRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedVLANTranslationPolicyRequest(x.id);
  updatePatchedVLANTranslationPolicyRequest(x.id);
  updatePatchedVLANTranslationPolicyRequest(x.id);
  verifyPatchedVLANTranslationPolicyRequestExists(x.id);
  verifyPatchedVLANTranslationPolicyRequestUpdated(x.id);
});

bthread("PaginatedCableList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedCableList(x.id);
  updatePaginatedCableList(x.id);
  updatePaginatedCableList(x.id);
  verifyPaginatedCableListExists(x.id);
  verifyPaginatedCableListUpdated(x.id);
});

bthread("Webhook lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWebhook(x.id);
  updateWebhook(x.id);
  updateWebhook(x.id);
  verifyWebhookExists(x.id);
  verifyWebhookUpdated(x.id);
});

bthread("PaginatedRackList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRackList(x.id);
  updatePaginatedRackList(x.id);
  updatePaginatedRackList(x.id);
  verifyPaginatedRackListExists(x.id);
  verifyPaginatedRackListUpdated(x.id);
});

bthread("PatchedFHRPGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedFHRPGroupRequest(x.id);
  updatePatchedFHRPGroupRequest(x.id);
  updatePatchedFHRPGroupRequest(x.id);
  verifyPatchedFHRPGroupRequestExists(x.id);
  verifyPatchedFHRPGroupRequestUpdated(x.id);
});

bthread("VirtualCircuitType lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualCircuitType(x.id);
  updateVirtualCircuitType(x.id);
  updateVirtualCircuitType(x.id);
  verifyVirtualCircuitTypeExists(x.id);
  verifyVirtualCircuitTypeUpdated(x.id);
});

bthread("BriefVLANTranslationPolicy lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVLANTranslationPolicy(x.id);
  updateBriefVLANTranslationPolicy(x.id);
  updateBriefVLANTranslationPolicy(x.id);
  verifyBriefVLANTranslationPolicyExists(x.id);
  verifyBriefVLANTranslationPolicyUpdated(x.id);
});

bthread("BriefIPSecProfile lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefIPSecProfile(x.id);
  updateBriefIPSecProfile(x.id);
  updateBriefIPSecProfile(x.id);
  verifyBriefIPSecProfileExists(x.id);
  verifyBriefIPSecProfileUpdated(x.id);
});

bthread("PaginatedTableConfigList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedTableConfigList(x.id);
  updatePaginatedTableConfigList(x.id);
  updatePaginatedTableConfigList(x.id);
  verifyPaginatedTableConfigListExists(x.id);
  verifyPaginatedTableConfigListUpdated(x.id);
});

bthread("ModuleBayTemplate lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModuleBayTemplate(x.id);
  updateModuleBayTemplate(x.id);
  updateModuleBayTemplate(x.id);
  verifyModuleBayTemplateExists(x.id);
  verifyModuleBayTemplateUpdated(x.id);
});

bthread("BriefWirelessLANGroupRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefWirelessLANGroupRequest(x.id);
  updateBriefWirelessLANGroupRequest(x.id);
  updateBriefWirelessLANGroupRequest(x.id);
  verifyBriefWirelessLANGroupRequestExists(x.id);
  verifyBriefWirelessLANGroupRequestUpdated(x.id);
});

bthread("PaginatedContactRoleList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedContactRoleList(x.id);
  updatePaginatedContactRoleList(x.id);
  updatePaginatedContactRoleList(x.id);
  verifyPaginatedContactRoleListExists(x.id);
  verifyPaginatedContactRoleListUpdated(x.id);
});

bthread("PatchedUserRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedUserRequest(x.id);
  updatePatchedUserRequest(x.id);
  updatePatchedUserRequest(x.id);
  verifyPatchedUserRequestExists(x.id);
  verifyPatchedUserRequestUpdated(x.id);
});

bthread("ContactGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addContactGroup(x.id);
  updateContactGroup(x.id);
  updateContactGroup(x.id);
  verifyContactGroupExists(x.id);
  verifyContactGroupUpdated(x.id);
});

bthread("CableRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCableRequest(x.id);
  updateCableRequest(x.id);
  updateCableRequest(x.id);
  verifyCableRequestExists(x.id);
  verifyCableRequestUpdated(x.id);
});

bthread("RouteTargetRequest lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRouteTargetRequest(x.id);
  updateRouteTargetRequest(x.id);
  updateRouteTargetRequest(x.id);
  verifyRouteTargetRequestExists(x.id);
  verifyRouteTargetRequestUpdated(x.id);
});

bthread("IPSecProposalRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIPSecProposalRequest(x.id);
  updateIPSecProposalRequest(x.id);
  updateIPSecProposalRequest(x.id);
  verifyIPSecProposalRequestExists(x.id);
  verifyIPSecProposalRequestUpdated(x.id);
});

bthread("PaginatedRackUnitList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRackUnitList(x.id);
  updatePaginatedRackUnitList(x.id);
  updatePaginatedRackUnitList(x.id);
  verifyPaginatedRackUnitListExists(x.id);
  verifyPaginatedRackUnitListUpdated(x.id);
});

bthread("PaginatedTunnelTerminationList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedTunnelTerminationList(x.id);
  updatePaginatedTunnelTerminationList(x.id);
  updatePaginatedTunnelTerminationList(x.id);
  verifyPaginatedTunnelTerminationListExists(x.id);
  verifyPaginatedTunnelTerminationListUpdated(x.id);
});

bthread("DashboardRequest lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDashboardRequest(x.id);
  updateDashboardRequest(x.id);
  updateDashboardRequest(x.id);
  verifyDashboardRequestExists(x.id);
  verifyDashboardRequestUpdated(x.id);
});

bthread("BriefVLANTranslationPolicyRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVLANTranslationPolicyRequest(x.id);
  updateBriefVLANTranslationPolicyRequest(x.id);
  updateBriefVLANTranslationPolicyRequest(x.id);
  verifyBriefVLANTranslationPolicyRequestExists(x.id);
  verifyBriefVLANTranslationPolicyRequestUpdated(x.id);
});

bthread("BriefContactRoleRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefContactRoleRequest(x.id);
  updateBriefContactRoleRequest(x.id);
  updateBriefContactRoleRequest(x.id);
  verifyBriefContactRoleRequestExists(x.id);
  verifyBriefContactRoleRequestUpdated(x.id);
});

bthread("SiteRequest lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSiteRequest(x.id);
  updateSiteRequest(x.id);
  updateSiteRequest(x.id);
  verifySiteRequestExists(x.id);
  verifySiteRequestUpdated(x.id);
});

bthread("NestedInterfaceTemplate lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedInterfaceTemplate(x.id);
  updateNestedInterfaceTemplate(x.id);
  updateNestedInterfaceTemplate(x.id);
  verifyNestedInterfaceTemplateExists(x.id);
  verifyNestedInterfaceTemplateUpdated(x.id);
});

bthread("PaginatedModuleTypeList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedModuleTypeList(x.id);
  updatePaginatedModuleTypeList(x.id);
  updatePaginatedModuleTypeList(x.id);
  verifyPaginatedModuleTypeListExists(x.id);
  verifyPaginatedModuleTypeListUpdated(x.id);
});

bthread("FrontPortTemplate lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFrontPortTemplate(x.id);
  updateFrontPortTemplate(x.id);
  updateFrontPortTemplate(x.id);
  verifyFrontPortTemplateExists(x.id);
  verifyFrontPortTemplateUpdated(x.id);
});

bthread("BriefRIR lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRIR(x.id);
  updateBriefRIR(x.id);
  updateBriefRIR(x.id);
  verifyBriefRIRExists(x.id);
  verifyBriefRIRUpdated(x.id);
});

bthread("Job lifecycle", function () {
  const x = pick([{id: "J001"}, {id: "J002"}]);
  addJob(x.id);
  updateJob(x.id);
  updateJob(x.id);
  verifyJobExists(x.id);
  verifyJobUpdated(x.id);
});

bthread("BriefContactRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefContactRequest(x.id);
  updateBriefContactRequest(x.id);
  updateBriefContactRequest(x.id);
  verifyBriefContactRequestExists(x.id);
  verifyBriefContactRequestUpdated(x.id);
});

bthread("PaginatedImageAttachmentList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedImageAttachmentList(x.id);
  updatePaginatedImageAttachmentList(x.id);
  updatePaginatedImageAttachmentList(x.id);
  verifyPaginatedImageAttachmentListExists(x.id);
  verifyPaginatedImageAttachmentListUpdated(x.id);
});

bthread("WritableModuleTypeRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableModuleTypeRequest(x.id);
  updateWritableModuleTypeRequest(x.id);
  updateWritableModuleTypeRequest(x.id);
  verifyWritableModuleTypeRequestExists(x.id);
  verifyWritableModuleTypeRequestUpdated(x.id);
});

bthread("RackTypeRequest lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRackTypeRequest(x.id);
  updateRackTypeRequest(x.id);
  updateRackTypeRequest(x.id);
  verifyRackTypeRequestExists(x.id);
  verifyRackTypeRequestUpdated(x.id);
});

bthread("CableTerminationRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCableTerminationRequest(x.id);
  updateCableTerminationRequest(x.id);
  updateCableTerminationRequest(x.id);
  verifyCableTerminationRequestExists(x.id);
  verifyCableTerminationRequestUpdated(x.id);
});

bthread("PaginatedJobList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedJobList(x.id);
  updatePaginatedJobList(x.id);
  updatePaginatedJobList(x.id);
  verifyPaginatedJobListExists(x.id);
  verifyPaginatedJobListUpdated(x.id);
});

bthread("BriefPowerPortTemplate lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefPowerPortTemplate(x.id);
  updateBriefPowerPortTemplate(x.id);
  updateBriefPowerPortTemplate(x.id);
  verifyBriefPowerPortTemplateExists(x.id);
  verifyBriefPowerPortTemplateUpdated(x.id);
});

bthread("DeviceBayTemplateRequest lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDeviceBayTemplateRequest(x.id);
  updateDeviceBayTemplateRequest(x.id);
  updateDeviceBayTemplateRequest(x.id);
  verifyDeviceBayTemplateRequestExists(x.id);
  verifyDeviceBayTemplateRequestUpdated(x.id);
});

bthread("PaginatedContactGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedContactGroupList(x.id);
  updatePaginatedContactGroupList(x.id);
  updatePaginatedContactGroupList(x.id);
  verifyPaginatedContactGroupListExists(x.id);
  verifyPaginatedContactGroupListUpdated(x.id);
});

bthread("Platform lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPlatform(x.id);
  updatePlatform(x.id);
  updatePlatform(x.id);
  verifyPlatformExists(x.id);
  verifyPlatformUpdated(x.id);
});

bthread("CustomFieldRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomFieldRequest(x.id);
  updateCustomFieldRequest(x.id);
  updateCustomFieldRequest(x.id);
  verifyCustomFieldRequestExists(x.id);
  verifyCustomFieldRequestUpdated(x.id);
});

bthread("PaginatedClusterList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedClusterList(x.id);
  updatePaginatedClusterList(x.id);
  updatePaginatedClusterList(x.id);
  verifyPaginatedClusterListExists(x.id);
  verifyPaginatedClusterListUpdated(x.id);
});

bthread("PatchedWritableCustomFieldRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableCustomFieldRequest(x.id);
  updatePatchedWritableCustomFieldRequest(x.id);
  updatePatchedWritableCustomFieldRequest(x.id);
  verifyPatchedWritableCustomFieldRequestExists(x.id);
  verifyPatchedWritableCustomFieldRequestUpdated(x.id);
});

bthread("PaginatedVirtualCircuitTypeList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVirtualCircuitTypeList(x.id);
  updatePaginatedVirtualCircuitTypeList(x.id);
  updatePaginatedVirtualCircuitTypeList(x.id);
  verifyPaginatedVirtualCircuitTypeListExists(x.id);
  verifyPaginatedVirtualCircuitTypeListUpdated(x.id);
});

bthread("PatchedWritableRackTypeRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableRackTypeRequest(x.id);
  updatePatchedWritableRackTypeRequest(x.id);
  updatePatchedWritableRackTypeRequest(x.id);
  verifyPatchedWritableRackTypeRequestExists(x.id);
  verifyPatchedWritableRackTypeRequestUpdated(x.id);
});

bthread("PatchedWritableConsoleServerPortRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableConsoleServerPortRequest(x.id);
  updatePatchedWritableConsoleServerPortRequest(x.id);
  updatePatchedWritableConsoleServerPortRequest(x.id);
  verifyPatchedWritableConsoleServerPortRequestExists(x.id);
  verifyPatchedWritableConsoleServerPortRequestUpdated(x.id);
});

bthread("PatchedWritableIKEProposalRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableIKEProposalRequest(x.id);
  updatePatchedWritableIKEProposalRequest(x.id);
  updatePatchedWritableIKEProposalRequest(x.id);
  verifyPatchedWritableIKEProposalRequestExists(x.id);
  verifyPatchedWritableIKEProposalRequestUpdated(x.id);
});

bthread("WritableConsoleServerPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableConsoleServerPortTemplateRequest(x.id);
  updateWritableConsoleServerPortTemplateRequest(x.id);
  updateWritableConsoleServerPortTemplateRequest(x.id);
  verifyWritableConsoleServerPortTemplateRequestExists(x.id);
  verifyWritableConsoleServerPortTemplateRequestUpdated(x.id);
});

bthread("PatchedWritableAggregateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableAggregateRequest(x.id);
  updatePatchedWritableAggregateRequest(x.id);
  updatePatchedWritableAggregateRequest(x.id);
  verifyPatchedWritableAggregateRequestExists(x.id);
  verifyPatchedWritableAggregateRequestUpdated(x.id);
});

bthread("BriefFHRPGroup lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefFHRPGroup(x.id);
  updateBriefFHRPGroup(x.id);
  updateBriefFHRPGroup(x.id);
  verifyBriefFHRPGroupExists(x.id);
  verifyBriefFHRPGroupUpdated(x.id);
});

bthread("PatchedContactRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedContactRequest(x.id);
  updatePatchedContactRequest(x.id);
  updatePatchedContactRequest(x.id);
  verifyPatchedContactRequestExists(x.id);
  verifyPatchedContactRequestUpdated(x.id);
});

bthread("PatchedSavedFilterRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedSavedFilterRequest(x.id);
  updatePatchedSavedFilterRequest(x.id);
  updatePatchedSavedFilterRequest(x.id);
  verifyPatchedSavedFilterRequestExists(x.id);
  verifyPatchedSavedFilterRequestUpdated(x.id);
});

bthread("BriefSiteGroup lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefSiteGroup(x.id);
  updateBriefSiteGroup(x.id);
  updateBriefSiteGroup(x.id);
  verifyBriefSiteGroupExists(x.id);
  verifyBriefSiteGroupUpdated(x.id);
});

bthread("PatchedVRFRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedVRFRequest(x.id);
  updatePatchedVRFRequest(x.id);
  updatePatchedVRFRequest(x.id);
  verifyPatchedVRFRequestExists(x.id);
  verifyPatchedVRFRequestUpdated(x.id);
});

bthread("VirtualCircuitTermination lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualCircuitTermination(x.id);
  updateVirtualCircuitTermination(x.id);
  updateVirtualCircuitTermination(x.id);
  verifyVirtualCircuitTerminationExists(x.id);
  verifyVirtualCircuitTerminationUpdated(x.id);
});

bthread("BriefIPSecPolicyRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefIPSecPolicyRequest(x.id);
  updateBriefIPSecPolicyRequest(x.id);
  updateBriefIPSecPolicyRequest(x.id);
  verifyBriefIPSecPolicyRequestExists(x.id);
  verifyBriefIPSecPolicyRequestUpdated(x.id);
});

bthread("ClusterTypeRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClusterTypeRequest(x.id);
  updateClusterTypeRequest(x.id);
  updateClusterTypeRequest(x.id);
  verifyClusterTypeRequestExists(x.id);
  verifyClusterTypeRequestUpdated(x.id);
});

bthread("Service lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addService(x.id);
  updateService(x.id);
  updateService(x.id);
  verifyServiceExists(x.id);
  verifyServiceUpdated(x.id);
});

bthread("BriefVLANRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVLANRequest(x.id);
  updateBriefVLANRequest(x.id);
  updateBriefVLANRequest(x.id);
  verifyBriefVLANRequestExists(x.id);
  verifyBriefVLANRequestUpdated(x.id);
});

bthread("PaginatedInventoryItemRoleList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedInventoryItemRoleList(x.id);
  updatePaginatedInventoryItemRoleList(x.id);
  updatePaginatedInventoryItemRoleList(x.id);
  verifyPaginatedInventoryItemRoleListExists(x.id);
  verifyPaginatedInventoryItemRoleListUpdated(x.id);
});

bthread("BriefPowerPanelRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefPowerPanelRequest(x.id);
  updateBriefPowerPanelRequest(x.id);
  updateBriefPowerPanelRequest(x.id);
  verifyBriefPowerPanelRequestExists(x.id);
  verifyBriefPowerPanelRequestUpdated(x.id);
});

bthread("PatchedConfigTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedConfigTemplateRequest(x.id);
  updatePatchedConfigTemplateRequest(x.id);
  updatePatchedConfigTemplateRequest(x.id);
  verifyPatchedConfigTemplateRequestExists(x.id);
  verifyPatchedConfigTemplateRequestUpdated(x.id);
});

bthread("TaggedItem lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTaggedItem(x.id);
  updateTaggedItem(x.id);
  updateTaggedItem(x.id);
  verifyTaggedItemExists(x.id);
  verifyTaggedItemUpdated(x.id);
});

bthread("CustomFieldChoiceSetRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomFieldChoiceSetRequest(x.id);
  updateCustomFieldChoiceSetRequest(x.id);
  updateCustomFieldChoiceSetRequest(x.id);
  verifyCustomFieldChoiceSetRequestExists(x.id);
  verifyCustomFieldChoiceSetRequestUpdated(x.id);
});

bthread("BriefDataFile lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefDataFile(x.id);
  updateBriefDataFile(x.id);
  updateBriefDataFile(x.id);
  verifyBriefDataFileExists(x.id);
  verifyBriefDataFileUpdated(x.id);
});

bthread("PaginatedObjectPermissionList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedObjectPermissionList(x.id);
  updatePaginatedObjectPermissionList(x.id);
  updatePaginatedObjectPermissionList(x.id);
  verifyPaginatedObjectPermissionListExists(x.id);
  verifyPaginatedObjectPermissionListUpdated(x.id);
});

bthread("BriefIPSecProfileRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefIPSecProfileRequest(x.id);
  updateBriefIPSecProfileRequest(x.id);
  updateBriefIPSecProfileRequest(x.id);
  verifyBriefIPSecProfileRequestExists(x.id);
  verifyBriefIPSecProfileRequestUpdated(x.id);
});

bthread("PatchedTenantRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedTenantRequest(x.id);
  updatePatchedTenantRequest(x.id);
  updatePatchedTenantRequest(x.id);
  verifyPatchedTenantRequestExists(x.id);
  verifyPatchedTenantRequestUpdated(x.id);
});

bthread("AvailableVLAN lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAvailableVLAN(x.id);
  updateAvailableVLAN(x.id);
  updateAvailableVLAN(x.id);
  verifyAvailableVLANExists(x.id);
  verifyAvailableVLANUpdated(x.id);
});

bthread("PaginatedContactList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedContactList(x.id);
  updatePaginatedContactList(x.id);
  updatePaginatedContactList(x.id);
  verifyPaginatedContactListExists(x.id);
  verifyPaginatedContactListUpdated(x.id);
});

bthread("PaginatedPowerPortList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedPowerPortList(x.id);
  updatePaginatedPowerPortList(x.id);
  updatePaginatedPowerPortList(x.id);
  verifyPaginatedPowerPortListExists(x.id);
  verifyPaginatedPowerPortListUpdated(x.id);
});

bthread("WritableSiteRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableSiteRequest(x.id);
  updateWritableSiteRequest(x.id);
  updateWritableSiteRequest(x.id);
  verifyWritableSiteRequestExists(x.id);
  verifyWritableSiteRequestUpdated(x.id);
});

bthread("ConfigTemplate lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConfigTemplate(x.id);
  updateConfigTemplate(x.id);
  updateConfigTemplate(x.id);
  verifyConfigTemplateExists(x.id);
  verifyConfigTemplateUpdated(x.id);
});

bthread("WritableFrontPortRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableFrontPortRequest(x.id);
  updateWritableFrontPortRequest(x.id);
  updateWritableFrontPortRequest(x.id);
  verifyWritableFrontPortRequestExists(x.id);
  verifyWritableFrontPortRequestUpdated(x.id);
});

bthread("CustomField lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomField(x.id);
  updateCustomField(x.id);
  updateCustomField(x.id);
  verifyCustomFieldExists(x.id);
  verifyCustomFieldUpdated(x.id);
});

bthread("PatchedConfigContextProfileRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedConfigContextProfileRequest(x.id);
  updatePatchedConfigContextProfileRequest(x.id);
  updatePatchedConfigContextProfileRequest(x.id);
  verifyPatchedConfigContextProfileRequestExists(x.id);
  verifyPatchedConfigContextProfileRequestUpdated(x.id);
});

bthread("BriefCustomFieldChoiceSet lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCustomFieldChoiceSet(x.id);
  updateBriefCustomFieldChoiceSet(x.id);
  updateBriefCustomFieldChoiceSet(x.id);
  verifyBriefCustomFieldChoiceSetExists(x.id);
  verifyBriefCustomFieldChoiceSetUpdated(x.id);
});

bthread("PaginatedRIRList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRIRList(x.id);
  updatePaginatedRIRList(x.id);
  updatePaginatedRIRList(x.id);
  verifyPaginatedRIRListExists(x.id);
  verifyPaginatedRIRListUpdated(x.id);
});

bthread("PatchedScriptInputRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedScriptInputRequest(x.id);
  updatePatchedScriptInputRequest(x.id);
  updatePatchedScriptInputRequest(x.id);
  verifyPatchedScriptInputRequestExists(x.id);
  verifyPatchedScriptInputRequestUpdated(x.id);
});

bthread("PrefixRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPrefixRequest(x.id);
  updatePrefixRequest(x.id);
  updatePrefixRequest(x.id);
  verifyPrefixRequestExists(x.id);
  verifyPrefixRequestUpdated(x.id);
});

bthread("BriefJob lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefJob(x.id);
  updateBriefJob(x.id);
  updateBriefJob(x.id);
  verifyBriefJobExists(x.id);
  verifyBriefJobUpdated(x.id);
});

bthread("WritableDeviceRoleRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableDeviceRoleRequest(x.id);
  updateWritableDeviceRoleRequest(x.id);
  updateWritableDeviceRoleRequest(x.id);
  verifyWritableDeviceRoleRequestExists(x.id);
  verifyWritableDeviceRoleRequestUpdated(x.id);
});

bthread("Tenant lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTenant(x.id);
  updateTenant(x.id);
  updateTenant(x.id);
  verifyTenantExists(x.id);
  verifyTenantUpdated(x.id);
});

bthread("PaginatedServiceList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedServiceList(x.id);
  updatePaginatedServiceList(x.id);
  updatePaginatedServiceList(x.id);
  verifyPaginatedServiceListExists(x.id);
  verifyPaginatedServiceListUpdated(x.id);
});

bthread("PatchedInventoryItemTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedInventoryItemTemplateRequest(x.id);
  updatePatchedInventoryItemTemplateRequest(x.id);
  updatePatchedInventoryItemTemplateRequest(x.id);
  verifyPatchedInventoryItemTemplateRequestExists(x.id);
  verifyPatchedInventoryItemTemplateRequestUpdated(x.id);
});

bthread("InterfaceRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInterfaceRequest(x.id);
  updateInterfaceRequest(x.id);
  updateInterfaceRequest(x.id);
  verifyInterfaceRequestExists(x.id);
  verifyInterfaceRequestUpdated(x.id);
});

bthread("BriefTenantGroupRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefTenantGroupRequest(x.id);
  updateBriefTenantGroupRequest(x.id);
  updateBriefTenantGroupRequest(x.id);
  verifyBriefTenantGroupRequestExists(x.id);
  verifyBriefTenantGroupRequestUpdated(x.id);
});

bthread("CustomLink lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomLink(x.id);
  updateCustomLink(x.id);
  updateCustomLink(x.id);
  verifyCustomLinkExists(x.id);
  verifyCustomLinkUpdated(x.id);
});

bthread("PaginatedDeviceBayList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedDeviceBayList(x.id);
  updatePaginatedDeviceBayList(x.id);
  updatePaginatedDeviceBayList(x.id);
  verifyPaginatedDeviceBayListExists(x.id);
  verifyPaginatedDeviceBayListUpdated(x.id);
});

bthread("WritableLocationRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableLocationRequest(x.id);
  updateWritableLocationRequest(x.id);
  updateWritableLocationRequest(x.id);
  verifyWritableLocationRequestExists(x.id);
  verifyWritableLocationRequestUpdated(x.id);
});

bthread("PatchedModuleBayRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedModuleBayRequest(x.id);
  updatePatchedModuleBayRequest(x.id);
  updatePatchedModuleBayRequest(x.id);
  verifyPatchedModuleBayRequestExists(x.id);
  verifyPatchedModuleBayRequestUpdated(x.id);
});

bthread("VirtualMachineWithConfigContext lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualMachineWithConfigContext(x.id);
  updateVirtualMachineWithConfigContext(x.id);
  updateVirtualMachineWithConfigContext(x.id);
  verifyVirtualMachineWithConfigContextExists(x.id);
  verifyVirtualMachineWithConfigContextUpdated(x.id);
});

bthread("PatchedWritableIPSecPolicyRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableIPSecPolicyRequest(x.id);
  updatePatchedWritableIPSecPolicyRequest(x.id);
  updatePatchedWritableIPSecPolicyRequest(x.id);
  verifyPatchedWritableIPSecPolicyRequestExists(x.id);
  verifyPatchedWritableIPSecPolicyRequestUpdated(x.id);
});

bthread("PatchedWritableL2VPNRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableL2VPNRequest(x.id);
  updatePatchedWritableL2VPNRequest(x.id);
  updatePatchedWritableL2VPNRequest(x.id);
  verifyPatchedWritableL2VPNRequestExists(x.id);
  verifyPatchedWritableL2VPNRequestUpdated(x.id);
});

bthread("CircuitGroupAssignment lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitGroupAssignment(x.id);
  updateCircuitGroupAssignment(x.id);
  updateCircuitGroupAssignment(x.id);
  verifyCircuitGroupAssignmentExists(x.id);
  verifyCircuitGroupAssignmentUpdated(x.id);
});

bthread("BriefRearPortTemplate lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRearPortTemplate(x.id);
  updateBriefRearPortTemplate(x.id);
  updateBriefRearPortTemplate(x.id);
  verifyBriefRearPortTemplateExists(x.id);
  verifyBriefRearPortTemplateUpdated(x.id);
});

bthread("PaginatedDeviceBayTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedDeviceBayTemplateList(x.id);
  updatePaginatedDeviceBayTemplateList(x.id);
  updatePaginatedDeviceBayTemplateList(x.id);
  verifyPaginatedDeviceBayTemplateListExists(x.id);
  verifyPaginatedDeviceBayTemplateListUpdated(x.id);
});

bthread("NestedRegion lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedRegion(x.id);
  updateNestedRegion(x.id);
  updateNestedRegion(x.id);
  verifyNestedRegionExists(x.id);
  verifyNestedRegionUpdated(x.id);
});

bthread("ContactAssignmentRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addContactAssignmentRequest(x.id);
  updateContactAssignmentRequest(x.id);
  updateContactAssignmentRequest(x.id);
  verifyContactAssignmentRequestExists(x.id);
  verifyContactAssignmentRequestUpdated(x.id);
});

bthread("ConsolePortTemplateRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConsolePortTemplateRequest(x.id);
  updateConsolePortTemplateRequest(x.id);
  updateConsolePortTemplateRequest(x.id);
  verifyConsolePortTemplateRequestExists(x.id);
  verifyConsolePortTemplateRequestUpdated(x.id);
});

bthread("WritableDataSourceRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableDataSourceRequest(x.id);
  updateWritableDataSourceRequest(x.id);
  updateWritableDataSourceRequest(x.id);
  verifyWritableDataSourceRequestExists(x.id);
  verifyWritableDataSourceRequestUpdated(x.id);
});

bthread("LocationRequest lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLocationRequest(x.id);
  updateLocationRequest(x.id);
  updateLocationRequest(x.id);
  verifyLocationRequestExists(x.id);
  verifyLocationRequestUpdated(x.id);
});

bthread("PaginatedConsoleServerPortTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedConsoleServerPortTemplateList(x.id);
  updatePaginatedConsoleServerPortTemplateList(x.id);
  updatePaginatedConsoleServerPortTemplateList(x.id);
  verifyPaginatedConsoleServerPortTemplateListExists(x.id);
  verifyPaginatedConsoleServerPortTemplateListUpdated(x.id);
});

bthread("PowerPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerPortTemplateRequest(x.id);
  updatePowerPortTemplateRequest(x.id);
  updatePowerPortTemplateRequest(x.id);
  verifyPowerPortTemplateRequestExists(x.id);
  verifyPowerPortTemplateRequestUpdated(x.id);
});

bthread("PaginatedCircuitGroupAssignmentList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedCircuitGroupAssignmentList(x.id);
  updatePaginatedCircuitGroupAssignmentList(x.id);
  updatePaginatedCircuitGroupAssignmentList(x.id);
  verifyPaginatedCircuitGroupAssignmentListExists(x.id);
  verifyPaginatedCircuitGroupAssignmentListUpdated(x.id);
});

bthread("PaginatedVirtualCircuitList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVirtualCircuitList(x.id);
  updatePaginatedVirtualCircuitList(x.id);
  updatePaginatedVirtualCircuitList(x.id);
  verifyPaginatedVirtualCircuitListExists(x.id);
  verifyPaginatedVirtualCircuitListUpdated(x.id);
});

bthread("BriefRackType lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRackType(x.id);
  updateBriefRackType(x.id);
  updateBriefRackType(x.id);
  verifyBriefRackTypeExists(x.id);
  verifyBriefRackTypeUpdated(x.id);
});

bthread("RearPortRequest lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRearPortRequest(x.id);
  updateRearPortRequest(x.id);
  updateRearPortRequest(x.id);
  verifyRearPortRequestExists(x.id);
  verifyRearPortRequestUpdated(x.id);
});

bthread("ExportTemplateRequest lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addExportTemplateRequest(x.id);
  updateExportTemplateRequest(x.id);
  updateExportTemplateRequest(x.id);
  verifyExportTemplateRequestExists(x.id);
  verifyExportTemplateRequestUpdated(x.id);
});

bthread("BriefRackRole lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRackRole(x.id);
  updateBriefRackRole(x.id);
  updateBriefRackRole(x.id);
  verifyBriefRackRoleExists(x.id);
  verifyBriefRackRoleUpdated(x.id);
});

bthread("PaginatedClusterGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedClusterGroupList(x.id);
  updatePaginatedClusterGroupList(x.id);
  updatePaginatedClusterGroupList(x.id);
  verifyPaginatedClusterGroupListExists(x.id);
  verifyPaginatedClusterGroupListUpdated(x.id);
});

bthread("PatchedConfigContextRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedConfigContextRequest(x.id);
  updatePatchedConfigContextRequest(x.id);
  updatePatchedConfigContextRequest(x.id);
  verifyPatchedConfigContextRequestExists(x.id);
  verifyPatchedConfigContextRequestUpdated(x.id);
});

bthread("PaginatedTokenList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedTokenList(x.id);
  updatePaginatedTokenList(x.id);
  updatePaginatedTokenList(x.id);
  verifyPaginatedTokenListExists(x.id);
  verifyPaginatedTokenListUpdated(x.id);
});

bthread("PatchedVLANGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedVLANGroupRequest(x.id);
  updatePatchedVLANGroupRequest(x.id);
  updatePatchedVLANGroupRequest(x.id);
  verifyPatchedVLANGroupRequestExists(x.id);
  verifyPatchedVLANGroupRequestUpdated(x.id);
});

bthread("TenantGroup lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTenantGroup(x.id);
  updateTenantGroup(x.id);
  updateTenantGroup(x.id);
  verifyTenantGroupExists(x.id);
  verifyTenantGroupUpdated(x.id);
});

bthread("PatchedProviderRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedProviderRequest(x.id);
  updatePatchedProviderRequest(x.id);
  updatePatchedProviderRequest(x.id);
  verifyPatchedProviderRequestExists(x.id);
  verifyPatchedProviderRequestUpdated(x.id);
});

bthread("RIRRequest lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRIRRequest(x.id);
  updateRIRRequest(x.id);
  updateRIRRequest(x.id);
  verifyRIRRequestExists(x.id);
  verifyRIRRequestUpdated(x.id);
});

bthread("PatchedWritableVirtualMachineWithConfigContextRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableVirtualMachineWithConfigContextRequest(x.id);
  updatePatchedWritableVirtualMachineWithConfigContextRequest(x.id);
  updatePatchedWritableVirtualMachineWithConfigContextRequest(x.id);
  verifyPatchedWritableVirtualMachineWithConfigContextRequestExists(x.id);
  verifyPatchedWritableVirtualMachineWithConfigContextRequestUpdated(x.id);
});

bthread("BriefCableRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCableRequest(x.id);
  updateBriefCableRequest(x.id);
  updateBriefCableRequest(x.id);
  verifyBriefCableRequestExists(x.id);
  verifyBriefCableRequestUpdated(x.id);
});

bthread("PatchedWritableVirtualDeviceContextRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableVirtualDeviceContextRequest(x.id);
  updatePatchedWritableVirtualDeviceContextRequest(x.id);
  updatePatchedWritableVirtualDeviceContextRequest(x.id);
  verifyPatchedWritableVirtualDeviceContextRequestExists(x.id);
  verifyPatchedWritableVirtualDeviceContextRequestUpdated(x.id);
});

bthread("WritableServiceTemplateRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableServiceTemplateRequest(x.id);
  updateWritableServiceTemplateRequest(x.id);
  updateWritableServiceTemplateRequest(x.id);
  verifyWritableServiceTemplateRequestExists(x.id);
  verifyWritableServiceTemplateRequestUpdated(x.id);
});

bthread("BriefContactRole lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefContactRole(x.id);
  updateBriefContactRole(x.id);
  updateBriefContactRole(x.id);
  verifyBriefContactRoleExists(x.id);
  verifyBriefContactRoleUpdated(x.id);
});

bthread("DeviceBayRequest lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDeviceBayRequest(x.id);
  updateDeviceBayRequest(x.id);
  updateDeviceBayRequest(x.id);
  verifyDeviceBayRequestExists(x.id);
  verifyDeviceBayRequestUpdated(x.id);
});

bthread("InventoryItemTemplateRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInventoryItemTemplateRequest(x.id);
  updateInventoryItemTemplateRequest(x.id);
  updateInventoryItemTemplateRequest(x.id);
  verifyInventoryItemTemplateRequestExists(x.id);
  verifyInventoryItemTemplateRequestUpdated(x.id);
});

bthread("VLANTranslationPolicy lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVLANTranslationPolicy(x.id);
  updateVLANTranslationPolicy(x.id);
  updateVLANTranslationPolicy(x.id);
  verifyVLANTranslationPolicyExists(x.id);
  verifyVLANTranslationPolicyUpdated(x.id);
});

bthread("PatchedWritableIPSecProposalRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableIPSecProposalRequest(x.id);
  updatePatchedWritableIPSecProposalRequest(x.id);
  updatePatchedWritableIPSecProposalRequest(x.id);
  verifyPatchedWritableIPSecProposalRequestExists(x.id);
  verifyPatchedWritableIPSecProposalRequestUpdated(x.id);
});

bthread("PaginatedWirelessLinkList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedWirelessLinkList(x.id);
  updatePaginatedWirelessLinkList(x.id);
  updatePaginatedWirelessLinkList(x.id);
  verifyPaginatedWirelessLinkListExists(x.id);
  verifyPaginatedWirelessLinkListUpdated(x.id);
});

bthread("BriefVirtualCircuitRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVirtualCircuitRequest(x.id);
  updateBriefVirtualCircuitRequest(x.id);
  updateBriefVirtualCircuitRequest(x.id);
  verifyBriefVirtualCircuitRequestExists(x.id);
  verifyBriefVirtualCircuitRequestUpdated(x.id);
});

bthread("PatchedWritableRegionRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableRegionRequest(x.id);
  updatePatchedWritableRegionRequest(x.id);
  updatePatchedWritableRegionRequest(x.id);
  verifyPatchedWritableRegionRequestExists(x.id);
  verifyPatchedWritableRegionRequestUpdated(x.id);
});

bthread("BriefClusterGroupRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefClusterGroupRequest(x.id);
  updateBriefClusterGroupRequest(x.id);
  updateBriefClusterGroupRequest(x.id);
  verifyBriefClusterGroupRequestExists(x.id);
  verifyBriefClusterGroupRequestUpdated(x.id);
});

bthread("ModuleRequest lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModuleRequest(x.id);
  updateModuleRequest(x.id);
  updateModuleRequest(x.id);
  verifyModuleRequestExists(x.id);
  verifyModuleRequestUpdated(x.id);
});

bthread("PatchedWritableFrontPortRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableFrontPortRequest(x.id);
  updatePatchedWritableFrontPortRequest(x.id);
  updatePatchedWritableFrontPortRequest(x.id);
  verifyPatchedWritableFrontPortRequestExists(x.id);
  verifyPatchedWritableFrontPortRequestUpdated(x.id);
});

bthread("WritableModuleRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableModuleRequest(x.id);
  updateWritableModuleRequest(x.id);
  updateWritableModuleRequest(x.id);
  verifyWritableModuleRequestExists(x.id);
  verifyWritableModuleRequestUpdated(x.id);
});

bthread("NestedDeviceRoleRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedDeviceRoleRequest(x.id);
  updateNestedDeviceRoleRequest(x.id);
  updateNestedDeviceRoleRequest(x.id);
  verifyNestedDeviceRoleRequestExists(x.id);
  verifyNestedDeviceRoleRequestUpdated(x.id);
});

bthread("NestedDeviceRole lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedDeviceRole(x.id);
  updateNestedDeviceRole(x.id);
  updateNestedDeviceRole(x.id);
  verifyNestedDeviceRoleExists(x.id);
  verifyNestedDeviceRoleUpdated(x.id);
});

bthread("NestedInterfaceTemplateRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedInterfaceTemplateRequest(x.id);
  updateNestedInterfaceTemplateRequest(x.id);
  updateNestedInterfaceTemplateRequest(x.id);
  verifyNestedInterfaceTemplateRequestExists(x.id);
  verifyNestedInterfaceTemplateRequestUpdated(x.id);
});

bthread("BookmarkRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBookmarkRequest(x.id);
  updateBookmarkRequest(x.id);
  updateBookmarkRequest(x.id);
  verifyBookmarkRequestExists(x.id);
  verifyBookmarkRequestUpdated(x.id);
});

bthread("PaginatedTenantList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedTenantList(x.id);
  updatePaginatedTenantList(x.id);
  updatePaginatedTenantList(x.id);
  verifyPaginatedTenantListExists(x.id);
  verifyPaginatedTenantListUpdated(x.id);
});

bthread("WritableCircuitRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableCircuitRequest(x.id);
  updateWritableCircuitRequest(x.id);
  updateWritableCircuitRequest(x.id);
  verifyWritableCircuitRequestExists(x.id);
  verifyWritableCircuitRequestUpdated(x.id);
});

bthread("PatchedWritablePrefixRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritablePrefixRequest(x.id);
  updatePatchedWritablePrefixRequest(x.id);
  updatePatchedWritablePrefixRequest(x.id);
  verifyPatchedWritablePrefixRequestExists(x.id);
  verifyPatchedWritablePrefixRequestUpdated(x.id);
});

bthread("BriefVLAN lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVLAN(x.id);
  updateBriefVLAN(x.id);
  updateBriefVLAN(x.id);
  verifyBriefVLANExists(x.id);
  verifyBriefVLANUpdated(x.id);
});

bthread("PaginatedExportTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedExportTemplateList(x.id);
  updatePaginatedExportTemplateList(x.id);
  updatePaginatedExportTemplateList(x.id);
  verifyPaginatedExportTemplateListExists(x.id);
  verifyPaginatedExportTemplateListUpdated(x.id);
});

bthread("PaginatedConfigContextList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedConfigContextList(x.id);
  updatePaginatedConfigContextList(x.id);
  updatePaginatedConfigContextList(x.id);
  verifyPaginatedConfigContextListExists(x.id);
  verifyPaginatedConfigContextListUpdated(x.id);
});

bthread("PatchedTagRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedTagRequest(x.id);
  updatePatchedTagRequest(x.id);
  updatePatchedTagRequest(x.id);
  verifyPatchedTagRequestExists(x.id);
  verifyPatchedTagRequestUpdated(x.id);
});

bthread("PatchedWritableClusterRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableClusterRequest(x.id);
  updatePatchedWritableClusterRequest(x.id);
  updatePatchedWritableClusterRequest(x.id);
  verifyPatchedWritableClusterRequestExists(x.id);
  verifyPatchedWritableClusterRequestUpdated(x.id);
});

bthread("PaginatedVirtualCircuitTerminationList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVirtualCircuitTerminationList(x.id);
  updatePaginatedVirtualCircuitTerminationList(x.id);
  updatePaginatedVirtualCircuitTerminationList(x.id);
  verifyPaginatedVirtualCircuitTerminationListExists(x.id);
  verifyPaginatedVirtualCircuitTerminationListUpdated(x.id);
});

bthread("CircuitTermination lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitTermination(x.id);
  updateCircuitTermination(x.id);
  updateCircuitTermination(x.id);
  verifyCircuitTerminationExists(x.id);
  verifyCircuitTerminationUpdated(x.id);
});

bthread("PaginatedSavedFilterList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedSavedFilterList(x.id);
  updatePaginatedSavedFilterList(x.id);
  updatePaginatedSavedFilterList(x.id);
  verifyPaginatedSavedFilterListExists(x.id);
  verifyPaginatedSavedFilterListUpdated(x.id);
});

bthread("AvailableIP lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAvailableIP(x.id);
  updateAvailableIP(x.id);
  updateAvailableIP(x.id);
  verifyAvailableIPExists(x.id);
  verifyAvailableIPUpdated(x.id);
});

bthread("BriefCircuitRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCircuitRequest(x.id);
  updateBriefCircuitRequest(x.id);
  updateBriefCircuitRequest(x.id);
  verifyBriefCircuitRequestExists(x.id);
  verifyBriefCircuitRequestUpdated(x.id);
});

bthread("WritableIPAddressRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableIPAddressRequest(x.id);
  updateWritableIPAddressRequest(x.id);
  updateWritableIPAddressRequest(x.id);
  verifyWritableIPAddressRequestExists(x.id);
  verifyWritableIPAddressRequestUpdated(x.id);
});

bthread("PatchedCableTerminationRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedCableTerminationRequest(x.id);
  updatePatchedCableTerminationRequest(x.id);
  updatePatchedCableTerminationRequest(x.id);
  verifyPatchedCableTerminationRequestExists(x.id);
  verifyPatchedCableTerminationRequestUpdated(x.id);
});

bthread("NestedDeviceRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedDeviceRequest(x.id);
  updateNestedDeviceRequest(x.id);
  updateNestedDeviceRequest(x.id);
  verifyNestedDeviceRequestExists(x.id);
  verifyNestedDeviceRequestUpdated(x.id);
});

bthread("WritableTunnelTerminationRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableTunnelTerminationRequest(x.id);
  updateWritableTunnelTerminationRequest(x.id);
  updateWritableTunnelTerminationRequest(x.id);
  verifyWritableTunnelTerminationRequestExists(x.id);
  verifyWritableTunnelTerminationRequestUpdated(x.id);
});

bthread("BriefIPSecPolicy lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefIPSecPolicy(x.id);
  updateBriefIPSecPolicy(x.id);
  updateBriefIPSecPolicy(x.id);
  verifyBriefIPSecPolicyExists(x.id);
  verifyBriefIPSecPolicyUpdated(x.id);
});

bthread("PaginatedPowerOutletList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedPowerOutletList(x.id);
  updatePaginatedPowerOutletList(x.id);
  updatePaginatedPowerOutletList(x.id);
  verifyPaginatedPowerOutletListExists(x.id);
  verifyPaginatedPowerOutletListUpdated(x.id);
});

bthread("CircuitCircuitTerminationRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitCircuitTerminationRequest(x.id);
  updateCircuitCircuitTerminationRequest(x.id);
  updateCircuitCircuitTerminationRequest(x.id);
  verifyCircuitCircuitTerminationRequestExists(x.id);
  verifyCircuitCircuitTerminationRequestUpdated(x.id);
});

bthread("Group lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGroup(x.id);
  updateGroup(x.id);
  updateGroup(x.id);
  verifyGroupExists(x.id);
  verifyGroupUpdated(x.id);
});

bthread("TableConfig lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTableConfig(x.id);
  updateTableConfig(x.id);
  updateTableConfig(x.id);
  verifyTableConfigExists(x.id);
  verifyTableConfigUpdated(x.id);
});

bthread("Interface lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInterface(x.id);
  updateInterface(x.id);
  updateInterface(x.id);
  verifyInterfaceExists(x.id);
  verifyInterfaceUpdated(x.id);
});

bthread("WritableDeviceWithConfigContextRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableDeviceWithConfigContextRequest(x.id);
  updateWritableDeviceWithConfigContextRequest(x.id);
  updateWritableDeviceWithConfigContextRequest(x.id);
  verifyWritableDeviceWithConfigContextRequestExists(x.id);
  verifyWritableDeviceWithConfigContextRequestUpdated(x.id);
});

bthread("NestedInterfaceRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedInterfaceRequest(x.id);
  updateNestedInterfaceRequest(x.id);
  updateNestedInterfaceRequest(x.id);
  verifyNestedInterfaceRequestExists(x.id);
  verifyNestedInterfaceRequestUpdated(x.id);
});

bthread("PowerPortRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerPortRequest(x.id);
  updatePowerPortRequest(x.id);
  updatePowerPortRequest(x.id);
  verifyPowerPortRequestExists(x.id);
  verifyPowerPortRequestUpdated(x.id);
});

bthread("ModuleTypeProfileRequest lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModuleTypeProfileRequest(x.id);
  updateModuleTypeProfileRequest(x.id);
  updateModuleTypeProfileRequest(x.id);
  verifyModuleTypeProfileRequestExists(x.id);
  verifyModuleTypeProfileRequestUpdated(x.id);
});

bthread("BriefRearPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRearPortTemplateRequest(x.id);
  updateBriefRearPortTemplateRequest(x.id);
  updateBriefRearPortTemplateRequest(x.id);
  verifyBriefRearPortTemplateRequestExists(x.id);
  verifyBriefRearPortTemplateRequestUpdated(x.id);
});

bthread("BriefPowerPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefPowerPortTemplateRequest(x.id);
  updateBriefPowerPortTemplateRequest(x.id);
  updateBriefPowerPortTemplateRequest(x.id);
  verifyBriefPowerPortTemplateRequestExists(x.id);
  verifyBriefPowerPortTemplateRequestUpdated(x.id);
});

bthread("NestedIPAddress lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedIPAddress(x.id);
  updateNestedIPAddress(x.id);
  updateNestedIPAddress(x.id);
  verifyNestedIPAddressExists(x.id);
  verifyNestedIPAddressUpdated(x.id);
});

bthread("PaginatedModuleTypeProfileList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedModuleTypeProfileList(x.id);
  updatePaginatedModuleTypeProfileList(x.id);
  updatePaginatedModuleTypeProfileList(x.id);
  verifyPaginatedModuleTypeProfileListExists(x.id);
  verifyPaginatedModuleTypeProfileListUpdated(x.id);
});

bthread("PatchedRIRRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedRIRRequest(x.id);
  updatePatchedRIRRequest(x.id);
  updatePatchedRIRRequest(x.id);
  verifyPatchedRIRRequestExists(x.id);
  verifyPatchedRIRRequestUpdated(x.id);
});

bthread("BriefRegionRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRegionRequest(x.id);
  updateBriefRegionRequest(x.id);
  updateBriefRegionRequest(x.id);
  verifyBriefRegionRequestExists(x.id);
  verifyBriefRegionRequestUpdated(x.id);
});

bthread("BackgroundTask lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBackgroundTask(x.id);
  updateBackgroundTask(x.id);
  updateBackgroundTask(x.id);
  verifyBackgroundTaskExists(x.id);
  verifyBackgroundTaskUpdated(x.id);
});

bthread("PatchedASNRangeRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedASNRangeRequest(x.id);
  updatePatchedASNRangeRequest(x.id);
  updatePatchedASNRangeRequest(x.id);
  verifyPatchedASNRangeRequestExists(x.id);
  verifyPatchedASNRangeRequestUpdated(x.id);
});

bthread("BriefCircuit lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCircuit(x.id);
  updateBriefCircuit(x.id);
  updateBriefCircuit(x.id);
  verifyBriefCircuitExists(x.id);
  verifyBriefCircuitUpdated(x.id);
});

bthread("BriefWirelessLANGroup lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefWirelessLANGroup(x.id);
  updateBriefWirelessLANGroup(x.id);
  updateBriefWirelessLANGroup(x.id);
  verifyBriefWirelessLANGroupExists(x.id);
  verifyBriefWirelessLANGroupUpdated(x.id);
});

bthread("PaginatedDataSourceList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedDataSourceList(x.id);
  updatePaginatedDataSourceList(x.id);
  updatePaginatedDataSourceList(x.id);
  verifyPaginatedDataSourceListExists(x.id);
  verifyPaginatedDataSourceListUpdated(x.id);
});

bthread("TunnelGroupRequest lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTunnelGroupRequest(x.id);
  updateTunnelGroupRequest(x.id);
  updateTunnelGroupRequest(x.id);
  verifyTunnelGroupRequestExists(x.id);
  verifyTunnelGroupRequestUpdated(x.id);
});

bthread("WritableVirtualChassisRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableVirtualChassisRequest(x.id);
  updateWritableVirtualChassisRequest(x.id);
  updateWritableVirtualChassisRequest(x.id);
  verifyWritableVirtualChassisRequestExists(x.id);
  verifyWritableVirtualChassisRequestUpdated(x.id);
});

bthread("Location lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addLocation(x.id);
  updateLocation(x.id);
  updateLocation(x.id);
  verifyLocationExists(x.id);
  verifyLocationUpdated(x.id);
});

bthread("PatchedWritableWirelessLANGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableWirelessLANGroupRequest(x.id);
  updatePatchedWritableWirelessLANGroupRequest(x.id);
  updatePatchedWritableWirelessLANGroupRequest(x.id);
  verifyPatchedWritableWirelessLANGroupRequestExists(x.id);
  verifyPatchedWritableWirelessLANGroupRequestUpdated(x.id);
});

bthread("Circuit lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuit(x.id);
  updateCircuit(x.id);
  updateCircuit(x.id);
  verifyCircuitExists(x.id);
  verifyCircuitUpdated(x.id);
});

bthread("PatchedMACAddressRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedMACAddressRequest(x.id);
  updatePatchedMACAddressRequest(x.id);
  updatePatchedMACAddressRequest(x.id);
  verifyPatchedMACAddressRequestExists(x.id);
  verifyPatchedMACAddressRequestUpdated(x.id);
});

bthread("TokenRequest lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTokenRequest(x.id);
  updateTokenRequest(x.id);
  updateTokenRequest(x.id);
  verifyTokenRequestExists(x.id);
  verifyTokenRequestUpdated(x.id);
});

bthread("InterfaceTemplate lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInterfaceTemplate(x.id);
  updateInterfaceTemplate(x.id);
  updateInterfaceTemplate(x.id);
  verifyInterfaceTemplateExists(x.id);
  verifyInterfaceTemplateUpdated(x.id);
});

bthread("PaginatedTunnelList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedTunnelList(x.id);
  updatePaginatedTunnelList(x.id);
  updatePaginatedTunnelList(x.id);
  verifyPaginatedTunnelListExists(x.id);
  verifyPaginatedTunnelListUpdated(x.id);
});

bthread("BriefIKEPolicyRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefIKEPolicyRequest(x.id);
  updateBriefIKEPolicyRequest(x.id);
  updateBriefIKEPolicyRequest(x.id);
  verifyBriefIKEPolicyRequestExists(x.id);
  verifyBriefIKEPolicyRequestUpdated(x.id);
});

bthread("BriefManufacturer lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefManufacturer(x.id);
  updateBriefManufacturer(x.id);
  updateBriefManufacturer(x.id);
  verifyBriefManufacturerExists(x.id);
  verifyBriefManufacturerUpdated(x.id);
});

bthread("Aggregate lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAggregate(x.id);
  updateAggregate(x.id);
  updateAggregate(x.id);
  verifyAggregateExists(x.id);
  verifyAggregateUpdated(x.id);
});

bthread("PatchedWritableRearPortRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableRearPortRequest(x.id);
  updatePatchedWritableRearPortRequest(x.id);
  updatePatchedWritableRearPortRequest(x.id);
  verifyPatchedWritableRearPortRequestExists(x.id);
  verifyPatchedWritableRearPortRequestUpdated(x.id);
});

bthread("PaginatedContactAssignmentList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedContactAssignmentList(x.id);
  updatePaginatedContactAssignmentList(x.id);
  updatePaginatedContactAssignmentList(x.id);
  verifyPaginatedContactAssignmentListExists(x.id);
  verifyPaginatedContactAssignmentListUpdated(x.id);
});

bthread("Device lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDevice(x.id);
  updateDevice(x.id);
  updateDevice(x.id);
  verifyDeviceExists(x.id);
  verifyDeviceUpdated(x.id);
});

bthread("WritableCustomFieldRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableCustomFieldRequest(x.id);
  updateWritableCustomFieldRequest(x.id);
  updateWritableCustomFieldRequest(x.id);
  verifyWritableCustomFieldRequestExists(x.id);
  verifyWritableCustomFieldRequestUpdated(x.id);
});

bthread("WritablePowerFeedRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritablePowerFeedRequest(x.id);
  updateWritablePowerFeedRequest(x.id);
  updateWritablePowerFeedRequest(x.id);
  verifyWritablePowerFeedRequestExists(x.id);
  verifyWritablePowerFeedRequestUpdated(x.id);
});

bthread("WirelessLinkRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWirelessLinkRequest(x.id);
  updateWirelessLinkRequest(x.id);
  updateWirelessLinkRequest(x.id);
  verifyWirelessLinkRequestExists(x.id);
  verifyWirelessLinkRequestUpdated(x.id);
});

bthread("PaginatedVRFList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVRFList(x.id);
  updatePaginatedVRFList(x.id);
  updatePaginatedVRFList(x.id);
  verifyPaginatedVRFListExists(x.id);
  verifyPaginatedVRFListUpdated(x.id);
});

bthread("WritableInventoryItemRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableInventoryItemRequest(x.id);
  updateWritableInventoryItemRequest(x.id);
  updateWritableInventoryItemRequest(x.id);
  verifyWritableInventoryItemRequestExists(x.id);
  verifyWritableInventoryItemRequestUpdated(x.id);
});

bthread("CircuitCircuitTermination lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitCircuitTermination(x.id);
  updateCircuitCircuitTermination(x.id);
  updateCircuitCircuitTermination(x.id);
  verifyCircuitCircuitTerminationExists(x.id);
  verifyCircuitCircuitTerminationUpdated(x.id);
});

bthread("BriefProviderAccountRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefProviderAccountRequest(x.id);
  updateBriefProviderAccountRequest(x.id);
  updateBriefProviderAccountRequest(x.id);
  verifyBriefProviderAccountRequestExists(x.id);
  verifyBriefProviderAccountRequestUpdated(x.id);
});

bthread("PatchedWritableContactAssignmentRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableContactAssignmentRequest(x.id);
  updatePatchedWritableContactAssignmentRequest(x.id);
  updatePatchedWritableContactAssignmentRequest(x.id);
  verifyPatchedWritableContactAssignmentRequestExists(x.id);
  verifyPatchedWritableContactAssignmentRequestUpdated(x.id);
});

bthread("TableConfigRequest lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTableConfigRequest(x.id);
  updateTableConfigRequest(x.id);
  updateTableConfigRequest(x.id);
  verifyTableConfigRequestExists(x.id);
  verifyTableConfigRequestUpdated(x.id);
});

bthread("EventRule lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEventRule(x.id);
  updateEventRule(x.id);
  updateEventRule(x.id);
  verifyEventRuleExists(x.id);
  verifyEventRuleUpdated(x.id);
});

bthread("VirtualCircuit lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualCircuit(x.id);
  updateVirtualCircuit(x.id);
  updateVirtualCircuit(x.id);
  verifyVirtualCircuitExists(x.id);
  verifyVirtualCircuitUpdated(x.id);
});

bthread("BriefProviderRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefProviderRequest(x.id);
  updateBriefProviderRequest(x.id);
  updateBriefProviderRequest(x.id);
  verifyBriefProviderRequestExists(x.id);
  verifyBriefProviderRequestUpdated(x.id);
});

bthread("PaginatedProviderNetworkList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedProviderNetworkList(x.id);
  updatePaginatedProviderNetworkList(x.id);
  updatePaginatedProviderNetworkList(x.id);
  verifyPaginatedProviderNetworkListExists(x.id);
  verifyPaginatedProviderNetworkListUpdated(x.id);
});

bthread("PaginatedScriptList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedScriptList(x.id);
  updatePaginatedScriptList(x.id);
  updatePaginatedScriptList(x.id);
  verifyPaginatedScriptListExists(x.id);
  verifyPaginatedScriptListUpdated(x.id);
});

bthread("PatchedWritablePowerPortRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritablePowerPortRequest(x.id);
  updatePatchedWritablePowerPortRequest(x.id);
  updatePatchedWritablePowerPortRequest(x.id);
  verifyPatchedWritablePowerPortRequestExists(x.id);
  verifyPatchedWritablePowerPortRequestUpdated(x.id);
});

bthread("VirtualDeviceContext lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualDeviceContext(x.id);
  updateVirtualDeviceContext(x.id);
  updateVirtualDeviceContext(x.id);
  verifyVirtualDeviceContextExists(x.id);
  verifyVirtualDeviceContextUpdated(x.id);
});

bthread("PowerPort lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerPort(x.id);
  updatePowerPort(x.id);
  updatePowerPort(x.id);
  verifyPowerPortExists(x.id);
  verifyPowerPortUpdated(x.id);
});

bthread("BriefSiteRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefSiteRequest(x.id);
  updateBriefSiteRequest(x.id);
  updateBriefSiteRequest(x.id);
  verifyBriefSiteRequestExists(x.id);
  verifyBriefSiteRequestUpdated(x.id);
});

bthread("PaginatedModuleList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedModuleList(x.id);
  updatePaginatedModuleList(x.id);
  updatePaginatedModuleList(x.id);
  verifyPaginatedModuleListExists(x.id);
  verifyPaginatedModuleListUpdated(x.id);
});

bthread("PaginatedVLANTranslationRuleList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVLANTranslationRuleList(x.id);
  updatePaginatedVLANTranslationRuleList(x.id);
  updatePaginatedVLANTranslationRuleList(x.id);
  verifyPaginatedVLANTranslationRuleListExists(x.id);
  verifyPaginatedVLANTranslationRuleListUpdated(x.id);
});

bthread("ASNRequest lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addASNRequest(x.id);
  updateASNRequest(x.id);
  updateASNRequest(x.id);
  verifyASNRequestExists(x.id);
  verifyASNRequestUpdated(x.id);
});

bthread("SavedFilter lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSavedFilter(x.id);
  updateSavedFilter(x.id);
  updateSavedFilter(x.id);
  verifySavedFilterExists(x.id);
  verifySavedFilterUpdated(x.id);
});

bthread("PaginatedRouteTargetList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRouteTargetList(x.id);
  updatePaginatedRouteTargetList(x.id);
  updatePaginatedRouteTargetList(x.id);
  verifyPaginatedRouteTargetListExists(x.id);
  verifyPaginatedRouteTargetListUpdated(x.id);
});

bthread("TenantRequest lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTenantRequest(x.id);
  updateTenantRequest(x.id);
  updateTenantRequest(x.id);
  verifyTenantRequestExists(x.id);
  verifyTenantRequestUpdated(x.id);
});

bthread("NestedModuleBay lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedModuleBay(x.id);
  updateNestedModuleBay(x.id);
  updateNestedModuleBay(x.id);
  verifyNestedModuleBayExists(x.id);
  verifyNestedModuleBayUpdated(x.id);
});

bthread("PatchedVLANTranslationRuleRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedVLANTranslationRuleRequest(x.id);
  updatePatchedVLANTranslationRuleRequest(x.id);
  updatePatchedVLANTranslationRuleRequest(x.id);
  verifyPatchedVLANTranslationRuleRequestExists(x.id);
  verifyPatchedVLANTranslationRuleRequestUpdated(x.id);
});

bthread("WritableVLANRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableVLANRequest(x.id);
  updateWritableVLANRequest(x.id);
  updateWritableVLANRequest(x.id);
  verifyWritableVLANRequestExists(x.id);
  verifyWritableVLANRequestUpdated(x.id);
});

bthread("PatchedWritableRackRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableRackRequest(x.id);
  updatePatchedWritableRackRequest(x.id);
  updatePatchedWritableRackRequest(x.id);
  verifyPatchedWritableRackRequestExists(x.id);
  verifyPatchedWritableRackRequestUpdated(x.id);
});

bthread("PatchedWritableJournalEntryRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableJournalEntryRequest(x.id);
  updatePatchedWritableJournalEntryRequest(x.id);
  updatePatchedWritableJournalEntryRequest(x.id);
  verifyPatchedWritableJournalEntryRequestExists(x.id);
  verifyPatchedWritableJournalEntryRequestUpdated(x.id);
});

bthread("PaginatedProviderAccountList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedProviderAccountList(x.id);
  updatePaginatedProviderAccountList(x.id);
  updatePaginatedProviderAccountList(x.id);
  verifyPaginatedProviderAccountListExists(x.id);
  verifyPaginatedProviderAccountListUpdated(x.id);
});

bthread("Token lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addToken(x.id);
  updateToken(x.id);
  updateToken(x.id);
  verifyTokenExists(x.id);
  verifyTokenUpdated(x.id);
});

bthread("PaginatedPowerFeedList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedPowerFeedList(x.id);
  updatePaginatedPowerFeedList(x.id);
  updatePaginatedPowerFeedList(x.id);
  verifyPaginatedPowerFeedListExists(x.id);
  verifyPaginatedPowerFeedListUpdated(x.id);
});

bthread("PatchedClusterTypeRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedClusterTypeRequest(x.id);
  updatePatchedClusterTypeRequest(x.id);
  updatePatchedClusterTypeRequest(x.id);
  verifyPatchedClusterTypeRequestExists(x.id);
  verifyPatchedClusterTypeRequestUpdated(x.id);
});

bthread("PowerOutletRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerOutletRequest(x.id);
  updatePowerOutletRequest(x.id);
  updatePowerOutletRequest(x.id);
  verifyPowerOutletRequestExists(x.id);
  verifyPowerOutletRequestUpdated(x.id);
});

bthread("BriefDeviceRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefDeviceRequest(x.id);
  updateBriefDeviceRequest(x.id);
  updateBriefDeviceRequest(x.id);
  verifyBriefDeviceRequestExists(x.id);
  verifyBriefDeviceRequestUpdated(x.id);
});

bthread("PaginatedTenantGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedTenantGroupList(x.id);
  updatePaginatedTenantGroupList(x.id);
  updatePaginatedTenantGroupList(x.id);
  verifyPaginatedTenantGroupListExists(x.id);
  verifyPaginatedTenantGroupListUpdated(x.id);
});

bthread("PatchedWritableLocationRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableLocationRequest(x.id);
  updatePatchedWritableLocationRequest(x.id);
  updatePatchedWritableLocationRequest(x.id);
  verifyPatchedWritableLocationRequestExists(x.id);
  verifyPatchedWritableLocationRequestUpdated(x.id);
});

bthread("BriefProviderNetworkRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefProviderNetworkRequest(x.id);
  updateBriefProviderNetworkRequest(x.id);
  updateBriefProviderNetworkRequest(x.id);
  verifyBriefProviderNetworkRequestExists(x.id);
  verifyBriefProviderNetworkRequestUpdated(x.id);
});

bthread("SiteGroup lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSiteGroup(x.id);
  updateSiteGroup(x.id);
  updateSiteGroup(x.id);
  verifySiteGroupExists(x.id);
  verifySiteGroupUpdated(x.id);
});

bthread("BriefCircuitGroupAssignmentSerializer_Request lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCircuitGroupAssignmentSerializer_Request(x.id);
  updateBriefCircuitGroupAssignmentSerializer_Request(x.id);
  updateBriefCircuitGroupAssignmentSerializer_Request(x.id);
  verifyBriefCircuitGroupAssignmentSerializer_RequestExists(x.id);
  verifyBriefCircuitGroupAssignmentSerializer_RequestUpdated(x.id);
});

bthread("PatchedImageAttachmentRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedImageAttachmentRequest(x.id);
  updatePatchedImageAttachmentRequest(x.id);
  updatePatchedImageAttachmentRequest(x.id);
  verifyPatchedImageAttachmentRequestExists(x.id);
  verifyPatchedImageAttachmentRequestUpdated(x.id);
});

bthread("PaginatedPrefixList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedPrefixList(x.id);
  updatePaginatedPrefixList(x.id);
  updatePaginatedPrefixList(x.id);
  verifyPaginatedPrefixListExists(x.id);
  verifyPaginatedPrefixListUpdated(x.id);
});

bthread("JournalEntry lifecycle", function () {
  const x = pick([{id: "J001"}, {id: "J002"}]);
  addJournalEntry(x.id);
  updateJournalEntry(x.id);
  updateJournalEntry(x.id);
  verifyJournalEntryExists(x.id);
  verifyJournalEntryUpdated(x.id);
});

bthread("PatchedWritableVirtualCircuitRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableVirtualCircuitRequest(x.id);
  updatePatchedWritableVirtualCircuitRequest(x.id);
  updatePatchedWritableVirtualCircuitRequest(x.id);
  verifyPatchedWritableVirtualCircuitRequestExists(x.id);
  verifyPatchedWritableVirtualCircuitRequestUpdated(x.id);
});

bthread("BriefTenantGroup lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefTenantGroup(x.id);
  updateBriefTenantGroup(x.id);
  updateBriefTenantGroup(x.id);
  verifyBriefTenantGroupExists(x.id);
  verifyBriefTenantGroupUpdated(x.id);
});

bthread("PatchedTableConfigRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedTableConfigRequest(x.id);
  updatePatchedTableConfigRequest(x.id);
  updatePatchedTableConfigRequest(x.id);
  verifyPatchedTableConfigRequestExists(x.id);
  verifyPatchedTableConfigRequestUpdated(x.id);
});

bthread("NestedContactGroupRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedContactGroupRequest(x.id);
  updateNestedContactGroupRequest(x.id);
  updateNestedContactGroupRequest(x.id);
  verifyNestedContactGroupRequestExists(x.id);
  verifyNestedContactGroupRequestUpdated(x.id);
});

bthread("PatchedWritableDataSourceRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableDataSourceRequest(x.id);
  updatePatchedWritableDataSourceRequest(x.id);
  updatePatchedWritableDataSourceRequest(x.id);
  verifyPatchedWritableDataSourceRequestExists(x.id);
  verifyPatchedWritableDataSourceRequestUpdated(x.id);
});

bthread("BriefCircuitGroupRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCircuitGroupRequest(x.id);
  updateBriefCircuitGroupRequest(x.id);
  updateBriefCircuitGroupRequest(x.id);
  verifyBriefCircuitGroupRequestExists(x.id);
  verifyBriefCircuitGroupRequestUpdated(x.id);
});

bthread("WritableDeviceTypeRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableDeviceTypeRequest(x.id);
  updateWritableDeviceTypeRequest(x.id);
  updateWritableDeviceTypeRequest(x.id);
  verifyWritableDeviceTypeRequestExists(x.id);
  verifyWritableDeviceTypeRequestUpdated(x.id);
});

bthread("PaginatedConfigContextProfileList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedConfigContextProfileList(x.id);
  updatePaginatedConfigContextProfileList(x.id);
  updatePaginatedConfigContextProfileList(x.id);
  verifyPaginatedConfigContextProfileListExists(x.id);
  verifyPaginatedConfigContextProfileListUpdated(x.id);
});

bthread("PaginatedIPRangeList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedIPRangeList(x.id);
  updatePaginatedIPRangeList(x.id);
  updatePaginatedIPRangeList(x.id);
  verifyPaginatedIPRangeListExists(x.id);
  verifyPaginatedIPRangeListUpdated(x.id);
});

bthread("SavedFilterRequest lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSavedFilterRequest(x.id);
  updateSavedFilterRequest(x.id);
  updateSavedFilterRequest(x.id);
  verifySavedFilterRequestExists(x.id);
  verifySavedFilterRequestUpdated(x.id);
});

bthread("Site lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSite(x.id);
  updateSite(x.id);
  updateSite(x.id);
  verifySiteExists(x.id);
  verifySiteUpdated(x.id);
});

bthread("BriefL2VPN lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefL2VPN(x.id);
  updateBriefL2VPN(x.id);
  updateBriefL2VPN(x.id);
  verifyBriefL2VPNExists(x.id);
  verifyBriefL2VPNUpdated(x.id);
});

bthread("BriefRegion lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRegion(x.id);
  updateBriefRegion(x.id);
  updateBriefRegion(x.id);
  verifyBriefRegionExists(x.id);
  verifyBriefRegionUpdated(x.id);
});

bthread("GenericObject lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGenericObject(x.id);
  updateGenericObject(x.id);
  updateGenericObject(x.id);
  verifyGenericObjectExists(x.id);
  verifyGenericObjectUpdated(x.id);
});

bthread("WritableConsoleServerPortRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableConsoleServerPortRequest(x.id);
  updateWritableConsoleServerPortRequest(x.id);
  updateWritableConsoleServerPortRequest(x.id);
  verifyWritableConsoleServerPortRequestExists(x.id);
  verifyWritableConsoleServerPortRequestUpdated(x.id);
});

bthread("BriefL2VPNRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefL2VPNRequest(x.id);
  updateBriefL2VPNRequest(x.id);
  updateBriefL2VPNRequest(x.id);
  verifyBriefL2VPNRequestExists(x.id);
  verifyBriefL2VPNRequestUpdated(x.id);
});

bthread("VLANGroup lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVLANGroup(x.id);
  updateVLANGroup(x.id);
  updateVLANGroup(x.id);
  verifyVLANGroupExists(x.id);
  verifyVLANGroupUpdated(x.id);
});

bthread("VLANTranslationRuleRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVLANTranslationRuleRequest(x.id);
  updateVLANTranslationRuleRequest(x.id);
  updateVLANTranslationRuleRequest(x.id);
  verifyVLANTranslationRuleRequestExists(x.id);
  verifyVLANTranslationRuleRequestUpdated(x.id);
});

bthread("DataSourceRequest lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDataSourceRequest(x.id);
  updateDataSourceRequest(x.id);
  updateDataSourceRequest(x.id);
  verifyDataSourceRequestExists(x.id);
  verifyDataSourceRequestUpdated(x.id);
});

bthread("ClusterGroupRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClusterGroupRequest(x.id);
  updateClusterGroupRequest(x.id);
  updateClusterGroupRequest(x.id);
  verifyClusterGroupRequestExists(x.id);
  verifyClusterGroupRequestUpdated(x.id);
});

bthread("L2VPNTermination lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addL2VPNTermination(x.id);
  updateL2VPNTermination(x.id);
  updateL2VPNTermination(x.id);
  verifyL2VPNTerminationExists(x.id);
  verifyL2VPNTerminationUpdated(x.id);
});

bthread("ServiceTemplate lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addServiceTemplate(x.id);
  updateServiceTemplate(x.id);
  updateServiceTemplate(x.id);
  verifyServiceTemplateExists(x.id);
  verifyServiceTemplateUpdated(x.id);
});

bthread("NestedGroup lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedGroup(x.id);
  updateNestedGroup(x.id);
  updateNestedGroup(x.id);
  verifyNestedGroupExists(x.id);
  verifyNestedGroupUpdated(x.id);
});

bthread("DeviceBayTemplate lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDeviceBayTemplate(x.id);
  updateDeviceBayTemplate(x.id);
  updateDeviceBayTemplate(x.id);
  verifyDeviceBayTemplateExists(x.id);
  verifyDeviceBayTemplateUpdated(x.id);
});

bthread("ASN lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addASN(x.id);
  updateASN(x.id);
  updateASN(x.id);
  verifyASNExists(x.id);
  verifyASNUpdated(x.id);
});

bthread("BriefConfigContextProfileRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefConfigContextProfileRequest(x.id);
  updateBriefConfigContextProfileRequest(x.id);
  updateBriefConfigContextProfileRequest(x.id);
  verifyBriefConfigContextProfileRequestExists(x.id);
  verifyBriefConfigContextProfileRequestUpdated(x.id);
});

bthread("PatchedSubscriptionRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedSubscriptionRequest(x.id);
  updatePatchedSubscriptionRequest(x.id);
  updatePatchedSubscriptionRequest(x.id);
  verifyPatchedSubscriptionRequestExists(x.id);
  verifyPatchedSubscriptionRequestUpdated(x.id);
});

bthread("PatchedWritableVMInterfaceRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableVMInterfaceRequest(x.id);
  updatePatchedWritableVMInterfaceRequest(x.id);
  updatePatchedWritableVMInterfaceRequest(x.id);
  verifyPatchedWritableVMInterfaceRequestExists(x.id);
  verifyPatchedWritableVMInterfaceRequestUpdated(x.id);
});

bthread("ConfigTemplateRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConfigTemplateRequest(x.id);
  updateConfigTemplateRequest(x.id);
  updateConfigTemplateRequest(x.id);
  verifyConfigTemplateRequestExists(x.id);
  verifyConfigTemplateRequestUpdated(x.id);
});

bthread("PaginatedSiteList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedSiteList(x.id);
  updatePaginatedSiteList(x.id);
  updatePaginatedSiteList(x.id);
  verifyPaginatedSiteListExists(x.id);
  verifyPaginatedSiteListUpdated(x.id);
});

bthread("PaginatedL2VPNTerminationList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedL2VPNTerminationList(x.id);
  updatePaginatedL2VPNTerminationList(x.id);
  updatePaginatedL2VPNTerminationList(x.id);
  verifyPaginatedL2VPNTerminationListExists(x.id);
  verifyPaginatedL2VPNTerminationListUpdated(x.id);
});

bthread("RackRequest lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRackRequest(x.id);
  updateRackRequest(x.id);
  updateRackRequest(x.id);
  verifyRackRequestExists(x.id);
  verifyRackRequestUpdated(x.id);
});

bthread("WritablePrefixRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritablePrefixRequest(x.id);
  updateWritablePrefixRequest(x.id);
  updateWritablePrefixRequest(x.id);
  verifyWritablePrefixRequestExists(x.id);
  verifyWritablePrefixRequestUpdated(x.id);
});

bthread("InventoryItemRole lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInventoryItemRole(x.id);
  updateInventoryItemRole(x.id);
  updateInventoryItemRole(x.id);
  verifyInventoryItemRoleExists(x.id);
  verifyInventoryItemRoleUpdated(x.id);
});

bthread("L2VPNRequest lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addL2VPNRequest(x.id);
  updateL2VPNRequest(x.id);
  updateL2VPNRequest(x.id);
  verifyL2VPNRequestExists(x.id);
  verifyL2VPNRequestUpdated(x.id);
});

bthread("BriefClusterTypeRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefClusterTypeRequest(x.id);
  updateBriefClusterTypeRequest(x.id);
  updateBriefClusterTypeRequest(x.id);
  verifyBriefClusterTypeRequestExists(x.id);
  verifyBriefClusterTypeRequestUpdated(x.id);
});

bthread("PatchedWritableVirtualCircuitTerminationRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableVirtualCircuitTerminationRequest(x.id);
  updatePatchedWritableVirtualCircuitTerminationRequest(x.id);
  updatePatchedWritableVirtualCircuitTerminationRequest(x.id);
  verifyPatchedWritableVirtualCircuitTerminationRequestExists(x.id);
  verifyPatchedWritableVirtualCircuitTerminationRequestUpdated(x.id);
});

bthread("FHRPGroupRequest lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFHRPGroupRequest(x.id);
  updateFHRPGroupRequest(x.id);
  updateFHRPGroupRequest(x.id);
  verifyFHRPGroupRequestExists(x.id);
  verifyFHRPGroupRequestUpdated(x.id);
});

bthread("NestedLocation lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedLocation(x.id);
  updateNestedLocation(x.id);
  updateNestedLocation(x.id);
  verifyNestedLocationExists(x.id);
  verifyNestedLocationUpdated(x.id);
});

bthread("BriefSite lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefSite(x.id);
  updateBriefSite(x.id);
  updateBriefSite(x.id);
  verifyBriefSiteExists(x.id);
  verifyBriefSiteUpdated(x.id);
});

bthread("ConfigContext lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConfigContext(x.id);
  updateConfigContext(x.id);
  updateConfigContext(x.id);
  verifyConfigContextExists(x.id);
  verifyConfigContextUpdated(x.id);
});

bthread("DeviceRoleRequest lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDeviceRoleRequest(x.id);
  updateDeviceRoleRequest(x.id);
  updateDeviceRoleRequest(x.id);
  verifyDeviceRoleRequestExists(x.id);
  verifyDeviceRoleRequestUpdated(x.id);
});

bthread("IPAddress lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIPAddress(x.id);
  updateIPAddress(x.id);
  updateIPAddress(x.id);
  verifyIPAddressExists(x.id);
  verifyIPAddressUpdated(x.id);
});

bthread("NestedTag lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedTag(x.id);
  updateNestedTag(x.id);
  updateNestedTag(x.id);
  verifyNestedTagExists(x.id);
  verifyNestedTagUpdated(x.id);
});

bthread("ObjectType lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addObjectType(x.id);
  updateObjectType(x.id);
  updateObjectType(x.id);
  verifyObjectTypeExists(x.id);
  verifyObjectTypeUpdated(x.id);
});

bthread("PaginatedDeviceTypeList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedDeviceTypeList(x.id);
  updatePaginatedDeviceTypeList(x.id);
  updatePaginatedDeviceTypeList(x.id);
  verifyPaginatedDeviceTypeListExists(x.id);
  verifyPaginatedDeviceTypeListUpdated(x.id);
});

bthread("WritableIKEPolicyRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableIKEPolicyRequest(x.id);
  updateWritableIKEPolicyRequest(x.id);
  updateWritableIKEPolicyRequest(x.id);
  verifyWritableIKEPolicyRequestExists(x.id);
  verifyWritableIKEPolicyRequestUpdated(x.id);
});

bthread("BriefClusterType lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefClusterType(x.id);
  updateBriefClusterType(x.id);
  updateBriefClusterType(x.id);
  verifyBriefClusterTypeExists(x.id);
  verifyBriefClusterTypeUpdated(x.id);
});

bthread("ConsolePortRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConsolePortRequest(x.id);
  updateConsolePortRequest(x.id);
  updateConsolePortRequest(x.id);
  verifyConsolePortRequestExists(x.id);
  verifyConsolePortRequestUpdated(x.id);
});

bthread("GroupRequest lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGroupRequest(x.id);
  updateGroupRequest(x.id);
  updateGroupRequest(x.id);
  verifyGroupRequestExists(x.id);
  verifyGroupRequestUpdated(x.id);
});

bthread("NestedIPAddressRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedIPAddressRequest(x.id);
  updateNestedIPAddressRequest(x.id);
  updateNestedIPAddressRequest(x.id);
  verifyNestedIPAddressRequestExists(x.id);
  verifyNestedIPAddressRequestUpdated(x.id);
});

bthread("VirtualCircuitRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualCircuitRequest(x.id);
  updateVirtualCircuitRequest(x.id);
  updateVirtualCircuitRequest(x.id);
  verifyVirtualCircuitRequestExists(x.id);
  verifyVirtualCircuitRequestUpdated(x.id);
});

bthread("Role lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRole(x.id);
  updateRole(x.id);
  updateRole(x.id);
  verifyRoleExists(x.id);
  verifyRoleUpdated(x.id);
});

bthread("PatchedWritableDeviceWithConfigContextRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableDeviceWithConfigContextRequest(x.id);
  updatePatchedWritableDeviceWithConfigContextRequest(x.id);
  updatePatchedWritableDeviceWithConfigContextRequest(x.id);
  verifyPatchedWritableDeviceWithConfigContextRequestExists(x.id);
  verifyPatchedWritableDeviceWithConfigContextRequestUpdated(x.id);
});

bthread("BriefInterface lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefInterface(x.id);
  updateBriefInterface(x.id);
  updateBriefInterface(x.id);
  verifyBriefInterfaceExists(x.id);
  verifyBriefInterfaceUpdated(x.id);
});

bthread("PatchedRouteTargetRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedRouteTargetRequest(x.id);
  updatePatchedRouteTargetRequest(x.id);
  updatePatchedRouteTargetRequest(x.id);
  verifyPatchedRouteTargetRequestExists(x.id);
  verifyPatchedRouteTargetRequestUpdated(x.id);
});

bthread("PatchedContactRoleRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedContactRoleRequest(x.id);
  updatePatchedContactRoleRequest(x.id);
  updatePatchedContactRoleRequest(x.id);
  verifyPatchedContactRoleRequestExists(x.id);
  verifyPatchedContactRoleRequestUpdated(x.id);
});

bthread("PatchedModuleBayTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedModuleBayTemplateRequest(x.id);
  updatePatchedModuleBayTemplateRequest(x.id);
  updatePatchedModuleBayTemplateRequest(x.id);
  verifyPatchedModuleBayTemplateRequestExists(x.id);
  verifyPatchedModuleBayTemplateRequestUpdated(x.id);
});

bthread("BriefMACAddress lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefMACAddress(x.id);
  updateBriefMACAddress(x.id);
  updateBriefMACAddress(x.id);
  verifyBriefMACAddressExists(x.id);
  verifyBriefMACAddressUpdated(x.id);
});

bthread("BriefModuleTypeRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefModuleTypeRequest(x.id);
  updateBriefModuleTypeRequest(x.id);
  updateBriefModuleTypeRequest(x.id);
  verifyBriefModuleTypeRequestExists(x.id);
  verifyBriefModuleTypeRequestUpdated(x.id);
});

bthread("RackRole lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRackRole(x.id);
  updateRackRole(x.id);
  updateRackRole(x.id);
  verifyRackRoleExists(x.id);
  verifyRackRoleUpdated(x.id);
});

bthread("WritableFrontPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableFrontPortTemplateRequest(x.id);
  updateWritableFrontPortTemplateRequest(x.id);
  updateWritableFrontPortTemplateRequest(x.id);
  verifyWritableFrontPortTemplateRequestExists(x.id);
  verifyWritableFrontPortTemplateRequestUpdated(x.id);
});

bthread("PaginatedCustomFieldList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedCustomFieldList(x.id);
  updatePaginatedCustomFieldList(x.id);
  updatePaginatedCustomFieldList(x.id);
  verifyPaginatedCustomFieldListExists(x.id);
  verifyPaginatedCustomFieldListUpdated(x.id);
});

bthread("NestedSiteGroup lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedSiteGroup(x.id);
  updateNestedSiteGroup(x.id);
  updateNestedSiteGroup(x.id);
  verifyNestedSiteGroupExists(x.id);
  verifyNestedSiteGroupUpdated(x.id);
});

bthread("NestedSiteGroupRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedSiteGroupRequest(x.id);
  updateNestedSiteGroupRequest(x.id);
  updateNestedSiteGroupRequest(x.id);
  verifyNestedSiteGroupRequestExists(x.id);
  verifyNestedSiteGroupRequestUpdated(x.id);
});

bthread("PatchedFHRPGroupAssignmentRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedFHRPGroupAssignmentRequest(x.id);
  updatePatchedFHRPGroupAssignmentRequest(x.id);
  updatePatchedFHRPGroupAssignmentRequest(x.id);
  verifyPatchedFHRPGroupAssignmentRequestExists(x.id);
  verifyPatchedFHRPGroupAssignmentRequestUpdated(x.id);
});

bthread("PaginatedNotificationGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedNotificationGroupList(x.id);
  updatePaginatedNotificationGroupList(x.id);
  updatePaginatedNotificationGroupList(x.id);
  verifyPaginatedNotificationGroupListExists(x.id);
  verifyPaginatedNotificationGroupListUpdated(x.id);
});

bthread("WritableRackReservationRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableRackReservationRequest(x.id);
  updateWritableRackReservationRequest(x.id);
  updateWritableRackReservationRequest(x.id);
  verifyWritableRackReservationRequestExists(x.id);
  verifyWritableRackReservationRequestUpdated(x.id);
});

bthread("Bookmark lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBookmark(x.id);
  updateBookmark(x.id);
  updateBookmark(x.id);
  verifyBookmarkExists(x.id);
  verifyBookmarkUpdated(x.id);
});

bthread("PatchedWritableIPRangeRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableIPRangeRequest(x.id);
  updatePatchedWritableIPRangeRequest(x.id);
  updatePatchedWritableIPRangeRequest(x.id);
  verifyPatchedWritableIPRangeRequestExists(x.id);
  verifyPatchedWritableIPRangeRequestUpdated(x.id);
});

bthread("BriefCluster lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCluster(x.id);
  updateBriefCluster(x.id);
  updateBriefCluster(x.id);
  verifyBriefClusterExists(x.id);
  verifyBriefClusterUpdated(x.id);
});

bthread("BriefClusterGroup lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefClusterGroup(x.id);
  updateBriefClusterGroup(x.id);
  updateBriefClusterGroup(x.id);
  verifyBriefClusterGroupExists(x.id);
  verifyBriefClusterGroupUpdated(x.id);
});

bthread("PaginatedClusterTypeList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedClusterTypeList(x.id);
  updatePaginatedClusterTypeList(x.id);
  updatePaginatedClusterTypeList(x.id);
  verifyPaginatedClusterTypeListExists(x.id);
  verifyPaginatedClusterTypeListUpdated(x.id);
});

bthread("PaginatedWirelessLANGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedWirelessLANGroupList(x.id);
  updatePaginatedWirelessLANGroupList(x.id);
  updatePaginatedWirelessLANGroupList(x.id);
  verifyPaginatedWirelessLANGroupListExists(x.id);
  verifyPaginatedWirelessLANGroupListUpdated(x.id);
});

bthread("RearPort lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRearPort(x.id);
  updateRearPort(x.id);
  updateRearPort(x.id);
  verifyRearPortExists(x.id);
  verifyRearPortUpdated(x.id);
});

bthread("ImageAttachment lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addImageAttachment(x.id);
  updateImageAttachment(x.id);
  updateImageAttachment(x.id);
  verifyImageAttachmentExists(x.id);
  verifyImageAttachmentUpdated(x.id);
});

bthread("BackgroundTaskRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBackgroundTaskRequest(x.id);
  updateBackgroundTaskRequest(x.id);
  updateBackgroundTaskRequest(x.id);
  verifyBackgroundTaskRequestExists(x.id);
  verifyBackgroundTaskRequestUpdated(x.id);
});

bthread("VirtualCircuitTerminationRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualCircuitTerminationRequest(x.id);
  updateVirtualCircuitTerminationRequest(x.id);
  updateVirtualCircuitTerminationRequest(x.id);
  verifyVirtualCircuitTerminationRequestExists(x.id);
  verifyVirtualCircuitTerminationRequestUpdated(x.id);
});

bthread("ContactAssignment lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addContactAssignment(x.id);
  updateContactAssignment(x.id);
  updateContactAssignment(x.id);
  verifyContactAssignmentExists(x.id);
  verifyContactAssignmentUpdated(x.id);
});

bthread("BriefIPAddress lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefIPAddress(x.id);
  updateBriefIPAddress(x.id);
  updateBriefIPAddress(x.id);
  verifyBriefIPAddressExists(x.id);
  verifyBriefIPAddressUpdated(x.id);
});

bthread("IKEPolicy lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIKEPolicy(x.id);
  updateIKEPolicy(x.id);
  updateIKEPolicy(x.id);
  verifyIKEPolicyExists(x.id);
  verifyIKEPolicyUpdated(x.id);
});

bthread("PaginatedVirtualDeviceContextList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVirtualDeviceContextList(x.id);
  updatePaginatedVirtualDeviceContextList(x.id);
  updatePaginatedVirtualDeviceContextList(x.id);
  verifyPaginatedVirtualDeviceContextListExists(x.id);
  verifyPaginatedVirtualDeviceContextListUpdated(x.id);
});

bthread("BriefRackTypeRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRackTypeRequest(x.id);
  updateBriefRackTypeRequest(x.id);
  updateBriefRackTypeRequest(x.id);
  verifyBriefRackTypeRequestExists(x.id);
  verifyBriefRackTypeRequestUpdated(x.id);
});

bthread("BriefConfigContextProfile lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefConfigContextProfile(x.id);
  updateBriefConfigContextProfile(x.id);
  updateBriefConfigContextProfile(x.id);
  verifyBriefConfigContextProfileExists(x.id);
  verifyBriefConfigContextProfileUpdated(x.id);
});

bthread("IKEPolicyRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIKEPolicyRequest(x.id);
  updateIKEPolicyRequest(x.id);
  updateIKEPolicyRequest(x.id);
  verifyIKEPolicyRequestExists(x.id);
  verifyIKEPolicyRequestUpdated(x.id);
});

bthread("PaginatedVirtualMachineWithConfigContextList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVirtualMachineWithConfigContextList(x.id);
  updatePaginatedVirtualMachineWithConfigContextList(x.id);
  updatePaginatedVirtualMachineWithConfigContextList(x.id);
  verifyPaginatedVirtualMachineWithConfigContextListExists(x.id);
  verifyPaginatedVirtualMachineWithConfigContextListUpdated(x.id);
});

bthread("CircuitTypeRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitTypeRequest(x.id);
  updateCircuitTypeRequest(x.id);
  updateCircuitTypeRequest(x.id);
  verifyCircuitTypeRequestExists(x.id);
  verifyCircuitTypeRequestUpdated(x.id);
});

bthread("WritableIPSecProfileRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableIPSecProfileRequest(x.id);
  updateWritableIPSecProfileRequest(x.id);
  updateWritableIPSecProfileRequest(x.id);
  verifyWritableIPSecProfileRequestExists(x.id);
  verifyWritableIPSecProfileRequestUpdated(x.id);
});

bthread("ServiceRequest lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addServiceRequest(x.id);
  updateServiceRequest(x.id);
  updateServiceRequest(x.id);
  verifyServiceRequestExists(x.id);
  verifyServiceRequestUpdated(x.id);
});

bthread("VirtualMachineWithConfigContextRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualMachineWithConfigContextRequest(x.id);
  updateVirtualMachineWithConfigContextRequest(x.id);
  updateVirtualMachineWithConfigContextRequest(x.id);
  verifyVirtualMachineWithConfigContextRequestExists(x.id);
  verifyVirtualMachineWithConfigContextRequestUpdated(x.id);
});

bthread("EventRuleRequest lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addEventRuleRequest(x.id);
  updateEventRuleRequest(x.id);
  updateEventRuleRequest(x.id);
  verifyEventRuleRequestExists(x.id);
  verifyEventRuleRequestUpdated(x.id);
});

bthread("BriefTunnelRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefTunnelRequest(x.id);
  updateBriefTunnelRequest(x.id);
  updateBriefTunnelRequest(x.id);
  verifyBriefTunnelRequestExists(x.id);
  verifyBriefTunnelRequestUpdated(x.id);
});

bthread("BriefTenant lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefTenant(x.id);
  updateBriefTenant(x.id);
  updateBriefTenant(x.id);
  verifyBriefTenantExists(x.id);
  verifyBriefTenantUpdated(x.id);
});

bthread("PatchedWritableIPSecProfileRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableIPSecProfileRequest(x.id);
  updatePatchedWritableIPSecProfileRequest(x.id);
  updatePatchedWritableIPSecProfileRequest(x.id);
  verifyPatchedWritableIPSecProfileRequestExists(x.id);
  verifyPatchedWritableIPSecProfileRequestUpdated(x.id);
});

bthread("PaginatedFHRPGroupAssignmentList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedFHRPGroupAssignmentList(x.id);
  updatePaginatedFHRPGroupAssignmentList(x.id);
  updatePaginatedFHRPGroupAssignmentList(x.id);
  verifyPaginatedFHRPGroupAssignmentListExists(x.id);
  verifyPaginatedFHRPGroupAssignmentListUpdated(x.id);
});

bthread("PaginatedModuleBayList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedModuleBayList(x.id);
  updatePaginatedModuleBayList(x.id);
  updatePaginatedModuleBayList(x.id);
  verifyPaginatedModuleBayListExists(x.id);
  verifyPaginatedModuleBayListUpdated(x.id);
});

bthread("PaginatedDeviceWithConfigContextList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedDeviceWithConfigContextList(x.id);
  updatePaginatedDeviceWithConfigContextList(x.id);
  updatePaginatedDeviceWithConfigContextList(x.id);
  verifyPaginatedDeviceWithConfigContextListExists(x.id);
  verifyPaginatedDeviceWithConfigContextListUpdated(x.id);
});

bthread("VirtualChassisRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualChassisRequest(x.id);
  updateVirtualChassisRequest(x.id);
  updateVirtualChassisRequest(x.id);
  verifyVirtualChassisRequestExists(x.id);
  verifyVirtualChassisRequestUpdated(x.id);
});

bthread("WritableSiteGroupRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableSiteGroupRequest(x.id);
  updateWritableSiteGroupRequest(x.id);
  updateWritableSiteGroupRequest(x.id);
  verifyWritableSiteGroupRequestExists(x.id);
  verifyWritableSiteGroupRequestUpdated(x.id);
});

bthread("IPSecProfile lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIPSecProfile(x.id);
  updateIPSecProfile(x.id);
  updateIPSecProfile(x.id);
  verifyIPSecProfileExists(x.id);
  verifyIPSecProfileUpdated(x.id);
});

bthread("BriefL2VPNTermination lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefL2VPNTermination(x.id);
  updateBriefL2VPNTermination(x.id);
  updateBriefL2VPNTermination(x.id);
  verifyBriefL2VPNTerminationExists(x.id);
  verifyBriefL2VPNTerminationUpdated(x.id);
});

bthread("BriefConfigTemplateRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefConfigTemplateRequest(x.id);
  updateBriefConfigTemplateRequest(x.id);
  updateBriefConfigTemplateRequest(x.id);
  verifyBriefConfigTemplateRequestExists(x.id);
  verifyBriefConfigTemplateRequestUpdated(x.id);
});

bthread("PaginatedVLANGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVLANGroupList(x.id);
  updatePaginatedVLANGroupList(x.id);
  updatePaginatedVLANGroupList(x.id);
  verifyPaginatedVLANGroupListExists(x.id);
  verifyPaginatedVLANGroupListUpdated(x.id);
});

bthread("PatchedRackRoleRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedRackRoleRequest(x.id);
  updatePatchedRackRoleRequest(x.id);
  updatePatchedRackRoleRequest(x.id);
  verifyPatchedRackRoleRequestExists(x.id);
  verifyPatchedRackRoleRequestUpdated(x.id);
});

bthread("VMInterfaceRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVMInterfaceRequest(x.id);
  updateVMInterfaceRequest(x.id);
  updateVMInterfaceRequest(x.id);
  verifyVMInterfaceRequestExists(x.id);
  verifyVMInterfaceRequestUpdated(x.id);
});

bthread("Tag lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTag(x.id);
  updateTag(x.id);
  updateTag(x.id);
  verifyTagExists(x.id);
  verifyTagUpdated(x.id);
});

bthread("BriefTenantRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefTenantRequest(x.id);
  updateBriefTenantRequest(x.id);
  updateBriefTenantRequest(x.id);
  verifyBriefTenantRequestExists(x.id);
  verifyBriefTenantRequestUpdated(x.id);
});

bthread("Cable lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCable(x.id);
  updateCable(x.id);
  updateCable(x.id);
  verifyCableExists(x.id);
  verifyCableUpdated(x.id);
});

bthread("CircuitGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitGroup(x.id);
  updateCircuitGroup(x.id);
  updateCircuitGroup(x.id);
  verifyCircuitGroupExists(x.id);
  verifyCircuitGroupUpdated(x.id);
});

bthread("PatchedObjectPermissionRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedObjectPermissionRequest(x.id);
  updatePatchedObjectPermissionRequest(x.id);
  updatePatchedObjectPermissionRequest(x.id);
  verifyPatchedObjectPermissionRequestExists(x.id);
  verifyPatchedObjectPermissionRequestUpdated(x.id);
});

bthread("FHRPGroup lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFHRPGroup(x.id);
  updateFHRPGroup(x.id);
  updateFHRPGroup(x.id);
  verifyFHRPGroupExists(x.id);
  verifyFHRPGroupUpdated(x.id);
});

bthread("IPRange lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIPRange(x.id);
  updateIPRange(x.id);
  updateIPRange(x.id);
  verifyIPRangeExists(x.id);
  verifyIPRangeUpdated(x.id);
});

bthread("ModuleBayRequest lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModuleBayRequest(x.id);
  updateModuleBayRequest(x.id);
  updateModuleBayRequest(x.id);
  verifyModuleBayRequestExists(x.id);
  verifyModuleBayRequestUpdated(x.id);
});

bthread("ModuleType lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModuleType(x.id);
  updateModuleType(x.id);
  updateModuleType(x.id);
  verifyModuleTypeExists(x.id);
  verifyModuleTypeUpdated(x.id);
});

bthread("BriefVirtualCircuitType lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVirtualCircuitType(x.id);
  updateBriefVirtualCircuitType(x.id);
  updateBriefVirtualCircuitType(x.id);
  verifyBriefVirtualCircuitTypeExists(x.id);
  verifyBriefVirtualCircuitTypeUpdated(x.id);
});

bthread("PaginatedRoleList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRoleList(x.id);
  updatePaginatedRoleList(x.id);
  updatePaginatedRoleList(x.id);
  verifyPaginatedRoleListExists(x.id);
  verifyPaginatedRoleListUpdated(x.id);
});

bthread("Tunnel lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTunnel(x.id);
  updateTunnel(x.id);
  updateTunnel(x.id);
  verifyTunnelExists(x.id);
  verifyTunnelUpdated(x.id);
});

bthread("BriefVRFRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVRFRequest(x.id);
  updateBriefVRFRequest(x.id);
  updateBriefVRFRequest(x.id);
  verifyBriefVRFRequestExists(x.id);
  verifyBriefVRFRequestUpdated(x.id);
});

bthread("RoleRequest lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRoleRequest(x.id);
  updateRoleRequest(x.id);
  updateRoleRequest(x.id);
  verifyRoleRequestExists(x.id);
  verifyRoleRequestUpdated(x.id);
});

bthread("ConsolePortTemplate lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConsolePortTemplate(x.id);
  updateConsolePortTemplate(x.id);
  updateConsolePortTemplate(x.id);
  verifyConsolePortTemplateExists(x.id);
  verifyConsolePortTemplateUpdated(x.id);
});

bthread("UserRequest lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUserRequest(x.id);
  updateUserRequest(x.id);
  updateUserRequest(x.id);
  verifyUserRequestExists(x.id);
  verifyUserRequestUpdated(x.id);
});

bthread("WritableContactAssignmentRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableContactAssignmentRequest(x.id);
  updateWritableContactAssignmentRequest(x.id);
  updateWritableContactAssignmentRequest(x.id);
  verifyWritableContactAssignmentRequestExists(x.id);
  verifyWritableContactAssignmentRequestUpdated(x.id);
});

bthread("Cluster lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCluster(x.id);
  updateCluster(x.id);
  updateCluster(x.id);
  verifyClusterExists(x.id);
  verifyClusterUpdated(x.id);
});

bthread("IPSecProposal lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIPSecProposal(x.id);
  updateIPSecProposal(x.id);
  updateIPSecProposal(x.id);
  verifyIPSecProposalExists(x.id);
  verifyIPSecProposalUpdated(x.id);
});

bthread("PaginatedPowerOutletTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedPowerOutletTemplateList(x.id);
  updatePaginatedPowerOutletTemplateList(x.id);
  updatePaginatedPowerOutletTemplateList(x.id);
  verifyPaginatedPowerOutletTemplateListExists(x.id);
  verifyPaginatedPowerOutletTemplateListUpdated(x.id);
});

bthread("FrontPortRearPortRequest lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFrontPortRearPortRequest(x.id);
  updateFrontPortRearPortRequest(x.id);
  updateFrontPortRearPortRequest(x.id);
  verifyFrontPortRearPortRequestExists(x.id);
  verifyFrontPortRearPortRequestUpdated(x.id);
});

bthread("WritableClusterRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableClusterRequest(x.id);
  updateWritableClusterRequest(x.id);
  updateWritableClusterRequest(x.id);
  verifyWritableClusterRequestExists(x.id);
  verifyWritableClusterRequestUpdated(x.id);
});

bthread("NestedProviderAccount lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedProviderAccount(x.id);
  updateNestedProviderAccount(x.id);
  updateNestedProviderAccount(x.id);
  verifyNestedProviderAccountExists(x.id);
  verifyNestedProviderAccountUpdated(x.id);
});

bthread("PatchedDashboardRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedDashboardRequest(x.id);
  updatePatchedDashboardRequest(x.id);
  updatePatchedDashboardRequest(x.id);
  verifyPatchedDashboardRequestExists(x.id);
  verifyPatchedDashboardRequestUpdated(x.id);
});

bthread("PowerPanelRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerPanelRequest(x.id);
  updatePowerPanelRequest(x.id);
  updatePowerPanelRequest(x.id);
  verifyPowerPanelRequestExists(x.id);
  verifyPowerPanelRequestUpdated(x.id);
});

bthread("NestedVirtualMachineRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedVirtualMachineRequest(x.id);
  updateNestedVirtualMachineRequest(x.id);
  updateNestedVirtualMachineRequest(x.id);
  verifyNestedVirtualMachineRequestExists(x.id);
  verifyNestedVirtualMachineRequestUpdated(x.id);
});

bthread("BriefPowerPanel lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefPowerPanel(x.id);
  updateBriefPowerPanel(x.id);
  updateBriefPowerPanel(x.id);
  verifyBriefPowerPanelExists(x.id);
  verifyBriefPowerPanelUpdated(x.id);
});

bthread("WritableIKEProposalRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableIKEProposalRequest(x.id);
  updateWritableIKEProposalRequest(x.id);
  updateWritableIKEProposalRequest(x.id);
  verifyWritableIKEProposalRequestExists(x.id);
  verifyWritableIKEProposalRequestUpdated(x.id);
});

bthread("PaginatedFHRPGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedFHRPGroupList(x.id);
  updatePaginatedFHRPGroupList(x.id);
  updatePaginatedFHRPGroupList(x.id);
  verifyPaginatedFHRPGroupListExists(x.id);
  verifyPaginatedFHRPGroupListUpdated(x.id);
});

bthread("BriefRole lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRole(x.id);
  updateBriefRole(x.id);
  updateBriefRole(x.id);
  verifyBriefRoleExists(x.id);
  verifyBriefRoleUpdated(x.id);
});

bthread("PaginatedCircuitList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedCircuitList(x.id);
  updatePaginatedCircuitList(x.id);
  updatePaginatedCircuitList(x.id);
  verifyPaginatedCircuitListExists(x.id);
  verifyPaginatedCircuitListUpdated(x.id);
});

bthread("PatchedWritableSiteRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableSiteRequest(x.id);
  updatePatchedWritableSiteRequest(x.id);
  updatePatchedWritableSiteRequest(x.id);
  verifyPatchedWritableSiteRequestExists(x.id);
  verifyPatchedWritableSiteRequestUpdated(x.id);
});

bthread("PaginatedTunnelGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedTunnelGroupList(x.id);
  updatePaginatedTunnelGroupList(x.id);
  updatePaginatedTunnelGroupList(x.id);
  verifyPaginatedTunnelGroupListExists(x.id);
  verifyPaginatedTunnelGroupListUpdated(x.id);
});

bthread("VirtualCircuitTypeRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualCircuitTypeRequest(x.id);
  updateVirtualCircuitTypeRequest(x.id);
  updateVirtualCircuitTypeRequest(x.id);
  verifyVirtualCircuitTypeRequestExists(x.id);
  verifyVirtualCircuitTypeRequestUpdated(x.id);
});

bthread("BriefCircuitType lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCircuitType(x.id);
  updateBriefCircuitType(x.id);
  updateBriefCircuitType(x.id);
  verifyBriefCircuitTypeExists(x.id);
  verifyBriefCircuitTypeUpdated(x.id);
});

bthread("TunnelGroup lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTunnelGroup(x.id);
  updateTunnelGroup(x.id);
  updateTunnelGroup(x.id);
  verifyTunnelGroupExists(x.id);
  verifyTunnelGroupUpdated(x.id);
});

bthread("BriefProvider lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefProvider(x.id);
  updateBriefProvider(x.id);
  updateBriefProvider(x.id);
  verifyBriefProviderExists(x.id);
  verifyBriefProviderUpdated(x.id);
});

bthread("L2VPNTerminationRequest lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addL2VPNTerminationRequest(x.id);
  updateL2VPNTerminationRequest(x.id);
  updateL2VPNTerminationRequest(x.id);
  verifyL2VPNTerminationRequestExists(x.id);
  verifyL2VPNTerminationRequestUpdated(x.id);
});

bthread("PatchedGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedGroupRequest(x.id);
  updatePatchedGroupRequest(x.id);
  updatePatchedGroupRequest(x.id);
  verifyPatchedGroupRequestExists(x.id);
  verifyPatchedGroupRequestUpdated(x.id);
});

bthread("PatchedWritableConsolePortTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableConsolePortTemplateRequest(x.id);
  updatePatchedWritableConsolePortTemplateRequest(x.id);
  updatePatchedWritableConsolePortTemplateRequest(x.id);
  verifyPatchedWritableConsolePortTemplateRequestExists(x.id);
  verifyPatchedWritableConsolePortTemplateRequestUpdated(x.id);
});

bthread("AvailableASN lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAvailableASN(x.id);
  updateAvailableASN(x.id);
  updateAvailableASN(x.id);
  verifyAvailableASNExists(x.id);
  verifyAvailableASNUpdated(x.id);
});

bthread("BriefDeviceRole lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefDeviceRole(x.id);
  updateBriefDeviceRole(x.id);
  updateBriefDeviceRole(x.id);
  verifyBriefDeviceRoleExists(x.id);
  verifyBriefDeviceRoleUpdated(x.id);
});

bthread("VirtualDisk lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualDisk(x.id);
  updateVirtualDisk(x.id);
  updateVirtualDisk(x.id);
  verifyVirtualDiskExists(x.id);
  verifyVirtualDiskUpdated(x.id);
});

bthread("IKEProposalRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIKEProposalRequest(x.id);
  updateIKEProposalRequest(x.id);
  updateIKEProposalRequest(x.id);
  verifyIKEProposalRequestExists(x.id);
  verifyIKEProposalRequestUpdated(x.id);
});

bthread("PatchedTunnelGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedTunnelGroupRequest(x.id);
  updatePatchedTunnelGroupRequest(x.id);
  updatePatchedTunnelGroupRequest(x.id);
  verifyPatchedTunnelGroupRequestExists(x.id);
  verifyPatchedTunnelGroupRequestUpdated(x.id);
});

bthread("BriefModuleRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefModuleRequest(x.id);
  updateBriefModuleRequest(x.id);
  updateBriefModuleRequest(x.id);
  verifyBriefModuleRequestExists(x.id);
  verifyBriefModuleRequestUpdated(x.id);
});

bthread("PaginatedFrontPortList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedFrontPortList(x.id);
  updatePaginatedFrontPortList(x.id);
  updatePaginatedFrontPortList(x.id);
  verifyPaginatedFrontPortListExists(x.id);
  verifyPaginatedFrontPortListUpdated(x.id);
});

bthread("BriefVLANGroup lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVLANGroup(x.id);
  updateBriefVLANGroup(x.id);
  updateBriefVLANGroup(x.id);
  verifyBriefVLANGroupExists(x.id);
  verifyBriefVLANGroupUpdated(x.id);
});

bthread("NotificationGroup lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNotificationGroup(x.id);
  updateNotificationGroup(x.id);
  updateNotificationGroup(x.id);
  verifyNotificationGroupExists(x.id);
  verifyNotificationGroupUpdated(x.id);
});

bthread("PaginatedMACAddressList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedMACAddressList(x.id);
  updatePaginatedMACAddressList(x.id);
  updatePaginatedMACAddressList(x.id);
  verifyPaginatedMACAddressListExists(x.id);
  verifyPaginatedMACAddressListUpdated(x.id);
});

bthread("PatchedWritableIKEPolicyRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableIKEPolicyRequest(x.id);
  updatePatchedWritableIKEPolicyRequest(x.id);
  updatePatchedWritableIKEPolicyRequest(x.id);
  verifyPatchedWritableIKEPolicyRequestExists(x.id);
  verifyPatchedWritableIKEPolicyRequestUpdated(x.id);
});

bthread("MACAddressRequest lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMACAddressRequest(x.id);
  updateMACAddressRequest(x.id);
  updateMACAddressRequest(x.id);
  verifyMACAddressRequestExists(x.id);
  verifyMACAddressRequestUpdated(x.id);
});

bthread("PaginatedInterfaceTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedInterfaceTemplateList(x.id);
  updatePaginatedInterfaceTemplateList(x.id);
  updatePaginatedInterfaceTemplateList(x.id);
  verifyPaginatedInterfaceTemplateListExists(x.id);
  verifyPaginatedInterfaceTemplateListUpdated(x.id);
});

bthread("BriefPlatform lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefPlatform(x.id);
  updateBriefPlatform(x.id);
  updateBriefPlatform(x.id);
  verifyBriefPlatformExists(x.id);
  verifyBriefPlatformUpdated(x.id);
});

bthread("PowerFeedRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerFeedRequest(x.id);
  updatePowerFeedRequest(x.id);
  updatePowerFeedRequest(x.id);
  verifyPowerFeedRequestExists(x.id);
  verifyPowerFeedRequestUpdated(x.id);
});

bthread("PaginatedSubscriptionList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedSubscriptionList(x.id);
  updatePaginatedSubscriptionList(x.id);
  updatePaginatedSubscriptionList(x.id);
  verifyPaginatedSubscriptionListExists(x.id);
  verifyPaginatedSubscriptionListUpdated(x.id);
});

bthread("WritableInterfaceRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableInterfaceRequest(x.id);
  updateWritableInterfaceRequest(x.id);
  updateWritableInterfaceRequest(x.id);
  verifyWritableInterfaceRequestExists(x.id);
  verifyWritableInterfaceRequestUpdated(x.id);
});

bthread("BriefTag lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefTag(x.id);
  updateBriefTag(x.id);
  updateBriefTag(x.id);
  verifyBriefTagExists(x.id);
  verifyBriefTagUpdated(x.id);
});

bthread("ASNRange lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addASNRange(x.id);
  updateASNRange(x.id);
  updateASNRange(x.id);
  verifyASNRangeExists(x.id);
  verifyASNRangeUpdated(x.id);
});

bthread("PaginatedIKEPolicyList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedIKEPolicyList(x.id);
  updatePaginatedIKEPolicyList(x.id);
  updatePaginatedIKEPolicyList(x.id);
  verifyPaginatedIKEPolicyListExists(x.id);
  verifyPaginatedIKEPolicyListUpdated(x.id);
});

bthread("PatchedVirtualCircuitTypeRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedVirtualCircuitTypeRequest(x.id);
  updatePatchedVirtualCircuitTypeRequest(x.id);
  updatePatchedVirtualCircuitTypeRequest(x.id);
  verifyPatchedVirtualCircuitTypeRequestExists(x.id);
  verifyPatchedVirtualCircuitTypeRequestUpdated(x.id);
});

bthread("WritableEventRuleRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableEventRuleRequest(x.id);
  updateWritableEventRuleRequest(x.id);
  updateWritableEventRuleRequest(x.id);
  verifyWritableEventRuleRequestExists(x.id);
  verifyWritableEventRuleRequestUpdated(x.id);
});

bthread("PaginatedAggregateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedAggregateList(x.id);
  updatePaginatedAggregateList(x.id);
  updatePaginatedAggregateList(x.id);
  verifyPaginatedAggregateListExists(x.id);
  verifyPaginatedAggregateListUpdated(x.id);
});

bthread("PatchedInventoryItemRoleRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedInventoryItemRoleRequest(x.id);
  updatePatchedInventoryItemRoleRequest(x.id);
  updatePatchedInventoryItemRoleRequest(x.id);
  verifyPatchedInventoryItemRoleRequestExists(x.id);
  verifyPatchedInventoryItemRoleRequestUpdated(x.id);
});

bthread("PatchedWritableWirelessLinkRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableWirelessLinkRequest(x.id);
  updatePatchedWritableWirelessLinkRequest(x.id);
  updatePatchedWritableWirelessLinkRequest(x.id);
  verifyPatchedWritableWirelessLinkRequestExists(x.id);
  verifyPatchedWritableWirelessLinkRequestUpdated(x.id);
});

bthread("PaginatedModuleBayTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedModuleBayTemplateList(x.id);
  updatePaginatedModuleBayTemplateList(x.id);
  updatePaginatedModuleBayTemplateList(x.id);
  verifyPaginatedModuleBayTemplateListExists(x.id);
  verifyPaginatedModuleBayTemplateListUpdated(x.id);
});

bthread("ProviderRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addProviderRequest(x.id);
  updateProviderRequest(x.id);
  updateProviderRequest(x.id);
  verifyProviderRequestExists(x.id);
  verifyProviderRequestUpdated(x.id);
});

bthread("BriefCable lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCable(x.id);
  updateBriefCable(x.id);
  updateBriefCable(x.id);
  verifyBriefCableExists(x.id);
  verifyBriefCableUpdated(x.id);
});

bthread("PaginatedConsolePortList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedConsolePortList(x.id);
  updatePaginatedConsolePortList(x.id);
  updatePaginatedConsolePortList(x.id);
  verifyPaginatedConsolePortListExists(x.id);
  verifyPaginatedConsolePortListUpdated(x.id);
});

bthread("PatchedWritablePowerFeedRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritablePowerFeedRequest(x.id);
  updatePatchedWritablePowerFeedRequest(x.id);
  updatePatchedWritablePowerFeedRequest(x.id);
  verifyPatchedWritablePowerFeedRequestExists(x.id);
  verifyPatchedWritablePowerFeedRequestUpdated(x.id);
});

bthread("ClusterGroup lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClusterGroup(x.id);
  updateClusterGroup(x.id);
  updateClusterGroup(x.id);
  verifyClusterGroupExists(x.id);
  verifyClusterGroupUpdated(x.id);
});

bthread("PaginatedCircuitTerminationList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedCircuitTerminationList(x.id);
  updatePaginatedCircuitTerminationList(x.id);
  updatePaginatedCircuitTerminationList(x.id);
  verifyPaginatedCircuitTerminationListExists(x.id);
  verifyPaginatedCircuitTerminationListUpdated(x.id);
});

bthread("WritableVirtualCircuitRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableVirtualCircuitRequest(x.id);
  updateWritableVirtualCircuitRequest(x.id);
  updateWritableVirtualCircuitRequest(x.id);
  verifyWritableVirtualCircuitRequestExists(x.id);
  verifyWritableVirtualCircuitRequestUpdated(x.id);
});

bthread("ContactGroupRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addContactGroupRequest(x.id);
  updateContactGroupRequest(x.id);
  updateContactGroupRequest(x.id);
  verifyContactGroupRequestExists(x.id);
  verifyContactGroupRequestUpdated(x.id);
});

bthread("ContactRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addContactRequest(x.id);
  updateContactRequest(x.id);
  updateContactRequest(x.id);
  verifyContactRequestExists(x.id);
  verifyContactRequestUpdated(x.id);
});

bthread("BriefRack lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRack(x.id);
  updateBriefRack(x.id);
  updateBriefRack(x.id);
  verifyBriefRackExists(x.id);
  verifyBriefRackUpdated(x.id);
});

bthread("ModuleTypeProfile lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModuleTypeProfile(x.id);
  updateModuleTypeProfile(x.id);
  updateModuleTypeProfile(x.id);
  verifyModuleTypeProfileExists(x.id);
  verifyModuleTypeProfileUpdated(x.id);
});

bthread("BriefConfigTemplate lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefConfigTemplate(x.id);
  updateBriefConfigTemplate(x.id);
  updateBriefConfigTemplate(x.id);
  verifyBriefConfigTemplateExists(x.id);
  verifyBriefConfigTemplateUpdated(x.id);
});

bthread("PaginatedRearPortList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRearPortList(x.id);
  updatePaginatedRearPortList(x.id);
  updatePaginatedRearPortList(x.id);
  verifyPaginatedRearPortListExists(x.id);
  verifyPaginatedRearPortListUpdated(x.id);
});

bthread("PatchedProviderAccountRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedProviderAccountRequest(x.id);
  updatePatchedProviderAccountRequest(x.id);
  updatePatchedProviderAccountRequest(x.id);
  verifyPatchedProviderAccountRequestExists(x.id);
  verifyPatchedProviderAccountRequestUpdated(x.id);
});

bthread("BriefLocationRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefLocationRequest(x.id);
  updateBriefLocationRequest(x.id);
  updateBriefLocationRequest(x.id);
  verifyBriefLocationRequestExists(x.id);
  verifyBriefLocationRequestUpdated(x.id);
});

bthread("PatchedASNRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedASNRequest(x.id);
  updatePatchedASNRequest(x.id);
  updatePatchedASNRequest(x.id);
  verifyPatchedASNRequestExists(x.id);
  verifyPatchedASNRequestUpdated(x.id);
});

bthread("NestedRegionRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedRegionRequest(x.id);
  updateNestedRegionRequest(x.id);
  updateNestedRegionRequest(x.id);
  verifyNestedRegionRequestExists(x.id);
  verifyNestedRegionRequestUpdated(x.id);
});

bthread("PatchedWritableFrontPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableFrontPortTemplateRequest(x.id);
  updatePatchedWritableFrontPortTemplateRequest(x.id);
  updatePatchedWritableFrontPortTemplateRequest(x.id);
  verifyPatchedWritableFrontPortTemplateRequestExists(x.id);
  verifyPatchedWritableFrontPortTemplateRequestUpdated(x.id);
});

bthread("DataSource lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDataSource(x.id);
  updateDataSource(x.id);
  updateDataSource(x.id);
  verifyDataSourceExists(x.id);
  verifyDataSourceUpdated(x.id);
});

bthread("PatchedWritableCircuitRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableCircuitRequest(x.id);
  updatePatchedWritableCircuitRequest(x.id);
  updatePatchedWritableCircuitRequest(x.id);
  verifyPatchedWritableCircuitRequestExists(x.id);
  verifyPatchedWritableCircuitRequestUpdated(x.id);
});

bthread("RIR lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRIR(x.id);
  updateRIR(x.id);
  updateRIR(x.id);
  verifyRIRExists(x.id);
  verifyRIRUpdated(x.id);
});

bthread("Module lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModule(x.id);
  updateModule(x.id);
  updateModule(x.id);
  verifyModuleExists(x.id);
  verifyModuleUpdated(x.id);
});

bthread("WritableL2VPNRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableL2VPNRequest(x.id);
  updateWritableL2VPNRequest(x.id);
  updateWritableL2VPNRequest(x.id);
  verifyWritableL2VPNRequestExists(x.id);
  verifyWritableL2VPNRequestUpdated(x.id);
});

bthread("BriefCircuitGroupAssignmentSerializer_ lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCircuitGroupAssignmentSerializer_(x.id);
  updateBriefCircuitGroupAssignmentSerializer_(x.id);
  updateBriefCircuitGroupAssignmentSerializer_(x.id);
  verifyBriefCircuitGroupAssignmentSerializer_Exists(x.id);
  verifyBriefCircuitGroupAssignmentSerializer_Updated(x.id);
});

bthread("PlatformRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPlatformRequest(x.id);
  updatePlatformRequest(x.id);
  updatePlatformRequest(x.id);
  verifyPlatformRequestExists(x.id);
  verifyPlatformRequestUpdated(x.id);
});

bthread("VLANTranslationRule lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVLANTranslationRule(x.id);
  updateVLANTranslationRule(x.id);
  updateVLANTranslationRule(x.id);
  verifyVLANTranslationRuleExists(x.id);
  verifyVLANTranslationRuleUpdated(x.id);
});

bthread("PatchedCustomLinkRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedCustomLinkRequest(x.id);
  updatePatchedCustomLinkRequest(x.id);
  updatePatchedCustomLinkRequest(x.id);
  verifyPatchedCustomLinkRequestExists(x.id);
  verifyPatchedCustomLinkRequestUpdated(x.id);
});

bthread("PaginatedServiceTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedServiceTemplateList(x.id);
  updatePaginatedServiceTemplateList(x.id);
  updatePaginatedServiceTemplateList(x.id);
  verifyPaginatedServiceTemplateListExists(x.id);
  verifyPaginatedServiceTemplateListUpdated(x.id);
});

bthread("PatchedPowerPanelRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedPowerPanelRequest(x.id);
  updatePatchedPowerPanelRequest(x.id);
  updatePatchedPowerPanelRequest(x.id);
  verifyPatchedPowerPanelRequestExists(x.id);
  verifyPatchedPowerPanelRequestUpdated(x.id);
});

bthread("PatchedWritableCustomFieldChoiceSetRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableCustomFieldChoiceSetRequest(x.id);
  updatePatchedWritableCustomFieldChoiceSetRequest(x.id);
  updatePatchedWritableCustomFieldChoiceSetRequest(x.id);
  verifyPatchedWritableCustomFieldChoiceSetRequestExists(x.id);
  verifyPatchedWritableCustomFieldChoiceSetRequestUpdated(x.id);
});

bthread("BriefUser lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefUser(x.id);
  updateBriefUser(x.id);
  updateBriefUser(x.id);
  verifyBriefUserExists(x.id);
  verifyBriefUserUpdated(x.id);
});

bthread("Contact lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addContact(x.id);
  updateContact(x.id);
  updateContact(x.id);
  verifyContactExists(x.id);
  verifyContactUpdated(x.id);
});

bthread("PatchedWritableVLANRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableVLANRequest(x.id);
  updatePatchedWritableVLANRequest(x.id);
  updatePatchedWritableVLANRequest(x.id);
  verifyPatchedWritableVLANRequestExists(x.id);
  verifyPatchedWritableVLANRequestUpdated(x.id);
});

bthread("Rack lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRack(x.id);
  updateRack(x.id);
  updateRack(x.id);
  verifyRackExists(x.id);
  verifyRackUpdated(x.id);
});

bthread("RegionRequest lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRegionRequest(x.id);
  updateRegionRequest(x.id);
  updateRegionRequest(x.id);
  verifyRegionRequestExists(x.id);
  verifyRegionRequestUpdated(x.id);
});

bthread("User lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUser(x.id);
  updateUser(x.id);
  updateUser(x.id);
  verifyUserExists(x.id);
  verifyUserUpdated(x.id);
});

bthread("CustomFieldChoiceSet lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomFieldChoiceSet(x.id);
  updateCustomFieldChoiceSet(x.id);
  updateCustomFieldChoiceSet(x.id);
  verifyCustomFieldChoiceSetExists(x.id);
  verifyCustomFieldChoiceSetUpdated(x.id);
});

bthread("PaginatedRackRoleList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRackRoleList(x.id);
  updatePaginatedRackRoleList(x.id);
  updatePaginatedRackRoleList(x.id);
  verifyPaginatedRackRoleListExists(x.id);
  verifyPaginatedRackRoleListUpdated(x.id);
});

bthread("Region lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRegion(x.id);
  updateRegion(x.id);
  updateRegion(x.id);
  verifyRegionExists(x.id);
  verifyRegionUpdated(x.id);
});

bthread("CircuitGroupRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitGroupRequest(x.id);
  updateCircuitGroupRequest(x.id);
  updateCircuitGroupRequest(x.id);
  verifyCircuitGroupRequestExists(x.id);
  verifyCircuitGroupRequestUpdated(x.id);
});

bthread("DeviceWithConfigContextRequest lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDeviceWithConfigContextRequest(x.id);
  updateDeviceWithConfigContextRequest(x.id);
  updateDeviceWithConfigContextRequest(x.id);
  verifyDeviceWithConfigContextRequestExists(x.id);
  verifyDeviceWithConfigContextRequestUpdated(x.id);
});

bthread("PatchedWritableTenantGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableTenantGroupRequest(x.id);
  updatePatchedWritableTenantGroupRequest(x.id);
  updatePatchedWritableTenantGroupRequest(x.id);
  verifyPatchedWritableTenantGroupRequestExists(x.id);
  verifyPatchedWritableTenantGroupRequestUpdated(x.id);
});

bthread("PatchedWritablePlatformRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritablePlatformRequest(x.id);
  updatePatchedWritablePlatformRequest(x.id);
  updatePatchedWritablePlatformRequest(x.id);
  verifyPatchedWritablePlatformRequestExists(x.id);
  verifyPatchedWritablePlatformRequestUpdated(x.id);
});

bthread("AvailablePrefix lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAvailablePrefix(x.id);
  updateAvailablePrefix(x.id);
  updateAvailablePrefix(x.id);
  verifyAvailablePrefixExists(x.id);
  verifyAvailablePrefixUpdated(x.id);
});

bthread("WritableContactGroupRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableContactGroupRequest(x.id);
  updateWritableContactGroupRequest(x.id);
  updateWritableContactGroupRequest(x.id);
  verifyWritableContactGroupRequestExists(x.id);
  verifyWritableContactGroupRequestUpdated(x.id);
});

bthread("GenericObjectRequest lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGenericObjectRequest(x.id);
  updateGenericObjectRequest(x.id);
  updateGenericObjectRequest(x.id);
  verifyGenericObjectRequestExists(x.id);
  verifyGenericObjectRequestUpdated(x.id);
});

bthread("BriefProviderAccount lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefProviderAccount(x.id);
  updateBriefProviderAccount(x.id);
  updateBriefProviderAccount(x.id);
  verifyBriefProviderAccountExists(x.id);
  verifyBriefProviderAccountUpdated(x.id);
});

bthread("ConsoleServerPortTemplate lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConsoleServerPortTemplate(x.id);
  updateConsoleServerPortTemplate(x.id);
  updateConsoleServerPortTemplate(x.id);
  verifyConsoleServerPortTemplateExists(x.id);
  verifyConsoleServerPortTemplateUpdated(x.id);
});

bthread("PaginatedPlatformList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedPlatformList(x.id);
  updatePaginatedPlatformList(x.id);
  updatePaginatedPlatformList(x.id);
  verifyPaginatedPlatformListExists(x.id);
  verifyPaginatedPlatformListUpdated(x.id);
});

bthread("BriefPowerPort lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefPowerPort(x.id);
  updateBriefPowerPort(x.id);
  updateBriefPowerPort(x.id);
  verifyBriefPowerPortExists(x.id);
  verifyBriefPowerPortUpdated(x.id);
});

bthread("NestedTenantGroup lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedTenantGroup(x.id);
  updateNestedTenantGroup(x.id);
  updateNestedTenantGroup(x.id);
  verifyNestedTenantGroupExists(x.id);
  verifyNestedTenantGroupUpdated(x.id);
});

bthread("PatchedModuleTypeProfileRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedModuleTypeProfileRequest(x.id);
  updatePatchedModuleTypeProfileRequest(x.id);
  updatePatchedModuleTypeProfileRequest(x.id);
  verifyPatchedModuleTypeProfileRequestExists(x.id);
  verifyPatchedModuleTypeProfileRequestUpdated(x.id);
});

bthread("PatchedWritableTunnelTerminationRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableTunnelTerminationRequest(x.id);
  updatePatchedWritableTunnelTerminationRequest(x.id);
  updatePatchedWritableTunnelTerminationRequest(x.id);
  verifyPatchedWritableTunnelTerminationRequestExists(x.id);
  verifyPatchedWritableTunnelTerminationRequestUpdated(x.id);
});

bthread("BriefInventoryItemRole lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefInventoryItemRole(x.id);
  updateBriefInventoryItemRole(x.id);
  updateBriefInventoryItemRole(x.id);
  verifyBriefInventoryItemRoleExists(x.id);
  verifyBriefInventoryItemRoleUpdated(x.id);
});

bthread("PaginatedObjectTypeList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedObjectTypeList(x.id);
  updatePaginatedObjectTypeList(x.id);
  updatePaginatedObjectTypeList(x.id);
  verifyPaginatedObjectTypeListExists(x.id);
  verifyPaginatedObjectTypeListUpdated(x.id);
});

bthread("Subscription lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSubscription(x.id);
  updateSubscription(x.id);
  updateSubscription(x.id);
  verifySubscriptionExists(x.id);
  verifySubscriptionUpdated(x.id);
});

bthread("BriefSiteGroupRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefSiteGroupRequest(x.id);
  updateBriefSiteGroupRequest(x.id);
  updateBriefSiteGroupRequest(x.id);
  verifyBriefSiteGroupRequestExists(x.id);
  verifyBriefSiteGroupRequestUpdated(x.id);
});

bthread("BriefTunnelGroupRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefTunnelGroupRequest(x.id);
  updateBriefTunnelGroupRequest(x.id);
  updateBriefTunnelGroupRequest(x.id);
  verifyBriefTunnelGroupRequestExists(x.id);
  verifyBriefTunnelGroupRequestUpdated(x.id);
});

bthread("WritableRearPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableRearPortTemplateRequest(x.id);
  updateWritableRearPortTemplateRequest(x.id);
  updateWritableRearPortTemplateRequest(x.id);
  verifyWritableRearPortTemplateRequestExists(x.id);
  verifyWritableRearPortTemplateRequestUpdated(x.id);
});

bthread("NestedInterface lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedInterface(x.id);
  updateNestedInterface(x.id);
  updateNestedInterface(x.id);
  verifyNestedInterfaceExists(x.id);
  verifyNestedInterfaceUpdated(x.id);
});

bthread("PatchedWritableConsoleServerPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableConsoleServerPortTemplateRequest(x.id);
  updatePatchedWritableConsoleServerPortTemplateRequest(x.id);
  updatePatchedWritableConsoleServerPortTemplateRequest(x.id);
  verifyPatchedWritableConsoleServerPortTemplateRequestExists(x.id);
  verifyPatchedWritableConsoleServerPortTemplateRequestUpdated(x.id);
});

bthread("NestedContactGroup lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedContactGroup(x.id);
  updateNestedContactGroup(x.id);
  updateNestedContactGroup(x.id);
  verifyNestedContactGroupExists(x.id);
  verifyNestedContactGroupUpdated(x.id);
});

bthread("InventoryItemRoleRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInventoryItemRoleRequest(x.id);
  updateInventoryItemRoleRequest(x.id);
  updateInventoryItemRoleRequest(x.id);
  verifyInventoryItemRoleRequestExists(x.id);
  verifyInventoryItemRoleRequestUpdated(x.id);
});

bthread("InterfaceTemplateRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInterfaceTemplateRequest(x.id);
  updateInterfaceTemplateRequest(x.id);
  updateInterfaceTemplateRequest(x.id);
  verifyInterfaceTemplateRequestExists(x.id);
  verifyInterfaceTemplateRequestUpdated(x.id);
});

bthread("WirelessLink lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWirelessLink(x.id);
  updateWirelessLink(x.id);
  updateWirelessLink(x.id);
  verifyWirelessLinkExists(x.id);
  verifyWirelessLinkUpdated(x.id);
});

bthread("WritableVirtualCircuitTerminationRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableVirtualCircuitTerminationRequest(x.id);
  updateWritableVirtualCircuitTerminationRequest(x.id);
  updateWritableVirtualCircuitTerminationRequest(x.id);
  verifyWritableVirtualCircuitTerminationRequestExists(x.id);
  verifyWritableVirtualCircuitTerminationRequestUpdated(x.id);
});

bthread("PowerPortTemplate lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerPortTemplate(x.id);
  updatePowerPortTemplate(x.id);
  updatePowerPortTemplate(x.id);
  verifyPowerPortTemplateExists(x.id);
  verifyPowerPortTemplateUpdated(x.id);
});

bthread("ProviderAccount lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addProviderAccount(x.id);
  updateProviderAccount(x.id);
  updateProviderAccount(x.id);
  verifyProviderAccountExists(x.id);
  verifyProviderAccountUpdated(x.id);
});

bthread("ScriptInputRequest lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addScriptInputRequest(x.id);
  updateScriptInputRequest(x.id);
  updateScriptInputRequest(x.id);
  verifyScriptInputRequestExists(x.id);
  verifyScriptInputRequestUpdated(x.id);
});

bthread("ProviderNetwork lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addProviderNetwork(x.id);
  updateProviderNetwork(x.id);
  updateProviderNetwork(x.id);
  verifyProviderNetworkExists(x.id);
  verifyProviderNetworkUpdated(x.id);
});

bthread("IntegerRange lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIntegerRange(x.id);
  updateIntegerRange(x.id);
  updateIntegerRange(x.id);
  verifyIntegerRangeExists(x.id);
  verifyIntegerRangeUpdated(x.id);
});

bthread("InventoryItem lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInventoryItem(x.id);
  updateInventoryItem(x.id);
  updateInventoryItem(x.id);
  verifyInventoryItemExists(x.id);
  verifyInventoryItemUpdated(x.id);
});

bthread("PaginatedConfigTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedConfigTemplateList(x.id);
  updatePaginatedConfigTemplateList(x.id);
  updatePaginatedConfigTemplateList(x.id);
  verifyPaginatedConfigTemplateListExists(x.id);
  verifyPaginatedConfigTemplateListUpdated(x.id);
});

bthread("VirtualDeviceContextRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualDeviceContextRequest(x.id);
  updateVirtualDeviceContextRequest(x.id);
  updateVirtualDeviceContextRequest(x.id);
  verifyVirtualDeviceContextRequestExists(x.id);
  verifyVirtualDeviceContextRequestUpdated(x.id);
});

bthread("WritableConsolePortTemplateRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableConsolePortTemplateRequest(x.id);
  updateWritableConsolePortTemplateRequest(x.id);
  updateWritableConsolePortTemplateRequest(x.id);
  verifyWritableConsolePortTemplateRequestExists(x.id);
  verifyWritableConsolePortTemplateRequestUpdated(x.id);
});

bthread("PaginatedWirelessLANList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedWirelessLANList(x.id);
  updatePaginatedWirelessLANList(x.id);
  updatePaginatedWirelessLANList(x.id);
  verifyPaginatedWirelessLANListExists(x.id);
  verifyPaginatedWirelessLANListUpdated(x.id);
});

bthread("SiteGroupRequest lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSiteGroupRequest(x.id);
  updateSiteGroupRequest(x.id);
  updateSiteGroupRequest(x.id);
  verifySiteGroupRequestExists(x.id);
  verifySiteGroupRequestUpdated(x.id);
});

bthread("BriefFHRPGroupRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefFHRPGroupRequest(x.id);
  updateBriefFHRPGroupRequest(x.id);
  updateBriefFHRPGroupRequest(x.id);
  verifyBriefFHRPGroupRequestExists(x.id);
  verifyBriefFHRPGroupRequestUpdated(x.id);
});

bthread("PowerOutlet lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerOutlet(x.id);
  updatePowerOutlet(x.id);
  updatePowerOutlet(x.id);
  verifyPowerOutletExists(x.id);
  verifyPowerOutletUpdated(x.id);
});

bthread("VirtualChassis lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualChassis(x.id);
  updateVirtualChassis(x.id);
  updateVirtualChassis(x.id);
  verifyVirtualChassisExists(x.id);
  verifyVirtualChassisUpdated(x.id);
});

bthread("PatchedWritableContactGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableContactGroupRequest(x.id);
  updatePatchedWritableContactGroupRequest(x.id);
  updatePatchedWritableContactGroupRequest(x.id);
  verifyPatchedWritableContactGroupRequestExists(x.id);
  verifyPatchedWritableContactGroupRequestUpdated(x.id);
});

bthread("NestedDevice lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedDevice(x.id);
  updateNestedDevice(x.id);
  updateNestedDevice(x.id);
  verifyNestedDeviceExists(x.id);
  verifyNestedDeviceUpdated(x.id);
});

bthread("PaginatedIPSecProposalList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedIPSecProposalList(x.id);
  updatePaginatedIPSecProposalList(x.id);
  updatePaginatedIPSecProposalList(x.id);
  verifyPaginatedIPSecProposalListExists(x.id);
  verifyPaginatedIPSecProposalListUpdated(x.id);
});

bthread("ContactRole lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addContactRole(x.id);
  updateContactRole(x.id);
  updateContactRole(x.id);
  verifyContactRoleExists(x.id);
  verifyContactRoleUpdated(x.id);
});

bthread("TokenProvision lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTokenProvision(x.id);
  updateTokenProvision(x.id);
  updateTokenProvision(x.id);
  verifyTokenProvisionExists(x.id);
  verifyTokenProvisionUpdated(x.id);
});

bthread("PaginatedBookmarkList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedBookmarkList(x.id);
  updatePaginatedBookmarkList(x.id);
  updatePaginatedBookmarkList(x.id);
  verifyPaginatedBookmarkListExists(x.id);
  verifyPaginatedBookmarkListUpdated(x.id);
});

bthread("WirelessLANGroupRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWirelessLANGroupRequest(x.id);
  updateWirelessLANGroupRequest(x.id);
  updateWirelessLANGroupRequest(x.id);
  verifyWirelessLANGroupRequestExists(x.id);
  verifyWirelessLANGroupRequestUpdated(x.id);
});

bthread("PaginatedLocationList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedLocationList(x.id);
  updatePaginatedLocationList(x.id);
  updatePaginatedLocationList(x.id);
  verifyPaginatedLocationListExists(x.id);
  verifyPaginatedLocationListUpdated(x.id);
});

bthread("NestedTagRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedTagRequest(x.id);
  updateNestedTagRequest(x.id);
  updateNestedTagRequest(x.id);
  verifyNestedTagRequestExists(x.id);
  verifyNestedTagRequestUpdated(x.id);
});

bthread("NestedPlatformRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedPlatformRequest(x.id);
  updateNestedPlatformRequest(x.id);
  updateNestedPlatformRequest(x.id);
  verifyNestedPlatformRequestExists(x.id);
  verifyNestedPlatformRequestUpdated(x.id);
});

bthread("PaginatedRearPortTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRearPortTemplateList(x.id);
  updatePaginatedRearPortTemplateList(x.id);
  updatePaginatedRearPortTemplateList(x.id);
  verifyPaginatedRearPortTemplateListExists(x.id);
  verifyPaginatedRearPortTemplateListUpdated(x.id);
});

bthread("PowerFeed lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerFeed(x.id);
  updatePowerFeed(x.id);
  updatePowerFeed(x.id);
  verifyPowerFeedExists(x.id);
  verifyPowerFeedUpdated(x.id);
});

bthread("WritableRegionRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableRegionRequest(x.id);
  updateWritableRegionRequest(x.id);
  updateWritableRegionRequest(x.id);
  verifyWritableRegionRequestExists(x.id);
  verifyWritableRegionRequestUpdated(x.id);
});

bthread("PaginatedCircuitTypeList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedCircuitTypeList(x.id);
  updatePaginatedCircuitTypeList(x.id);
  updatePaginatedCircuitTypeList(x.id);
  verifyPaginatedCircuitTypeListExists(x.id);
  verifyPaginatedCircuitTypeListUpdated(x.id);
});

bthread("BriefVirtualMachine lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVirtualMachine(x.id);
  updateBriefVirtualMachine(x.id);
  updateBriefVirtualMachine(x.id);
  verifyBriefVirtualMachineExists(x.id);
  verifyBriefVirtualMachineUpdated(x.id);
});

bthread("CircuitGroupAssignmentRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitGroupAssignmentRequest(x.id);
  updateCircuitGroupAssignmentRequest(x.id);
  updateCircuitGroupAssignmentRequest(x.id);
  verifyCircuitGroupAssignmentRequestExists(x.id);
  verifyCircuitGroupAssignmentRequestUpdated(x.id);
});

bthread("PatchedWritablePowerOutletRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritablePowerOutletRequest(x.id);
  updatePatchedWritablePowerOutletRequest(x.id);
  updatePatchedWritablePowerOutletRequest(x.id);
  verifyPatchedWritablePowerOutletRequestExists(x.id);
  verifyPatchedWritablePowerOutletRequestUpdated(x.id);
});

bthread("BriefDeviceType lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefDeviceType(x.id);
  updateBriefDeviceType(x.id);
  updateBriefDeviceType(x.id);
  verifyBriefDeviceTypeExists(x.id);
  verifyBriefDeviceTypeUpdated(x.id);
});

bthread("TokenProvisionRequest lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTokenProvisionRequest(x.id);
  updateTokenProvisionRequest(x.id);
  updateTokenProvisionRequest(x.id);
  verifyTokenProvisionRequestExists(x.id);
  verifyTokenProvisionRequestUpdated(x.id);
});

bthread("TunnelTermination lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTunnelTermination(x.id);
  updateTunnelTermination(x.id);
  updateTunnelTermination(x.id);
  verifyTunnelTerminationExists(x.id);
  verifyTunnelTerminationUpdated(x.id);
});

bthread("PaginatedProviderList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedProviderList(x.id);
  updatePaginatedProviderList(x.id);
  updatePaginatedProviderList(x.id);
  verifyPaginatedProviderListExists(x.id);
  verifyPaginatedProviderListUpdated(x.id);
});

bthread("WritableRearPortRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableRearPortRequest(x.id);
  updateWritableRearPortRequest(x.id);
  updateWritableRearPortRequest(x.id);
  verifyWritableRearPortRequestExists(x.id);
  verifyWritableRearPortRequestUpdated(x.id);
});

bthread("BriefPowerPortRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefPowerPortRequest(x.id);
  updateBriefPowerPortRequest(x.id);
  updateBriefPowerPortRequest(x.id);
  verifyBriefPowerPortRequestExists(x.id);
  verifyBriefPowerPortRequestUpdated(x.id);
});

bthread("BriefRoleRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRoleRequest(x.id);
  updateBriefRoleRequest(x.id);
  updateBriefRoleRequest(x.id);
  verifyBriefRoleRequestExists(x.id);
  verifyBriefRoleRequestUpdated(x.id);
});

bthread("BriefJobRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefJobRequest(x.id);
  updateBriefJobRequest(x.id);
  updateBriefJobRequest(x.id);
  verifyBriefJobRequestExists(x.id);
  verifyBriefJobRequestUpdated(x.id);
});

bthread("BriefUserRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefUserRequest(x.id);
  updateBriefUserRequest(x.id);
  updateBriefUserRequest(x.id);
  verifyBriefUserRequestExists(x.id);
  verifyBriefUserRequestUpdated(x.id);
});

bthread("VMInterface lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVMInterface(x.id);
  updateVMInterface(x.id);
  updateVMInterface(x.id);
  verifyVMInterfaceExists(x.id);
  verifyVMInterfaceUpdated(x.id);
});

bthread("FHRPGroupAssignmentRequest lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFHRPGroupAssignmentRequest(x.id);
  updateFHRPGroupAssignmentRequest(x.id);
  updateFHRPGroupAssignmentRequest(x.id);
  verifyFHRPGroupAssignmentRequestExists(x.id);
  verifyFHRPGroupAssignmentRequestUpdated(x.id);
});

bthread("BriefCircuitTypeRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCircuitTypeRequest(x.id);
  updateBriefCircuitTypeRequest(x.id);
  updateBriefCircuitTypeRequest(x.id);
  verifyBriefCircuitTypeRequestExists(x.id);
  verifyBriefCircuitTypeRequestUpdated(x.id);
});

bthread("PaginatedL2VPNList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedL2VPNList(x.id);
  updatePaginatedL2VPNList(x.id);
  updatePaginatedL2VPNList(x.id);
  verifyPaginatedL2VPNListExists(x.id);
  verifyPaginatedL2VPNListUpdated(x.id);
});

bthread("PaginatedManufacturerList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedManufacturerList(x.id);
  updatePaginatedManufacturerList(x.id);
  updatePaginatedManufacturerList(x.id);
  verifyPaginatedManufacturerListExists(x.id);
  verifyPaginatedManufacturerListUpdated(x.id);
});

bthread("VLANGroupRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVLANGroupRequest(x.id);
  updateVLANGroupRequest(x.id);
  updateVLANGroupRequest(x.id);
  verifyVLANGroupRequestExists(x.id);
  verifyVLANGroupRequestUpdated(x.id);
});

bthread("WritableAggregateRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableAggregateRequest(x.id);
  updateWritableAggregateRequest(x.id);
  updateWritableAggregateRequest(x.id);
  verifyWritableAggregateRequestExists(x.id);
  verifyWritableAggregateRequestUpdated(x.id);
});

bthread("BriefIKEPolicy lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefIKEPolicy(x.id);
  updateBriefIKEPolicy(x.id);
  updateBriefIKEPolicy(x.id);
  verifyBriefIKEPolicyExists(x.id);
  verifyBriefIKEPolicyUpdated(x.id);
});

bthread("BriefDataSource lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefDataSource(x.id);
  updateBriefDataSource(x.id);
  updateBriefDataSource(x.id);
  verifyBriefDataSourceExists(x.id);
  verifyBriefDataSourceUpdated(x.id);
});

bthread("RackReservationRequest lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRackReservationRequest(x.id);
  updateRackReservationRequest(x.id);
  updateRackReservationRequest(x.id);
  verifyRackReservationRequestExists(x.id);
  verifyRackReservationRequestUpdated(x.id);
});

bthread("DeviceBay lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDeviceBay(x.id);
  updateDeviceBay(x.id);
  updateDeviceBay(x.id);
  verifyDeviceBayExists(x.id);
  verifyDeviceBayUpdated(x.id);
});

bthread("BriefCircuitGroup lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefCircuitGroup(x.id);
  updateBriefCircuitGroup(x.id);
  updateBriefCircuitGroup(x.id);
  verifyBriefCircuitGroupExists(x.id);
  verifyBriefCircuitGroupUpdated(x.id);
});

bthread("NestedWirelessLink lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedWirelessLink(x.id);
  updateNestedWirelessLink(x.id);
  updateNestedWirelessLink(x.id);
  verifyNestedWirelessLinkExists(x.id);
  verifyNestedWirelessLinkUpdated(x.id);
});

bthread("BriefRIRRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefRIRRequest(x.id);
  updateBriefRIRRequest(x.id);
  updateBriefRIRRequest(x.id);
  verifyBriefRIRRequestExists(x.id);
  verifyBriefRIRRequestUpdated(x.id);
});

bthread("PaginatedTagList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedTagList(x.id);
  updatePaginatedTagList(x.id);
  updatePaginatedTagList(x.id);
  verifyPaginatedTagListExists(x.id);
  verifyPaginatedTagListUpdated(x.id);
});

bthread("BriefTunnel lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefTunnel(x.id);
  updateBriefTunnel(x.id);
  updateBriefTunnel(x.id);
  verifyBriefTunnelExists(x.id);
  verifyBriefTunnelUpdated(x.id);
});

bthread("NestedLocationRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedLocationRequest(x.id);
  updateNestedLocationRequest(x.id);
  updateNestedLocationRequest(x.id);
  verifyNestedLocationRequestExists(x.id);
  verifyNestedLocationRequestUpdated(x.id);
});

bthread("NestedWirelessLANGroup lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedWirelessLANGroup(x.id);
  updateNestedWirelessLANGroup(x.id);
  updateNestedWirelessLANGroup(x.id);
  verifyNestedWirelessLANGroupExists(x.id);
  verifyNestedWirelessLANGroupUpdated(x.id);
});

bthread("PaginatedIKEProposalList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedIKEProposalList(x.id);
  updatePaginatedIKEProposalList(x.id);
  updatePaginatedIKEProposalList(x.id);
  verifyPaginatedIKEProposalListExists(x.id);
  verifyPaginatedIKEProposalListUpdated(x.id);
});

bthread("PaginatedVMInterfaceList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVMInterfaceList(x.id);
  updatePaginatedVMInterfaceList(x.id);
  updatePaginatedVMInterfaceList(x.id);
  verifyPaginatedVMInterfaceListExists(x.id);
  verifyPaginatedVMInterfaceListUpdated(x.id);
});

bthread("NestedVLANRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedVLANRequest(x.id);
  updateNestedVLANRequest(x.id);
  updateNestedVLANRequest(x.id);
  verifyNestedVLANRequestExists(x.id);
  verifyNestedVLANRequestUpdated(x.id);
});

bthread("PatchedWebhookRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWebhookRequest(x.id);
  updatePatchedWebhookRequest(x.id);
  updatePatchedWebhookRequest(x.id);
  verifyPatchedWebhookRequestExists(x.id);
  verifyPatchedWebhookRequestUpdated(x.id);
});

bthread("PatchedWritableIPAddressRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableIPAddressRequest(x.id);
  updatePatchedWritableIPAddressRequest(x.id);
  updatePatchedWritableIPAddressRequest(x.id);
  verifyPatchedWritableIPAddressRequestExists(x.id);
  verifyPatchedWritableIPAddressRequestUpdated(x.id);
});

bthread("WritableIPSecProposalRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableIPSecProposalRequest(x.id);
  updateWritableIPSecProposalRequest(x.id);
  updateWritableIPSecProposalRequest(x.id);
  verifyWritableIPSecProposalRequestExists(x.id);
  verifyWritableIPSecProposalRequestUpdated(x.id);
});

bthread("PatchedNotificationRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedNotificationRequest(x.id);
  updatePatchedNotificationRequest(x.id);
  updatePatchedNotificationRequest(x.id);
  verifyPatchedNotificationRequestExists(x.id);
  verifyPatchedNotificationRequestUpdated(x.id);
});

bthread("WritablePlatformRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritablePlatformRequest(x.id);
  updateWritablePlatformRequest(x.id);
  updateWritablePlatformRequest(x.id);
  verifyWritablePlatformRequestExists(x.id);
  verifyWritablePlatformRequestUpdated(x.id);
});

bthread("PowerOutletTemplate lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerOutletTemplate(x.id);
  updatePowerOutletTemplate(x.id);
  updatePowerOutletTemplate(x.id);
  verifyPowerOutletTemplateExists(x.id);
  verifyPowerOutletTemplateUpdated(x.id);
});

bthread("PatchedDeviceBayRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedDeviceBayRequest(x.id);
  updatePatchedDeviceBayRequest(x.id);
  updatePatchedDeviceBayRequest(x.id);
  verifyPatchedDeviceBayRequestExists(x.id);
  verifyPatchedDeviceBayRequestUpdated(x.id);
});

bthread("PatchedBookmarkRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedBookmarkRequest(x.id);
  updatePatchedBookmarkRequest(x.id);
  updatePatchedBookmarkRequest(x.id);
  verifyPatchedBookmarkRequestExists(x.id);
  verifyPatchedBookmarkRequestUpdated(x.id);
});

bthread("BriefDeviceRoleRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefDeviceRoleRequest(x.id);
  updateBriefDeviceRoleRequest(x.id);
  updateBriefDeviceRoleRequest(x.id);
  verifyBriefDeviceRoleRequestExists(x.id);
  verifyBriefDeviceRoleRequestUpdated(x.id);
});

bthread("WritableIPSecPolicyRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableIPSecPolicyRequest(x.id);
  updateWritableIPSecPolicyRequest(x.id);
  updateWritableIPSecPolicyRequest(x.id);
  verifyWritableIPSecPolicyRequestExists(x.id);
  verifyWritableIPSecPolicyRequestUpdated(x.id);
});

bthread("CircuitRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCircuitRequest(x.id);
  updateCircuitRequest(x.id);
  updateCircuitRequest(x.id);
  verifyCircuitRequestExists(x.id);
  verifyCircuitRequestUpdated(x.id);
});

bthread("MACAddress lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMACAddress(x.id);
  updateMACAddress(x.id);
  updateMACAddress(x.id);
  verifyMACAddressExists(x.id);
  verifyMACAddressUpdated(x.id);
});

bthread("DataFile lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDataFile(x.id);
  updateDataFile(x.id);
  updateDataFile(x.id);
  verifyDataFileExists(x.id);
  verifyDataFileUpdated(x.id);
});

bthread("WritableConsolePortRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableConsolePortRequest(x.id);
  updateWritableConsolePortRequest(x.id);
  updateWritableConsolePortRequest(x.id);
  verifyWritableConsolePortRequestExists(x.id);
  verifyWritableConsolePortRequestUpdated(x.id);
});

bthread("DeviceTypeRequest lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDeviceTypeRequest(x.id);
  updateDeviceTypeRequest(x.id);
  updateDeviceTypeRequest(x.id);
  verifyDeviceTypeRequestExists(x.id);
  verifyDeviceTypeRequestUpdated(x.id);
});

bthread("PaginatedCustomLinkList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedCustomLinkList(x.id);
  updatePaginatedCustomLinkList(x.id);
  updatePaginatedCustomLinkList(x.id);
  verifyPaginatedCustomLinkListExists(x.id);
  verifyPaginatedCustomLinkListUpdated(x.id);
});

bthread("DeviceType lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDeviceType(x.id);
  updateDeviceType(x.id);
  updateDeviceType(x.id);
  verifyDeviceTypeExists(x.id);
  verifyDeviceTypeUpdated(x.id);
});

bthread("PatchedTokenRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedTokenRequest(x.id);
  updatePatchedTokenRequest(x.id);
  updatePatchedTokenRequest(x.id);
  verifyPatchedTokenRequestExists(x.id);
  verifyPatchedTokenRequestUpdated(x.id);
});

bthread("BriefModuleTypeProfileRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefModuleTypeProfileRequest(x.id);
  updateBriefModuleTypeProfileRequest(x.id);
  updateBriefModuleTypeProfileRequest(x.id);
  verifyBriefModuleTypeProfileRequestExists(x.id);
  verifyBriefModuleTypeProfileRequestUpdated(x.id);
});

bthread("DeviceWithConfigContext lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDeviceWithConfigContext(x.id);
  updateDeviceWithConfigContext(x.id);
  updateDeviceWithConfigContext(x.id);
  verifyDeviceWithConfigContextExists(x.id);
  verifyDeviceWithConfigContextUpdated(x.id);
});

bthread("ModuleBayTemplateRequest lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModuleBayTemplateRequest(x.id);
  updateModuleBayTemplateRequest(x.id);
  updateModuleBayTemplateRequest(x.id);
  verifyModuleBayTemplateRequestExists(x.id);
  verifyModuleBayTemplateRequestUpdated(x.id);
});

bthread("ProviderAccountRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addProviderAccountRequest(x.id);
  updateProviderAccountRequest(x.id);
  updateProviderAccountRequest(x.id);
  verifyProviderAccountRequestExists(x.id);
  verifyProviderAccountRequestUpdated(x.id);
});

bthread("WritableRackTypeRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableRackTypeRequest(x.id);
  updateWritableRackTypeRequest(x.id);
  updateWritableRackTypeRequest(x.id);
  verifyWritableRackTypeRequestExists(x.id);
  verifyWritableRackTypeRequestUpdated(x.id);
});

bthread("BriefInventoryItemRoleRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefInventoryItemRoleRequest(x.id);
  updateBriefInventoryItemRoleRequest(x.id);
  updateBriefInventoryItemRoleRequest(x.id);
  verifyBriefInventoryItemRoleRequestExists(x.id);
  verifyBriefInventoryItemRoleRequestUpdated(x.id);
});

bthread("PaginatedUserList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedUserList(x.id);
  updatePaginatedUserList(x.id);
  updatePaginatedUserList(x.id);
  verifyPaginatedUserListExists(x.id);
  verifyPaginatedUserListUpdated(x.id);
});

bthread("IPSecProfileRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIPSecProfileRequest(x.id);
  updateIPSecProfileRequest(x.id);
  updateIPSecProfileRequest(x.id);
  verifyIPSecProfileRequestExists(x.id);
  verifyIPSecProfileRequestUpdated(x.id);
});

bthread("PaginatedInventoryItemList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedInventoryItemList(x.id);
  updatePaginatedInventoryItemList(x.id);
  updatePaginatedInventoryItemList(x.id);
  verifyPaginatedInventoryItemListExists(x.id);
  verifyPaginatedInventoryItemListUpdated(x.id);
});

bthread("RackRoleRequest lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRackRoleRequest(x.id);
  updateRackRoleRequest(x.id);
  updateRackRoleRequest(x.id);
  verifyRackRoleRequestExists(x.id);
  verifyRackRoleRequestUpdated(x.id);
});

bthread("BriefModule lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefModule(x.id);
  updateBriefModule(x.id);
  updateBriefModule(x.id);
  verifyBriefModuleExists(x.id);
  verifyBriefModuleUpdated(x.id);
});

bthread("PatchedWritableSiteGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableSiteGroupRequest(x.id);
  updatePatchedWritableSiteGroupRequest(x.id);
  updatePatchedWritableSiteGroupRequest(x.id);
  verifyPatchedWritableSiteGroupRequestExists(x.id);
  verifyPatchedWritableSiteGroupRequestUpdated(x.id);
});

bthread("WirelessLANRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWirelessLANRequest(x.id);
  updateWirelessLANRequest(x.id);
  updateWirelessLANRequest(x.id);
  verifyWirelessLANRequestExists(x.id);
  verifyWirelessLANRequestUpdated(x.id);
});

bthread("PaginatedDataFileList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedDataFileList(x.id);
  updatePaginatedDataFileList(x.id);
  updatePaginatedDataFileList(x.id);
  verifyPaginatedDataFileListExists(x.id);
  verifyPaginatedDataFileListUpdated(x.id);
});

bthread("PaginatedVLANTranslationPolicyList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVLANTranslationPolicyList(x.id);
  updatePaginatedVLANTranslationPolicyList(x.id);
  updatePaginatedVLANTranslationPolicyList(x.id);
  verifyPaginatedVLANTranslationPolicyListExists(x.id);
  verifyPaginatedVLANTranslationPolicyListUpdated(x.id);
});

bthread("Provider lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addProvider(x.id);
  updateProvider(x.id);
  updateProvider(x.id);
  verifyProviderExists(x.id);
  verifyProviderUpdated(x.id);
});

bthread("TagRequest lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTagRequest(x.id);
  updateTagRequest(x.id);
  updateTagRequest(x.id);
  verifyTagRequestExists(x.id);
  verifyTagRequestUpdated(x.id);
});

bthread("BriefInterfaceRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefInterfaceRequest(x.id);
  updateBriefInterfaceRequest(x.id);
  updateBriefInterfaceRequest(x.id);
  verifyBriefInterfaceRequestExists(x.id);
  verifyBriefInterfaceRequestUpdated(x.id);
});

bthread("ContactRoleRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addContactRoleRequest(x.id);
  updateContactRoleRequest(x.id);
  updateContactRoleRequest(x.id);
  verifyContactRoleRequestExists(x.id);
  verifyContactRoleRequestUpdated(x.id);
});

bthread("IntegerRangeRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIntegerRangeRequest(x.id);
  updateIntegerRangeRequest(x.id);
  updateIntegerRangeRequest(x.id);
  verifyIntegerRangeRequestExists(x.id);
  verifyIntegerRangeRequestUpdated(x.id);
});

bthread("NestedTenantGroupRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedTenantGroupRequest(x.id);
  updateNestedTenantGroupRequest(x.id);
  updateNestedTenantGroupRequest(x.id);
  verifyNestedTenantGroupRequestExists(x.id);
  verifyNestedTenantGroupRequestUpdated(x.id);
});

bthread("PatchedWritableDeviceRoleRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableDeviceRoleRequest(x.id);
  updatePatchedWritableDeviceRoleRequest(x.id);
  updatePatchedWritableDeviceRoleRequest(x.id);
  verifyPatchedWritableDeviceRoleRequestExists(x.id);
  verifyPatchedWritableDeviceRoleRequestUpdated(x.id);
});

bthread("NotificationRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNotificationRequest(x.id);
  updateNotificationRequest(x.id);
  updateNotificationRequest(x.id);
  verifyNotificationRequestExists(x.id);
  verifyNotificationRequestUpdated(x.id);
});

bthread("PatchedWritableDeviceTypeRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableDeviceTypeRequest(x.id);
  updatePatchedWritableDeviceTypeRequest(x.id);
  updatePatchedWritableDeviceTypeRequest(x.id);
  verifyPatchedWritableDeviceTypeRequestExists(x.id);
  verifyPatchedWritableDeviceTypeRequestUpdated(x.id);
});

bthread("PatchedWritableModuleRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableModuleRequest(x.id);
  updatePatchedWritableModuleRequest(x.id);
  updatePatchedWritableModuleRequest(x.id);
  verifyPatchedWritableModuleRequestExists(x.id);
  verifyPatchedWritableModuleRequestUpdated(x.id);
});

bthread("RackUnit lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRackUnit(x.id);
  updateRackUnit(x.id);
  updateRackUnit(x.id);
  verifyRackUnitExists(x.id);
  verifyRackUnitUpdated(x.id);
});

bthread("PaginatedVirtualChassisList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedVirtualChassisList(x.id);
  updatePaginatedVirtualChassisList(x.id);
  updatePaginatedVirtualChassisList(x.id);
  verifyPaginatedVirtualChassisListExists(x.id);
  verifyPaginatedVirtualChassisListUpdated(x.id);
});

bthread("BriefDevice lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefDevice(x.id);
  updateBriefDevice(x.id);
  updateBriefDevice(x.id);
  verifyBriefDeviceExists(x.id);
  verifyBriefDeviceUpdated(x.id);
});

bthread("PaginatedEventRuleList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedEventRuleList(x.id);
  updatePaginatedEventRuleList(x.id);
  updatePaginatedEventRuleList(x.id);
  verifyPaginatedEventRuleListExists(x.id);
  verifyPaginatedEventRuleListUpdated(x.id);
});

bthread("BriefVLANGroupRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVLANGroupRequest(x.id);
  updateBriefVLANGroupRequest(x.id);
  updateBriefVLANGroupRequest(x.id);
  verifyBriefVLANGroupRequestExists(x.id);
  verifyBriefVLANGroupRequestUpdated(x.id);
});

bthread("PatchedWritableModuleTypeRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableModuleTypeRequest(x.id);
  updatePatchedWritableModuleTypeRequest(x.id);
  updatePatchedWritableModuleTypeRequest(x.id);
  verifyPatchedWritableModuleTypeRequestExists(x.id);
  verifyPatchedWritableModuleTypeRequestUpdated(x.id);
});

bthread("PatchedWritableInterfaceTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableInterfaceTemplateRequest(x.id);
  updatePatchedWritableInterfaceTemplateRequest(x.id);
  updatePatchedWritableInterfaceTemplateRequest(x.id);
  verifyPatchedWritableInterfaceTemplateRequestExists(x.id);
  verifyPatchedWritableInterfaceTemplateRequestUpdated(x.id);
});

bthread("ClusterType lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClusterType(x.id);
  updateClusterType(x.id);
  updateClusterType(x.id);
  verifyClusterTypeExists(x.id);
  verifyClusterTypeUpdated(x.id);
});

bthread("Notification lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNotification(x.id);
  updateNotification(x.id);
  updateNotification(x.id);
  verifyNotificationExists(x.id);
  verifyNotificationUpdated(x.id);
});

bthread("WritableWirelessLANGroupRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableWirelessLANGroupRequest(x.id);
  updateWritableWirelessLANGroupRequest(x.id);
  updateWritableWirelessLANGroupRequest(x.id);
  verifyWritableWirelessLANGroupRequestExists(x.id);
  verifyWritableWirelessLANGroupRequestUpdated(x.id);
});

bthread("TunnelTerminationRequest lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTunnelTerminationRequest(x.id);
  updateTunnelTerminationRequest(x.id);
  updateTunnelTerminationRequest(x.id);
  verifyTunnelTerminationRequestExists(x.id);
  verifyTunnelTerminationRequestUpdated(x.id);
});

bthread("ObjectPermissionRequest lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addObjectPermissionRequest(x.id);
  updateObjectPermissionRequest(x.id);
  updateObjectPermissionRequest(x.id);
  verifyObjectPermissionRequestExists(x.id);
  verifyObjectPermissionRequestUpdated(x.id);
});

bthread("VLAN lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVLAN(x.id);
  updateVLAN(x.id);
  updateVLAN(x.id);
  verifyVLANExists(x.id);
  verifyVLANUpdated(x.id);
});

bthread("FrontPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFrontPortTemplateRequest(x.id);
  updateFrontPortTemplateRequest(x.id);
  updateFrontPortTemplateRequest(x.id);
  verifyFrontPortTemplateRequestExists(x.id);
  verifyFrontPortTemplateRequestUpdated(x.id);
});

bthread("NestedVLAN lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedVLAN(x.id);
  updateNestedVLAN(x.id);
  updateNestedVLAN(x.id);
  verifyNestedVLANExists(x.id);
  verifyNestedVLANUpdated(x.id);
});

bthread("BriefManufacturerRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefManufacturerRequest(x.id);
  updateBriefManufacturerRequest(x.id);
  updateBriefManufacturerRequest(x.id);
  verifyBriefManufacturerRequestExists(x.id);
  verifyBriefManufacturerRequestUpdated(x.id);
});

bthread("PatchedWritableCircuitGroupAssignmentRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableCircuitGroupAssignmentRequest(x.id);
  updatePatchedWritableCircuitGroupAssignmentRequest(x.id);
  updatePatchedWritableCircuitGroupAssignmentRequest(x.id);
  verifyPatchedWritableCircuitGroupAssignmentRequestExists(x.id);
  verifyPatchedWritableCircuitGroupAssignmentRequestUpdated(x.id);
});

bthread("InventoryItemRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addInventoryItemRequest(x.id);
  updateInventoryItemRequest(x.id);
  updateInventoryItemRequest(x.id);
  verifyInventoryItemRequestExists(x.id);
  verifyInventoryItemRequestUpdated(x.id);
});

bthread("L2VPN lifecycle", function () {
  const x = pick([{id: "L001"}, {id: "L002"}]);
  addL2VPN(x.id);
  updateL2VPN(x.id);
  updateL2VPN(x.id);
  verifyL2VPNExists(x.id);
  verifyL2VPNUpdated(x.id);
});

bthread("NestedUser lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedUser(x.id);
  updateNestedUser(x.id);
  updateNestedUser(x.id);
  verifyNestedUserExists(x.id);
  verifyNestedUserUpdated(x.id);
});

bthread("ConsolePort lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConsolePort(x.id);
  updateConsolePort(x.id);
  updateConsolePort(x.id);
  verifyConsolePortExists(x.id);
  verifyConsolePortUpdated(x.id);
});

bthread("WritableCustomFieldChoiceSetRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableCustomFieldChoiceSetRequest(x.id);
  updateWritableCustomFieldChoiceSetRequest(x.id);
  updateWritableCustomFieldChoiceSetRequest(x.id);
  verifyWritableCustomFieldChoiceSetRequestExists(x.id);
  verifyWritableCustomFieldChoiceSetRequestUpdated(x.id);
});

bthread("PaginatedTaggedItemList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedTaggedItemList(x.id);
  updatePaginatedTaggedItemList(x.id);
  updatePaginatedTaggedItemList(x.id);
  verifyPaginatedTaggedItemListExists(x.id);
  verifyPaginatedTaggedItemListUpdated(x.id);
});

bthread("BriefVirtualCircuitTypeRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVirtualCircuitTypeRequest(x.id);
  updateBriefVirtualCircuitTypeRequest(x.id);
  updateBriefVirtualCircuitTypeRequest(x.id);
  verifyBriefVirtualCircuitTypeRequestExists(x.id);
  verifyBriefVirtualCircuitTypeRequestUpdated(x.id);
});

bthread("Manufacturer lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addManufacturer(x.id);
  updateManufacturer(x.id);
  updateManufacturer(x.id);
  verifyManufacturerExists(x.id);
  verifyManufacturerUpdated(x.id);
});

bthread("ModuleTypeRequest lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModuleTypeRequest(x.id);
  updateModuleTypeRequest(x.id);
  updateModuleTypeRequest(x.id);
  verifyModuleTypeRequestExists(x.id);
  verifyModuleTypeRequestUpdated(x.id);
});

bthread("WritableTenantGroupRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableTenantGroupRequest(x.id);
  updateWritableTenantGroupRequest(x.id);
  updateWritableTenantGroupRequest(x.id);
  verifyWritableTenantGroupRequestExists(x.id);
  verifyWritableTenantGroupRequestUpdated(x.id);
});

bthread("RearPortTemplate lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRearPortTemplate(x.id);
  updateRearPortTemplate(x.id);
  updateRearPortTemplate(x.id);
  verifyRearPortTemplateExists(x.id);
  verifyRearPortTemplateUpdated(x.id);
});

bthread("BriefProviderNetwork lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefProviderNetwork(x.id);
  updateBriefProviderNetwork(x.id);
  updateBriefProviderNetwork(x.id);
  verifyBriefProviderNetworkExists(x.id);
  verifyBriefProviderNetworkUpdated(x.id);
});

bthread("NotificationGroupRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNotificationGroupRequest(x.id);
  updateNotificationGroupRequest(x.id);
  updateNotificationGroupRequest(x.id);
  verifyNotificationGroupRequestExists(x.id);
  verifyNotificationGroupRequestUpdated(x.id);
});

bthread("PatchedClusterGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedClusterGroupRequest(x.id);
  updatePatchedClusterGroupRequest(x.id);
  updatePatchedClusterGroupRequest(x.id);
  verifyPatchedClusterGroupRequestExists(x.id);
  verifyPatchedClusterGroupRequestUpdated(x.id);
});

bthread("ClusterRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addClusterRequest(x.id);
  updateClusterRequest(x.id);
  updateClusterRequest(x.id);
  verifyClusterRequestExists(x.id);
  verifyClusterRequestUpdated(x.id);
});

bthread("PatchedCircuitGroupRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedCircuitGroupRequest(x.id);
  updatePatchedCircuitGroupRequest(x.id);
  updatePatchedCircuitGroupRequest(x.id);
  verifyPatchedCircuitGroupRequestExists(x.id);
  verifyPatchedCircuitGroupRequestUpdated(x.id);
});

bthread("WritableTunnelRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableTunnelRequest(x.id);
  updateWritableTunnelRequest(x.id);
  updateWritableTunnelRequest(x.id);
  verifyWritableTunnelRequestExists(x.id);
  verifyWritableTunnelRequestUpdated(x.id);
});

bthread("PaginatedInterfaceList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedInterfaceList(x.id);
  updatePaginatedInterfaceList(x.id);
  updatePaginatedInterfaceList(x.id);
  verifyPaginatedInterfaceListExists(x.id);
  verifyPaginatedInterfaceListUpdated(x.id);
});

bthread("WirelessLANGroup lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWirelessLANGroup(x.id);
  updateWirelessLANGroup(x.id);
  updateWirelessLANGroup(x.id);
  verifyWirelessLANGroupExists(x.id);
  verifyWirelessLANGroupUpdated(x.id);
});

bthread("PatchedWritableServiceTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableServiceTemplateRequest(x.id);
  updatePatchedWritableServiceTemplateRequest(x.id);
  updatePatchedWritableServiceTemplateRequest(x.id);
  verifyPatchedWritableServiceTemplateRequestExists(x.id);
  verifyPatchedWritableServiceTemplateRequestUpdated(x.id);
});

bthread("IKEProposal lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIKEProposal(x.id);
  updateIKEProposal(x.id);
  updateIKEProposal(x.id);
  verifyIKEProposalExists(x.id);
  verifyIKEProposalUpdated(x.id);
});

bthread("PatchedWritableTunnelRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableTunnelRequest(x.id);
  updatePatchedWritableTunnelRequest(x.id);
  updatePatchedWritableTunnelRequest(x.id);
  verifyPatchedWritableTunnelRequestExists(x.id);
  verifyPatchedWritableTunnelRequestUpdated(x.id);
});

bthread("PatchedWritableInterfaceRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableInterfaceRequest(x.id);
  updatePatchedWritableInterfaceRequest(x.id);
  updatePatchedWritableInterfaceRequest(x.id);
  verifyPatchedWritableInterfaceRequestExists(x.id);
  verifyPatchedWritableInterfaceRequestUpdated(x.id);
});

bthread("NestedPlatform lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedPlatform(x.id);
  updateNestedPlatform(x.id);
  updateNestedPlatform(x.id);
  verifyNestedPlatformExists(x.id);
  verifyNestedPlatformUpdated(x.id);
});

bthread("Dashboard lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDashboard(x.id);
  updateDashboard(x.id);
  updateDashboard(x.id);
  verifyDashboardExists(x.id);
  verifyDashboardUpdated(x.id);
});

bthread("ConsoleServerPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConsoleServerPortTemplateRequest(x.id);
  updateConsoleServerPortTemplateRequest(x.id);
  updateConsoleServerPortTemplateRequest(x.id);
  verifyConsoleServerPortTemplateRequestExists(x.id);
  verifyConsoleServerPortTemplateRequestUpdated(x.id);
});

bthread("PatchedL2VPNTerminationRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedL2VPNTerminationRequest(x.id);
  updatePatchedL2VPNTerminationRequest(x.id);
  updatePatchedL2VPNTerminationRequest(x.id);
  verifyPatchedL2VPNTerminationRequestExists(x.id);
  verifyPatchedL2VPNTerminationRequestUpdated(x.id);
});

bthread("BriefModuleType lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefModuleType(x.id);
  updateBriefModuleType(x.id);
  updateBriefModuleType(x.id);
  verifyBriefModuleTypeExists(x.id);
  verifyBriefModuleTypeUpdated(x.id);
});

bthread("BriefContact lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefContact(x.id);
  updateBriefContact(x.id);
  updateBriefContact(x.id);
  verifyBriefContactExists(x.id);
  verifyBriefContactUpdated(x.id);
});

bthread("PatchedWritableCableRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableCableRequest(x.id);
  updatePatchedWritableCableRequest(x.id);
  updatePatchedWritableCableRequest(x.id);
  verifyPatchedWritableCableRequestExists(x.id);
  verifyPatchedWritableCableRequestUpdated(x.id);
});

bthread("ConfigContextProfileRequest lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConfigContextProfileRequest(x.id);
  updateConfigContextProfileRequest(x.id);
  updateConfigContextProfileRequest(x.id);
  verifyConfigContextProfileRequestExists(x.id);
  verifyConfigContextProfileRequestUpdated(x.id);
});

bthread("ASNRangeRequest lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addASNRangeRequest(x.id);
  updateASNRangeRequest(x.id);
  updateASNRangeRequest(x.id);
  verifyASNRangeRequestExists(x.id);
  verifyASNRangeRequestUpdated(x.id);
});

bthread("ObjectChange lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addObjectChange(x.id);
  updateObjectChange(x.id);
  updateObjectChange(x.id);
  verifyObjectChangeExists(x.id);
  verifyObjectChangeUpdated(x.id);
});

bthread("PatchedRoleRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedRoleRequest(x.id);
  updatePatchedRoleRequest(x.id);
  updatePatchedRoleRequest(x.id);
  verifyPatchedRoleRequestExists(x.id);
  verifyPatchedRoleRequestUpdated(x.id);
});

bthread("BriefPlatformRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefPlatformRequest(x.id);
  updateBriefPlatformRequest(x.id);
  updateBriefPlatformRequest(x.id);
  verifyBriefPlatformRequestExists(x.id);
  verifyBriefPlatformRequestUpdated(x.id);
});

bthread("PatchedWritableVirtualChassisRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableVirtualChassisRequest(x.id);
  updatePatchedWritableVirtualChassisRequest(x.id);
  updatePatchedWritableVirtualChassisRequest(x.id);
  verifyPatchedWritableVirtualChassisRequestExists(x.id);
  verifyPatchedWritableVirtualChassisRequestUpdated(x.id);
});

bthread("PaginatedObjectChangeList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedObjectChangeList(x.id);
  updatePaginatedObjectChangeList(x.id);
  updatePaginatedObjectChangeList(x.id);
  verifyPaginatedObjectChangeListExists(x.id);
  verifyPaginatedObjectChangeListUpdated(x.id);
});

bthread("RackType lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRackType(x.id);
  updateRackType(x.id);
  updateRackType(x.id);
  verifyRackTypeExists(x.id);
  verifyRackTypeUpdated(x.id);
});

bthread("PaginatedIPSecPolicyList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedIPSecPolicyList(x.id);
  updatePaginatedIPSecPolicyList(x.id);
  updatePaginatedIPSecPolicyList(x.id);
  verifyPaginatedIPSecPolicyListExists(x.id);
  verifyPaginatedIPSecPolicyListUpdated(x.id);
});

bthread("PaginatedJournalEntryList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedJournalEntryList(x.id);
  updatePaginatedJournalEntryList(x.id);
  updatePaginatedJournalEntryList(x.id);
  verifyPaginatedJournalEntryListExists(x.id);
  verifyPaginatedJournalEntryListUpdated(x.id);
});

bthread("ModuleBay lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addModuleBay(x.id);
  updateModuleBay(x.id);
  updateModuleBay(x.id);
  verifyModuleBayExists(x.id);
  verifyModuleBayUpdated(x.id);
});

bthread("PaginatedPowerPortTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedPowerPortTemplateList(x.id);
  updatePaginatedPowerPortTemplateList(x.id);
  updatePaginatedPowerPortTemplateList(x.id);
  verifyPaginatedPowerPortTemplateListExists(x.id);
  verifyPaginatedPowerPortTemplateListUpdated(x.id);
});

bthread("WritableVMInterfaceRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableVMInterfaceRequest(x.id);
  updateWritableVMInterfaceRequest(x.id);
  updateWritableVMInterfaceRequest(x.id);
  verifyWritableVMInterfaceRequestExists(x.id);
  verifyWritableVMInterfaceRequestUpdated(x.id);
});

bthread("NestedModuleBayRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedModuleBayRequest(x.id);
  updateNestedModuleBayRequest(x.id);
  updateNestedModuleBayRequest(x.id);
  verifyNestedModuleBayRequestExists(x.id);
  verifyNestedModuleBayRequestUpdated(x.id);
});

bthread("PaginatedInventoryItemTemplateList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedInventoryItemTemplateList(x.id);
  updatePaginatedInventoryItemTemplateList(x.id);
  updatePaginatedInventoryItemTemplateList(x.id);
  verifyPaginatedInventoryItemTemplateListExists(x.id);
  verifyPaginatedInventoryItemTemplateListUpdated(x.id);
});

bthread("WirelessLAN lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWirelessLAN(x.id);
  updateWirelessLAN(x.id);
  updateWirelessLAN(x.id);
  verifyWirelessLANExists(x.id);
  verifyWirelessLANUpdated(x.id);
});

bthread("ImageAttachmentRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addImageAttachmentRequest(x.id);
  updateImageAttachmentRequest(x.id);
  updateImageAttachmentRequest(x.id);
  verifyImageAttachmentRequestExists(x.id);
  verifyImageAttachmentRequestUpdated(x.id);
});

bthread("JournalEntryRequest lifecycle", function () {
  const x = pick([{id: "J001"}, {id: "J002"}]);
  addJournalEntryRequest(x.id);
  updateJournalEntryRequest(x.id);
  updateJournalEntryRequest(x.id);
  verifyJournalEntryRequestExists(x.id);
  verifyJournalEntryRequestUpdated(x.id);
});

bthread("PaginatedGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedGroupList(x.id);
  updatePaginatedGroupList(x.id);
  updatePaginatedGroupList(x.id);
  verifyPaginatedGroupListExists(x.id);
  verifyPaginatedGroupListUpdated(x.id);
});

bthread("TenantGroupRequest lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTenantGroupRequest(x.id);
  updateTenantGroupRequest(x.id);
  updateTenantGroupRequest(x.id);
  verifyTenantGroupRequestExists(x.id);
  verifyTenantGroupRequestUpdated(x.id);
});

bthread("PaginatedSiteGroupList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedSiteGroupList(x.id);
  updatePaginatedSiteGroupList(x.id);
  updatePaginatedSiteGroupList(x.id);
  verifyPaginatedSiteGroupListExists(x.id);
  verifyPaginatedSiteGroupListUpdated(x.id);
});

bthread("PowerOutletTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerOutletTemplateRequest(x.id);
  updatePowerOutletTemplateRequest(x.id);
  updatePowerOutletTemplateRequest(x.id);
  verifyPowerOutletTemplateRequestExists(x.id);
  verifyPowerOutletTemplateRequestUpdated(x.id);
});

bthread("PaginatedCableTerminationList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedCableTerminationList(x.id);
  updatePaginatedCableTerminationList(x.id);
  updatePaginatedCableTerminationList(x.id);
  verifyPaginatedCableTerminationListExists(x.id);
  verifyPaginatedCableTerminationListUpdated(x.id);
});

bthread("BriefVirtualChassisRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVirtualChassisRequest(x.id);
  updateBriefVirtualChassisRequest(x.id);
  updateBriefVirtualChassisRequest(x.id);
  verifyBriefVirtualChassisRequestExists(x.id);
  verifyBriefVirtualChassisRequestUpdated(x.id);
});

bthread("NestedWirelessLinkRequest lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedWirelessLinkRequest(x.id);
  updateNestedWirelessLinkRequest(x.id);
  updateNestedWirelessLinkRequest(x.id);
  verifyNestedWirelessLinkRequestExists(x.id);
  verifyNestedWirelessLinkRequestUpdated(x.id);
});

bthread("PowerPanel lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPowerPanel(x.id);
  updatePowerPanel(x.id);
  updatePowerPanel(x.id);
  verifyPowerPanelExists(x.id);
  verifyPowerPanelUpdated(x.id);
});

bthread("PatchedWritableInventoryItemRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableInventoryItemRequest(x.id);
  updatePatchedWritableInventoryItemRequest(x.id);
  updatePatchedWritableInventoryItemRequest(x.id);
  verifyPatchedWritableInventoryItemRequestExists(x.id);
  verifyPatchedWritableInventoryItemRequestUpdated(x.id);
});

bthread("IPSecPolicyRequest lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIPSecPolicyRequest(x.id);
  updateIPSecPolicyRequest(x.id);
  updateIPSecPolicyRequest(x.id);
  verifyIPSecPolicyRequestExists(x.id);
  verifyIPSecPolicyRequestUpdated(x.id);
});

bthread("PatchedExportTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedExportTemplateRequest(x.id);
  updatePatchedExportTemplateRequest(x.id);
  updatePatchedExportTemplateRequest(x.id);
  verifyPatchedExportTemplateRequestExists(x.id);
  verifyPatchedExportTemplateRequestUpdated(x.id);
});

bthread("FHRPGroupAssignment lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFHRPGroupAssignment(x.id);
  updateFHRPGroupAssignment(x.id);
  updateFHRPGroupAssignment(x.id);
  verifyFHRPGroupAssignmentExists(x.id);
  verifyFHRPGroupAssignmentUpdated(x.id);
});

bthread("PatchedDeviceBayTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedDeviceBayTemplateRequest(x.id);
  updatePatchedDeviceBayTemplateRequest(x.id);
  updatePatchedDeviceBayTemplateRequest(x.id);
  verifyPatchedDeviceBayTemplateRequestExists(x.id);
  verifyPatchedDeviceBayTemplateRequestUpdated(x.id);
});

bthread("PaginatedNotificationList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedNotificationList(x.id);
  updatePaginatedNotificationList(x.id);
  updatePaginatedNotificationList(x.id);
  verifyPaginatedNotificationListExists(x.id);
  verifyPaginatedNotificationListUpdated(x.id);
});

bthread("AggregateRequest lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAggregateRequest(x.id);
  updateAggregateRequest(x.id);
  updateAggregateRequest(x.id);
  verifyAggregateRequestExists(x.id);
  verifyAggregateRequestUpdated(x.id);
});

bthread("BriefDeviceTypeRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefDeviceTypeRequest(x.id);
  updateBriefDeviceTypeRequest(x.id);
  updateBriefDeviceTypeRequest(x.id);
  verifyBriefDeviceTypeRequestExists(x.id);
  verifyBriefDeviceTypeRequestUpdated(x.id);
});

bthread("BriefVirtualMachineRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVirtualMachineRequest(x.id);
  updateBriefVirtualMachineRequest(x.id);
  updateBriefVirtualMachineRequest(x.id);
  verifyBriefVirtualMachineRequestExists(x.id);
  verifyBriefVirtualMachineRequestUpdated(x.id);
});

bthread("VirtualDiskRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVirtualDiskRequest(x.id);
  updateVirtualDiskRequest(x.id);
  updateVirtualDiskRequest(x.id);
  verifyVirtualDiskRequestExists(x.id);
  verifyVirtualDiskRequestUpdated(x.id);
});

bthread("PatchedWritablePowerOutletTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritablePowerOutletTemplateRequest(x.id);
  updatePatchedWritablePowerOutletTemplateRequest(x.id);
  updatePatchedWritablePowerOutletTemplateRequest(x.id);
  verifyPatchedWritablePowerOutletTemplateRequestExists(x.id);
  verifyPatchedWritablePowerOutletTemplateRequestUpdated(x.id);
});

bthread("WebhookRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWebhookRequest(x.id);
  updateWebhookRequest(x.id);
  updateWebhookRequest(x.id);
  verifyWebhookRequestExists(x.id);
  verifyWebhookRequestUpdated(x.id);
});

bthread("WritablePowerOutletRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritablePowerOutletRequest(x.id);
  updateWritablePowerOutletRequest(x.id);
  updateWritablePowerOutletRequest(x.id);
  verifyWritablePowerOutletRequestExists(x.id);
  verifyWritablePowerOutletRequestUpdated(x.id);
});

bthread("WritablePowerOutletTemplateRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritablePowerOutletTemplateRequest(x.id);
  updateWritablePowerOutletTemplateRequest(x.id);
  updateWritablePowerOutletTemplateRequest(x.id);
  verifyWritablePowerOutletTemplateRequestExists(x.id);
  verifyWritablePowerOutletTemplateRequestUpdated(x.id);
});

bthread("PatchedWritableServiceRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableServiceRequest(x.id);
  updatePatchedWritableServiceRequest(x.id);
  updatePatchedWritableServiceRequest(x.id);
  verifyPatchedWritableServiceRequestExists(x.id);
  verifyPatchedWritableServiceRequestUpdated(x.id);
});

bthread("WritableServiceRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableServiceRequest(x.id);
  updateWritableServiceRequest(x.id);
  updateWritableServiceRequest(x.id);
  verifyWritableServiceRequestExists(x.id);
  verifyWritableServiceRequestUpdated(x.id);
});

bthread("PatchedManufacturerRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedManufacturerRequest(x.id);
  updatePatchedManufacturerRequest(x.id);
  updatePatchedManufacturerRequest(x.id);
  verifyPatchedManufacturerRequestExists(x.id);
  verifyPatchedManufacturerRequestUpdated(x.id);
});

bthread("PaginatedRackReservationList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedRackReservationList(x.id);
  updatePaginatedRackReservationList(x.id);
  updatePaginatedRackReservationList(x.id);
  verifyPaginatedRackReservationListExists(x.id);
  verifyPaginatedRackReservationListUpdated(x.id);
});

bthread("ManufacturerRequest lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addManufacturerRequest(x.id);
  updateManufacturerRequest(x.id);
  updateManufacturerRequest(x.id);
  verifyManufacturerRequestExists(x.id);
  verifyManufacturerRequestUpdated(x.id);
});

bthread("RouteTarget lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRouteTarget(x.id);
  updateRouteTarget(x.id);
  updateRouteTarget(x.id);
  verifyRouteTargetExists(x.id);
  verifyRouteTargetUpdated(x.id);
});

bthread("VRFRequest lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVRFRequest(x.id);
  updateVRFRequest(x.id);
  updateVRFRequest(x.id);
  verifyVRFRequestExists(x.id);
  verifyVRFRequestUpdated(x.id);
});

bthread("ConfigContextProfile lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConfigContextProfile(x.id);
  updateConfigContextProfile(x.id);
  updateConfigContextProfile(x.id);
  verifyConfigContextProfileExists(x.id);
  verifyConfigContextProfileUpdated(x.id);
});

bthread("PaginatedASNList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedASNList(x.id);
  updatePaginatedASNList(x.id);
  updatePaginatedASNList(x.id);
  verifyPaginatedASNListExists(x.id);
  verifyPaginatedASNListUpdated(x.id);
});

bthread("VRF lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVRF(x.id);
  updateVRF(x.id);
  updateVRF(x.id);
  verifyVRFExists(x.id);
  verifyVRFUpdated(x.id);
});

bthread("BriefIPAddressRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefIPAddressRequest(x.id);
  updateBriefIPAddressRequest(x.id);
  updateBriefIPAddressRequest(x.id);
  verifyBriefIPAddressRequestExists(x.id);
  verifyBriefIPAddressRequestUpdated(x.id);
});

bthread("WritableCableRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableCableRequest(x.id);
  updateWritableCableRequest(x.id);
  updateWritableCableRequest(x.id);
  verifyWritableCableRequestExists(x.id);
  verifyWritableCableRequestUpdated(x.id);
});

bthread("PatchedProviderNetworkRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedProviderNetworkRequest(x.id);
  updatePatchedProviderNetworkRequest(x.id);
  updatePatchedProviderNetworkRequest(x.id);
  verifyPatchedProviderNetworkRequestExists(x.id);
  verifyPatchedProviderNetworkRequestUpdated(x.id);
});

bthread("WritableRackRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableRackRequest(x.id);
  updateWritableRackRequest(x.id);
  updateWritableRackRequest(x.id);
  verifyWritableRackRequestExists(x.id);
  verifyWritableRackRequestUpdated(x.id);
});

bthread("FrontPort lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFrontPort(x.id);
  updateFrontPort(x.id);
  updateFrontPort(x.id);
  verifyFrontPortExists(x.id);
  verifyFrontPortUpdated(x.id);
});

bthread("WritableWirelessLANRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritableWirelessLANRequest(x.id);
  updateWritableWirelessLANRequest(x.id);
  updateWritableWirelessLANRequest(x.id);
  verifyWritableWirelessLANRequestExists(x.id);
  verifyWritableWirelessLANRequestUpdated(x.id);
});

bthread("PaginatedPowerPanelList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedPowerPanelList(x.id);
  updatePaginatedPowerPanelList(x.id);
  updatePaginatedPowerPanelList(x.id);
  verifyPaginatedPowerPanelListExists(x.id);
  verifyPaginatedPowerPanelListUpdated(x.id);
});

bthread("PaginatedCustomFieldChoiceSetList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedCustomFieldChoiceSetList(x.id);
  updatePaginatedCustomFieldChoiceSetList(x.id);
  updatePaginatedCustomFieldChoiceSetList(x.id);
  verifyPaginatedCustomFieldChoiceSetListExists(x.id);
  verifyPaginatedCustomFieldChoiceSetListUpdated(x.id);
});

bthread("PaginatedDeviceRoleList lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPaginatedDeviceRoleList(x.id);
  updatePaginatedDeviceRoleList(x.id);
  updatePaginatedDeviceRoleList(x.id);
  verifyPaginatedDeviceRoleListExists(x.id);
  verifyPaginatedDeviceRoleListUpdated(x.id);
});

bthread("PatchedWritableRearPortTemplateRequest lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPatchedWritableRearPortTemplateRequest(x.id);
  updatePatchedWritableRearPortTemplateRequest(x.id);
  updatePatchedWritableRearPortTemplateRequest(x.id);
  verifyPatchedWritableRearPortTemplateRequestExists(x.id);
  verifyPatchedWritableRearPortTemplateRequestUpdated(x.id);
});

bthread("BriefVirtualCircuit lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefVirtualCircuit(x.id);
  updateBriefVirtualCircuit(x.id);
  updateBriefVirtualCircuit(x.id);
  verifyBriefVirtualCircuitExists(x.id);
  verifyBriefVirtualCircuitUpdated(x.id);
});

bthread("NestedVirtualMachine lifecycle", function () {
  const x = pick([{id: "N001"}, {id: "N002"}]);
  addNestedVirtualMachine(x.id);
  updateNestedVirtualMachine(x.id);
  updateNestedVirtualMachine(x.id);
  verifyNestedVirtualMachineExists(x.id);
  verifyNestedVirtualMachineUpdated(x.id);
});

bthread("BriefClusterRequest lifecycle", function () {
  const x = pick([{id: "B001"}, {id: "B002"}]);
  addBriefClusterRequest(x.id);
  updateBriefClusterRequest(x.id);
  updateBriefClusterRequest(x.id);
  verifyBriefClusterRequestExists(x.id);
  verifyBriefClusterRequestUpdated(x.id);
});

bthread("WritablePowerPortRequest lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWritablePowerPortRequest(x.id);
  updateWritablePowerPortRequest(x.id);
  updateWritablePowerPortRequest(x.id);
  verifyWritablePowerPortRequestExists(x.id);
  verifyWritablePowerPortRequestUpdated(x.id);
});

bthread("ExportTemplate lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addExportTemplate(x.id);
  updateExportTemplate(x.id);
  updateExportTemplate(x.id);
  verifyExportTemplateExists(x.id);
  verifyExportTemplateUpdated(x.id);
});

// ===== PASSIVE ASSERTIONS =====

bthread("PaginatedFrontPortTemplateList create verification", function () {
  const e = waitForAnyPaginatedFrontPortTemplateListAdded();
  block(matchDeletePaginatedFrontPortTemplateList(e.id, ANY), function () {
    verifyPaginatedFrontPortTemplateListExists(e.id);
  });
});

bthread("PaginatedFrontPortTemplateList update verification", function () {
  const e = waitForAnyPaginatedFrontPortTemplateListUpdated();
  block(matchDeletePaginatedFrontPortTemplateList(e.id, ANY), function () {
    verifyPaginatedFrontPortTemplateListUpdated(e.id);
  });
});

bthread("PaginatedFrontPortTemplateList delete verification", function () {
  const e = waitForAnyPaginatedFrontPortTemplateListDeleted();
  block(matchAddPaginatedFrontPortTemplateList(e.id, ANY), function () {
    verifyPaginatedFrontPortTemplateListDoesNotExist(e.id);
  });
});

bthread("BriefDataSourceRequest create verification", function () {
  const e = waitForAnyBriefDataSourceRequestAdded();
  block(matchDeleteBriefDataSourceRequest(e.id, ANY), function () {
    verifyBriefDataSourceRequestExists(e.id);
  });
});

bthread("BriefDataSourceRequest update verification", function () {
  const e = waitForAnyBriefDataSourceRequestUpdated();
  block(matchDeleteBriefDataSourceRequest(e.id, ANY), function () {
    verifyBriefDataSourceRequestUpdated(e.id);
  });
});

bthread("BriefDataSourceRequest delete verification", function () {
  const e = waitForAnyBriefDataSourceRequestDeleted();
  block(matchAddBriefDataSourceRequest(e.id, ANY), function () {
    verifyBriefDataSourceRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedASNRangeList create verification", function () {
  const e = waitForAnyPaginatedASNRangeListAdded();
  block(matchDeletePaginatedASNRangeList(e.id, ANY), function () {
    verifyPaginatedASNRangeListExists(e.id);
  });
});

bthread("PaginatedASNRangeList update verification", function () {
  const e = waitForAnyPaginatedASNRangeListUpdated();
  block(matchDeletePaginatedASNRangeList(e.id, ANY), function () {
    verifyPaginatedASNRangeListUpdated(e.id);
  });
});

bthread("PaginatedASNRangeList delete verification", function () {
  const e = waitForAnyPaginatedASNRangeListDeleted();
  block(matchAddPaginatedASNRangeList(e.id, ANY), function () {
    verifyPaginatedASNRangeListDoesNotExist(e.id);
  });
});

bthread("PatchedNotificationGroupRequest create verification", function () {
  const e = waitForAnyPatchedNotificationGroupRequestAdded();
  block(matchDeletePatchedNotificationGroupRequest(e.id, ANY), function () {
    verifyPatchedNotificationGroupRequestExists(e.id);
  });
});

bthread("PatchedNotificationGroupRequest update verification", function () {
  const e = waitForAnyPatchedNotificationGroupRequestUpdated();
  block(matchDeletePatchedNotificationGroupRequest(e.id, ANY), function () {
    verifyPatchedNotificationGroupRequestUpdated(e.id);
  });
});

bthread("PatchedNotificationGroupRequest delete verification", function () {
  const e = waitForAnyPatchedNotificationGroupRequestDeleted();
  block(matchAddPatchedNotificationGroupRequest(e.id, ANY), function () {
    verifyPatchedNotificationGroupRequestDoesNotExist(e.id);
  });
});

bthread("RearPortTemplateRequest create verification", function () {
  const e = waitForAnyRearPortTemplateRequestAdded();
  block(matchDeleteRearPortTemplateRequest(e.id, ANY), function () {
    verifyRearPortTemplateRequestExists(e.id);
  });
});

bthread("RearPortTemplateRequest update verification", function () {
  const e = waitForAnyRearPortTemplateRequestUpdated();
  block(matchDeleteRearPortTemplateRequest(e.id, ANY), function () {
    verifyRearPortTemplateRequestUpdated(e.id);
  });
});

bthread("RearPortTemplateRequest delete verification", function () {
  const e = waitForAnyRearPortTemplateRequestDeleted();
  block(matchAddRearPortTemplateRequest(e.id, ANY), function () {
    verifyRearPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("IPAddressRequest create verification", function () {
  const e = waitForAnyIPAddressRequestAdded();
  block(matchDeleteIPAddressRequest(e.id, ANY), function () {
    verifyIPAddressRequestExists(e.id);
  });
});

bthread("IPAddressRequest update verification", function () {
  const e = waitForAnyIPAddressRequestUpdated();
  block(matchDeleteIPAddressRequest(e.id, ANY), function () {
    verifyIPAddressRequestUpdated(e.id);
  });
});

bthread("IPAddressRequest delete verification", function () {
  const e = waitForAnyIPAddressRequestDeleted();
  block(matchAddIPAddressRequest(e.id, ANY), function () {
    verifyIPAddressRequestDoesNotExist(e.id);
  });
});

bthread("ProviderNetworkRequest create verification", function () {
  const e = waitForAnyProviderNetworkRequestAdded();
  block(matchDeleteProviderNetworkRequest(e.id, ANY), function () {
    verifyProviderNetworkRequestExists(e.id);
  });
});

bthread("ProviderNetworkRequest update verification", function () {
  const e = waitForAnyProviderNetworkRequestUpdated();
  block(matchDeleteProviderNetworkRequest(e.id, ANY), function () {
    verifyProviderNetworkRequestUpdated(e.id);
  });
});

bthread("ProviderNetworkRequest delete verification", function () {
  const e = waitForAnyProviderNetworkRequestDeleted();
  block(matchAddProviderNetworkRequest(e.id, ANY), function () {
    verifyProviderNetworkRequestDoesNotExist(e.id);
  });
});

bthread("BriefL2VPNTerminationRequest create verification", function () {
  const e = waitForAnyBriefL2VPNTerminationRequestAdded();
  block(matchDeleteBriefL2VPNTerminationRequest(e.id, ANY), function () {
    verifyBriefL2VPNTerminationRequestExists(e.id);
  });
});

bthread("BriefL2VPNTerminationRequest update verification", function () {
  const e = waitForAnyBriefL2VPNTerminationRequestUpdated();
  block(matchDeleteBriefL2VPNTerminationRequest(e.id, ANY), function () {
    verifyBriefL2VPNTerminationRequestUpdated(e.id);
  });
});

bthread("BriefL2VPNTerminationRequest delete verification", function () {
  const e = waitForAnyBriefL2VPNTerminationRequestDeleted();
  block(matchAddBriefL2VPNTerminationRequest(e.id, ANY), function () {
    verifyBriefL2VPNTerminationRequestDoesNotExist(e.id);
  });
});

bthread("ObjectPermission create verification", function () {
  const e = waitForAnyObjectPermissionAdded();
  block(matchDeleteObjectPermission(e.id, ANY), function () {
    verifyObjectPermissionExists(e.id);
  });
});

bthread("ObjectPermission update verification", function () {
  const e = waitForAnyObjectPermissionUpdated();
  block(matchDeleteObjectPermission(e.id, ANY), function () {
    verifyObjectPermissionUpdated(e.id);
  });
});

bthread("ObjectPermission delete verification", function () {
  const e = waitForAnyObjectPermissionDeleted();
  block(matchAddObjectPermission(e.id, ANY), function () {
    verifyObjectPermissionDoesNotExist(e.id);
  });
});

bthread("PaginatedIPAddressList create verification", function () {
  const e = waitForAnyPaginatedIPAddressListAdded();
  block(matchDeletePaginatedIPAddressList(e.id, ANY), function () {
    verifyPaginatedIPAddressListExists(e.id);
  });
});

bthread("PaginatedIPAddressList update verification", function () {
  const e = waitForAnyPaginatedIPAddressListUpdated();
  block(matchDeletePaginatedIPAddressList(e.id, ANY), function () {
    verifyPaginatedIPAddressListUpdated(e.id);
  });
});

bthread("PaginatedIPAddressList delete verification", function () {
  const e = waitForAnyPaginatedIPAddressListDeleted();
  block(matchAddPaginatedIPAddressList(e.id, ANY), function () {
    verifyPaginatedIPAddressListDoesNotExist(e.id);
  });
});

bthread("FrontPortRearPort create verification", function () {
  const e = waitForAnyFrontPortRearPortAdded();
  block(matchDeleteFrontPortRearPort(e.id, ANY), function () {
    verifyFrontPortRearPortExists(e.id);
  });
});

bthread("FrontPortRearPort update verification", function () {
  const e = waitForAnyFrontPortRearPortUpdated();
  block(matchDeleteFrontPortRearPort(e.id, ANY), function () {
    verifyFrontPortRearPortUpdated(e.id);
  });
});

bthread("FrontPortRearPort delete verification", function () {
  const e = waitForAnyFrontPortRearPortDeleted();
  block(matchAddFrontPortRearPort(e.id, ANY), function () {
    verifyFrontPortRearPortDoesNotExist(e.id);
  });
});

bthread("PatchedWritableEventRuleRequest create verification", function () {
  const e = waitForAnyPatchedWritableEventRuleRequestAdded();
  block(matchDeletePatchedWritableEventRuleRequest(e.id, ANY), function () {
    verifyPatchedWritableEventRuleRequestExists(e.id);
  });
});

bthread("PatchedWritableEventRuleRequest update verification", function () {
  const e = waitForAnyPatchedWritableEventRuleRequestUpdated();
  block(matchDeletePatchedWritableEventRuleRequest(e.id, ANY), function () {
    verifyPatchedWritableEventRuleRequestUpdated(e.id);
  });
});

bthread("PatchedWritableEventRuleRequest delete verification", function () {
  const e = waitForAnyPatchedWritableEventRuleRequestDeleted();
  block(matchAddPatchedWritableEventRuleRequest(e.id, ANY), function () {
    verifyPatchedWritableEventRuleRequestDoesNotExist(e.id);
  });
});

bthread("BriefRackRequest create verification", function () {
  const e = waitForAnyBriefRackRequestAdded();
  block(matchDeleteBriefRackRequest(e.id, ANY), function () {
    verifyBriefRackRequestExists(e.id);
  });
});

bthread("BriefRackRequest update verification", function () {
  const e = waitForAnyBriefRackRequestUpdated();
  block(matchDeleteBriefRackRequest(e.id, ANY), function () {
    verifyBriefRackRequestUpdated(e.id);
  });
});

bthread("BriefRackRequest delete verification", function () {
  const e = waitForAnyBriefRackRequestDeleted();
  block(matchAddBriefRackRequest(e.id, ANY), function () {
    verifyBriefRackRequestDoesNotExist(e.id);
  });
});

bthread("CustomLinkRequest create verification", function () {
  const e = waitForAnyCustomLinkRequestAdded();
  block(matchDeleteCustomLinkRequest(e.id, ANY), function () {
    verifyCustomLinkRequestExists(e.id);
  });
});

bthread("CustomLinkRequest update verification", function () {
  const e = waitForAnyCustomLinkRequestUpdated();
  block(matchDeleteCustomLinkRequest(e.id, ANY), function () {
    verifyCustomLinkRequestUpdated(e.id);
  });
});

bthread("CustomLinkRequest delete verification", function () {
  const e = waitForAnyCustomLinkRequestDeleted();
  block(matchAddCustomLinkRequest(e.id, ANY), function () {
    verifyCustomLinkRequestDoesNotExist(e.id);
  });
});

bthread("ConsoleServerPort create verification", function () {
  const e = waitForAnyConsoleServerPortAdded();
  block(matchDeleteConsoleServerPort(e.id, ANY), function () {
    verifyConsoleServerPortExists(e.id);
  });
});

bthread("ConsoleServerPort update verification", function () {
  const e = waitForAnyConsoleServerPortUpdated();
  block(matchDeleteConsoleServerPort(e.id, ANY), function () {
    verifyConsoleServerPortUpdated(e.id);
  });
});

bthread("ConsoleServerPort delete verification", function () {
  const e = waitForAnyConsoleServerPortDeleted();
  block(matchAddConsoleServerPort(e.id, ANY), function () {
    verifyConsoleServerPortDoesNotExist(e.id);
  });
});

bthread("PatchedCircuitTypeRequest create verification", function () {
  const e = waitForAnyPatchedCircuitTypeRequestAdded();
  block(matchDeletePatchedCircuitTypeRequest(e.id, ANY), function () {
    verifyPatchedCircuitTypeRequestExists(e.id);
  });
});

bthread("PatchedCircuitTypeRequest update verification", function () {
  const e = waitForAnyPatchedCircuitTypeRequestUpdated();
  block(matchDeletePatchedCircuitTypeRequest(e.id, ANY), function () {
    verifyPatchedCircuitTypeRequestUpdated(e.id);
  });
});

bthread("PatchedCircuitTypeRequest delete verification", function () {
  const e = waitForAnyPatchedCircuitTypeRequestDeleted();
  block(matchAddPatchedCircuitTypeRequest(e.id, ANY), function () {
    verifyPatchedCircuitTypeRequestDoesNotExist(e.id);
  });
});

bthread("BriefVirtualChassis create verification", function () {
  const e = waitForAnyBriefVirtualChassisAdded();
  block(matchDeleteBriefVirtualChassis(e.id, ANY), function () {
    verifyBriefVirtualChassisExists(e.id);
  });
});

bthread("BriefVirtualChassis update verification", function () {
  const e = waitForAnyBriefVirtualChassisUpdated();
  block(matchDeleteBriefVirtualChassis(e.id, ANY), function () {
    verifyBriefVirtualChassisUpdated(e.id);
  });
});

bthread("BriefVirtualChassis delete verification", function () {
  const e = waitForAnyBriefVirtualChassisDeleted();
  block(matchAddBriefVirtualChassis(e.id, ANY), function () {
    verifyBriefVirtualChassisDoesNotExist(e.id);
  });
});

bthread("BriefMACAddressRequest create verification", function () {
  const e = waitForAnyBriefMACAddressRequestAdded();
  block(matchDeleteBriefMACAddressRequest(e.id, ANY), function () {
    verifyBriefMACAddressRequestExists(e.id);
  });
});

bthread("BriefMACAddressRequest update verification", function () {
  const e = waitForAnyBriefMACAddressRequestUpdated();
  block(matchDeleteBriefMACAddressRequest(e.id, ANY), function () {
    verifyBriefMACAddressRequestUpdated(e.id);
  });
});

bthread("BriefMACAddressRequest delete verification", function () {
  const e = waitForAnyBriefMACAddressRequestDeleted();
  block(matchAddBriefMACAddressRequest(e.id, ANY), function () {
    verifyBriefMACAddressRequestDoesNotExist(e.id);
  });
});

bthread("IPSecPolicy create verification", function () {
  const e = waitForAnyIPSecPolicyAdded();
  block(matchDeleteIPSecPolicy(e.id, ANY), function () {
    verifyIPSecPolicyExists(e.id);
  });
});

bthread("IPSecPolicy update verification", function () {
  const e = waitForAnyIPSecPolicyUpdated();
  block(matchDeleteIPSecPolicy(e.id, ANY), function () {
    verifyIPSecPolicyUpdated(e.id);
  });
});

bthread("IPSecPolicy delete verification", function () {
  const e = waitForAnyIPSecPolicyDeleted();
  block(matchAddIPSecPolicy(e.id, ANY), function () {
    verifyIPSecPolicyDoesNotExist(e.id);
  });
});

bthread("IPRangeRequest create verification", function () {
  const e = waitForAnyIPRangeRequestAdded();
  block(matchDeleteIPRangeRequest(e.id, ANY), function () {
    verifyIPRangeRequestExists(e.id);
  });
});

bthread("IPRangeRequest update verification", function () {
  const e = waitForAnyIPRangeRequestUpdated();
  block(matchDeleteIPRangeRequest(e.id, ANY), function () {
    verifyIPRangeRequestUpdated(e.id);
  });
});

bthread("IPRangeRequest delete verification", function () {
  const e = waitForAnyIPRangeRequestDeleted();
  block(matchAddIPRangeRequest(e.id, ANY), function () {
    verifyIPRangeRequestDoesNotExist(e.id);
  });
});

bthread("WritablePowerPortTemplateRequest create verification", function () {
  const e = waitForAnyWritablePowerPortTemplateRequestAdded();
  block(matchDeleteWritablePowerPortTemplateRequest(e.id, ANY), function () {
    verifyWritablePowerPortTemplateRequestExists(e.id);
  });
});

bthread("WritablePowerPortTemplateRequest update verification", function () {
  const e = waitForAnyWritablePowerPortTemplateRequestUpdated();
  block(matchDeleteWritablePowerPortTemplateRequest(e.id, ANY), function () {
    verifyWritablePowerPortTemplateRequestUpdated(e.id);
  });
});

bthread("WritablePowerPortTemplateRequest delete verification", function () {
  const e = waitForAnyWritablePowerPortTemplateRequestDeleted();
  block(matchAddWritablePowerPortTemplateRequest(e.id, ANY), function () {
    verifyWritablePowerPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedCircuitGroupList create verification", function () {
  const e = waitForAnyPaginatedCircuitGroupListAdded();
  block(matchDeletePaginatedCircuitGroupList(e.id, ANY), function () {
    verifyPaginatedCircuitGroupListExists(e.id);
  });
});

bthread("PaginatedCircuitGroupList update verification", function () {
  const e = waitForAnyPaginatedCircuitGroupListUpdated();
  block(matchDeletePaginatedCircuitGroupList(e.id, ANY), function () {
    verifyPaginatedCircuitGroupListUpdated(e.id);
  });
});

bthread("PaginatedCircuitGroupList delete verification", function () {
  const e = waitForAnyPaginatedCircuitGroupListDeleted();
  block(matchAddPaginatedCircuitGroupList(e.id, ANY), function () {
    verifyPaginatedCircuitGroupListDoesNotExist(e.id);
  });
});

bthread("BriefModuleTypeProfile create verification", function () {
  const e = waitForAnyBriefModuleTypeProfileAdded();
  block(matchDeleteBriefModuleTypeProfile(e.id, ANY), function () {
    verifyBriefModuleTypeProfileExists(e.id);
  });
});

bthread("BriefModuleTypeProfile update verification", function () {
  const e = waitForAnyBriefModuleTypeProfileUpdated();
  block(matchDeleteBriefModuleTypeProfile(e.id, ANY), function () {
    verifyBriefModuleTypeProfileUpdated(e.id);
  });
});

bthread("BriefModuleTypeProfile delete verification", function () {
  const e = waitForAnyBriefModuleTypeProfileDeleted();
  block(matchAddBriefModuleTypeProfile(e.id, ANY), function () {
    verifyBriefModuleTypeProfileDoesNotExist(e.id);
  });
});

bthread("BriefVRF create verification", function () {
  const e = waitForAnyBriefVRFAdded();
  block(matchDeleteBriefVRF(e.id, ANY), function () {
    verifyBriefVRFExists(e.id);
  });
});

bthread("BriefVRF update verification", function () {
  const e = waitForAnyBriefVRFUpdated();
  block(matchDeleteBriefVRF(e.id, ANY), function () {
    verifyBriefVRFUpdated(e.id);
  });
});

bthread("BriefVRF delete verification", function () {
  const e = waitForAnyBriefVRFDeleted();
  block(matchAddBriefVRF(e.id, ANY), function () {
    verifyBriefVRFDoesNotExist(e.id);
  });
});

bthread("FrontPortRequest create verification", function () {
  const e = waitForAnyFrontPortRequestAdded();
  block(matchDeleteFrontPortRequest(e.id, ANY), function () {
    verifyFrontPortRequestExists(e.id);
  });
});

bthread("FrontPortRequest update verification", function () {
  const e = waitForAnyFrontPortRequestUpdated();
  block(matchDeleteFrontPortRequest(e.id, ANY), function () {
    verifyFrontPortRequestUpdated(e.id);
  });
});

bthread("FrontPortRequest delete verification", function () {
  const e = waitForAnyFrontPortRequestDeleted();
  block(matchAddFrontPortRequest(e.id, ANY), function () {
    verifyFrontPortRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedConsoleServerPortList create verification", function () {
  const e = waitForAnyPaginatedConsoleServerPortListAdded();
  block(matchDeletePaginatedConsoleServerPortList(e.id, ANY), function () {
    verifyPaginatedConsoleServerPortListExists(e.id);
  });
});

bthread("PaginatedConsoleServerPortList update verification", function () {
  const e = waitForAnyPaginatedConsoleServerPortListUpdated();
  block(matchDeletePaginatedConsoleServerPortList(e.id, ANY), function () {
    verifyPaginatedConsoleServerPortListUpdated(e.id);
  });
});

bthread("PaginatedConsoleServerPortList delete verification", function () {
  const e = waitForAnyPaginatedConsoleServerPortListDeleted();
  block(matchAddPaginatedConsoleServerPortList(e.id, ANY), function () {
    verifyPaginatedConsoleServerPortListDoesNotExist(e.id);
  });
});

bthread("BriefTunnelGroup create verification", function () {
  const e = waitForAnyBriefTunnelGroupAdded();
  block(matchDeleteBriefTunnelGroup(e.id, ANY), function () {
    verifyBriefTunnelGroupExists(e.id);
  });
});

bthread("BriefTunnelGroup update verification", function () {
  const e = waitForAnyBriefTunnelGroupUpdated();
  block(matchDeleteBriefTunnelGroup(e.id, ANY), function () {
    verifyBriefTunnelGroupUpdated(e.id);
  });
});

bthread("BriefTunnelGroup delete verification", function () {
  const e = waitForAnyBriefTunnelGroupDeleted();
  block(matchAddBriefTunnelGroup(e.id, ANY), function () {
    verifyBriefTunnelGroupDoesNotExist(e.id);
  });
});

bthread("WritableVirtualMachineWithConfigContextRequest create verification", function () {
  const e = waitForAnyWritableVirtualMachineWithConfigContextRequestAdded();
  block(matchDeleteWritableVirtualMachineWithConfigContextRequest(e.id, ANY), function () {
    verifyWritableVirtualMachineWithConfigContextRequestExists(e.id);
  });
});

bthread("WritableVirtualMachineWithConfigContextRequest update verification", function () {
  const e = waitForAnyWritableVirtualMachineWithConfigContextRequestUpdated();
  block(matchDeleteWritableVirtualMachineWithConfigContextRequest(e.id, ANY), function () {
    verifyWritableVirtualMachineWithConfigContextRequestUpdated(e.id);
  });
});

bthread("WritableVirtualMachineWithConfigContextRequest delete verification", function () {
  const e = waitForAnyWritableVirtualMachineWithConfigContextRequestDeleted();
  block(matchAddWritableVirtualMachineWithConfigContextRequest(e.id, ANY), function () {
    verifyWritableVirtualMachineWithConfigContextRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableRackReservationRequest create verification", function () {
  const e = waitForAnyPatchedWritableRackReservationRequestAdded();
  block(matchDeletePatchedWritableRackReservationRequest(e.id, ANY), function () {
    verifyPatchedWritableRackReservationRequestExists(e.id);
  });
});

bthread("PatchedWritableRackReservationRequest update verification", function () {
  const e = waitForAnyPatchedWritableRackReservationRequestUpdated();
  block(matchDeletePatchedWritableRackReservationRequest(e.id, ANY), function () {
    verifyPatchedWritableRackReservationRequestUpdated(e.id);
  });
});

bthread("PatchedWritableRackReservationRequest delete verification", function () {
  const e = waitForAnyPatchedWritableRackReservationRequestDeleted();
  block(matchAddPatchedWritableRackReservationRequest(e.id, ANY), function () {
    verifyPatchedWritableRackReservationRequestDoesNotExist(e.id);
  });
});

bthread("ConsoleServerPortRequest create verification", function () {
  const e = waitForAnyConsoleServerPortRequestAdded();
  block(matchDeleteConsoleServerPortRequest(e.id, ANY), function () {
    verifyConsoleServerPortRequestExists(e.id);
  });
});

bthread("ConsoleServerPortRequest update verification", function () {
  const e = waitForAnyConsoleServerPortRequestUpdated();
  block(matchDeleteConsoleServerPortRequest(e.id, ANY), function () {
    verifyConsoleServerPortRequestUpdated(e.id);
  });
});

bthread("ConsoleServerPortRequest delete verification", function () {
  const e = waitForAnyConsoleServerPortRequestDeleted();
  block(matchAddConsoleServerPortRequest(e.id, ANY), function () {
    verifyConsoleServerPortRequestDoesNotExist(e.id);
  });
});

bthread("WritableWirelessLinkRequest create verification", function () {
  const e = waitForAnyWritableWirelessLinkRequestAdded();
  block(matchDeleteWritableWirelessLinkRequest(e.id, ANY), function () {
    verifyWritableWirelessLinkRequestExists(e.id);
  });
});

bthread("WritableWirelessLinkRequest update verification", function () {
  const e = waitForAnyWritableWirelessLinkRequestUpdated();
  block(matchDeleteWritableWirelessLinkRequest(e.id, ANY), function () {
    verifyWritableWirelessLinkRequestUpdated(e.id);
  });
});

bthread("WritableWirelessLinkRequest delete verification", function () {
  const e = waitForAnyWritableWirelessLinkRequestDeleted();
  block(matchAddWritableWirelessLinkRequest(e.id, ANY), function () {
    verifyWritableWirelessLinkRequestDoesNotExist(e.id);
  });
});

bthread("WritableVirtualDeviceContextRequest create verification", function () {
  const e = waitForAnyWritableVirtualDeviceContextRequestAdded();
  block(matchDeleteWritableVirtualDeviceContextRequest(e.id, ANY), function () {
    verifyWritableVirtualDeviceContextRequestExists(e.id);
  });
});

bthread("WritableVirtualDeviceContextRequest update verification", function () {
  const e = waitForAnyWritableVirtualDeviceContextRequestUpdated();
  block(matchDeleteWritableVirtualDeviceContextRequest(e.id, ANY), function () {
    verifyWritableVirtualDeviceContextRequestUpdated(e.id);
  });
});

bthread("WritableVirtualDeviceContextRequest delete verification", function () {
  const e = waitForAnyWritableVirtualDeviceContextRequestDeleted();
  block(matchAddWritableVirtualDeviceContextRequest(e.id, ANY), function () {
    verifyWritableVirtualDeviceContextRequestDoesNotExist(e.id);
  });
});

bthread("BriefLocation create verification", function () {
  const e = waitForAnyBriefLocationAdded();
  block(matchDeleteBriefLocation(e.id, ANY), function () {
    verifyBriefLocationExists(e.id);
  });
});

bthread("BriefLocation update verification", function () {
  const e = waitForAnyBriefLocationUpdated();
  block(matchDeleteBriefLocation(e.id, ANY), function () {
    verifyBriefLocationUpdated(e.id);
  });
});

bthread("BriefLocation delete verification", function () {
  const e = waitForAnyBriefLocationDeleted();
  block(matchAddBriefLocation(e.id, ANY), function () {
    verifyBriefLocationDoesNotExist(e.id);
  });
});

bthread("WritableInterfaceTemplateRequest create verification", function () {
  const e = waitForAnyWritableInterfaceTemplateRequestAdded();
  block(matchDeleteWritableInterfaceTemplateRequest(e.id, ANY), function () {
    verifyWritableInterfaceTemplateRequestExists(e.id);
  });
});

bthread("WritableInterfaceTemplateRequest update verification", function () {
  const e = waitForAnyWritableInterfaceTemplateRequestUpdated();
  block(matchDeleteWritableInterfaceTemplateRequest(e.id, ANY), function () {
    verifyWritableInterfaceTemplateRequestUpdated(e.id);
  });
});

bthread("WritableInterfaceTemplateRequest delete verification", function () {
  const e = waitForAnyWritableInterfaceTemplateRequestDeleted();
  block(matchAddWritableInterfaceTemplateRequest(e.id, ANY), function () {
    verifyWritableInterfaceTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritablePowerPortTemplateRequest create verification", function () {
  const e = waitForAnyPatchedWritablePowerPortTemplateRequestAdded();
  block(matchDeletePatchedWritablePowerPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerPortTemplateRequestExists(e.id);
  });
});

bthread("PatchedWritablePowerPortTemplateRequest update verification", function () {
  const e = waitForAnyPatchedWritablePowerPortTemplateRequestUpdated();
  block(matchDeletePatchedWritablePowerPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerPortTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedWritablePowerPortTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedWritablePowerPortTemplateRequestDeleted();
  block(matchAddPatchedWritablePowerPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableConsolePortRequest create verification", function () {
  const e = waitForAnyPatchedWritableConsolePortRequestAdded();
  block(matchDeletePatchedWritableConsolePortRequest(e.id, ANY), function () {
    verifyPatchedWritableConsolePortRequestExists(e.id);
  });
});

bthread("PatchedWritableConsolePortRequest update verification", function () {
  const e = waitForAnyPatchedWritableConsolePortRequestUpdated();
  block(matchDeletePatchedWritableConsolePortRequest(e.id, ANY), function () {
    verifyPatchedWritableConsolePortRequestUpdated(e.id);
  });
});

bthread("PatchedWritableConsolePortRequest delete verification", function () {
  const e = waitForAnyPatchedWritableConsolePortRequestDeleted();
  block(matchAddPatchedWritableConsolePortRequest(e.id, ANY), function () {
    verifyPatchedWritableConsolePortRequestDoesNotExist(e.id);
  });
});

bthread("NestedVMInterfaceRequest create verification", function () {
  const e = waitForAnyNestedVMInterfaceRequestAdded();
  block(matchDeleteNestedVMInterfaceRequest(e.id, ANY), function () {
    verifyNestedVMInterfaceRequestExists(e.id);
  });
});

bthread("NestedVMInterfaceRequest update verification", function () {
  const e = waitForAnyNestedVMInterfaceRequestUpdated();
  block(matchDeleteNestedVMInterfaceRequest(e.id, ANY), function () {
    verifyNestedVMInterfaceRequestUpdated(e.id);
  });
});

bthread("NestedVMInterfaceRequest delete verification", function () {
  const e = waitForAnyNestedVMInterfaceRequestDeleted();
  block(matchAddNestedVMInterfaceRequest(e.id, ANY), function () {
    verifyNestedVMInterfaceRequestDoesNotExist(e.id);
  });
});

bthread("BriefCustomFieldChoiceSetRequest create verification", function () {
  const e = waitForAnyBriefCustomFieldChoiceSetRequestAdded();
  block(matchDeleteBriefCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyBriefCustomFieldChoiceSetRequestExists(e.id);
  });
});

bthread("BriefCustomFieldChoiceSetRequest update verification", function () {
  const e = waitForAnyBriefCustomFieldChoiceSetRequestUpdated();
  block(matchDeleteBriefCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyBriefCustomFieldChoiceSetRequestUpdated(e.id);
  });
});

bthread("BriefCustomFieldChoiceSetRequest delete verification", function () {
  const e = waitForAnyBriefCustomFieldChoiceSetRequestDeleted();
  block(matchAddBriefCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyBriefCustomFieldChoiceSetRequestDoesNotExist(e.id);
  });
});

bthread("WritableIPRangeRequest create verification", function () {
  const e = waitForAnyWritableIPRangeRequestAdded();
  block(matchDeleteWritableIPRangeRequest(e.id, ANY), function () {
    verifyWritableIPRangeRequestExists(e.id);
  });
});

bthread("WritableIPRangeRequest update verification", function () {
  const e = waitForAnyWritableIPRangeRequestUpdated();
  block(matchDeleteWritableIPRangeRequest(e.id, ANY), function () {
    verifyWritableIPRangeRequestUpdated(e.id);
  });
});

bthread("WritableIPRangeRequest delete verification", function () {
  const e = waitForAnyWritableIPRangeRequestDeleted();
  block(matchAddWritableIPRangeRequest(e.id, ANY), function () {
    verifyWritableIPRangeRequestDoesNotExist(e.id);
  });
});

bthread("DeviceRole create verification", function () {
  const e = waitForAnyDeviceRoleAdded();
  block(matchDeleteDeviceRole(e.id, ANY), function () {
    verifyDeviceRoleExists(e.id);
  });
});

bthread("DeviceRole update verification", function () {
  const e = waitForAnyDeviceRoleUpdated();
  block(matchDeleteDeviceRole(e.id, ANY), function () {
    verifyDeviceRoleUpdated(e.id);
  });
});

bthread("DeviceRole delete verification", function () {
  const e = waitForAnyDeviceRoleDeleted();
  block(matchAddDeviceRole(e.id, ANY), function () {
    verifyDeviceRoleDoesNotExist(e.id);
  });
});

bthread("ConfigContextRequest create verification", function () {
  const e = waitForAnyConfigContextRequestAdded();
  block(matchDeleteConfigContextRequest(e.id, ANY), function () {
    verifyConfigContextRequestExists(e.id);
  });
});

bthread("ConfigContextRequest update verification", function () {
  const e = waitForAnyConfigContextRequestUpdated();
  block(matchDeleteConfigContextRequest(e.id, ANY), function () {
    verifyConfigContextRequestUpdated(e.id);
  });
});

bthread("ConfigContextRequest delete verification", function () {
  const e = waitForAnyConfigContextRequestDeleted();
  block(matchAddConfigContextRequest(e.id, ANY), function () {
    verifyConfigContextRequestDoesNotExist(e.id);
  });
});

bthread("RackReservation create verification", function () {
  const e = waitForAnyRackReservationAdded();
  block(matchDeleteRackReservation(e.id, ANY), function () {
    verifyRackReservationExists(e.id);
  });
});

bthread("RackReservation update verification", function () {
  const e = waitForAnyRackReservationUpdated();
  block(matchDeleteRackReservation(e.id, ANY), function () {
    verifyRackReservationUpdated(e.id);
  });
});

bthread("RackReservation delete verification", function () {
  const e = waitForAnyRackReservationDeleted();
  block(matchAddRackReservation(e.id, ANY), function () {
    verifyRackReservationDoesNotExist(e.id);
  });
});

bthread("NestedVMInterface create verification", function () {
  const e = waitForAnyNestedVMInterfaceAdded();
  block(matchDeleteNestedVMInterface(e.id, ANY), function () {
    verifyNestedVMInterfaceExists(e.id);
  });
});

bthread("NestedVMInterface update verification", function () {
  const e = waitForAnyNestedVMInterfaceUpdated();
  block(matchDeleteNestedVMInterface(e.id, ANY), function () {
    verifyNestedVMInterfaceUpdated(e.id);
  });
});

bthread("NestedVMInterface delete verification", function () {
  const e = waitForAnyNestedVMInterfaceDeleted();
  block(matchAddNestedVMInterface(e.id, ANY), function () {
    verifyNestedVMInterfaceDoesNotExist(e.id);
  });
});

bthread("BriefRackRoleRequest create verification", function () {
  const e = waitForAnyBriefRackRoleRequestAdded();
  block(matchDeleteBriefRackRoleRequest(e.id, ANY), function () {
    verifyBriefRackRoleRequestExists(e.id);
  });
});

bthread("BriefRackRoleRequest update verification", function () {
  const e = waitForAnyBriefRackRoleRequestUpdated();
  block(matchDeleteBriefRackRoleRequest(e.id, ANY), function () {
    verifyBriefRackRoleRequestUpdated(e.id);
  });
});

bthread("BriefRackRoleRequest delete verification", function () {
  const e = waitForAnyBriefRackRoleRequestDeleted();
  block(matchAddBriefRackRoleRequest(e.id, ANY), function () {
    verifyBriefRackRoleRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedVLANList create verification", function () {
  const e = waitForAnyPaginatedVLANListAdded();
  block(matchDeletePaginatedVLANList(e.id, ANY), function () {
    verifyPaginatedVLANListExists(e.id);
  });
});

bthread("PaginatedVLANList update verification", function () {
  const e = waitForAnyPaginatedVLANListUpdated();
  block(matchDeletePaginatedVLANList(e.id, ANY), function () {
    verifyPaginatedVLANListUpdated(e.id);
  });
});

bthread("PaginatedVLANList delete verification", function () {
  const e = waitForAnyPaginatedVLANListDeleted();
  block(matchAddPaginatedVLANList(e.id, ANY), function () {
    verifyPaginatedVLANListDoesNotExist(e.id);
  });
});

bthread("VLANRequest create verification", function () {
  const e = waitForAnyVLANRequestAdded();
  block(matchDeleteVLANRequest(e.id, ANY), function () {
    verifyVLANRequestExists(e.id);
  });
});

bthread("VLANRequest update verification", function () {
  const e = waitForAnyVLANRequestUpdated();
  block(matchDeleteVLANRequest(e.id, ANY), function () {
    verifyVLANRequestUpdated(e.id);
  });
});

bthread("VLANRequest delete verification", function () {
  const e = waitForAnyVLANRequestDeleted();
  block(matchAddVLANRequest(e.id, ANY), function () {
    verifyVLANRequestDoesNotExist(e.id);
  });
});

bthread("TunnelRequest create verification", function () {
  const e = waitForAnyTunnelRequestAdded();
  block(matchDeleteTunnelRequest(e.id, ANY), function () {
    verifyTunnelRequestExists(e.id);
  });
});

bthread("TunnelRequest update verification", function () {
  const e = waitForAnyTunnelRequestUpdated();
  block(matchDeleteTunnelRequest(e.id, ANY), function () {
    verifyTunnelRequestUpdated(e.id);
  });
});

bthread("TunnelRequest delete verification", function () {
  const e = waitForAnyTunnelRequestDeleted();
  block(matchAddTunnelRequest(e.id, ANY), function () {
    verifyTunnelRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedConsolePortTemplateList create verification", function () {
  const e = waitForAnyPaginatedConsolePortTemplateListAdded();
  block(matchDeletePaginatedConsolePortTemplateList(e.id, ANY), function () {
    verifyPaginatedConsolePortTemplateListExists(e.id);
  });
});

bthread("PaginatedConsolePortTemplateList update verification", function () {
  const e = waitForAnyPaginatedConsolePortTemplateListUpdated();
  block(matchDeletePaginatedConsolePortTemplateList(e.id, ANY), function () {
    verifyPaginatedConsolePortTemplateListUpdated(e.id);
  });
});

bthread("PaginatedConsolePortTemplateList delete verification", function () {
  const e = waitForAnyPaginatedConsolePortTemplateListDeleted();
  block(matchAddPaginatedConsolePortTemplateList(e.id, ANY), function () {
    verifyPaginatedConsolePortTemplateListDoesNotExist(e.id);
  });
});

bthread("ServiceTemplateRequest create verification", function () {
  const e = waitForAnyServiceTemplateRequestAdded();
  block(matchDeleteServiceTemplateRequest(e.id, ANY), function () {
    verifyServiceTemplateRequestExists(e.id);
  });
});

bthread("ServiceTemplateRequest update verification", function () {
  const e = waitForAnyServiceTemplateRequestUpdated();
  block(matchDeleteServiceTemplateRequest(e.id, ANY), function () {
    verifyServiceTemplateRequestUpdated(e.id);
  });
});

bthread("ServiceTemplateRequest delete verification", function () {
  const e = waitForAnyServiceTemplateRequestDeleted();
  block(matchAddServiceTemplateRequest(e.id, ANY), function () {
    verifyServiceTemplateRequestDoesNotExist(e.id);
  });
});

bthread("Script create verification", function () {
  const e = waitForAnyScriptAdded();
  block(matchDeleteScript(e.id, ANY), function () {
    verifyScriptExists(e.id);
  });
});

bthread("Script update verification", function () {
  const e = waitForAnyScriptUpdated();
  block(matchDeleteScript(e.id, ANY), function () {
    verifyScriptUpdated(e.id);
  });
});

bthread("Script delete verification", function () {
  const e = waitForAnyScriptDeleted();
  block(matchAddScript(e.id, ANY), function () {
    verifyScriptDoesNotExist(e.id);
  });
});

bthread("PatchedVirtualDiskRequest create verification", function () {
  const e = waitForAnyPatchedVirtualDiskRequestAdded();
  block(matchDeletePatchedVirtualDiskRequest(e.id, ANY), function () {
    verifyPatchedVirtualDiskRequestExists(e.id);
  });
});

bthread("PatchedVirtualDiskRequest update verification", function () {
  const e = waitForAnyPatchedVirtualDiskRequestUpdated();
  block(matchDeletePatchedVirtualDiskRequest(e.id, ANY), function () {
    verifyPatchedVirtualDiskRequestUpdated(e.id);
  });
});

bthread("PatchedVirtualDiskRequest delete verification", function () {
  const e = waitForAnyPatchedVirtualDiskRequestDeleted();
  block(matchAddPatchedVirtualDiskRequest(e.id, ANY), function () {
    verifyPatchedVirtualDiskRequestDoesNotExist(e.id);
  });
});

bthread("SubscriptionRequest create verification", function () {
  const e = waitForAnySubscriptionRequestAdded();
  block(matchDeleteSubscriptionRequest(e.id, ANY), function () {
    verifySubscriptionRequestExists(e.id);
  });
});

bthread("SubscriptionRequest update verification", function () {
  const e = waitForAnySubscriptionRequestUpdated();
  block(matchDeleteSubscriptionRequest(e.id, ANY), function () {
    verifySubscriptionRequestUpdated(e.id);
  });
});

bthread("SubscriptionRequest delete verification", function () {
  const e = waitForAnySubscriptionRequestDeleted();
  block(matchAddSubscriptionRequest(e.id, ANY), function () {
    verifySubscriptionRequestDoesNotExist(e.id);
  });
});

bthread("InventoryItemTemplate create verification", function () {
  const e = waitForAnyInventoryItemTemplateAdded();
  block(matchDeleteInventoryItemTemplate(e.id, ANY), function () {
    verifyInventoryItemTemplateExists(e.id);
  });
});

bthread("InventoryItemTemplate update verification", function () {
  const e = waitForAnyInventoryItemTemplateUpdated();
  block(matchDeleteInventoryItemTemplate(e.id, ANY), function () {
    verifyInventoryItemTemplateUpdated(e.id);
  });
});

bthread("InventoryItemTemplate delete verification", function () {
  const e = waitForAnyInventoryItemTemplateDeleted();
  block(matchAddInventoryItemTemplate(e.id, ANY), function () {
    verifyInventoryItemTemplateDoesNotExist(e.id);
  });
});

bthread("PaginatedVirtualDiskList create verification", function () {
  const e = waitForAnyPaginatedVirtualDiskListAdded();
  block(matchDeletePaginatedVirtualDiskList(e.id, ANY), function () {
    verifyPaginatedVirtualDiskListExists(e.id);
  });
});

bthread("PaginatedVirtualDiskList update verification", function () {
  const e = waitForAnyPaginatedVirtualDiskListUpdated();
  block(matchDeletePaginatedVirtualDiskList(e.id, ANY), function () {
    verifyPaginatedVirtualDiskListUpdated(e.id);
  });
});

bthread("PaginatedVirtualDiskList delete verification", function () {
  const e = waitForAnyPaginatedVirtualDiskListDeleted();
  block(matchAddPaginatedVirtualDiskList(e.id, ANY), function () {
    verifyPaginatedVirtualDiskListDoesNotExist(e.id);
  });
});

bthread("PatchedCircuitTerminationRequest create verification", function () {
  const e = waitForAnyPatchedCircuitTerminationRequestAdded();
  block(matchDeletePatchedCircuitTerminationRequest(e.id, ANY), function () {
    verifyPatchedCircuitTerminationRequestExists(e.id);
  });
});

bthread("PatchedCircuitTerminationRequest update verification", function () {
  const e = waitForAnyPatchedCircuitTerminationRequestUpdated();
  block(matchDeletePatchedCircuitTerminationRequest(e.id, ANY), function () {
    verifyPatchedCircuitTerminationRequestUpdated(e.id);
  });
});

bthread("PatchedCircuitTerminationRequest delete verification", function () {
  const e = waitForAnyPatchedCircuitTerminationRequestDeleted();
  block(matchAddPatchedCircuitTerminationRequest(e.id, ANY), function () {
    verifyPatchedCircuitTerminationRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedRegionList create verification", function () {
  const e = waitForAnyPaginatedRegionListAdded();
  block(matchDeletePaginatedRegionList(e.id, ANY), function () {
    verifyPaginatedRegionListExists(e.id);
  });
});

bthread("PaginatedRegionList update verification", function () {
  const e = waitForAnyPaginatedRegionListUpdated();
  block(matchDeletePaginatedRegionList(e.id, ANY), function () {
    verifyPaginatedRegionListUpdated(e.id);
  });
});

bthread("PaginatedRegionList delete verification", function () {
  const e = waitForAnyPaginatedRegionListDeleted();
  block(matchAddPaginatedRegionList(e.id, ANY), function () {
    verifyPaginatedRegionListDoesNotExist(e.id);
  });
});

bthread("CableTermination create verification", function () {
  const e = waitForAnyCableTerminationAdded();
  block(matchDeleteCableTermination(e.id, ANY), function () {
    verifyCableTerminationExists(e.id);
  });
});

bthread("CableTermination update verification", function () {
  const e = waitForAnyCableTerminationUpdated();
  block(matchDeleteCableTermination(e.id, ANY), function () {
    verifyCableTerminationUpdated(e.id);
  });
});

bthread("CableTermination delete verification", function () {
  const e = waitForAnyCableTerminationDeleted();
  block(matchAddCableTermination(e.id, ANY), function () {
    verifyCableTerminationDoesNotExist(e.id);
  });
});

bthread("CircuitTerminationRequest create verification", function () {
  const e = waitForAnyCircuitTerminationRequestAdded();
  block(matchDeleteCircuitTerminationRequest(e.id, ANY), function () {
    verifyCircuitTerminationRequestExists(e.id);
  });
});

bthread("CircuitTerminationRequest update verification", function () {
  const e = waitForAnyCircuitTerminationRequestUpdated();
  block(matchDeleteCircuitTerminationRequest(e.id, ANY), function () {
    verifyCircuitTerminationRequestUpdated(e.id);
  });
});

bthread("CircuitTerminationRequest delete verification", function () {
  const e = waitForAnyCircuitTerminationRequestDeleted();
  block(matchAddCircuitTerminationRequest(e.id, ANY), function () {
    verifyCircuitTerminationRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedIPSecProfileList create verification", function () {
  const e = waitForAnyPaginatedIPSecProfileListAdded();
  block(matchDeletePaginatedIPSecProfileList(e.id, ANY), function () {
    verifyPaginatedIPSecProfileListExists(e.id);
  });
});

bthread("PaginatedIPSecProfileList update verification", function () {
  const e = waitForAnyPaginatedIPSecProfileListUpdated();
  block(matchDeletePaginatedIPSecProfileList(e.id, ANY), function () {
    verifyPaginatedIPSecProfileListUpdated(e.id);
  });
});

bthread("PaginatedIPSecProfileList delete verification", function () {
  const e = waitForAnyPaginatedIPSecProfileListDeleted();
  block(matchAddPaginatedIPSecProfileList(e.id, ANY), function () {
    verifyPaginatedIPSecProfileListDoesNotExist(e.id);
  });
});

bthread("VLANTranslationPolicyRequest create verification", function () {
  const e = waitForAnyVLANTranslationPolicyRequestAdded();
  block(matchDeleteVLANTranslationPolicyRequest(e.id, ANY), function () {
    verifyVLANTranslationPolicyRequestExists(e.id);
  });
});

bthread("VLANTranslationPolicyRequest update verification", function () {
  const e = waitForAnyVLANTranslationPolicyRequestUpdated();
  block(matchDeleteVLANTranslationPolicyRequest(e.id, ANY), function () {
    verifyVLANTranslationPolicyRequestUpdated(e.id);
  });
});

bthread("VLANTranslationPolicyRequest delete verification", function () {
  const e = waitForAnyVLANTranslationPolicyRequestDeleted();
  block(matchAddVLANTranslationPolicyRequest(e.id, ANY), function () {
    verifyVLANTranslationPolicyRequestDoesNotExist(e.id);
  });
});

bthread("WritableJournalEntryRequest create verification", function () {
  const e = waitForAnyWritableJournalEntryRequestAdded();
  block(matchDeleteWritableJournalEntryRequest(e.id, ANY), function () {
    verifyWritableJournalEntryRequestExists(e.id);
  });
});

bthread("WritableJournalEntryRequest update verification", function () {
  const e = waitForAnyWritableJournalEntryRequestUpdated();
  block(matchDeleteWritableJournalEntryRequest(e.id, ANY), function () {
    verifyWritableJournalEntryRequestUpdated(e.id);
  });
});

bthread("WritableJournalEntryRequest delete verification", function () {
  const e = waitForAnyWritableJournalEntryRequestDeleted();
  block(matchAddWritableJournalEntryRequest(e.id, ANY), function () {
    verifyWritableJournalEntryRequestDoesNotExist(e.id);
  });
});

bthread("Prefix create verification", function () {
  const e = waitForAnyPrefixAdded();
  block(matchDeletePrefix(e.id, ANY), function () {
    verifyPrefixExists(e.id);
  });
});

bthread("Prefix update verification", function () {
  const e = waitForAnyPrefixUpdated();
  block(matchDeletePrefix(e.id, ANY), function () {
    verifyPrefixUpdated(e.id);
  });
});

bthread("Prefix delete verification", function () {
  const e = waitForAnyPrefixDeleted();
  block(matchAddPrefix(e.id, ANY), function () {
    verifyPrefixDoesNotExist(e.id);
  });
});

bthread("PatchedWritableWirelessLANRequest create verification", function () {
  const e = waitForAnyPatchedWritableWirelessLANRequestAdded();
  block(matchDeletePatchedWritableWirelessLANRequest(e.id, ANY), function () {
    verifyPatchedWritableWirelessLANRequestExists(e.id);
  });
});

bthread("PatchedWritableWirelessLANRequest update verification", function () {
  const e = waitForAnyPatchedWritableWirelessLANRequestUpdated();
  block(matchDeletePatchedWritableWirelessLANRequest(e.id, ANY), function () {
    verifyPatchedWritableWirelessLANRequestUpdated(e.id);
  });
});

bthread("PatchedWritableWirelessLANRequest delete verification", function () {
  const e = waitForAnyPatchedWritableWirelessLANRequestDeleted();
  block(matchAddPatchedWritableWirelessLANRequest(e.id, ANY), function () {
    verifyPatchedWritableWirelessLANRequestDoesNotExist(e.id);
  });
});

bthread("CircuitType create verification", function () {
  const e = waitForAnyCircuitTypeAdded();
  block(matchDeleteCircuitType(e.id, ANY), function () {
    verifyCircuitTypeExists(e.id);
  });
});

bthread("CircuitType update verification", function () {
  const e = waitForAnyCircuitTypeUpdated();
  block(matchDeleteCircuitType(e.id, ANY), function () {
    verifyCircuitTypeUpdated(e.id);
  });
});

bthread("CircuitType delete verification", function () {
  const e = waitForAnyCircuitTypeDeleted();
  block(matchAddCircuitType(e.id, ANY), function () {
    verifyCircuitTypeDoesNotExist(e.id);
  });
});

bthread("WritableCircuitGroupAssignmentRequest create verification", function () {
  const e = waitForAnyWritableCircuitGroupAssignmentRequestAdded();
  block(matchDeleteWritableCircuitGroupAssignmentRequest(e.id, ANY), function () {
    verifyWritableCircuitGroupAssignmentRequestExists(e.id);
  });
});

bthread("WritableCircuitGroupAssignmentRequest update verification", function () {
  const e = waitForAnyWritableCircuitGroupAssignmentRequestUpdated();
  block(matchDeleteWritableCircuitGroupAssignmentRequest(e.id, ANY), function () {
    verifyWritableCircuitGroupAssignmentRequestUpdated(e.id);
  });
});

bthread("WritableCircuitGroupAssignmentRequest delete verification", function () {
  const e = waitForAnyWritableCircuitGroupAssignmentRequestDeleted();
  block(matchAddWritableCircuitGroupAssignmentRequest(e.id, ANY), function () {
    verifyWritableCircuitGroupAssignmentRequestDoesNotExist(e.id);
  });
});

bthread("NestedWirelessLANGroupRequest create verification", function () {
  const e = waitForAnyNestedWirelessLANGroupRequestAdded();
  block(matchDeleteNestedWirelessLANGroupRequest(e.id, ANY), function () {
    verifyNestedWirelessLANGroupRequestExists(e.id);
  });
});

bthread("NestedWirelessLANGroupRequest update verification", function () {
  const e = waitForAnyNestedWirelessLANGroupRequestUpdated();
  block(matchDeleteNestedWirelessLANGroupRequest(e.id, ANY), function () {
    verifyNestedWirelessLANGroupRequestUpdated(e.id);
  });
});

bthread("NestedWirelessLANGroupRequest delete verification", function () {
  const e = waitForAnyNestedWirelessLANGroupRequestDeleted();
  block(matchAddNestedWirelessLANGroupRequest(e.id, ANY), function () {
    verifyNestedWirelessLANGroupRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedRackTypeList create verification", function () {
  const e = waitForAnyPaginatedRackTypeListAdded();
  block(matchDeletePaginatedRackTypeList(e.id, ANY), function () {
    verifyPaginatedRackTypeListExists(e.id);
  });
});

bthread("PaginatedRackTypeList update verification", function () {
  const e = waitForAnyPaginatedRackTypeListUpdated();
  block(matchDeletePaginatedRackTypeList(e.id, ANY), function () {
    verifyPaginatedRackTypeListUpdated(e.id);
  });
});

bthread("PaginatedRackTypeList delete verification", function () {
  const e = waitForAnyPaginatedRackTypeListDeleted();
  block(matchAddPaginatedRackTypeList(e.id, ANY), function () {
    verifyPaginatedRackTypeListDoesNotExist(e.id);
  });
});

bthread("PaginatedWebhookList create verification", function () {
  const e = waitForAnyPaginatedWebhookListAdded();
  block(matchDeletePaginatedWebhookList(e.id, ANY), function () {
    verifyPaginatedWebhookListExists(e.id);
  });
});

bthread("PaginatedWebhookList update verification", function () {
  const e = waitForAnyPaginatedWebhookListUpdated();
  block(matchDeletePaginatedWebhookList(e.id, ANY), function () {
    verifyPaginatedWebhookListUpdated(e.id);
  });
});

bthread("PaginatedWebhookList delete verification", function () {
  const e = waitForAnyPaginatedWebhookListDeleted();
  block(matchAddPaginatedWebhookList(e.id, ANY), function () {
    verifyPaginatedWebhookListDoesNotExist(e.id);
  });
});

bthread("PatchedVLANTranslationPolicyRequest create verification", function () {
  const e = waitForAnyPatchedVLANTranslationPolicyRequestAdded();
  block(matchDeletePatchedVLANTranslationPolicyRequest(e.id, ANY), function () {
    verifyPatchedVLANTranslationPolicyRequestExists(e.id);
  });
});

bthread("PatchedVLANTranslationPolicyRequest update verification", function () {
  const e = waitForAnyPatchedVLANTranslationPolicyRequestUpdated();
  block(matchDeletePatchedVLANTranslationPolicyRequest(e.id, ANY), function () {
    verifyPatchedVLANTranslationPolicyRequestUpdated(e.id);
  });
});

bthread("PatchedVLANTranslationPolicyRequest delete verification", function () {
  const e = waitForAnyPatchedVLANTranslationPolicyRequestDeleted();
  block(matchAddPatchedVLANTranslationPolicyRequest(e.id, ANY), function () {
    verifyPatchedVLANTranslationPolicyRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedCableList create verification", function () {
  const e = waitForAnyPaginatedCableListAdded();
  block(matchDeletePaginatedCableList(e.id, ANY), function () {
    verifyPaginatedCableListExists(e.id);
  });
});

bthread("PaginatedCableList update verification", function () {
  const e = waitForAnyPaginatedCableListUpdated();
  block(matchDeletePaginatedCableList(e.id, ANY), function () {
    verifyPaginatedCableListUpdated(e.id);
  });
});

bthread("PaginatedCableList delete verification", function () {
  const e = waitForAnyPaginatedCableListDeleted();
  block(matchAddPaginatedCableList(e.id, ANY), function () {
    verifyPaginatedCableListDoesNotExist(e.id);
  });
});

bthread("Webhook create verification", function () {
  const e = waitForAnyWebhookAdded();
  block(matchDeleteWebhook(e.id, ANY), function () {
    verifyWebhookExists(e.id);
  });
});

bthread("Webhook update verification", function () {
  const e = waitForAnyWebhookUpdated();
  block(matchDeleteWebhook(e.id, ANY), function () {
    verifyWebhookUpdated(e.id);
  });
});

bthread("Webhook delete verification", function () {
  const e = waitForAnyWebhookDeleted();
  block(matchAddWebhook(e.id, ANY), function () {
    verifyWebhookDoesNotExist(e.id);
  });
});

bthread("PaginatedRackList create verification", function () {
  const e = waitForAnyPaginatedRackListAdded();
  block(matchDeletePaginatedRackList(e.id, ANY), function () {
    verifyPaginatedRackListExists(e.id);
  });
});

bthread("PaginatedRackList update verification", function () {
  const e = waitForAnyPaginatedRackListUpdated();
  block(matchDeletePaginatedRackList(e.id, ANY), function () {
    verifyPaginatedRackListUpdated(e.id);
  });
});

bthread("PaginatedRackList delete verification", function () {
  const e = waitForAnyPaginatedRackListDeleted();
  block(matchAddPaginatedRackList(e.id, ANY), function () {
    verifyPaginatedRackListDoesNotExist(e.id);
  });
});

bthread("PatchedFHRPGroupRequest create verification", function () {
  const e = waitForAnyPatchedFHRPGroupRequestAdded();
  block(matchDeletePatchedFHRPGroupRequest(e.id, ANY), function () {
    verifyPatchedFHRPGroupRequestExists(e.id);
  });
});

bthread("PatchedFHRPGroupRequest update verification", function () {
  const e = waitForAnyPatchedFHRPGroupRequestUpdated();
  block(matchDeletePatchedFHRPGroupRequest(e.id, ANY), function () {
    verifyPatchedFHRPGroupRequestUpdated(e.id);
  });
});

bthread("PatchedFHRPGroupRequest delete verification", function () {
  const e = waitForAnyPatchedFHRPGroupRequestDeleted();
  block(matchAddPatchedFHRPGroupRequest(e.id, ANY), function () {
    verifyPatchedFHRPGroupRequestDoesNotExist(e.id);
  });
});

bthread("VirtualCircuitType create verification", function () {
  const e = waitForAnyVirtualCircuitTypeAdded();
  block(matchDeleteVirtualCircuitType(e.id, ANY), function () {
    verifyVirtualCircuitTypeExists(e.id);
  });
});

bthread("VirtualCircuitType update verification", function () {
  const e = waitForAnyVirtualCircuitTypeUpdated();
  block(matchDeleteVirtualCircuitType(e.id, ANY), function () {
    verifyVirtualCircuitTypeUpdated(e.id);
  });
});

bthread("VirtualCircuitType delete verification", function () {
  const e = waitForAnyVirtualCircuitTypeDeleted();
  block(matchAddVirtualCircuitType(e.id, ANY), function () {
    verifyVirtualCircuitTypeDoesNotExist(e.id);
  });
});

bthread("BriefVLANTranslationPolicy create verification", function () {
  const e = waitForAnyBriefVLANTranslationPolicyAdded();
  block(matchDeleteBriefVLANTranslationPolicy(e.id, ANY), function () {
    verifyBriefVLANTranslationPolicyExists(e.id);
  });
});

bthread("BriefVLANTranslationPolicy update verification", function () {
  const e = waitForAnyBriefVLANTranslationPolicyUpdated();
  block(matchDeleteBriefVLANTranslationPolicy(e.id, ANY), function () {
    verifyBriefVLANTranslationPolicyUpdated(e.id);
  });
});

bthread("BriefVLANTranslationPolicy delete verification", function () {
  const e = waitForAnyBriefVLANTranslationPolicyDeleted();
  block(matchAddBriefVLANTranslationPolicy(e.id, ANY), function () {
    verifyBriefVLANTranslationPolicyDoesNotExist(e.id);
  });
});

bthread("BriefIPSecProfile create verification", function () {
  const e = waitForAnyBriefIPSecProfileAdded();
  block(matchDeleteBriefIPSecProfile(e.id, ANY), function () {
    verifyBriefIPSecProfileExists(e.id);
  });
});

bthread("BriefIPSecProfile update verification", function () {
  const e = waitForAnyBriefIPSecProfileUpdated();
  block(matchDeleteBriefIPSecProfile(e.id, ANY), function () {
    verifyBriefIPSecProfileUpdated(e.id);
  });
});

bthread("BriefIPSecProfile delete verification", function () {
  const e = waitForAnyBriefIPSecProfileDeleted();
  block(matchAddBriefIPSecProfile(e.id, ANY), function () {
    verifyBriefIPSecProfileDoesNotExist(e.id);
  });
});

bthread("PaginatedTableConfigList create verification", function () {
  const e = waitForAnyPaginatedTableConfigListAdded();
  block(matchDeletePaginatedTableConfigList(e.id, ANY), function () {
    verifyPaginatedTableConfigListExists(e.id);
  });
});

bthread("PaginatedTableConfigList update verification", function () {
  const e = waitForAnyPaginatedTableConfigListUpdated();
  block(matchDeletePaginatedTableConfigList(e.id, ANY), function () {
    verifyPaginatedTableConfigListUpdated(e.id);
  });
});

bthread("PaginatedTableConfigList delete verification", function () {
  const e = waitForAnyPaginatedTableConfigListDeleted();
  block(matchAddPaginatedTableConfigList(e.id, ANY), function () {
    verifyPaginatedTableConfigListDoesNotExist(e.id);
  });
});

bthread("ModuleBayTemplate create verification", function () {
  const e = waitForAnyModuleBayTemplateAdded();
  block(matchDeleteModuleBayTemplate(e.id, ANY), function () {
    verifyModuleBayTemplateExists(e.id);
  });
});

bthread("ModuleBayTemplate update verification", function () {
  const e = waitForAnyModuleBayTemplateUpdated();
  block(matchDeleteModuleBayTemplate(e.id, ANY), function () {
    verifyModuleBayTemplateUpdated(e.id);
  });
});

bthread("ModuleBayTemplate delete verification", function () {
  const e = waitForAnyModuleBayTemplateDeleted();
  block(matchAddModuleBayTemplate(e.id, ANY), function () {
    verifyModuleBayTemplateDoesNotExist(e.id);
  });
});

bthread("BriefWirelessLANGroupRequest create verification", function () {
  const e = waitForAnyBriefWirelessLANGroupRequestAdded();
  block(matchDeleteBriefWirelessLANGroupRequest(e.id, ANY), function () {
    verifyBriefWirelessLANGroupRequestExists(e.id);
  });
});

bthread("BriefWirelessLANGroupRequest update verification", function () {
  const e = waitForAnyBriefWirelessLANGroupRequestUpdated();
  block(matchDeleteBriefWirelessLANGroupRequest(e.id, ANY), function () {
    verifyBriefWirelessLANGroupRequestUpdated(e.id);
  });
});

bthread("BriefWirelessLANGroupRequest delete verification", function () {
  const e = waitForAnyBriefWirelessLANGroupRequestDeleted();
  block(matchAddBriefWirelessLANGroupRequest(e.id, ANY), function () {
    verifyBriefWirelessLANGroupRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedContactRoleList create verification", function () {
  const e = waitForAnyPaginatedContactRoleListAdded();
  block(matchDeletePaginatedContactRoleList(e.id, ANY), function () {
    verifyPaginatedContactRoleListExists(e.id);
  });
});

bthread("PaginatedContactRoleList update verification", function () {
  const e = waitForAnyPaginatedContactRoleListUpdated();
  block(matchDeletePaginatedContactRoleList(e.id, ANY), function () {
    verifyPaginatedContactRoleListUpdated(e.id);
  });
});

bthread("PaginatedContactRoleList delete verification", function () {
  const e = waitForAnyPaginatedContactRoleListDeleted();
  block(matchAddPaginatedContactRoleList(e.id, ANY), function () {
    verifyPaginatedContactRoleListDoesNotExist(e.id);
  });
});

bthread("PatchedUserRequest create verification", function () {
  const e = waitForAnyPatchedUserRequestAdded();
  block(matchDeletePatchedUserRequest(e.id, ANY), function () {
    verifyPatchedUserRequestExists(e.id);
  });
});

bthread("PatchedUserRequest update verification", function () {
  const e = waitForAnyPatchedUserRequestUpdated();
  block(matchDeletePatchedUserRequest(e.id, ANY), function () {
    verifyPatchedUserRequestUpdated(e.id);
  });
});

bthread("PatchedUserRequest delete verification", function () {
  const e = waitForAnyPatchedUserRequestDeleted();
  block(matchAddPatchedUserRequest(e.id, ANY), function () {
    verifyPatchedUserRequestDoesNotExist(e.id);
  });
});

bthread("ContactGroup create verification", function () {
  const e = waitForAnyContactGroupAdded();
  block(matchDeleteContactGroup(e.id, ANY), function () {
    verifyContactGroupExists(e.id);
  });
});

bthread("ContactGroup update verification", function () {
  const e = waitForAnyContactGroupUpdated();
  block(matchDeleteContactGroup(e.id, ANY), function () {
    verifyContactGroupUpdated(e.id);
  });
});

bthread("ContactGroup delete verification", function () {
  const e = waitForAnyContactGroupDeleted();
  block(matchAddContactGroup(e.id, ANY), function () {
    verifyContactGroupDoesNotExist(e.id);
  });
});

bthread("CableRequest create verification", function () {
  const e = waitForAnyCableRequestAdded();
  block(matchDeleteCableRequest(e.id, ANY), function () {
    verifyCableRequestExists(e.id);
  });
});

bthread("CableRequest update verification", function () {
  const e = waitForAnyCableRequestUpdated();
  block(matchDeleteCableRequest(e.id, ANY), function () {
    verifyCableRequestUpdated(e.id);
  });
});

bthread("CableRequest delete verification", function () {
  const e = waitForAnyCableRequestDeleted();
  block(matchAddCableRequest(e.id, ANY), function () {
    verifyCableRequestDoesNotExist(e.id);
  });
});

bthread("RouteTargetRequest create verification", function () {
  const e = waitForAnyRouteTargetRequestAdded();
  block(matchDeleteRouteTargetRequest(e.id, ANY), function () {
    verifyRouteTargetRequestExists(e.id);
  });
});

bthread("RouteTargetRequest update verification", function () {
  const e = waitForAnyRouteTargetRequestUpdated();
  block(matchDeleteRouteTargetRequest(e.id, ANY), function () {
    verifyRouteTargetRequestUpdated(e.id);
  });
});

bthread("RouteTargetRequest delete verification", function () {
  const e = waitForAnyRouteTargetRequestDeleted();
  block(matchAddRouteTargetRequest(e.id, ANY), function () {
    verifyRouteTargetRequestDoesNotExist(e.id);
  });
});

bthread("IPSecProposalRequest create verification", function () {
  const e = waitForAnyIPSecProposalRequestAdded();
  block(matchDeleteIPSecProposalRequest(e.id, ANY), function () {
    verifyIPSecProposalRequestExists(e.id);
  });
});

bthread("IPSecProposalRequest update verification", function () {
  const e = waitForAnyIPSecProposalRequestUpdated();
  block(matchDeleteIPSecProposalRequest(e.id, ANY), function () {
    verifyIPSecProposalRequestUpdated(e.id);
  });
});

bthread("IPSecProposalRequest delete verification", function () {
  const e = waitForAnyIPSecProposalRequestDeleted();
  block(matchAddIPSecProposalRequest(e.id, ANY), function () {
    verifyIPSecProposalRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedRackUnitList create verification", function () {
  const e = waitForAnyPaginatedRackUnitListAdded();
  block(matchDeletePaginatedRackUnitList(e.id, ANY), function () {
    verifyPaginatedRackUnitListExists(e.id);
  });
});

bthread("PaginatedRackUnitList update verification", function () {
  const e = waitForAnyPaginatedRackUnitListUpdated();
  block(matchDeletePaginatedRackUnitList(e.id, ANY), function () {
    verifyPaginatedRackUnitListUpdated(e.id);
  });
});

bthread("PaginatedRackUnitList delete verification", function () {
  const e = waitForAnyPaginatedRackUnitListDeleted();
  block(matchAddPaginatedRackUnitList(e.id, ANY), function () {
    verifyPaginatedRackUnitListDoesNotExist(e.id);
  });
});

bthread("PaginatedTunnelTerminationList create verification", function () {
  const e = waitForAnyPaginatedTunnelTerminationListAdded();
  block(matchDeletePaginatedTunnelTerminationList(e.id, ANY), function () {
    verifyPaginatedTunnelTerminationListExists(e.id);
  });
});

bthread("PaginatedTunnelTerminationList update verification", function () {
  const e = waitForAnyPaginatedTunnelTerminationListUpdated();
  block(matchDeletePaginatedTunnelTerminationList(e.id, ANY), function () {
    verifyPaginatedTunnelTerminationListUpdated(e.id);
  });
});

bthread("PaginatedTunnelTerminationList delete verification", function () {
  const e = waitForAnyPaginatedTunnelTerminationListDeleted();
  block(matchAddPaginatedTunnelTerminationList(e.id, ANY), function () {
    verifyPaginatedTunnelTerminationListDoesNotExist(e.id);
  });
});

bthread("DashboardRequest create verification", function () {
  const e = waitForAnyDashboardRequestAdded();
  block(matchDeleteDashboardRequest(e.id, ANY), function () {
    verifyDashboardRequestExists(e.id);
  });
});

bthread("DashboardRequest update verification", function () {
  const e = waitForAnyDashboardRequestUpdated();
  block(matchDeleteDashboardRequest(e.id, ANY), function () {
    verifyDashboardRequestUpdated(e.id);
  });
});

bthread("DashboardRequest delete verification", function () {
  const e = waitForAnyDashboardRequestDeleted();
  block(matchAddDashboardRequest(e.id, ANY), function () {
    verifyDashboardRequestDoesNotExist(e.id);
  });
});

bthread("BriefVLANTranslationPolicyRequest create verification", function () {
  const e = waitForAnyBriefVLANTranslationPolicyRequestAdded();
  block(matchDeleteBriefVLANTranslationPolicyRequest(e.id, ANY), function () {
    verifyBriefVLANTranslationPolicyRequestExists(e.id);
  });
});

bthread("BriefVLANTranslationPolicyRequest update verification", function () {
  const e = waitForAnyBriefVLANTranslationPolicyRequestUpdated();
  block(matchDeleteBriefVLANTranslationPolicyRequest(e.id, ANY), function () {
    verifyBriefVLANTranslationPolicyRequestUpdated(e.id);
  });
});

bthread("BriefVLANTranslationPolicyRequest delete verification", function () {
  const e = waitForAnyBriefVLANTranslationPolicyRequestDeleted();
  block(matchAddBriefVLANTranslationPolicyRequest(e.id, ANY), function () {
    verifyBriefVLANTranslationPolicyRequestDoesNotExist(e.id);
  });
});

bthread("BriefContactRoleRequest create verification", function () {
  const e = waitForAnyBriefContactRoleRequestAdded();
  block(matchDeleteBriefContactRoleRequest(e.id, ANY), function () {
    verifyBriefContactRoleRequestExists(e.id);
  });
});

bthread("BriefContactRoleRequest update verification", function () {
  const e = waitForAnyBriefContactRoleRequestUpdated();
  block(matchDeleteBriefContactRoleRequest(e.id, ANY), function () {
    verifyBriefContactRoleRequestUpdated(e.id);
  });
});

bthread("BriefContactRoleRequest delete verification", function () {
  const e = waitForAnyBriefContactRoleRequestDeleted();
  block(matchAddBriefContactRoleRequest(e.id, ANY), function () {
    verifyBriefContactRoleRequestDoesNotExist(e.id);
  });
});

bthread("SiteRequest create verification", function () {
  const e = waitForAnySiteRequestAdded();
  block(matchDeleteSiteRequest(e.id, ANY), function () {
    verifySiteRequestExists(e.id);
  });
});

bthread("SiteRequest update verification", function () {
  const e = waitForAnySiteRequestUpdated();
  block(matchDeleteSiteRequest(e.id, ANY), function () {
    verifySiteRequestUpdated(e.id);
  });
});

bthread("SiteRequest delete verification", function () {
  const e = waitForAnySiteRequestDeleted();
  block(matchAddSiteRequest(e.id, ANY), function () {
    verifySiteRequestDoesNotExist(e.id);
  });
});

bthread("NestedInterfaceTemplate create verification", function () {
  const e = waitForAnyNestedInterfaceTemplateAdded();
  block(matchDeleteNestedInterfaceTemplate(e.id, ANY), function () {
    verifyNestedInterfaceTemplateExists(e.id);
  });
});

bthread("NestedInterfaceTemplate update verification", function () {
  const e = waitForAnyNestedInterfaceTemplateUpdated();
  block(matchDeleteNestedInterfaceTemplate(e.id, ANY), function () {
    verifyNestedInterfaceTemplateUpdated(e.id);
  });
});

bthread("NestedInterfaceTemplate delete verification", function () {
  const e = waitForAnyNestedInterfaceTemplateDeleted();
  block(matchAddNestedInterfaceTemplate(e.id, ANY), function () {
    verifyNestedInterfaceTemplateDoesNotExist(e.id);
  });
});

bthread("PaginatedModuleTypeList create verification", function () {
  const e = waitForAnyPaginatedModuleTypeListAdded();
  block(matchDeletePaginatedModuleTypeList(e.id, ANY), function () {
    verifyPaginatedModuleTypeListExists(e.id);
  });
});

bthread("PaginatedModuleTypeList update verification", function () {
  const e = waitForAnyPaginatedModuleTypeListUpdated();
  block(matchDeletePaginatedModuleTypeList(e.id, ANY), function () {
    verifyPaginatedModuleTypeListUpdated(e.id);
  });
});

bthread("PaginatedModuleTypeList delete verification", function () {
  const e = waitForAnyPaginatedModuleTypeListDeleted();
  block(matchAddPaginatedModuleTypeList(e.id, ANY), function () {
    verifyPaginatedModuleTypeListDoesNotExist(e.id);
  });
});

bthread("FrontPortTemplate create verification", function () {
  const e = waitForAnyFrontPortTemplateAdded();
  block(matchDeleteFrontPortTemplate(e.id, ANY), function () {
    verifyFrontPortTemplateExists(e.id);
  });
});

bthread("FrontPortTemplate update verification", function () {
  const e = waitForAnyFrontPortTemplateUpdated();
  block(matchDeleteFrontPortTemplate(e.id, ANY), function () {
    verifyFrontPortTemplateUpdated(e.id);
  });
});

bthread("FrontPortTemplate delete verification", function () {
  const e = waitForAnyFrontPortTemplateDeleted();
  block(matchAddFrontPortTemplate(e.id, ANY), function () {
    verifyFrontPortTemplateDoesNotExist(e.id);
  });
});

bthread("BriefRIR create verification", function () {
  const e = waitForAnyBriefRIRAdded();
  block(matchDeleteBriefRIR(e.id, ANY), function () {
    verifyBriefRIRExists(e.id);
  });
});

bthread("BriefRIR update verification", function () {
  const e = waitForAnyBriefRIRUpdated();
  block(matchDeleteBriefRIR(e.id, ANY), function () {
    verifyBriefRIRUpdated(e.id);
  });
});

bthread("BriefRIR delete verification", function () {
  const e = waitForAnyBriefRIRDeleted();
  block(matchAddBriefRIR(e.id, ANY), function () {
    verifyBriefRIRDoesNotExist(e.id);
  });
});

bthread("Job create verification", function () {
  const e = waitForAnyJobAdded();
  block(matchDeleteJob(e.id, ANY), function () {
    verifyJobExists(e.id);
  });
});

bthread("Job update verification", function () {
  const e = waitForAnyJobUpdated();
  block(matchDeleteJob(e.id, ANY), function () {
    verifyJobUpdated(e.id);
  });
});

bthread("Job delete verification", function () {
  const e = waitForAnyJobDeleted();
  block(matchAddJob(e.id, ANY), function () {
    verifyJobDoesNotExist(e.id);
  });
});

bthread("BriefContactRequest create verification", function () {
  const e = waitForAnyBriefContactRequestAdded();
  block(matchDeleteBriefContactRequest(e.id, ANY), function () {
    verifyBriefContactRequestExists(e.id);
  });
});

bthread("BriefContactRequest update verification", function () {
  const e = waitForAnyBriefContactRequestUpdated();
  block(matchDeleteBriefContactRequest(e.id, ANY), function () {
    verifyBriefContactRequestUpdated(e.id);
  });
});

bthread("BriefContactRequest delete verification", function () {
  const e = waitForAnyBriefContactRequestDeleted();
  block(matchAddBriefContactRequest(e.id, ANY), function () {
    verifyBriefContactRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedImageAttachmentList create verification", function () {
  const e = waitForAnyPaginatedImageAttachmentListAdded();
  block(matchDeletePaginatedImageAttachmentList(e.id, ANY), function () {
    verifyPaginatedImageAttachmentListExists(e.id);
  });
});

bthread("PaginatedImageAttachmentList update verification", function () {
  const e = waitForAnyPaginatedImageAttachmentListUpdated();
  block(matchDeletePaginatedImageAttachmentList(e.id, ANY), function () {
    verifyPaginatedImageAttachmentListUpdated(e.id);
  });
});

bthread("PaginatedImageAttachmentList delete verification", function () {
  const e = waitForAnyPaginatedImageAttachmentListDeleted();
  block(matchAddPaginatedImageAttachmentList(e.id, ANY), function () {
    verifyPaginatedImageAttachmentListDoesNotExist(e.id);
  });
});

bthread("WritableModuleTypeRequest create verification", function () {
  const e = waitForAnyWritableModuleTypeRequestAdded();
  block(matchDeleteWritableModuleTypeRequest(e.id, ANY), function () {
    verifyWritableModuleTypeRequestExists(e.id);
  });
});

bthread("WritableModuleTypeRequest update verification", function () {
  const e = waitForAnyWritableModuleTypeRequestUpdated();
  block(matchDeleteWritableModuleTypeRequest(e.id, ANY), function () {
    verifyWritableModuleTypeRequestUpdated(e.id);
  });
});

bthread("WritableModuleTypeRequest delete verification", function () {
  const e = waitForAnyWritableModuleTypeRequestDeleted();
  block(matchAddWritableModuleTypeRequest(e.id, ANY), function () {
    verifyWritableModuleTypeRequestDoesNotExist(e.id);
  });
});

bthread("RackTypeRequest create verification", function () {
  const e = waitForAnyRackTypeRequestAdded();
  block(matchDeleteRackTypeRequest(e.id, ANY), function () {
    verifyRackTypeRequestExists(e.id);
  });
});

bthread("RackTypeRequest update verification", function () {
  const e = waitForAnyRackTypeRequestUpdated();
  block(matchDeleteRackTypeRequest(e.id, ANY), function () {
    verifyRackTypeRequestUpdated(e.id);
  });
});

bthread("RackTypeRequest delete verification", function () {
  const e = waitForAnyRackTypeRequestDeleted();
  block(matchAddRackTypeRequest(e.id, ANY), function () {
    verifyRackTypeRequestDoesNotExist(e.id);
  });
});

bthread("CableTerminationRequest create verification", function () {
  const e = waitForAnyCableTerminationRequestAdded();
  block(matchDeleteCableTerminationRequest(e.id, ANY), function () {
    verifyCableTerminationRequestExists(e.id);
  });
});

bthread("CableTerminationRequest update verification", function () {
  const e = waitForAnyCableTerminationRequestUpdated();
  block(matchDeleteCableTerminationRequest(e.id, ANY), function () {
    verifyCableTerminationRequestUpdated(e.id);
  });
});

bthread("CableTerminationRequest delete verification", function () {
  const e = waitForAnyCableTerminationRequestDeleted();
  block(matchAddCableTerminationRequest(e.id, ANY), function () {
    verifyCableTerminationRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedJobList create verification", function () {
  const e = waitForAnyPaginatedJobListAdded();
  block(matchDeletePaginatedJobList(e.id, ANY), function () {
    verifyPaginatedJobListExists(e.id);
  });
});

bthread("PaginatedJobList update verification", function () {
  const e = waitForAnyPaginatedJobListUpdated();
  block(matchDeletePaginatedJobList(e.id, ANY), function () {
    verifyPaginatedJobListUpdated(e.id);
  });
});

bthread("PaginatedJobList delete verification", function () {
  const e = waitForAnyPaginatedJobListDeleted();
  block(matchAddPaginatedJobList(e.id, ANY), function () {
    verifyPaginatedJobListDoesNotExist(e.id);
  });
});

bthread("BriefPowerPortTemplate create verification", function () {
  const e = waitForAnyBriefPowerPortTemplateAdded();
  block(matchDeleteBriefPowerPortTemplate(e.id, ANY), function () {
    verifyBriefPowerPortTemplateExists(e.id);
  });
});

bthread("BriefPowerPortTemplate update verification", function () {
  const e = waitForAnyBriefPowerPortTemplateUpdated();
  block(matchDeleteBriefPowerPortTemplate(e.id, ANY), function () {
    verifyBriefPowerPortTemplateUpdated(e.id);
  });
});

bthread("BriefPowerPortTemplate delete verification", function () {
  const e = waitForAnyBriefPowerPortTemplateDeleted();
  block(matchAddBriefPowerPortTemplate(e.id, ANY), function () {
    verifyBriefPowerPortTemplateDoesNotExist(e.id);
  });
});

bthread("DeviceBayTemplateRequest create verification", function () {
  const e = waitForAnyDeviceBayTemplateRequestAdded();
  block(matchDeleteDeviceBayTemplateRequest(e.id, ANY), function () {
    verifyDeviceBayTemplateRequestExists(e.id);
  });
});

bthread("DeviceBayTemplateRequest update verification", function () {
  const e = waitForAnyDeviceBayTemplateRequestUpdated();
  block(matchDeleteDeviceBayTemplateRequest(e.id, ANY), function () {
    verifyDeviceBayTemplateRequestUpdated(e.id);
  });
});

bthread("DeviceBayTemplateRequest delete verification", function () {
  const e = waitForAnyDeviceBayTemplateRequestDeleted();
  block(matchAddDeviceBayTemplateRequest(e.id, ANY), function () {
    verifyDeviceBayTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedContactGroupList create verification", function () {
  const e = waitForAnyPaginatedContactGroupListAdded();
  block(matchDeletePaginatedContactGroupList(e.id, ANY), function () {
    verifyPaginatedContactGroupListExists(e.id);
  });
});

bthread("PaginatedContactGroupList update verification", function () {
  const e = waitForAnyPaginatedContactGroupListUpdated();
  block(matchDeletePaginatedContactGroupList(e.id, ANY), function () {
    verifyPaginatedContactGroupListUpdated(e.id);
  });
});

bthread("PaginatedContactGroupList delete verification", function () {
  const e = waitForAnyPaginatedContactGroupListDeleted();
  block(matchAddPaginatedContactGroupList(e.id, ANY), function () {
    verifyPaginatedContactGroupListDoesNotExist(e.id);
  });
});

bthread("Platform create verification", function () {
  const e = waitForAnyPlatformAdded();
  block(matchDeletePlatform(e.id, ANY), function () {
    verifyPlatformExists(e.id);
  });
});

bthread("Platform update verification", function () {
  const e = waitForAnyPlatformUpdated();
  block(matchDeletePlatform(e.id, ANY), function () {
    verifyPlatformUpdated(e.id);
  });
});

bthread("Platform delete verification", function () {
  const e = waitForAnyPlatformDeleted();
  block(matchAddPlatform(e.id, ANY), function () {
    verifyPlatformDoesNotExist(e.id);
  });
});

bthread("CustomFieldRequest create verification", function () {
  const e = waitForAnyCustomFieldRequestAdded();
  block(matchDeleteCustomFieldRequest(e.id, ANY), function () {
    verifyCustomFieldRequestExists(e.id);
  });
});

bthread("CustomFieldRequest update verification", function () {
  const e = waitForAnyCustomFieldRequestUpdated();
  block(matchDeleteCustomFieldRequest(e.id, ANY), function () {
    verifyCustomFieldRequestUpdated(e.id);
  });
});

bthread("CustomFieldRequest delete verification", function () {
  const e = waitForAnyCustomFieldRequestDeleted();
  block(matchAddCustomFieldRequest(e.id, ANY), function () {
    verifyCustomFieldRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedClusterList create verification", function () {
  const e = waitForAnyPaginatedClusterListAdded();
  block(matchDeletePaginatedClusterList(e.id, ANY), function () {
    verifyPaginatedClusterListExists(e.id);
  });
});

bthread("PaginatedClusterList update verification", function () {
  const e = waitForAnyPaginatedClusterListUpdated();
  block(matchDeletePaginatedClusterList(e.id, ANY), function () {
    verifyPaginatedClusterListUpdated(e.id);
  });
});

bthread("PaginatedClusterList delete verification", function () {
  const e = waitForAnyPaginatedClusterListDeleted();
  block(matchAddPaginatedClusterList(e.id, ANY), function () {
    verifyPaginatedClusterListDoesNotExist(e.id);
  });
});

bthread("PatchedWritableCustomFieldRequest create verification", function () {
  const e = waitForAnyPatchedWritableCustomFieldRequestAdded();
  block(matchDeletePatchedWritableCustomFieldRequest(e.id, ANY), function () {
    verifyPatchedWritableCustomFieldRequestExists(e.id);
  });
});

bthread("PatchedWritableCustomFieldRequest update verification", function () {
  const e = waitForAnyPatchedWritableCustomFieldRequestUpdated();
  block(matchDeletePatchedWritableCustomFieldRequest(e.id, ANY), function () {
    verifyPatchedWritableCustomFieldRequestUpdated(e.id);
  });
});

bthread("PatchedWritableCustomFieldRequest delete verification", function () {
  const e = waitForAnyPatchedWritableCustomFieldRequestDeleted();
  block(matchAddPatchedWritableCustomFieldRequest(e.id, ANY), function () {
    verifyPatchedWritableCustomFieldRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedVirtualCircuitTypeList create verification", function () {
  const e = waitForAnyPaginatedVirtualCircuitTypeListAdded();
  block(matchDeletePaginatedVirtualCircuitTypeList(e.id, ANY), function () {
    verifyPaginatedVirtualCircuitTypeListExists(e.id);
  });
});

bthread("PaginatedVirtualCircuitTypeList update verification", function () {
  const e = waitForAnyPaginatedVirtualCircuitTypeListUpdated();
  block(matchDeletePaginatedVirtualCircuitTypeList(e.id, ANY), function () {
    verifyPaginatedVirtualCircuitTypeListUpdated(e.id);
  });
});

bthread("PaginatedVirtualCircuitTypeList delete verification", function () {
  const e = waitForAnyPaginatedVirtualCircuitTypeListDeleted();
  block(matchAddPaginatedVirtualCircuitTypeList(e.id, ANY), function () {
    verifyPaginatedVirtualCircuitTypeListDoesNotExist(e.id);
  });
});

bthread("PatchedWritableRackTypeRequest create verification", function () {
  const e = waitForAnyPatchedWritableRackTypeRequestAdded();
  block(matchDeletePatchedWritableRackTypeRequest(e.id, ANY), function () {
    verifyPatchedWritableRackTypeRequestExists(e.id);
  });
});

bthread("PatchedWritableRackTypeRequest update verification", function () {
  const e = waitForAnyPatchedWritableRackTypeRequestUpdated();
  block(matchDeletePatchedWritableRackTypeRequest(e.id, ANY), function () {
    verifyPatchedWritableRackTypeRequestUpdated(e.id);
  });
});

bthread("PatchedWritableRackTypeRequest delete verification", function () {
  const e = waitForAnyPatchedWritableRackTypeRequestDeleted();
  block(matchAddPatchedWritableRackTypeRequest(e.id, ANY), function () {
    verifyPatchedWritableRackTypeRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableConsoleServerPortRequest create verification", function () {
  const e = waitForAnyPatchedWritableConsoleServerPortRequestAdded();
  block(matchDeletePatchedWritableConsoleServerPortRequest(e.id, ANY), function () {
    verifyPatchedWritableConsoleServerPortRequestExists(e.id);
  });
});

bthread("PatchedWritableConsoleServerPortRequest update verification", function () {
  const e = waitForAnyPatchedWritableConsoleServerPortRequestUpdated();
  block(matchDeletePatchedWritableConsoleServerPortRequest(e.id, ANY), function () {
    verifyPatchedWritableConsoleServerPortRequestUpdated(e.id);
  });
});

bthread("PatchedWritableConsoleServerPortRequest delete verification", function () {
  const e = waitForAnyPatchedWritableConsoleServerPortRequestDeleted();
  block(matchAddPatchedWritableConsoleServerPortRequest(e.id, ANY), function () {
    verifyPatchedWritableConsoleServerPortRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableIKEProposalRequest create verification", function () {
  const e = waitForAnyPatchedWritableIKEProposalRequestAdded();
  block(matchDeletePatchedWritableIKEProposalRequest(e.id, ANY), function () {
    verifyPatchedWritableIKEProposalRequestExists(e.id);
  });
});

bthread("PatchedWritableIKEProposalRequest update verification", function () {
  const e = waitForAnyPatchedWritableIKEProposalRequestUpdated();
  block(matchDeletePatchedWritableIKEProposalRequest(e.id, ANY), function () {
    verifyPatchedWritableIKEProposalRequestUpdated(e.id);
  });
});

bthread("PatchedWritableIKEProposalRequest delete verification", function () {
  const e = waitForAnyPatchedWritableIKEProposalRequestDeleted();
  block(matchAddPatchedWritableIKEProposalRequest(e.id, ANY), function () {
    verifyPatchedWritableIKEProposalRequestDoesNotExist(e.id);
  });
});

bthread("WritableConsoleServerPortTemplateRequest create verification", function () {
  const e = waitForAnyWritableConsoleServerPortTemplateRequestAdded();
  block(matchDeleteWritableConsoleServerPortTemplateRequest(e.id, ANY), function () {
    verifyWritableConsoleServerPortTemplateRequestExists(e.id);
  });
});

bthread("WritableConsoleServerPortTemplateRequest update verification", function () {
  const e = waitForAnyWritableConsoleServerPortTemplateRequestUpdated();
  block(matchDeleteWritableConsoleServerPortTemplateRequest(e.id, ANY), function () {
    verifyWritableConsoleServerPortTemplateRequestUpdated(e.id);
  });
});

bthread("WritableConsoleServerPortTemplateRequest delete verification", function () {
  const e = waitForAnyWritableConsoleServerPortTemplateRequestDeleted();
  block(matchAddWritableConsoleServerPortTemplateRequest(e.id, ANY), function () {
    verifyWritableConsoleServerPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableAggregateRequest create verification", function () {
  const e = waitForAnyPatchedWritableAggregateRequestAdded();
  block(matchDeletePatchedWritableAggregateRequest(e.id, ANY), function () {
    verifyPatchedWritableAggregateRequestExists(e.id);
  });
});

bthread("PatchedWritableAggregateRequest update verification", function () {
  const e = waitForAnyPatchedWritableAggregateRequestUpdated();
  block(matchDeletePatchedWritableAggregateRequest(e.id, ANY), function () {
    verifyPatchedWritableAggregateRequestUpdated(e.id);
  });
});

bthread("PatchedWritableAggregateRequest delete verification", function () {
  const e = waitForAnyPatchedWritableAggregateRequestDeleted();
  block(matchAddPatchedWritableAggregateRequest(e.id, ANY), function () {
    verifyPatchedWritableAggregateRequestDoesNotExist(e.id);
  });
});

bthread("BriefFHRPGroup create verification", function () {
  const e = waitForAnyBriefFHRPGroupAdded();
  block(matchDeleteBriefFHRPGroup(e.id, ANY), function () {
    verifyBriefFHRPGroupExists(e.id);
  });
});

bthread("BriefFHRPGroup update verification", function () {
  const e = waitForAnyBriefFHRPGroupUpdated();
  block(matchDeleteBriefFHRPGroup(e.id, ANY), function () {
    verifyBriefFHRPGroupUpdated(e.id);
  });
});

bthread("BriefFHRPGroup delete verification", function () {
  const e = waitForAnyBriefFHRPGroupDeleted();
  block(matchAddBriefFHRPGroup(e.id, ANY), function () {
    verifyBriefFHRPGroupDoesNotExist(e.id);
  });
});

bthread("PatchedContactRequest create verification", function () {
  const e = waitForAnyPatchedContactRequestAdded();
  block(matchDeletePatchedContactRequest(e.id, ANY), function () {
    verifyPatchedContactRequestExists(e.id);
  });
});

bthread("PatchedContactRequest update verification", function () {
  const e = waitForAnyPatchedContactRequestUpdated();
  block(matchDeletePatchedContactRequest(e.id, ANY), function () {
    verifyPatchedContactRequestUpdated(e.id);
  });
});

bthread("PatchedContactRequest delete verification", function () {
  const e = waitForAnyPatchedContactRequestDeleted();
  block(matchAddPatchedContactRequest(e.id, ANY), function () {
    verifyPatchedContactRequestDoesNotExist(e.id);
  });
});

bthread("PatchedSavedFilterRequest create verification", function () {
  const e = waitForAnyPatchedSavedFilterRequestAdded();
  block(matchDeletePatchedSavedFilterRequest(e.id, ANY), function () {
    verifyPatchedSavedFilterRequestExists(e.id);
  });
});

bthread("PatchedSavedFilterRequest update verification", function () {
  const e = waitForAnyPatchedSavedFilterRequestUpdated();
  block(matchDeletePatchedSavedFilterRequest(e.id, ANY), function () {
    verifyPatchedSavedFilterRequestUpdated(e.id);
  });
});

bthread("PatchedSavedFilterRequest delete verification", function () {
  const e = waitForAnyPatchedSavedFilterRequestDeleted();
  block(matchAddPatchedSavedFilterRequest(e.id, ANY), function () {
    verifyPatchedSavedFilterRequestDoesNotExist(e.id);
  });
});

bthread("BriefSiteGroup create verification", function () {
  const e = waitForAnyBriefSiteGroupAdded();
  block(matchDeleteBriefSiteGroup(e.id, ANY), function () {
    verifyBriefSiteGroupExists(e.id);
  });
});

bthread("BriefSiteGroup update verification", function () {
  const e = waitForAnyBriefSiteGroupUpdated();
  block(matchDeleteBriefSiteGroup(e.id, ANY), function () {
    verifyBriefSiteGroupUpdated(e.id);
  });
});

bthread("BriefSiteGroup delete verification", function () {
  const e = waitForAnyBriefSiteGroupDeleted();
  block(matchAddBriefSiteGroup(e.id, ANY), function () {
    verifyBriefSiteGroupDoesNotExist(e.id);
  });
});

bthread("PatchedVRFRequest create verification", function () {
  const e = waitForAnyPatchedVRFRequestAdded();
  block(matchDeletePatchedVRFRequest(e.id, ANY), function () {
    verifyPatchedVRFRequestExists(e.id);
  });
});

bthread("PatchedVRFRequest update verification", function () {
  const e = waitForAnyPatchedVRFRequestUpdated();
  block(matchDeletePatchedVRFRequest(e.id, ANY), function () {
    verifyPatchedVRFRequestUpdated(e.id);
  });
});

bthread("PatchedVRFRequest delete verification", function () {
  const e = waitForAnyPatchedVRFRequestDeleted();
  block(matchAddPatchedVRFRequest(e.id, ANY), function () {
    verifyPatchedVRFRequestDoesNotExist(e.id);
  });
});

bthread("VirtualCircuitTermination create verification", function () {
  const e = waitForAnyVirtualCircuitTerminationAdded();
  block(matchDeleteVirtualCircuitTermination(e.id, ANY), function () {
    verifyVirtualCircuitTerminationExists(e.id);
  });
});

bthread("VirtualCircuitTermination update verification", function () {
  const e = waitForAnyVirtualCircuitTerminationUpdated();
  block(matchDeleteVirtualCircuitTermination(e.id, ANY), function () {
    verifyVirtualCircuitTerminationUpdated(e.id);
  });
});

bthread("VirtualCircuitTermination delete verification", function () {
  const e = waitForAnyVirtualCircuitTerminationDeleted();
  block(matchAddVirtualCircuitTermination(e.id, ANY), function () {
    verifyVirtualCircuitTerminationDoesNotExist(e.id);
  });
});

bthread("BriefIPSecPolicyRequest create verification", function () {
  const e = waitForAnyBriefIPSecPolicyRequestAdded();
  block(matchDeleteBriefIPSecPolicyRequest(e.id, ANY), function () {
    verifyBriefIPSecPolicyRequestExists(e.id);
  });
});

bthread("BriefIPSecPolicyRequest update verification", function () {
  const e = waitForAnyBriefIPSecPolicyRequestUpdated();
  block(matchDeleteBriefIPSecPolicyRequest(e.id, ANY), function () {
    verifyBriefIPSecPolicyRequestUpdated(e.id);
  });
});

bthread("BriefIPSecPolicyRequest delete verification", function () {
  const e = waitForAnyBriefIPSecPolicyRequestDeleted();
  block(matchAddBriefIPSecPolicyRequest(e.id, ANY), function () {
    verifyBriefIPSecPolicyRequestDoesNotExist(e.id);
  });
});

bthread("ClusterTypeRequest create verification", function () {
  const e = waitForAnyClusterTypeRequestAdded();
  block(matchDeleteClusterTypeRequest(e.id, ANY), function () {
    verifyClusterTypeRequestExists(e.id);
  });
});

bthread("ClusterTypeRequest update verification", function () {
  const e = waitForAnyClusterTypeRequestUpdated();
  block(matchDeleteClusterTypeRequest(e.id, ANY), function () {
    verifyClusterTypeRequestUpdated(e.id);
  });
});

bthread("ClusterTypeRequest delete verification", function () {
  const e = waitForAnyClusterTypeRequestDeleted();
  block(matchAddClusterTypeRequest(e.id, ANY), function () {
    verifyClusterTypeRequestDoesNotExist(e.id);
  });
});

bthread("Service create verification", function () {
  const e = waitForAnyServiceAdded();
  block(matchDeleteService(e.id, ANY), function () {
    verifyServiceExists(e.id);
  });
});

bthread("Service update verification", function () {
  const e = waitForAnyServiceUpdated();
  block(matchDeleteService(e.id, ANY), function () {
    verifyServiceUpdated(e.id);
  });
});

bthread("Service delete verification", function () {
  const e = waitForAnyServiceDeleted();
  block(matchAddService(e.id, ANY), function () {
    verifyServiceDoesNotExist(e.id);
  });
});

bthread("BriefVLANRequest create verification", function () {
  const e = waitForAnyBriefVLANRequestAdded();
  block(matchDeleteBriefVLANRequest(e.id, ANY), function () {
    verifyBriefVLANRequestExists(e.id);
  });
});

bthread("BriefVLANRequest update verification", function () {
  const e = waitForAnyBriefVLANRequestUpdated();
  block(matchDeleteBriefVLANRequest(e.id, ANY), function () {
    verifyBriefVLANRequestUpdated(e.id);
  });
});

bthread("BriefVLANRequest delete verification", function () {
  const e = waitForAnyBriefVLANRequestDeleted();
  block(matchAddBriefVLANRequest(e.id, ANY), function () {
    verifyBriefVLANRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedInventoryItemRoleList create verification", function () {
  const e = waitForAnyPaginatedInventoryItemRoleListAdded();
  block(matchDeletePaginatedInventoryItemRoleList(e.id, ANY), function () {
    verifyPaginatedInventoryItemRoleListExists(e.id);
  });
});

bthread("PaginatedInventoryItemRoleList update verification", function () {
  const e = waitForAnyPaginatedInventoryItemRoleListUpdated();
  block(matchDeletePaginatedInventoryItemRoleList(e.id, ANY), function () {
    verifyPaginatedInventoryItemRoleListUpdated(e.id);
  });
});

bthread("PaginatedInventoryItemRoleList delete verification", function () {
  const e = waitForAnyPaginatedInventoryItemRoleListDeleted();
  block(matchAddPaginatedInventoryItemRoleList(e.id, ANY), function () {
    verifyPaginatedInventoryItemRoleListDoesNotExist(e.id);
  });
});

bthread("BriefPowerPanelRequest create verification", function () {
  const e = waitForAnyBriefPowerPanelRequestAdded();
  block(matchDeleteBriefPowerPanelRequest(e.id, ANY), function () {
    verifyBriefPowerPanelRequestExists(e.id);
  });
});

bthread("BriefPowerPanelRequest update verification", function () {
  const e = waitForAnyBriefPowerPanelRequestUpdated();
  block(matchDeleteBriefPowerPanelRequest(e.id, ANY), function () {
    verifyBriefPowerPanelRequestUpdated(e.id);
  });
});

bthread("BriefPowerPanelRequest delete verification", function () {
  const e = waitForAnyBriefPowerPanelRequestDeleted();
  block(matchAddBriefPowerPanelRequest(e.id, ANY), function () {
    verifyBriefPowerPanelRequestDoesNotExist(e.id);
  });
});

bthread("PatchedConfigTemplateRequest create verification", function () {
  const e = waitForAnyPatchedConfigTemplateRequestAdded();
  block(matchDeletePatchedConfigTemplateRequest(e.id, ANY), function () {
    verifyPatchedConfigTemplateRequestExists(e.id);
  });
});

bthread("PatchedConfigTemplateRequest update verification", function () {
  const e = waitForAnyPatchedConfigTemplateRequestUpdated();
  block(matchDeletePatchedConfigTemplateRequest(e.id, ANY), function () {
    verifyPatchedConfigTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedConfigTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedConfigTemplateRequestDeleted();
  block(matchAddPatchedConfigTemplateRequest(e.id, ANY), function () {
    verifyPatchedConfigTemplateRequestDoesNotExist(e.id);
  });
});

bthread("TaggedItem create verification", function () {
  const e = waitForAnyTaggedItemAdded();
  block(matchDeleteTaggedItem(e.id, ANY), function () {
    verifyTaggedItemExists(e.id);
  });
});

bthread("TaggedItem update verification", function () {
  const e = waitForAnyTaggedItemUpdated();
  block(matchDeleteTaggedItem(e.id, ANY), function () {
    verifyTaggedItemUpdated(e.id);
  });
});

bthread("TaggedItem delete verification", function () {
  const e = waitForAnyTaggedItemDeleted();
  block(matchAddTaggedItem(e.id, ANY), function () {
    verifyTaggedItemDoesNotExist(e.id);
  });
});

bthread("CustomFieldChoiceSetRequest create verification", function () {
  const e = waitForAnyCustomFieldChoiceSetRequestAdded();
  block(matchDeleteCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyCustomFieldChoiceSetRequestExists(e.id);
  });
});

bthread("CustomFieldChoiceSetRequest update verification", function () {
  const e = waitForAnyCustomFieldChoiceSetRequestUpdated();
  block(matchDeleteCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyCustomFieldChoiceSetRequestUpdated(e.id);
  });
});

bthread("CustomFieldChoiceSetRequest delete verification", function () {
  const e = waitForAnyCustomFieldChoiceSetRequestDeleted();
  block(matchAddCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyCustomFieldChoiceSetRequestDoesNotExist(e.id);
  });
});

bthread("BriefDataFile create verification", function () {
  const e = waitForAnyBriefDataFileAdded();
  block(matchDeleteBriefDataFile(e.id, ANY), function () {
    verifyBriefDataFileExists(e.id);
  });
});

bthread("BriefDataFile update verification", function () {
  const e = waitForAnyBriefDataFileUpdated();
  block(matchDeleteBriefDataFile(e.id, ANY), function () {
    verifyBriefDataFileUpdated(e.id);
  });
});

bthread("BriefDataFile delete verification", function () {
  const e = waitForAnyBriefDataFileDeleted();
  block(matchAddBriefDataFile(e.id, ANY), function () {
    verifyBriefDataFileDoesNotExist(e.id);
  });
});

bthread("PaginatedObjectPermissionList create verification", function () {
  const e = waitForAnyPaginatedObjectPermissionListAdded();
  block(matchDeletePaginatedObjectPermissionList(e.id, ANY), function () {
    verifyPaginatedObjectPermissionListExists(e.id);
  });
});

bthread("PaginatedObjectPermissionList update verification", function () {
  const e = waitForAnyPaginatedObjectPermissionListUpdated();
  block(matchDeletePaginatedObjectPermissionList(e.id, ANY), function () {
    verifyPaginatedObjectPermissionListUpdated(e.id);
  });
});

bthread("PaginatedObjectPermissionList delete verification", function () {
  const e = waitForAnyPaginatedObjectPermissionListDeleted();
  block(matchAddPaginatedObjectPermissionList(e.id, ANY), function () {
    verifyPaginatedObjectPermissionListDoesNotExist(e.id);
  });
});

bthread("BriefIPSecProfileRequest create verification", function () {
  const e = waitForAnyBriefIPSecProfileRequestAdded();
  block(matchDeleteBriefIPSecProfileRequest(e.id, ANY), function () {
    verifyBriefIPSecProfileRequestExists(e.id);
  });
});

bthread("BriefIPSecProfileRequest update verification", function () {
  const e = waitForAnyBriefIPSecProfileRequestUpdated();
  block(matchDeleteBriefIPSecProfileRequest(e.id, ANY), function () {
    verifyBriefIPSecProfileRequestUpdated(e.id);
  });
});

bthread("BriefIPSecProfileRequest delete verification", function () {
  const e = waitForAnyBriefIPSecProfileRequestDeleted();
  block(matchAddBriefIPSecProfileRequest(e.id, ANY), function () {
    verifyBriefIPSecProfileRequestDoesNotExist(e.id);
  });
});

bthread("PatchedTenantRequest create verification", function () {
  const e = waitForAnyPatchedTenantRequestAdded();
  block(matchDeletePatchedTenantRequest(e.id, ANY), function () {
    verifyPatchedTenantRequestExists(e.id);
  });
});

bthread("PatchedTenantRequest update verification", function () {
  const e = waitForAnyPatchedTenantRequestUpdated();
  block(matchDeletePatchedTenantRequest(e.id, ANY), function () {
    verifyPatchedTenantRequestUpdated(e.id);
  });
});

bthread("PatchedTenantRequest delete verification", function () {
  const e = waitForAnyPatchedTenantRequestDeleted();
  block(matchAddPatchedTenantRequest(e.id, ANY), function () {
    verifyPatchedTenantRequestDoesNotExist(e.id);
  });
});

bthread("AvailableVLAN create verification", function () {
  const e = waitForAnyAvailableVLANAdded();
  block(matchDeleteAvailableVLAN(e.id, ANY), function () {
    verifyAvailableVLANExists(e.id);
  });
});

bthread("AvailableVLAN update verification", function () {
  const e = waitForAnyAvailableVLANUpdated();
  block(matchDeleteAvailableVLAN(e.id, ANY), function () {
    verifyAvailableVLANUpdated(e.id);
  });
});

bthread("AvailableVLAN delete verification", function () {
  const e = waitForAnyAvailableVLANDeleted();
  block(matchAddAvailableVLAN(e.id, ANY), function () {
    verifyAvailableVLANDoesNotExist(e.id);
  });
});

bthread("PaginatedContactList create verification", function () {
  const e = waitForAnyPaginatedContactListAdded();
  block(matchDeletePaginatedContactList(e.id, ANY), function () {
    verifyPaginatedContactListExists(e.id);
  });
});

bthread("PaginatedContactList update verification", function () {
  const e = waitForAnyPaginatedContactListUpdated();
  block(matchDeletePaginatedContactList(e.id, ANY), function () {
    verifyPaginatedContactListUpdated(e.id);
  });
});

bthread("PaginatedContactList delete verification", function () {
  const e = waitForAnyPaginatedContactListDeleted();
  block(matchAddPaginatedContactList(e.id, ANY), function () {
    verifyPaginatedContactListDoesNotExist(e.id);
  });
});

bthread("PaginatedPowerPortList create verification", function () {
  const e = waitForAnyPaginatedPowerPortListAdded();
  block(matchDeletePaginatedPowerPortList(e.id, ANY), function () {
    verifyPaginatedPowerPortListExists(e.id);
  });
});

bthread("PaginatedPowerPortList update verification", function () {
  const e = waitForAnyPaginatedPowerPortListUpdated();
  block(matchDeletePaginatedPowerPortList(e.id, ANY), function () {
    verifyPaginatedPowerPortListUpdated(e.id);
  });
});

bthread("PaginatedPowerPortList delete verification", function () {
  const e = waitForAnyPaginatedPowerPortListDeleted();
  block(matchAddPaginatedPowerPortList(e.id, ANY), function () {
    verifyPaginatedPowerPortListDoesNotExist(e.id);
  });
});

bthread("WritableSiteRequest create verification", function () {
  const e = waitForAnyWritableSiteRequestAdded();
  block(matchDeleteWritableSiteRequest(e.id, ANY), function () {
    verifyWritableSiteRequestExists(e.id);
  });
});

bthread("WritableSiteRequest update verification", function () {
  const e = waitForAnyWritableSiteRequestUpdated();
  block(matchDeleteWritableSiteRequest(e.id, ANY), function () {
    verifyWritableSiteRequestUpdated(e.id);
  });
});

bthread("WritableSiteRequest delete verification", function () {
  const e = waitForAnyWritableSiteRequestDeleted();
  block(matchAddWritableSiteRequest(e.id, ANY), function () {
    verifyWritableSiteRequestDoesNotExist(e.id);
  });
});

bthread("ConfigTemplate create verification", function () {
  const e = waitForAnyConfigTemplateAdded();
  block(matchDeleteConfigTemplate(e.id, ANY), function () {
    verifyConfigTemplateExists(e.id);
  });
});

bthread("ConfigTemplate update verification", function () {
  const e = waitForAnyConfigTemplateUpdated();
  block(matchDeleteConfigTemplate(e.id, ANY), function () {
    verifyConfigTemplateUpdated(e.id);
  });
});

bthread("ConfigTemplate delete verification", function () {
  const e = waitForAnyConfigTemplateDeleted();
  block(matchAddConfigTemplate(e.id, ANY), function () {
    verifyConfigTemplateDoesNotExist(e.id);
  });
});

bthread("WritableFrontPortRequest create verification", function () {
  const e = waitForAnyWritableFrontPortRequestAdded();
  block(matchDeleteWritableFrontPortRequest(e.id, ANY), function () {
    verifyWritableFrontPortRequestExists(e.id);
  });
});

bthread("WritableFrontPortRequest update verification", function () {
  const e = waitForAnyWritableFrontPortRequestUpdated();
  block(matchDeleteWritableFrontPortRequest(e.id, ANY), function () {
    verifyWritableFrontPortRequestUpdated(e.id);
  });
});

bthread("WritableFrontPortRequest delete verification", function () {
  const e = waitForAnyWritableFrontPortRequestDeleted();
  block(matchAddWritableFrontPortRequest(e.id, ANY), function () {
    verifyWritableFrontPortRequestDoesNotExist(e.id);
  });
});

bthread("CustomField create verification", function () {
  const e = waitForAnyCustomFieldAdded();
  block(matchDeleteCustomField(e.id, ANY), function () {
    verifyCustomFieldExists(e.id);
  });
});

bthread("CustomField update verification", function () {
  const e = waitForAnyCustomFieldUpdated();
  block(matchDeleteCustomField(e.id, ANY), function () {
    verifyCustomFieldUpdated(e.id);
  });
});

bthread("CustomField delete verification", function () {
  const e = waitForAnyCustomFieldDeleted();
  block(matchAddCustomField(e.id, ANY), function () {
    verifyCustomFieldDoesNotExist(e.id);
  });
});

bthread("PatchedConfigContextProfileRequest create verification", function () {
  const e = waitForAnyPatchedConfigContextProfileRequestAdded();
  block(matchDeletePatchedConfigContextProfileRequest(e.id, ANY), function () {
    verifyPatchedConfigContextProfileRequestExists(e.id);
  });
});

bthread("PatchedConfigContextProfileRequest update verification", function () {
  const e = waitForAnyPatchedConfigContextProfileRequestUpdated();
  block(matchDeletePatchedConfigContextProfileRequest(e.id, ANY), function () {
    verifyPatchedConfigContextProfileRequestUpdated(e.id);
  });
});

bthread("PatchedConfigContextProfileRequest delete verification", function () {
  const e = waitForAnyPatchedConfigContextProfileRequestDeleted();
  block(matchAddPatchedConfigContextProfileRequest(e.id, ANY), function () {
    verifyPatchedConfigContextProfileRequestDoesNotExist(e.id);
  });
});

bthread("BriefCustomFieldChoiceSet create verification", function () {
  const e = waitForAnyBriefCustomFieldChoiceSetAdded();
  block(matchDeleteBriefCustomFieldChoiceSet(e.id, ANY), function () {
    verifyBriefCustomFieldChoiceSetExists(e.id);
  });
});

bthread("BriefCustomFieldChoiceSet update verification", function () {
  const e = waitForAnyBriefCustomFieldChoiceSetUpdated();
  block(matchDeleteBriefCustomFieldChoiceSet(e.id, ANY), function () {
    verifyBriefCustomFieldChoiceSetUpdated(e.id);
  });
});

bthread("BriefCustomFieldChoiceSet delete verification", function () {
  const e = waitForAnyBriefCustomFieldChoiceSetDeleted();
  block(matchAddBriefCustomFieldChoiceSet(e.id, ANY), function () {
    verifyBriefCustomFieldChoiceSetDoesNotExist(e.id);
  });
});

bthread("PaginatedRIRList create verification", function () {
  const e = waitForAnyPaginatedRIRListAdded();
  block(matchDeletePaginatedRIRList(e.id, ANY), function () {
    verifyPaginatedRIRListExists(e.id);
  });
});

bthread("PaginatedRIRList update verification", function () {
  const e = waitForAnyPaginatedRIRListUpdated();
  block(matchDeletePaginatedRIRList(e.id, ANY), function () {
    verifyPaginatedRIRListUpdated(e.id);
  });
});

bthread("PaginatedRIRList delete verification", function () {
  const e = waitForAnyPaginatedRIRListDeleted();
  block(matchAddPaginatedRIRList(e.id, ANY), function () {
    verifyPaginatedRIRListDoesNotExist(e.id);
  });
});

bthread("PatchedScriptInputRequest create verification", function () {
  const e = waitForAnyPatchedScriptInputRequestAdded();
  block(matchDeletePatchedScriptInputRequest(e.id, ANY), function () {
    verifyPatchedScriptInputRequestExists(e.id);
  });
});

bthread("PatchedScriptInputRequest update verification", function () {
  const e = waitForAnyPatchedScriptInputRequestUpdated();
  block(matchDeletePatchedScriptInputRequest(e.id, ANY), function () {
    verifyPatchedScriptInputRequestUpdated(e.id);
  });
});

bthread("PatchedScriptInputRequest delete verification", function () {
  const e = waitForAnyPatchedScriptInputRequestDeleted();
  block(matchAddPatchedScriptInputRequest(e.id, ANY), function () {
    verifyPatchedScriptInputRequestDoesNotExist(e.id);
  });
});

bthread("PrefixRequest create verification", function () {
  const e = waitForAnyPrefixRequestAdded();
  block(matchDeletePrefixRequest(e.id, ANY), function () {
    verifyPrefixRequestExists(e.id);
  });
});

bthread("PrefixRequest update verification", function () {
  const e = waitForAnyPrefixRequestUpdated();
  block(matchDeletePrefixRequest(e.id, ANY), function () {
    verifyPrefixRequestUpdated(e.id);
  });
});

bthread("PrefixRequest delete verification", function () {
  const e = waitForAnyPrefixRequestDeleted();
  block(matchAddPrefixRequest(e.id, ANY), function () {
    verifyPrefixRequestDoesNotExist(e.id);
  });
});

bthread("BriefJob create verification", function () {
  const e = waitForAnyBriefJobAdded();
  block(matchDeleteBriefJob(e.id, ANY), function () {
    verifyBriefJobExists(e.id);
  });
});

bthread("BriefJob update verification", function () {
  const e = waitForAnyBriefJobUpdated();
  block(matchDeleteBriefJob(e.id, ANY), function () {
    verifyBriefJobUpdated(e.id);
  });
});

bthread("BriefJob delete verification", function () {
  const e = waitForAnyBriefJobDeleted();
  block(matchAddBriefJob(e.id, ANY), function () {
    verifyBriefJobDoesNotExist(e.id);
  });
});

bthread("WritableDeviceRoleRequest create verification", function () {
  const e = waitForAnyWritableDeviceRoleRequestAdded();
  block(matchDeleteWritableDeviceRoleRequest(e.id, ANY), function () {
    verifyWritableDeviceRoleRequestExists(e.id);
  });
});

bthread("WritableDeviceRoleRequest update verification", function () {
  const e = waitForAnyWritableDeviceRoleRequestUpdated();
  block(matchDeleteWritableDeviceRoleRequest(e.id, ANY), function () {
    verifyWritableDeviceRoleRequestUpdated(e.id);
  });
});

bthread("WritableDeviceRoleRequest delete verification", function () {
  const e = waitForAnyWritableDeviceRoleRequestDeleted();
  block(matchAddWritableDeviceRoleRequest(e.id, ANY), function () {
    verifyWritableDeviceRoleRequestDoesNotExist(e.id);
  });
});

bthread("Tenant create verification", function () {
  const e = waitForAnyTenantAdded();
  block(matchDeleteTenant(e.id, ANY), function () {
    verifyTenantExists(e.id);
  });
});

bthread("Tenant update verification", function () {
  const e = waitForAnyTenantUpdated();
  block(matchDeleteTenant(e.id, ANY), function () {
    verifyTenantUpdated(e.id);
  });
});

bthread("Tenant delete verification", function () {
  const e = waitForAnyTenantDeleted();
  block(matchAddTenant(e.id, ANY), function () {
    verifyTenantDoesNotExist(e.id);
  });
});

bthread("PaginatedServiceList create verification", function () {
  const e = waitForAnyPaginatedServiceListAdded();
  block(matchDeletePaginatedServiceList(e.id, ANY), function () {
    verifyPaginatedServiceListExists(e.id);
  });
});

bthread("PaginatedServiceList update verification", function () {
  const e = waitForAnyPaginatedServiceListUpdated();
  block(matchDeletePaginatedServiceList(e.id, ANY), function () {
    verifyPaginatedServiceListUpdated(e.id);
  });
});

bthread("PaginatedServiceList delete verification", function () {
  const e = waitForAnyPaginatedServiceListDeleted();
  block(matchAddPaginatedServiceList(e.id, ANY), function () {
    verifyPaginatedServiceListDoesNotExist(e.id);
  });
});

bthread("PatchedInventoryItemTemplateRequest create verification", function () {
  const e = waitForAnyPatchedInventoryItemTemplateRequestAdded();
  block(matchDeletePatchedInventoryItemTemplateRequest(e.id, ANY), function () {
    verifyPatchedInventoryItemTemplateRequestExists(e.id);
  });
});

bthread("PatchedInventoryItemTemplateRequest update verification", function () {
  const e = waitForAnyPatchedInventoryItemTemplateRequestUpdated();
  block(matchDeletePatchedInventoryItemTemplateRequest(e.id, ANY), function () {
    verifyPatchedInventoryItemTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedInventoryItemTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedInventoryItemTemplateRequestDeleted();
  block(matchAddPatchedInventoryItemTemplateRequest(e.id, ANY), function () {
    verifyPatchedInventoryItemTemplateRequestDoesNotExist(e.id);
  });
});

bthread("InterfaceRequest create verification", function () {
  const e = waitForAnyInterfaceRequestAdded();
  block(matchDeleteInterfaceRequest(e.id, ANY), function () {
    verifyInterfaceRequestExists(e.id);
  });
});

bthread("InterfaceRequest update verification", function () {
  const e = waitForAnyInterfaceRequestUpdated();
  block(matchDeleteInterfaceRequest(e.id, ANY), function () {
    verifyInterfaceRequestUpdated(e.id);
  });
});

bthread("InterfaceRequest delete verification", function () {
  const e = waitForAnyInterfaceRequestDeleted();
  block(matchAddInterfaceRequest(e.id, ANY), function () {
    verifyInterfaceRequestDoesNotExist(e.id);
  });
});

bthread("BriefTenantGroupRequest create verification", function () {
  const e = waitForAnyBriefTenantGroupRequestAdded();
  block(matchDeleteBriefTenantGroupRequest(e.id, ANY), function () {
    verifyBriefTenantGroupRequestExists(e.id);
  });
});

bthread("BriefTenantGroupRequest update verification", function () {
  const e = waitForAnyBriefTenantGroupRequestUpdated();
  block(matchDeleteBriefTenantGroupRequest(e.id, ANY), function () {
    verifyBriefTenantGroupRequestUpdated(e.id);
  });
});

bthread("BriefTenantGroupRequest delete verification", function () {
  const e = waitForAnyBriefTenantGroupRequestDeleted();
  block(matchAddBriefTenantGroupRequest(e.id, ANY), function () {
    verifyBriefTenantGroupRequestDoesNotExist(e.id);
  });
});

bthread("CustomLink create verification", function () {
  const e = waitForAnyCustomLinkAdded();
  block(matchDeleteCustomLink(e.id, ANY), function () {
    verifyCustomLinkExists(e.id);
  });
});

bthread("CustomLink update verification", function () {
  const e = waitForAnyCustomLinkUpdated();
  block(matchDeleteCustomLink(e.id, ANY), function () {
    verifyCustomLinkUpdated(e.id);
  });
});

bthread("CustomLink delete verification", function () {
  const e = waitForAnyCustomLinkDeleted();
  block(matchAddCustomLink(e.id, ANY), function () {
    verifyCustomLinkDoesNotExist(e.id);
  });
});

bthread("PaginatedDeviceBayList create verification", function () {
  const e = waitForAnyPaginatedDeviceBayListAdded();
  block(matchDeletePaginatedDeviceBayList(e.id, ANY), function () {
    verifyPaginatedDeviceBayListExists(e.id);
  });
});

bthread("PaginatedDeviceBayList update verification", function () {
  const e = waitForAnyPaginatedDeviceBayListUpdated();
  block(matchDeletePaginatedDeviceBayList(e.id, ANY), function () {
    verifyPaginatedDeviceBayListUpdated(e.id);
  });
});

bthread("PaginatedDeviceBayList delete verification", function () {
  const e = waitForAnyPaginatedDeviceBayListDeleted();
  block(matchAddPaginatedDeviceBayList(e.id, ANY), function () {
    verifyPaginatedDeviceBayListDoesNotExist(e.id);
  });
});

bthread("WritableLocationRequest create verification", function () {
  const e = waitForAnyWritableLocationRequestAdded();
  block(matchDeleteWritableLocationRequest(e.id, ANY), function () {
    verifyWritableLocationRequestExists(e.id);
  });
});

bthread("WritableLocationRequest update verification", function () {
  const e = waitForAnyWritableLocationRequestUpdated();
  block(matchDeleteWritableLocationRequest(e.id, ANY), function () {
    verifyWritableLocationRequestUpdated(e.id);
  });
});

bthread("WritableLocationRequest delete verification", function () {
  const e = waitForAnyWritableLocationRequestDeleted();
  block(matchAddWritableLocationRequest(e.id, ANY), function () {
    verifyWritableLocationRequestDoesNotExist(e.id);
  });
});

bthread("PatchedModuleBayRequest create verification", function () {
  const e = waitForAnyPatchedModuleBayRequestAdded();
  block(matchDeletePatchedModuleBayRequest(e.id, ANY), function () {
    verifyPatchedModuleBayRequestExists(e.id);
  });
});

bthread("PatchedModuleBayRequest update verification", function () {
  const e = waitForAnyPatchedModuleBayRequestUpdated();
  block(matchDeletePatchedModuleBayRequest(e.id, ANY), function () {
    verifyPatchedModuleBayRequestUpdated(e.id);
  });
});

bthread("PatchedModuleBayRequest delete verification", function () {
  const e = waitForAnyPatchedModuleBayRequestDeleted();
  block(matchAddPatchedModuleBayRequest(e.id, ANY), function () {
    verifyPatchedModuleBayRequestDoesNotExist(e.id);
  });
});

bthread("VirtualMachineWithConfigContext create verification", function () {
  const e = waitForAnyVirtualMachineWithConfigContextAdded();
  block(matchDeleteVirtualMachineWithConfigContext(e.id, ANY), function () {
    verifyVirtualMachineWithConfigContextExists(e.id);
  });
});

bthread("VirtualMachineWithConfigContext update verification", function () {
  const e = waitForAnyVirtualMachineWithConfigContextUpdated();
  block(matchDeleteVirtualMachineWithConfigContext(e.id, ANY), function () {
    verifyVirtualMachineWithConfigContextUpdated(e.id);
  });
});

bthread("VirtualMachineWithConfigContext delete verification", function () {
  const e = waitForAnyVirtualMachineWithConfigContextDeleted();
  block(matchAddVirtualMachineWithConfigContext(e.id, ANY), function () {
    verifyVirtualMachineWithConfigContextDoesNotExist(e.id);
  });
});

bthread("PatchedWritableIPSecPolicyRequest create verification", function () {
  const e = waitForAnyPatchedWritableIPSecPolicyRequestAdded();
  block(matchDeletePatchedWritableIPSecPolicyRequest(e.id, ANY), function () {
    verifyPatchedWritableIPSecPolicyRequestExists(e.id);
  });
});

bthread("PatchedWritableIPSecPolicyRequest update verification", function () {
  const e = waitForAnyPatchedWritableIPSecPolicyRequestUpdated();
  block(matchDeletePatchedWritableIPSecPolicyRequest(e.id, ANY), function () {
    verifyPatchedWritableIPSecPolicyRequestUpdated(e.id);
  });
});

bthread("PatchedWritableIPSecPolicyRequest delete verification", function () {
  const e = waitForAnyPatchedWritableIPSecPolicyRequestDeleted();
  block(matchAddPatchedWritableIPSecPolicyRequest(e.id, ANY), function () {
    verifyPatchedWritableIPSecPolicyRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableL2VPNRequest create verification", function () {
  const e = waitForAnyPatchedWritableL2VPNRequestAdded();
  block(matchDeletePatchedWritableL2VPNRequest(e.id, ANY), function () {
    verifyPatchedWritableL2VPNRequestExists(e.id);
  });
});

bthread("PatchedWritableL2VPNRequest update verification", function () {
  const e = waitForAnyPatchedWritableL2VPNRequestUpdated();
  block(matchDeletePatchedWritableL2VPNRequest(e.id, ANY), function () {
    verifyPatchedWritableL2VPNRequestUpdated(e.id);
  });
});

bthread("PatchedWritableL2VPNRequest delete verification", function () {
  const e = waitForAnyPatchedWritableL2VPNRequestDeleted();
  block(matchAddPatchedWritableL2VPNRequest(e.id, ANY), function () {
    verifyPatchedWritableL2VPNRequestDoesNotExist(e.id);
  });
});

bthread("CircuitGroupAssignment create verification", function () {
  const e = waitForAnyCircuitGroupAssignmentAdded();
  block(matchDeleteCircuitGroupAssignment(e.id, ANY), function () {
    verifyCircuitGroupAssignmentExists(e.id);
  });
});

bthread("CircuitGroupAssignment update verification", function () {
  const e = waitForAnyCircuitGroupAssignmentUpdated();
  block(matchDeleteCircuitGroupAssignment(e.id, ANY), function () {
    verifyCircuitGroupAssignmentUpdated(e.id);
  });
});

bthread("CircuitGroupAssignment delete verification", function () {
  const e = waitForAnyCircuitGroupAssignmentDeleted();
  block(matchAddCircuitGroupAssignment(e.id, ANY), function () {
    verifyCircuitGroupAssignmentDoesNotExist(e.id);
  });
});

bthread("BriefRearPortTemplate create verification", function () {
  const e = waitForAnyBriefRearPortTemplateAdded();
  block(matchDeleteBriefRearPortTemplate(e.id, ANY), function () {
    verifyBriefRearPortTemplateExists(e.id);
  });
});

bthread("BriefRearPortTemplate update verification", function () {
  const e = waitForAnyBriefRearPortTemplateUpdated();
  block(matchDeleteBriefRearPortTemplate(e.id, ANY), function () {
    verifyBriefRearPortTemplateUpdated(e.id);
  });
});

bthread("BriefRearPortTemplate delete verification", function () {
  const e = waitForAnyBriefRearPortTemplateDeleted();
  block(matchAddBriefRearPortTemplate(e.id, ANY), function () {
    verifyBriefRearPortTemplateDoesNotExist(e.id);
  });
});

bthread("PaginatedDeviceBayTemplateList create verification", function () {
  const e = waitForAnyPaginatedDeviceBayTemplateListAdded();
  block(matchDeletePaginatedDeviceBayTemplateList(e.id, ANY), function () {
    verifyPaginatedDeviceBayTemplateListExists(e.id);
  });
});

bthread("PaginatedDeviceBayTemplateList update verification", function () {
  const e = waitForAnyPaginatedDeviceBayTemplateListUpdated();
  block(matchDeletePaginatedDeviceBayTemplateList(e.id, ANY), function () {
    verifyPaginatedDeviceBayTemplateListUpdated(e.id);
  });
});

bthread("PaginatedDeviceBayTemplateList delete verification", function () {
  const e = waitForAnyPaginatedDeviceBayTemplateListDeleted();
  block(matchAddPaginatedDeviceBayTemplateList(e.id, ANY), function () {
    verifyPaginatedDeviceBayTemplateListDoesNotExist(e.id);
  });
});

bthread("NestedRegion create verification", function () {
  const e = waitForAnyNestedRegionAdded();
  block(matchDeleteNestedRegion(e.id, ANY), function () {
    verifyNestedRegionExists(e.id);
  });
});

bthread("NestedRegion update verification", function () {
  const e = waitForAnyNestedRegionUpdated();
  block(matchDeleteNestedRegion(e.id, ANY), function () {
    verifyNestedRegionUpdated(e.id);
  });
});

bthread("NestedRegion delete verification", function () {
  const e = waitForAnyNestedRegionDeleted();
  block(matchAddNestedRegion(e.id, ANY), function () {
    verifyNestedRegionDoesNotExist(e.id);
  });
});

bthread("ContactAssignmentRequest create verification", function () {
  const e = waitForAnyContactAssignmentRequestAdded();
  block(matchDeleteContactAssignmentRequest(e.id, ANY), function () {
    verifyContactAssignmentRequestExists(e.id);
  });
});

bthread("ContactAssignmentRequest update verification", function () {
  const e = waitForAnyContactAssignmentRequestUpdated();
  block(matchDeleteContactAssignmentRequest(e.id, ANY), function () {
    verifyContactAssignmentRequestUpdated(e.id);
  });
});

bthread("ContactAssignmentRequest delete verification", function () {
  const e = waitForAnyContactAssignmentRequestDeleted();
  block(matchAddContactAssignmentRequest(e.id, ANY), function () {
    verifyContactAssignmentRequestDoesNotExist(e.id);
  });
});

bthread("ConsolePortTemplateRequest create verification", function () {
  const e = waitForAnyConsolePortTemplateRequestAdded();
  block(matchDeleteConsolePortTemplateRequest(e.id, ANY), function () {
    verifyConsolePortTemplateRequestExists(e.id);
  });
});

bthread("ConsolePortTemplateRequest update verification", function () {
  const e = waitForAnyConsolePortTemplateRequestUpdated();
  block(matchDeleteConsolePortTemplateRequest(e.id, ANY), function () {
    verifyConsolePortTemplateRequestUpdated(e.id);
  });
});

bthread("ConsolePortTemplateRequest delete verification", function () {
  const e = waitForAnyConsolePortTemplateRequestDeleted();
  block(matchAddConsolePortTemplateRequest(e.id, ANY), function () {
    verifyConsolePortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("WritableDataSourceRequest create verification", function () {
  const e = waitForAnyWritableDataSourceRequestAdded();
  block(matchDeleteWritableDataSourceRequest(e.id, ANY), function () {
    verifyWritableDataSourceRequestExists(e.id);
  });
});

bthread("WritableDataSourceRequest update verification", function () {
  const e = waitForAnyWritableDataSourceRequestUpdated();
  block(matchDeleteWritableDataSourceRequest(e.id, ANY), function () {
    verifyWritableDataSourceRequestUpdated(e.id);
  });
});

bthread("WritableDataSourceRequest delete verification", function () {
  const e = waitForAnyWritableDataSourceRequestDeleted();
  block(matchAddWritableDataSourceRequest(e.id, ANY), function () {
    verifyWritableDataSourceRequestDoesNotExist(e.id);
  });
});

bthread("LocationRequest create verification", function () {
  const e = waitForAnyLocationRequestAdded();
  block(matchDeleteLocationRequest(e.id, ANY), function () {
    verifyLocationRequestExists(e.id);
  });
});

bthread("LocationRequest update verification", function () {
  const e = waitForAnyLocationRequestUpdated();
  block(matchDeleteLocationRequest(e.id, ANY), function () {
    verifyLocationRequestUpdated(e.id);
  });
});

bthread("LocationRequest delete verification", function () {
  const e = waitForAnyLocationRequestDeleted();
  block(matchAddLocationRequest(e.id, ANY), function () {
    verifyLocationRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedConsoleServerPortTemplateList create verification", function () {
  const e = waitForAnyPaginatedConsoleServerPortTemplateListAdded();
  block(matchDeletePaginatedConsoleServerPortTemplateList(e.id, ANY), function () {
    verifyPaginatedConsoleServerPortTemplateListExists(e.id);
  });
});

bthread("PaginatedConsoleServerPortTemplateList update verification", function () {
  const e = waitForAnyPaginatedConsoleServerPortTemplateListUpdated();
  block(matchDeletePaginatedConsoleServerPortTemplateList(e.id, ANY), function () {
    verifyPaginatedConsoleServerPortTemplateListUpdated(e.id);
  });
});

bthread("PaginatedConsoleServerPortTemplateList delete verification", function () {
  const e = waitForAnyPaginatedConsoleServerPortTemplateListDeleted();
  block(matchAddPaginatedConsoleServerPortTemplateList(e.id, ANY), function () {
    verifyPaginatedConsoleServerPortTemplateListDoesNotExist(e.id);
  });
});

bthread("PowerPortTemplateRequest create verification", function () {
  const e = waitForAnyPowerPortTemplateRequestAdded();
  block(matchDeletePowerPortTemplateRequest(e.id, ANY), function () {
    verifyPowerPortTemplateRequestExists(e.id);
  });
});

bthread("PowerPortTemplateRequest update verification", function () {
  const e = waitForAnyPowerPortTemplateRequestUpdated();
  block(matchDeletePowerPortTemplateRequest(e.id, ANY), function () {
    verifyPowerPortTemplateRequestUpdated(e.id);
  });
});

bthread("PowerPortTemplateRequest delete verification", function () {
  const e = waitForAnyPowerPortTemplateRequestDeleted();
  block(matchAddPowerPortTemplateRequest(e.id, ANY), function () {
    verifyPowerPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedCircuitGroupAssignmentList create verification", function () {
  const e = waitForAnyPaginatedCircuitGroupAssignmentListAdded();
  block(matchDeletePaginatedCircuitGroupAssignmentList(e.id, ANY), function () {
    verifyPaginatedCircuitGroupAssignmentListExists(e.id);
  });
});

bthread("PaginatedCircuitGroupAssignmentList update verification", function () {
  const e = waitForAnyPaginatedCircuitGroupAssignmentListUpdated();
  block(matchDeletePaginatedCircuitGroupAssignmentList(e.id, ANY), function () {
    verifyPaginatedCircuitGroupAssignmentListUpdated(e.id);
  });
});

bthread("PaginatedCircuitGroupAssignmentList delete verification", function () {
  const e = waitForAnyPaginatedCircuitGroupAssignmentListDeleted();
  block(matchAddPaginatedCircuitGroupAssignmentList(e.id, ANY), function () {
    verifyPaginatedCircuitGroupAssignmentListDoesNotExist(e.id);
  });
});

bthread("PaginatedVirtualCircuitList create verification", function () {
  const e = waitForAnyPaginatedVirtualCircuitListAdded();
  block(matchDeletePaginatedVirtualCircuitList(e.id, ANY), function () {
    verifyPaginatedVirtualCircuitListExists(e.id);
  });
});

bthread("PaginatedVirtualCircuitList update verification", function () {
  const e = waitForAnyPaginatedVirtualCircuitListUpdated();
  block(matchDeletePaginatedVirtualCircuitList(e.id, ANY), function () {
    verifyPaginatedVirtualCircuitListUpdated(e.id);
  });
});

bthread("PaginatedVirtualCircuitList delete verification", function () {
  const e = waitForAnyPaginatedVirtualCircuitListDeleted();
  block(matchAddPaginatedVirtualCircuitList(e.id, ANY), function () {
    verifyPaginatedVirtualCircuitListDoesNotExist(e.id);
  });
});

bthread("BriefRackType create verification", function () {
  const e = waitForAnyBriefRackTypeAdded();
  block(matchDeleteBriefRackType(e.id, ANY), function () {
    verifyBriefRackTypeExists(e.id);
  });
});

bthread("BriefRackType update verification", function () {
  const e = waitForAnyBriefRackTypeUpdated();
  block(matchDeleteBriefRackType(e.id, ANY), function () {
    verifyBriefRackTypeUpdated(e.id);
  });
});

bthread("BriefRackType delete verification", function () {
  const e = waitForAnyBriefRackTypeDeleted();
  block(matchAddBriefRackType(e.id, ANY), function () {
    verifyBriefRackTypeDoesNotExist(e.id);
  });
});

bthread("RearPortRequest create verification", function () {
  const e = waitForAnyRearPortRequestAdded();
  block(matchDeleteRearPortRequest(e.id, ANY), function () {
    verifyRearPortRequestExists(e.id);
  });
});

bthread("RearPortRequest update verification", function () {
  const e = waitForAnyRearPortRequestUpdated();
  block(matchDeleteRearPortRequest(e.id, ANY), function () {
    verifyRearPortRequestUpdated(e.id);
  });
});

bthread("RearPortRequest delete verification", function () {
  const e = waitForAnyRearPortRequestDeleted();
  block(matchAddRearPortRequest(e.id, ANY), function () {
    verifyRearPortRequestDoesNotExist(e.id);
  });
});

bthread("ExportTemplateRequest create verification", function () {
  const e = waitForAnyExportTemplateRequestAdded();
  block(matchDeleteExportTemplateRequest(e.id, ANY), function () {
    verifyExportTemplateRequestExists(e.id);
  });
});

bthread("ExportTemplateRequest update verification", function () {
  const e = waitForAnyExportTemplateRequestUpdated();
  block(matchDeleteExportTemplateRequest(e.id, ANY), function () {
    verifyExportTemplateRequestUpdated(e.id);
  });
});

bthread("ExportTemplateRequest delete verification", function () {
  const e = waitForAnyExportTemplateRequestDeleted();
  block(matchAddExportTemplateRequest(e.id, ANY), function () {
    verifyExportTemplateRequestDoesNotExist(e.id);
  });
});

bthread("BriefRackRole create verification", function () {
  const e = waitForAnyBriefRackRoleAdded();
  block(matchDeleteBriefRackRole(e.id, ANY), function () {
    verifyBriefRackRoleExists(e.id);
  });
});

bthread("BriefRackRole update verification", function () {
  const e = waitForAnyBriefRackRoleUpdated();
  block(matchDeleteBriefRackRole(e.id, ANY), function () {
    verifyBriefRackRoleUpdated(e.id);
  });
});

bthread("BriefRackRole delete verification", function () {
  const e = waitForAnyBriefRackRoleDeleted();
  block(matchAddBriefRackRole(e.id, ANY), function () {
    verifyBriefRackRoleDoesNotExist(e.id);
  });
});

bthread("PaginatedClusterGroupList create verification", function () {
  const e = waitForAnyPaginatedClusterGroupListAdded();
  block(matchDeletePaginatedClusterGroupList(e.id, ANY), function () {
    verifyPaginatedClusterGroupListExists(e.id);
  });
});

bthread("PaginatedClusterGroupList update verification", function () {
  const e = waitForAnyPaginatedClusterGroupListUpdated();
  block(matchDeletePaginatedClusterGroupList(e.id, ANY), function () {
    verifyPaginatedClusterGroupListUpdated(e.id);
  });
});

bthread("PaginatedClusterGroupList delete verification", function () {
  const e = waitForAnyPaginatedClusterGroupListDeleted();
  block(matchAddPaginatedClusterGroupList(e.id, ANY), function () {
    verifyPaginatedClusterGroupListDoesNotExist(e.id);
  });
});

bthread("PatchedConfigContextRequest create verification", function () {
  const e = waitForAnyPatchedConfigContextRequestAdded();
  block(matchDeletePatchedConfigContextRequest(e.id, ANY), function () {
    verifyPatchedConfigContextRequestExists(e.id);
  });
});

bthread("PatchedConfigContextRequest update verification", function () {
  const e = waitForAnyPatchedConfigContextRequestUpdated();
  block(matchDeletePatchedConfigContextRequest(e.id, ANY), function () {
    verifyPatchedConfigContextRequestUpdated(e.id);
  });
});

bthread("PatchedConfigContextRequest delete verification", function () {
  const e = waitForAnyPatchedConfigContextRequestDeleted();
  block(matchAddPatchedConfigContextRequest(e.id, ANY), function () {
    verifyPatchedConfigContextRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedTokenList create verification", function () {
  const e = waitForAnyPaginatedTokenListAdded();
  block(matchDeletePaginatedTokenList(e.id, ANY), function () {
    verifyPaginatedTokenListExists(e.id);
  });
});

bthread("PaginatedTokenList update verification", function () {
  const e = waitForAnyPaginatedTokenListUpdated();
  block(matchDeletePaginatedTokenList(e.id, ANY), function () {
    verifyPaginatedTokenListUpdated(e.id);
  });
});

bthread("PaginatedTokenList delete verification", function () {
  const e = waitForAnyPaginatedTokenListDeleted();
  block(matchAddPaginatedTokenList(e.id, ANY), function () {
    verifyPaginatedTokenListDoesNotExist(e.id);
  });
});

bthread("PatchedVLANGroupRequest create verification", function () {
  const e = waitForAnyPatchedVLANGroupRequestAdded();
  block(matchDeletePatchedVLANGroupRequest(e.id, ANY), function () {
    verifyPatchedVLANGroupRequestExists(e.id);
  });
});

bthread("PatchedVLANGroupRequest update verification", function () {
  const e = waitForAnyPatchedVLANGroupRequestUpdated();
  block(matchDeletePatchedVLANGroupRequest(e.id, ANY), function () {
    verifyPatchedVLANGroupRequestUpdated(e.id);
  });
});

bthread("PatchedVLANGroupRequest delete verification", function () {
  const e = waitForAnyPatchedVLANGroupRequestDeleted();
  block(matchAddPatchedVLANGroupRequest(e.id, ANY), function () {
    verifyPatchedVLANGroupRequestDoesNotExist(e.id);
  });
});

bthread("TenantGroup create verification", function () {
  const e = waitForAnyTenantGroupAdded();
  block(matchDeleteTenantGroup(e.id, ANY), function () {
    verifyTenantGroupExists(e.id);
  });
});

bthread("TenantGroup update verification", function () {
  const e = waitForAnyTenantGroupUpdated();
  block(matchDeleteTenantGroup(e.id, ANY), function () {
    verifyTenantGroupUpdated(e.id);
  });
});

bthread("TenantGroup delete verification", function () {
  const e = waitForAnyTenantGroupDeleted();
  block(matchAddTenantGroup(e.id, ANY), function () {
    verifyTenantGroupDoesNotExist(e.id);
  });
});

bthread("PatchedProviderRequest create verification", function () {
  const e = waitForAnyPatchedProviderRequestAdded();
  block(matchDeletePatchedProviderRequest(e.id, ANY), function () {
    verifyPatchedProviderRequestExists(e.id);
  });
});

bthread("PatchedProviderRequest update verification", function () {
  const e = waitForAnyPatchedProviderRequestUpdated();
  block(matchDeletePatchedProviderRequest(e.id, ANY), function () {
    verifyPatchedProviderRequestUpdated(e.id);
  });
});

bthread("PatchedProviderRequest delete verification", function () {
  const e = waitForAnyPatchedProviderRequestDeleted();
  block(matchAddPatchedProviderRequest(e.id, ANY), function () {
    verifyPatchedProviderRequestDoesNotExist(e.id);
  });
});

bthread("RIRRequest create verification", function () {
  const e = waitForAnyRIRRequestAdded();
  block(matchDeleteRIRRequest(e.id, ANY), function () {
    verifyRIRRequestExists(e.id);
  });
});

bthread("RIRRequest update verification", function () {
  const e = waitForAnyRIRRequestUpdated();
  block(matchDeleteRIRRequest(e.id, ANY), function () {
    verifyRIRRequestUpdated(e.id);
  });
});

bthread("RIRRequest delete verification", function () {
  const e = waitForAnyRIRRequestDeleted();
  block(matchAddRIRRequest(e.id, ANY), function () {
    verifyRIRRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableVirtualMachineWithConfigContextRequest create verification", function () {
  const e = waitForAnyPatchedWritableVirtualMachineWithConfigContextRequestAdded();
  block(matchDeletePatchedWritableVirtualMachineWithConfigContextRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualMachineWithConfigContextRequestExists(e.id);
  });
});

bthread("PatchedWritableVirtualMachineWithConfigContextRequest update verification", function () {
  const e = waitForAnyPatchedWritableVirtualMachineWithConfigContextRequestUpdated();
  block(matchDeletePatchedWritableVirtualMachineWithConfigContextRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualMachineWithConfigContextRequestUpdated(e.id);
  });
});

bthread("PatchedWritableVirtualMachineWithConfigContextRequest delete verification", function () {
  const e = waitForAnyPatchedWritableVirtualMachineWithConfigContextRequestDeleted();
  block(matchAddPatchedWritableVirtualMachineWithConfigContextRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualMachineWithConfigContextRequestDoesNotExist(e.id);
  });
});

bthread("BriefCableRequest create verification", function () {
  const e = waitForAnyBriefCableRequestAdded();
  block(matchDeleteBriefCableRequest(e.id, ANY), function () {
    verifyBriefCableRequestExists(e.id);
  });
});

bthread("BriefCableRequest update verification", function () {
  const e = waitForAnyBriefCableRequestUpdated();
  block(matchDeleteBriefCableRequest(e.id, ANY), function () {
    verifyBriefCableRequestUpdated(e.id);
  });
});

bthread("BriefCableRequest delete verification", function () {
  const e = waitForAnyBriefCableRequestDeleted();
  block(matchAddBriefCableRequest(e.id, ANY), function () {
    verifyBriefCableRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableVirtualDeviceContextRequest create verification", function () {
  const e = waitForAnyPatchedWritableVirtualDeviceContextRequestAdded();
  block(matchDeletePatchedWritableVirtualDeviceContextRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualDeviceContextRequestExists(e.id);
  });
});

bthread("PatchedWritableVirtualDeviceContextRequest update verification", function () {
  const e = waitForAnyPatchedWritableVirtualDeviceContextRequestUpdated();
  block(matchDeletePatchedWritableVirtualDeviceContextRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualDeviceContextRequestUpdated(e.id);
  });
});

bthread("PatchedWritableVirtualDeviceContextRequest delete verification", function () {
  const e = waitForAnyPatchedWritableVirtualDeviceContextRequestDeleted();
  block(matchAddPatchedWritableVirtualDeviceContextRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualDeviceContextRequestDoesNotExist(e.id);
  });
});

bthread("WritableServiceTemplateRequest create verification", function () {
  const e = waitForAnyWritableServiceTemplateRequestAdded();
  block(matchDeleteWritableServiceTemplateRequest(e.id, ANY), function () {
    verifyWritableServiceTemplateRequestExists(e.id);
  });
});

bthread("WritableServiceTemplateRequest update verification", function () {
  const e = waitForAnyWritableServiceTemplateRequestUpdated();
  block(matchDeleteWritableServiceTemplateRequest(e.id, ANY), function () {
    verifyWritableServiceTemplateRequestUpdated(e.id);
  });
});

bthread("WritableServiceTemplateRequest delete verification", function () {
  const e = waitForAnyWritableServiceTemplateRequestDeleted();
  block(matchAddWritableServiceTemplateRequest(e.id, ANY), function () {
    verifyWritableServiceTemplateRequestDoesNotExist(e.id);
  });
});

bthread("BriefContactRole create verification", function () {
  const e = waitForAnyBriefContactRoleAdded();
  block(matchDeleteBriefContactRole(e.id, ANY), function () {
    verifyBriefContactRoleExists(e.id);
  });
});

bthread("BriefContactRole update verification", function () {
  const e = waitForAnyBriefContactRoleUpdated();
  block(matchDeleteBriefContactRole(e.id, ANY), function () {
    verifyBriefContactRoleUpdated(e.id);
  });
});

bthread("BriefContactRole delete verification", function () {
  const e = waitForAnyBriefContactRoleDeleted();
  block(matchAddBriefContactRole(e.id, ANY), function () {
    verifyBriefContactRoleDoesNotExist(e.id);
  });
});

bthread("DeviceBayRequest create verification", function () {
  const e = waitForAnyDeviceBayRequestAdded();
  block(matchDeleteDeviceBayRequest(e.id, ANY), function () {
    verifyDeviceBayRequestExists(e.id);
  });
});

bthread("DeviceBayRequest update verification", function () {
  const e = waitForAnyDeviceBayRequestUpdated();
  block(matchDeleteDeviceBayRequest(e.id, ANY), function () {
    verifyDeviceBayRequestUpdated(e.id);
  });
});

bthread("DeviceBayRequest delete verification", function () {
  const e = waitForAnyDeviceBayRequestDeleted();
  block(matchAddDeviceBayRequest(e.id, ANY), function () {
    verifyDeviceBayRequestDoesNotExist(e.id);
  });
});

bthread("InventoryItemTemplateRequest create verification", function () {
  const e = waitForAnyInventoryItemTemplateRequestAdded();
  block(matchDeleteInventoryItemTemplateRequest(e.id, ANY), function () {
    verifyInventoryItemTemplateRequestExists(e.id);
  });
});

bthread("InventoryItemTemplateRequest update verification", function () {
  const e = waitForAnyInventoryItemTemplateRequestUpdated();
  block(matchDeleteInventoryItemTemplateRequest(e.id, ANY), function () {
    verifyInventoryItemTemplateRequestUpdated(e.id);
  });
});

bthread("InventoryItemTemplateRequest delete verification", function () {
  const e = waitForAnyInventoryItemTemplateRequestDeleted();
  block(matchAddInventoryItemTemplateRequest(e.id, ANY), function () {
    verifyInventoryItemTemplateRequestDoesNotExist(e.id);
  });
});

bthread("VLANTranslationPolicy create verification", function () {
  const e = waitForAnyVLANTranslationPolicyAdded();
  block(matchDeleteVLANTranslationPolicy(e.id, ANY), function () {
    verifyVLANTranslationPolicyExists(e.id);
  });
});

bthread("VLANTranslationPolicy update verification", function () {
  const e = waitForAnyVLANTranslationPolicyUpdated();
  block(matchDeleteVLANTranslationPolicy(e.id, ANY), function () {
    verifyVLANTranslationPolicyUpdated(e.id);
  });
});

bthread("VLANTranslationPolicy delete verification", function () {
  const e = waitForAnyVLANTranslationPolicyDeleted();
  block(matchAddVLANTranslationPolicy(e.id, ANY), function () {
    verifyVLANTranslationPolicyDoesNotExist(e.id);
  });
});

bthread("PatchedWritableIPSecProposalRequest create verification", function () {
  const e = waitForAnyPatchedWritableIPSecProposalRequestAdded();
  block(matchDeletePatchedWritableIPSecProposalRequest(e.id, ANY), function () {
    verifyPatchedWritableIPSecProposalRequestExists(e.id);
  });
});

bthread("PatchedWritableIPSecProposalRequest update verification", function () {
  const e = waitForAnyPatchedWritableIPSecProposalRequestUpdated();
  block(matchDeletePatchedWritableIPSecProposalRequest(e.id, ANY), function () {
    verifyPatchedWritableIPSecProposalRequestUpdated(e.id);
  });
});

bthread("PatchedWritableIPSecProposalRequest delete verification", function () {
  const e = waitForAnyPatchedWritableIPSecProposalRequestDeleted();
  block(matchAddPatchedWritableIPSecProposalRequest(e.id, ANY), function () {
    verifyPatchedWritableIPSecProposalRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedWirelessLinkList create verification", function () {
  const e = waitForAnyPaginatedWirelessLinkListAdded();
  block(matchDeletePaginatedWirelessLinkList(e.id, ANY), function () {
    verifyPaginatedWirelessLinkListExists(e.id);
  });
});

bthread("PaginatedWirelessLinkList update verification", function () {
  const e = waitForAnyPaginatedWirelessLinkListUpdated();
  block(matchDeletePaginatedWirelessLinkList(e.id, ANY), function () {
    verifyPaginatedWirelessLinkListUpdated(e.id);
  });
});

bthread("PaginatedWirelessLinkList delete verification", function () {
  const e = waitForAnyPaginatedWirelessLinkListDeleted();
  block(matchAddPaginatedWirelessLinkList(e.id, ANY), function () {
    verifyPaginatedWirelessLinkListDoesNotExist(e.id);
  });
});

bthread("BriefVirtualCircuitRequest create verification", function () {
  const e = waitForAnyBriefVirtualCircuitRequestAdded();
  block(matchDeleteBriefVirtualCircuitRequest(e.id, ANY), function () {
    verifyBriefVirtualCircuitRequestExists(e.id);
  });
});

bthread("BriefVirtualCircuitRequest update verification", function () {
  const e = waitForAnyBriefVirtualCircuitRequestUpdated();
  block(matchDeleteBriefVirtualCircuitRequest(e.id, ANY), function () {
    verifyBriefVirtualCircuitRequestUpdated(e.id);
  });
});

bthread("BriefVirtualCircuitRequest delete verification", function () {
  const e = waitForAnyBriefVirtualCircuitRequestDeleted();
  block(matchAddBriefVirtualCircuitRequest(e.id, ANY), function () {
    verifyBriefVirtualCircuitRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableRegionRequest create verification", function () {
  const e = waitForAnyPatchedWritableRegionRequestAdded();
  block(matchDeletePatchedWritableRegionRequest(e.id, ANY), function () {
    verifyPatchedWritableRegionRequestExists(e.id);
  });
});

bthread("PatchedWritableRegionRequest update verification", function () {
  const e = waitForAnyPatchedWritableRegionRequestUpdated();
  block(matchDeletePatchedWritableRegionRequest(e.id, ANY), function () {
    verifyPatchedWritableRegionRequestUpdated(e.id);
  });
});

bthread("PatchedWritableRegionRequest delete verification", function () {
  const e = waitForAnyPatchedWritableRegionRequestDeleted();
  block(matchAddPatchedWritableRegionRequest(e.id, ANY), function () {
    verifyPatchedWritableRegionRequestDoesNotExist(e.id);
  });
});

bthread("BriefClusterGroupRequest create verification", function () {
  const e = waitForAnyBriefClusterGroupRequestAdded();
  block(matchDeleteBriefClusterGroupRequest(e.id, ANY), function () {
    verifyBriefClusterGroupRequestExists(e.id);
  });
});

bthread("BriefClusterGroupRequest update verification", function () {
  const e = waitForAnyBriefClusterGroupRequestUpdated();
  block(matchDeleteBriefClusterGroupRequest(e.id, ANY), function () {
    verifyBriefClusterGroupRequestUpdated(e.id);
  });
});

bthread("BriefClusterGroupRequest delete verification", function () {
  const e = waitForAnyBriefClusterGroupRequestDeleted();
  block(matchAddBriefClusterGroupRequest(e.id, ANY), function () {
    verifyBriefClusterGroupRequestDoesNotExist(e.id);
  });
});

bthread("ModuleRequest create verification", function () {
  const e = waitForAnyModuleRequestAdded();
  block(matchDeleteModuleRequest(e.id, ANY), function () {
    verifyModuleRequestExists(e.id);
  });
});

bthread("ModuleRequest update verification", function () {
  const e = waitForAnyModuleRequestUpdated();
  block(matchDeleteModuleRequest(e.id, ANY), function () {
    verifyModuleRequestUpdated(e.id);
  });
});

bthread("ModuleRequest delete verification", function () {
  const e = waitForAnyModuleRequestDeleted();
  block(matchAddModuleRequest(e.id, ANY), function () {
    verifyModuleRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableFrontPortRequest create verification", function () {
  const e = waitForAnyPatchedWritableFrontPortRequestAdded();
  block(matchDeletePatchedWritableFrontPortRequest(e.id, ANY), function () {
    verifyPatchedWritableFrontPortRequestExists(e.id);
  });
});

bthread("PatchedWritableFrontPortRequest update verification", function () {
  const e = waitForAnyPatchedWritableFrontPortRequestUpdated();
  block(matchDeletePatchedWritableFrontPortRequest(e.id, ANY), function () {
    verifyPatchedWritableFrontPortRequestUpdated(e.id);
  });
});

bthread("PatchedWritableFrontPortRequest delete verification", function () {
  const e = waitForAnyPatchedWritableFrontPortRequestDeleted();
  block(matchAddPatchedWritableFrontPortRequest(e.id, ANY), function () {
    verifyPatchedWritableFrontPortRequestDoesNotExist(e.id);
  });
});

bthread("WritableModuleRequest create verification", function () {
  const e = waitForAnyWritableModuleRequestAdded();
  block(matchDeleteWritableModuleRequest(e.id, ANY), function () {
    verifyWritableModuleRequestExists(e.id);
  });
});

bthread("WritableModuleRequest update verification", function () {
  const e = waitForAnyWritableModuleRequestUpdated();
  block(matchDeleteWritableModuleRequest(e.id, ANY), function () {
    verifyWritableModuleRequestUpdated(e.id);
  });
});

bthread("WritableModuleRequest delete verification", function () {
  const e = waitForAnyWritableModuleRequestDeleted();
  block(matchAddWritableModuleRequest(e.id, ANY), function () {
    verifyWritableModuleRequestDoesNotExist(e.id);
  });
});

bthread("NestedDeviceRoleRequest create verification", function () {
  const e = waitForAnyNestedDeviceRoleRequestAdded();
  block(matchDeleteNestedDeviceRoleRequest(e.id, ANY), function () {
    verifyNestedDeviceRoleRequestExists(e.id);
  });
});

bthread("NestedDeviceRoleRequest update verification", function () {
  const e = waitForAnyNestedDeviceRoleRequestUpdated();
  block(matchDeleteNestedDeviceRoleRequest(e.id, ANY), function () {
    verifyNestedDeviceRoleRequestUpdated(e.id);
  });
});

bthread("NestedDeviceRoleRequest delete verification", function () {
  const e = waitForAnyNestedDeviceRoleRequestDeleted();
  block(matchAddNestedDeviceRoleRequest(e.id, ANY), function () {
    verifyNestedDeviceRoleRequestDoesNotExist(e.id);
  });
});

bthread("NestedDeviceRole create verification", function () {
  const e = waitForAnyNestedDeviceRoleAdded();
  block(matchDeleteNestedDeviceRole(e.id, ANY), function () {
    verifyNestedDeviceRoleExists(e.id);
  });
});

bthread("NestedDeviceRole update verification", function () {
  const e = waitForAnyNestedDeviceRoleUpdated();
  block(matchDeleteNestedDeviceRole(e.id, ANY), function () {
    verifyNestedDeviceRoleUpdated(e.id);
  });
});

bthread("NestedDeviceRole delete verification", function () {
  const e = waitForAnyNestedDeviceRoleDeleted();
  block(matchAddNestedDeviceRole(e.id, ANY), function () {
    verifyNestedDeviceRoleDoesNotExist(e.id);
  });
});

bthread("NestedInterfaceTemplateRequest create verification", function () {
  const e = waitForAnyNestedInterfaceTemplateRequestAdded();
  block(matchDeleteNestedInterfaceTemplateRequest(e.id, ANY), function () {
    verifyNestedInterfaceTemplateRequestExists(e.id);
  });
});

bthread("NestedInterfaceTemplateRequest update verification", function () {
  const e = waitForAnyNestedInterfaceTemplateRequestUpdated();
  block(matchDeleteNestedInterfaceTemplateRequest(e.id, ANY), function () {
    verifyNestedInterfaceTemplateRequestUpdated(e.id);
  });
});

bthread("NestedInterfaceTemplateRequest delete verification", function () {
  const e = waitForAnyNestedInterfaceTemplateRequestDeleted();
  block(matchAddNestedInterfaceTemplateRequest(e.id, ANY), function () {
    verifyNestedInterfaceTemplateRequestDoesNotExist(e.id);
  });
});

bthread("BookmarkRequest create verification", function () {
  const e = waitForAnyBookmarkRequestAdded();
  block(matchDeleteBookmarkRequest(e.id, ANY), function () {
    verifyBookmarkRequestExists(e.id);
  });
});

bthread("BookmarkRequest update verification", function () {
  const e = waitForAnyBookmarkRequestUpdated();
  block(matchDeleteBookmarkRequest(e.id, ANY), function () {
    verifyBookmarkRequestUpdated(e.id);
  });
});

bthread("BookmarkRequest delete verification", function () {
  const e = waitForAnyBookmarkRequestDeleted();
  block(matchAddBookmarkRequest(e.id, ANY), function () {
    verifyBookmarkRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedTenantList create verification", function () {
  const e = waitForAnyPaginatedTenantListAdded();
  block(matchDeletePaginatedTenantList(e.id, ANY), function () {
    verifyPaginatedTenantListExists(e.id);
  });
});

bthread("PaginatedTenantList update verification", function () {
  const e = waitForAnyPaginatedTenantListUpdated();
  block(matchDeletePaginatedTenantList(e.id, ANY), function () {
    verifyPaginatedTenantListUpdated(e.id);
  });
});

bthread("PaginatedTenantList delete verification", function () {
  const e = waitForAnyPaginatedTenantListDeleted();
  block(matchAddPaginatedTenantList(e.id, ANY), function () {
    verifyPaginatedTenantListDoesNotExist(e.id);
  });
});

bthread("WritableCircuitRequest create verification", function () {
  const e = waitForAnyWritableCircuitRequestAdded();
  block(matchDeleteWritableCircuitRequest(e.id, ANY), function () {
    verifyWritableCircuitRequestExists(e.id);
  });
});

bthread("WritableCircuitRequest update verification", function () {
  const e = waitForAnyWritableCircuitRequestUpdated();
  block(matchDeleteWritableCircuitRequest(e.id, ANY), function () {
    verifyWritableCircuitRequestUpdated(e.id);
  });
});

bthread("WritableCircuitRequest delete verification", function () {
  const e = waitForAnyWritableCircuitRequestDeleted();
  block(matchAddWritableCircuitRequest(e.id, ANY), function () {
    verifyWritableCircuitRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritablePrefixRequest create verification", function () {
  const e = waitForAnyPatchedWritablePrefixRequestAdded();
  block(matchDeletePatchedWritablePrefixRequest(e.id, ANY), function () {
    verifyPatchedWritablePrefixRequestExists(e.id);
  });
});

bthread("PatchedWritablePrefixRequest update verification", function () {
  const e = waitForAnyPatchedWritablePrefixRequestUpdated();
  block(matchDeletePatchedWritablePrefixRequest(e.id, ANY), function () {
    verifyPatchedWritablePrefixRequestUpdated(e.id);
  });
});

bthread("PatchedWritablePrefixRequest delete verification", function () {
  const e = waitForAnyPatchedWritablePrefixRequestDeleted();
  block(matchAddPatchedWritablePrefixRequest(e.id, ANY), function () {
    verifyPatchedWritablePrefixRequestDoesNotExist(e.id);
  });
});

bthread("BriefVLAN create verification", function () {
  const e = waitForAnyBriefVLANAdded();
  block(matchDeleteBriefVLAN(e.id, ANY), function () {
    verifyBriefVLANExists(e.id);
  });
});

bthread("BriefVLAN update verification", function () {
  const e = waitForAnyBriefVLANUpdated();
  block(matchDeleteBriefVLAN(e.id, ANY), function () {
    verifyBriefVLANUpdated(e.id);
  });
});

bthread("BriefVLAN delete verification", function () {
  const e = waitForAnyBriefVLANDeleted();
  block(matchAddBriefVLAN(e.id, ANY), function () {
    verifyBriefVLANDoesNotExist(e.id);
  });
});

bthread("PaginatedExportTemplateList create verification", function () {
  const e = waitForAnyPaginatedExportTemplateListAdded();
  block(matchDeletePaginatedExportTemplateList(e.id, ANY), function () {
    verifyPaginatedExportTemplateListExists(e.id);
  });
});

bthread("PaginatedExportTemplateList update verification", function () {
  const e = waitForAnyPaginatedExportTemplateListUpdated();
  block(matchDeletePaginatedExportTemplateList(e.id, ANY), function () {
    verifyPaginatedExportTemplateListUpdated(e.id);
  });
});

bthread("PaginatedExportTemplateList delete verification", function () {
  const e = waitForAnyPaginatedExportTemplateListDeleted();
  block(matchAddPaginatedExportTemplateList(e.id, ANY), function () {
    verifyPaginatedExportTemplateListDoesNotExist(e.id);
  });
});

bthread("PaginatedConfigContextList create verification", function () {
  const e = waitForAnyPaginatedConfigContextListAdded();
  block(matchDeletePaginatedConfigContextList(e.id, ANY), function () {
    verifyPaginatedConfigContextListExists(e.id);
  });
});

bthread("PaginatedConfigContextList update verification", function () {
  const e = waitForAnyPaginatedConfigContextListUpdated();
  block(matchDeletePaginatedConfigContextList(e.id, ANY), function () {
    verifyPaginatedConfigContextListUpdated(e.id);
  });
});

bthread("PaginatedConfigContextList delete verification", function () {
  const e = waitForAnyPaginatedConfigContextListDeleted();
  block(matchAddPaginatedConfigContextList(e.id, ANY), function () {
    verifyPaginatedConfigContextListDoesNotExist(e.id);
  });
});

bthread("PatchedTagRequest create verification", function () {
  const e = waitForAnyPatchedTagRequestAdded();
  block(matchDeletePatchedTagRequest(e.id, ANY), function () {
    verifyPatchedTagRequestExists(e.id);
  });
});

bthread("PatchedTagRequest update verification", function () {
  const e = waitForAnyPatchedTagRequestUpdated();
  block(matchDeletePatchedTagRequest(e.id, ANY), function () {
    verifyPatchedTagRequestUpdated(e.id);
  });
});

bthread("PatchedTagRequest delete verification", function () {
  const e = waitForAnyPatchedTagRequestDeleted();
  block(matchAddPatchedTagRequest(e.id, ANY), function () {
    verifyPatchedTagRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableClusterRequest create verification", function () {
  const e = waitForAnyPatchedWritableClusterRequestAdded();
  block(matchDeletePatchedWritableClusterRequest(e.id, ANY), function () {
    verifyPatchedWritableClusterRequestExists(e.id);
  });
});

bthread("PatchedWritableClusterRequest update verification", function () {
  const e = waitForAnyPatchedWritableClusterRequestUpdated();
  block(matchDeletePatchedWritableClusterRequest(e.id, ANY), function () {
    verifyPatchedWritableClusterRequestUpdated(e.id);
  });
});

bthread("PatchedWritableClusterRequest delete verification", function () {
  const e = waitForAnyPatchedWritableClusterRequestDeleted();
  block(matchAddPatchedWritableClusterRequest(e.id, ANY), function () {
    verifyPatchedWritableClusterRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedVirtualCircuitTerminationList create verification", function () {
  const e = waitForAnyPaginatedVirtualCircuitTerminationListAdded();
  block(matchDeletePaginatedVirtualCircuitTerminationList(e.id, ANY), function () {
    verifyPaginatedVirtualCircuitTerminationListExists(e.id);
  });
});

bthread("PaginatedVirtualCircuitTerminationList update verification", function () {
  const e = waitForAnyPaginatedVirtualCircuitTerminationListUpdated();
  block(matchDeletePaginatedVirtualCircuitTerminationList(e.id, ANY), function () {
    verifyPaginatedVirtualCircuitTerminationListUpdated(e.id);
  });
});

bthread("PaginatedVirtualCircuitTerminationList delete verification", function () {
  const e = waitForAnyPaginatedVirtualCircuitTerminationListDeleted();
  block(matchAddPaginatedVirtualCircuitTerminationList(e.id, ANY), function () {
    verifyPaginatedVirtualCircuitTerminationListDoesNotExist(e.id);
  });
});

bthread("CircuitTermination create verification", function () {
  const e = waitForAnyCircuitTerminationAdded();
  block(matchDeleteCircuitTermination(e.id, ANY), function () {
    verifyCircuitTerminationExists(e.id);
  });
});

bthread("CircuitTermination update verification", function () {
  const e = waitForAnyCircuitTerminationUpdated();
  block(matchDeleteCircuitTermination(e.id, ANY), function () {
    verifyCircuitTerminationUpdated(e.id);
  });
});

bthread("CircuitTermination delete verification", function () {
  const e = waitForAnyCircuitTerminationDeleted();
  block(matchAddCircuitTermination(e.id, ANY), function () {
    verifyCircuitTerminationDoesNotExist(e.id);
  });
});

bthread("PaginatedSavedFilterList create verification", function () {
  const e = waitForAnyPaginatedSavedFilterListAdded();
  block(matchDeletePaginatedSavedFilterList(e.id, ANY), function () {
    verifyPaginatedSavedFilterListExists(e.id);
  });
});

bthread("PaginatedSavedFilterList update verification", function () {
  const e = waitForAnyPaginatedSavedFilterListUpdated();
  block(matchDeletePaginatedSavedFilterList(e.id, ANY), function () {
    verifyPaginatedSavedFilterListUpdated(e.id);
  });
});

bthread("PaginatedSavedFilterList delete verification", function () {
  const e = waitForAnyPaginatedSavedFilterListDeleted();
  block(matchAddPaginatedSavedFilterList(e.id, ANY), function () {
    verifyPaginatedSavedFilterListDoesNotExist(e.id);
  });
});

bthread("AvailableIP create verification", function () {
  const e = waitForAnyAvailableIPAdded();
  block(matchDeleteAvailableIP(e.id, ANY), function () {
    verifyAvailableIPExists(e.id);
  });
});

bthread("AvailableIP update verification", function () {
  const e = waitForAnyAvailableIPUpdated();
  block(matchDeleteAvailableIP(e.id, ANY), function () {
    verifyAvailableIPUpdated(e.id);
  });
});

bthread("AvailableIP delete verification", function () {
  const e = waitForAnyAvailableIPDeleted();
  block(matchAddAvailableIP(e.id, ANY), function () {
    verifyAvailableIPDoesNotExist(e.id);
  });
});

bthread("BriefCircuitRequest create verification", function () {
  const e = waitForAnyBriefCircuitRequestAdded();
  block(matchDeleteBriefCircuitRequest(e.id, ANY), function () {
    verifyBriefCircuitRequestExists(e.id);
  });
});

bthread("BriefCircuitRequest update verification", function () {
  const e = waitForAnyBriefCircuitRequestUpdated();
  block(matchDeleteBriefCircuitRequest(e.id, ANY), function () {
    verifyBriefCircuitRequestUpdated(e.id);
  });
});

bthread("BriefCircuitRequest delete verification", function () {
  const e = waitForAnyBriefCircuitRequestDeleted();
  block(matchAddBriefCircuitRequest(e.id, ANY), function () {
    verifyBriefCircuitRequestDoesNotExist(e.id);
  });
});

bthread("WritableIPAddressRequest create verification", function () {
  const e = waitForAnyWritableIPAddressRequestAdded();
  block(matchDeleteWritableIPAddressRequest(e.id, ANY), function () {
    verifyWritableIPAddressRequestExists(e.id);
  });
});

bthread("WritableIPAddressRequest update verification", function () {
  const e = waitForAnyWritableIPAddressRequestUpdated();
  block(matchDeleteWritableIPAddressRequest(e.id, ANY), function () {
    verifyWritableIPAddressRequestUpdated(e.id);
  });
});

bthread("WritableIPAddressRequest delete verification", function () {
  const e = waitForAnyWritableIPAddressRequestDeleted();
  block(matchAddWritableIPAddressRequest(e.id, ANY), function () {
    verifyWritableIPAddressRequestDoesNotExist(e.id);
  });
});

bthread("PatchedCableTerminationRequest create verification", function () {
  const e = waitForAnyPatchedCableTerminationRequestAdded();
  block(matchDeletePatchedCableTerminationRequest(e.id, ANY), function () {
    verifyPatchedCableTerminationRequestExists(e.id);
  });
});

bthread("PatchedCableTerminationRequest update verification", function () {
  const e = waitForAnyPatchedCableTerminationRequestUpdated();
  block(matchDeletePatchedCableTerminationRequest(e.id, ANY), function () {
    verifyPatchedCableTerminationRequestUpdated(e.id);
  });
});

bthread("PatchedCableTerminationRequest delete verification", function () {
  const e = waitForAnyPatchedCableTerminationRequestDeleted();
  block(matchAddPatchedCableTerminationRequest(e.id, ANY), function () {
    verifyPatchedCableTerminationRequestDoesNotExist(e.id);
  });
});

bthread("NestedDeviceRequest create verification", function () {
  const e = waitForAnyNestedDeviceRequestAdded();
  block(matchDeleteNestedDeviceRequest(e.id, ANY), function () {
    verifyNestedDeviceRequestExists(e.id);
  });
});

bthread("NestedDeviceRequest update verification", function () {
  const e = waitForAnyNestedDeviceRequestUpdated();
  block(matchDeleteNestedDeviceRequest(e.id, ANY), function () {
    verifyNestedDeviceRequestUpdated(e.id);
  });
});

bthread("NestedDeviceRequest delete verification", function () {
  const e = waitForAnyNestedDeviceRequestDeleted();
  block(matchAddNestedDeviceRequest(e.id, ANY), function () {
    verifyNestedDeviceRequestDoesNotExist(e.id);
  });
});

bthread("WritableTunnelTerminationRequest create verification", function () {
  const e = waitForAnyWritableTunnelTerminationRequestAdded();
  block(matchDeleteWritableTunnelTerminationRequest(e.id, ANY), function () {
    verifyWritableTunnelTerminationRequestExists(e.id);
  });
});

bthread("WritableTunnelTerminationRequest update verification", function () {
  const e = waitForAnyWritableTunnelTerminationRequestUpdated();
  block(matchDeleteWritableTunnelTerminationRequest(e.id, ANY), function () {
    verifyWritableTunnelTerminationRequestUpdated(e.id);
  });
});

bthread("WritableTunnelTerminationRequest delete verification", function () {
  const e = waitForAnyWritableTunnelTerminationRequestDeleted();
  block(matchAddWritableTunnelTerminationRequest(e.id, ANY), function () {
    verifyWritableTunnelTerminationRequestDoesNotExist(e.id);
  });
});

bthread("BriefIPSecPolicy create verification", function () {
  const e = waitForAnyBriefIPSecPolicyAdded();
  block(matchDeleteBriefIPSecPolicy(e.id, ANY), function () {
    verifyBriefIPSecPolicyExists(e.id);
  });
});

bthread("BriefIPSecPolicy update verification", function () {
  const e = waitForAnyBriefIPSecPolicyUpdated();
  block(matchDeleteBriefIPSecPolicy(e.id, ANY), function () {
    verifyBriefIPSecPolicyUpdated(e.id);
  });
});

bthread("BriefIPSecPolicy delete verification", function () {
  const e = waitForAnyBriefIPSecPolicyDeleted();
  block(matchAddBriefIPSecPolicy(e.id, ANY), function () {
    verifyBriefIPSecPolicyDoesNotExist(e.id);
  });
});

bthread("PaginatedPowerOutletList create verification", function () {
  const e = waitForAnyPaginatedPowerOutletListAdded();
  block(matchDeletePaginatedPowerOutletList(e.id, ANY), function () {
    verifyPaginatedPowerOutletListExists(e.id);
  });
});

bthread("PaginatedPowerOutletList update verification", function () {
  const e = waitForAnyPaginatedPowerOutletListUpdated();
  block(matchDeletePaginatedPowerOutletList(e.id, ANY), function () {
    verifyPaginatedPowerOutletListUpdated(e.id);
  });
});

bthread("PaginatedPowerOutletList delete verification", function () {
  const e = waitForAnyPaginatedPowerOutletListDeleted();
  block(matchAddPaginatedPowerOutletList(e.id, ANY), function () {
    verifyPaginatedPowerOutletListDoesNotExist(e.id);
  });
});

bthread("CircuitCircuitTerminationRequest create verification", function () {
  const e = waitForAnyCircuitCircuitTerminationRequestAdded();
  block(matchDeleteCircuitCircuitTerminationRequest(e.id, ANY), function () {
    verifyCircuitCircuitTerminationRequestExists(e.id);
  });
});

bthread("CircuitCircuitTerminationRequest update verification", function () {
  const e = waitForAnyCircuitCircuitTerminationRequestUpdated();
  block(matchDeleteCircuitCircuitTerminationRequest(e.id, ANY), function () {
    verifyCircuitCircuitTerminationRequestUpdated(e.id);
  });
});

bthread("CircuitCircuitTerminationRequest delete verification", function () {
  const e = waitForAnyCircuitCircuitTerminationRequestDeleted();
  block(matchAddCircuitCircuitTerminationRequest(e.id, ANY), function () {
    verifyCircuitCircuitTerminationRequestDoesNotExist(e.id);
  });
});

bthread("Group create verification", function () {
  const e = waitForAnyGroupAdded();
  block(matchDeleteGroup(e.id, ANY), function () {
    verifyGroupExists(e.id);
  });
});

bthread("Group update verification", function () {
  const e = waitForAnyGroupUpdated();
  block(matchDeleteGroup(e.id, ANY), function () {
    verifyGroupUpdated(e.id);
  });
});

bthread("Group delete verification", function () {
  const e = waitForAnyGroupDeleted();
  block(matchAddGroup(e.id, ANY), function () {
    verifyGroupDoesNotExist(e.id);
  });
});

bthread("TableConfig create verification", function () {
  const e = waitForAnyTableConfigAdded();
  block(matchDeleteTableConfig(e.id, ANY), function () {
    verifyTableConfigExists(e.id);
  });
});

bthread("TableConfig update verification", function () {
  const e = waitForAnyTableConfigUpdated();
  block(matchDeleteTableConfig(e.id, ANY), function () {
    verifyTableConfigUpdated(e.id);
  });
});

bthread("TableConfig delete verification", function () {
  const e = waitForAnyTableConfigDeleted();
  block(matchAddTableConfig(e.id, ANY), function () {
    verifyTableConfigDoesNotExist(e.id);
  });
});

bthread("Interface create verification", function () {
  const e = waitForAnyInterfaceAdded();
  block(matchDeleteInterface(e.id, ANY), function () {
    verifyInterfaceExists(e.id);
  });
});

bthread("Interface update verification", function () {
  const e = waitForAnyInterfaceUpdated();
  block(matchDeleteInterface(e.id, ANY), function () {
    verifyInterfaceUpdated(e.id);
  });
});

bthread("Interface delete verification", function () {
  const e = waitForAnyInterfaceDeleted();
  block(matchAddInterface(e.id, ANY), function () {
    verifyInterfaceDoesNotExist(e.id);
  });
});

bthread("WritableDeviceWithConfigContextRequest create verification", function () {
  const e = waitForAnyWritableDeviceWithConfigContextRequestAdded();
  block(matchDeleteWritableDeviceWithConfigContextRequest(e.id, ANY), function () {
    verifyWritableDeviceWithConfigContextRequestExists(e.id);
  });
});

bthread("WritableDeviceWithConfigContextRequest update verification", function () {
  const e = waitForAnyWritableDeviceWithConfigContextRequestUpdated();
  block(matchDeleteWritableDeviceWithConfigContextRequest(e.id, ANY), function () {
    verifyWritableDeviceWithConfigContextRequestUpdated(e.id);
  });
});

bthread("WritableDeviceWithConfigContextRequest delete verification", function () {
  const e = waitForAnyWritableDeviceWithConfigContextRequestDeleted();
  block(matchAddWritableDeviceWithConfigContextRequest(e.id, ANY), function () {
    verifyWritableDeviceWithConfigContextRequestDoesNotExist(e.id);
  });
});

bthread("NestedInterfaceRequest create verification", function () {
  const e = waitForAnyNestedInterfaceRequestAdded();
  block(matchDeleteNestedInterfaceRequest(e.id, ANY), function () {
    verifyNestedInterfaceRequestExists(e.id);
  });
});

bthread("NestedInterfaceRequest update verification", function () {
  const e = waitForAnyNestedInterfaceRequestUpdated();
  block(matchDeleteNestedInterfaceRequest(e.id, ANY), function () {
    verifyNestedInterfaceRequestUpdated(e.id);
  });
});

bthread("NestedInterfaceRequest delete verification", function () {
  const e = waitForAnyNestedInterfaceRequestDeleted();
  block(matchAddNestedInterfaceRequest(e.id, ANY), function () {
    verifyNestedInterfaceRequestDoesNotExist(e.id);
  });
});

bthread("PowerPortRequest create verification", function () {
  const e = waitForAnyPowerPortRequestAdded();
  block(matchDeletePowerPortRequest(e.id, ANY), function () {
    verifyPowerPortRequestExists(e.id);
  });
});

bthread("PowerPortRequest update verification", function () {
  const e = waitForAnyPowerPortRequestUpdated();
  block(matchDeletePowerPortRequest(e.id, ANY), function () {
    verifyPowerPortRequestUpdated(e.id);
  });
});

bthread("PowerPortRequest delete verification", function () {
  const e = waitForAnyPowerPortRequestDeleted();
  block(matchAddPowerPortRequest(e.id, ANY), function () {
    verifyPowerPortRequestDoesNotExist(e.id);
  });
});

bthread("ModuleTypeProfileRequest create verification", function () {
  const e = waitForAnyModuleTypeProfileRequestAdded();
  block(matchDeleteModuleTypeProfileRequest(e.id, ANY), function () {
    verifyModuleTypeProfileRequestExists(e.id);
  });
});

bthread("ModuleTypeProfileRequest update verification", function () {
  const e = waitForAnyModuleTypeProfileRequestUpdated();
  block(matchDeleteModuleTypeProfileRequest(e.id, ANY), function () {
    verifyModuleTypeProfileRequestUpdated(e.id);
  });
});

bthread("ModuleTypeProfileRequest delete verification", function () {
  const e = waitForAnyModuleTypeProfileRequestDeleted();
  block(matchAddModuleTypeProfileRequest(e.id, ANY), function () {
    verifyModuleTypeProfileRequestDoesNotExist(e.id);
  });
});

bthread("BriefRearPortTemplateRequest create verification", function () {
  const e = waitForAnyBriefRearPortTemplateRequestAdded();
  block(matchDeleteBriefRearPortTemplateRequest(e.id, ANY), function () {
    verifyBriefRearPortTemplateRequestExists(e.id);
  });
});

bthread("BriefRearPortTemplateRequest update verification", function () {
  const e = waitForAnyBriefRearPortTemplateRequestUpdated();
  block(matchDeleteBriefRearPortTemplateRequest(e.id, ANY), function () {
    verifyBriefRearPortTemplateRequestUpdated(e.id);
  });
});

bthread("BriefRearPortTemplateRequest delete verification", function () {
  const e = waitForAnyBriefRearPortTemplateRequestDeleted();
  block(matchAddBriefRearPortTemplateRequest(e.id, ANY), function () {
    verifyBriefRearPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("BriefPowerPortTemplateRequest create verification", function () {
  const e = waitForAnyBriefPowerPortTemplateRequestAdded();
  block(matchDeleteBriefPowerPortTemplateRequest(e.id, ANY), function () {
    verifyBriefPowerPortTemplateRequestExists(e.id);
  });
});

bthread("BriefPowerPortTemplateRequest update verification", function () {
  const e = waitForAnyBriefPowerPortTemplateRequestUpdated();
  block(matchDeleteBriefPowerPortTemplateRequest(e.id, ANY), function () {
    verifyBriefPowerPortTemplateRequestUpdated(e.id);
  });
});

bthread("BriefPowerPortTemplateRequest delete verification", function () {
  const e = waitForAnyBriefPowerPortTemplateRequestDeleted();
  block(matchAddBriefPowerPortTemplateRequest(e.id, ANY), function () {
    verifyBriefPowerPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("NestedIPAddress create verification", function () {
  const e = waitForAnyNestedIPAddressAdded();
  block(matchDeleteNestedIPAddress(e.id, ANY), function () {
    verifyNestedIPAddressExists(e.id);
  });
});

bthread("NestedIPAddress update verification", function () {
  const e = waitForAnyNestedIPAddressUpdated();
  block(matchDeleteNestedIPAddress(e.id, ANY), function () {
    verifyNestedIPAddressUpdated(e.id);
  });
});

bthread("NestedIPAddress delete verification", function () {
  const e = waitForAnyNestedIPAddressDeleted();
  block(matchAddNestedIPAddress(e.id, ANY), function () {
    verifyNestedIPAddressDoesNotExist(e.id);
  });
});

bthread("PaginatedModuleTypeProfileList create verification", function () {
  const e = waitForAnyPaginatedModuleTypeProfileListAdded();
  block(matchDeletePaginatedModuleTypeProfileList(e.id, ANY), function () {
    verifyPaginatedModuleTypeProfileListExists(e.id);
  });
});

bthread("PaginatedModuleTypeProfileList update verification", function () {
  const e = waitForAnyPaginatedModuleTypeProfileListUpdated();
  block(matchDeletePaginatedModuleTypeProfileList(e.id, ANY), function () {
    verifyPaginatedModuleTypeProfileListUpdated(e.id);
  });
});

bthread("PaginatedModuleTypeProfileList delete verification", function () {
  const e = waitForAnyPaginatedModuleTypeProfileListDeleted();
  block(matchAddPaginatedModuleTypeProfileList(e.id, ANY), function () {
    verifyPaginatedModuleTypeProfileListDoesNotExist(e.id);
  });
});

bthread("PatchedRIRRequest create verification", function () {
  const e = waitForAnyPatchedRIRRequestAdded();
  block(matchDeletePatchedRIRRequest(e.id, ANY), function () {
    verifyPatchedRIRRequestExists(e.id);
  });
});

bthread("PatchedRIRRequest update verification", function () {
  const e = waitForAnyPatchedRIRRequestUpdated();
  block(matchDeletePatchedRIRRequest(e.id, ANY), function () {
    verifyPatchedRIRRequestUpdated(e.id);
  });
});

bthread("PatchedRIRRequest delete verification", function () {
  const e = waitForAnyPatchedRIRRequestDeleted();
  block(matchAddPatchedRIRRequest(e.id, ANY), function () {
    verifyPatchedRIRRequestDoesNotExist(e.id);
  });
});

bthread("BriefRegionRequest create verification", function () {
  const e = waitForAnyBriefRegionRequestAdded();
  block(matchDeleteBriefRegionRequest(e.id, ANY), function () {
    verifyBriefRegionRequestExists(e.id);
  });
});

bthread("BriefRegionRequest update verification", function () {
  const e = waitForAnyBriefRegionRequestUpdated();
  block(matchDeleteBriefRegionRequest(e.id, ANY), function () {
    verifyBriefRegionRequestUpdated(e.id);
  });
});

bthread("BriefRegionRequest delete verification", function () {
  const e = waitForAnyBriefRegionRequestDeleted();
  block(matchAddBriefRegionRequest(e.id, ANY), function () {
    verifyBriefRegionRequestDoesNotExist(e.id);
  });
});

bthread("BackgroundTask create verification", function () {
  const e = waitForAnyBackgroundTaskAdded();
  block(matchDeleteBackgroundTask(e.id, ANY), function () {
    verifyBackgroundTaskExists(e.id);
  });
});

bthread("BackgroundTask update verification", function () {
  const e = waitForAnyBackgroundTaskUpdated();
  block(matchDeleteBackgroundTask(e.id, ANY), function () {
    verifyBackgroundTaskUpdated(e.id);
  });
});

bthread("BackgroundTask delete verification", function () {
  const e = waitForAnyBackgroundTaskDeleted();
  block(matchAddBackgroundTask(e.id, ANY), function () {
    verifyBackgroundTaskDoesNotExist(e.id);
  });
});

bthread("PatchedASNRangeRequest create verification", function () {
  const e = waitForAnyPatchedASNRangeRequestAdded();
  block(matchDeletePatchedASNRangeRequest(e.id, ANY), function () {
    verifyPatchedASNRangeRequestExists(e.id);
  });
});

bthread("PatchedASNRangeRequest update verification", function () {
  const e = waitForAnyPatchedASNRangeRequestUpdated();
  block(matchDeletePatchedASNRangeRequest(e.id, ANY), function () {
    verifyPatchedASNRangeRequestUpdated(e.id);
  });
});

bthread("PatchedASNRangeRequest delete verification", function () {
  const e = waitForAnyPatchedASNRangeRequestDeleted();
  block(matchAddPatchedASNRangeRequest(e.id, ANY), function () {
    verifyPatchedASNRangeRequestDoesNotExist(e.id);
  });
});

bthread("BriefCircuit create verification", function () {
  const e = waitForAnyBriefCircuitAdded();
  block(matchDeleteBriefCircuit(e.id, ANY), function () {
    verifyBriefCircuitExists(e.id);
  });
});

bthread("BriefCircuit update verification", function () {
  const e = waitForAnyBriefCircuitUpdated();
  block(matchDeleteBriefCircuit(e.id, ANY), function () {
    verifyBriefCircuitUpdated(e.id);
  });
});

bthread("BriefCircuit delete verification", function () {
  const e = waitForAnyBriefCircuitDeleted();
  block(matchAddBriefCircuit(e.id, ANY), function () {
    verifyBriefCircuitDoesNotExist(e.id);
  });
});

bthread("BriefWirelessLANGroup create verification", function () {
  const e = waitForAnyBriefWirelessLANGroupAdded();
  block(matchDeleteBriefWirelessLANGroup(e.id, ANY), function () {
    verifyBriefWirelessLANGroupExists(e.id);
  });
});

bthread("BriefWirelessLANGroup update verification", function () {
  const e = waitForAnyBriefWirelessLANGroupUpdated();
  block(matchDeleteBriefWirelessLANGroup(e.id, ANY), function () {
    verifyBriefWirelessLANGroupUpdated(e.id);
  });
});

bthread("BriefWirelessLANGroup delete verification", function () {
  const e = waitForAnyBriefWirelessLANGroupDeleted();
  block(matchAddBriefWirelessLANGroup(e.id, ANY), function () {
    verifyBriefWirelessLANGroupDoesNotExist(e.id);
  });
});

bthread("PaginatedDataSourceList create verification", function () {
  const e = waitForAnyPaginatedDataSourceListAdded();
  block(matchDeletePaginatedDataSourceList(e.id, ANY), function () {
    verifyPaginatedDataSourceListExists(e.id);
  });
});

bthread("PaginatedDataSourceList update verification", function () {
  const e = waitForAnyPaginatedDataSourceListUpdated();
  block(matchDeletePaginatedDataSourceList(e.id, ANY), function () {
    verifyPaginatedDataSourceListUpdated(e.id);
  });
});

bthread("PaginatedDataSourceList delete verification", function () {
  const e = waitForAnyPaginatedDataSourceListDeleted();
  block(matchAddPaginatedDataSourceList(e.id, ANY), function () {
    verifyPaginatedDataSourceListDoesNotExist(e.id);
  });
});

bthread("TunnelGroupRequest create verification", function () {
  const e = waitForAnyTunnelGroupRequestAdded();
  block(matchDeleteTunnelGroupRequest(e.id, ANY), function () {
    verifyTunnelGroupRequestExists(e.id);
  });
});

bthread("TunnelGroupRequest update verification", function () {
  const e = waitForAnyTunnelGroupRequestUpdated();
  block(matchDeleteTunnelGroupRequest(e.id, ANY), function () {
    verifyTunnelGroupRequestUpdated(e.id);
  });
});

bthread("TunnelGroupRequest delete verification", function () {
  const e = waitForAnyTunnelGroupRequestDeleted();
  block(matchAddTunnelGroupRequest(e.id, ANY), function () {
    verifyTunnelGroupRequestDoesNotExist(e.id);
  });
});

bthread("WritableVirtualChassisRequest create verification", function () {
  const e = waitForAnyWritableVirtualChassisRequestAdded();
  block(matchDeleteWritableVirtualChassisRequest(e.id, ANY), function () {
    verifyWritableVirtualChassisRequestExists(e.id);
  });
});

bthread("WritableVirtualChassisRequest update verification", function () {
  const e = waitForAnyWritableVirtualChassisRequestUpdated();
  block(matchDeleteWritableVirtualChassisRequest(e.id, ANY), function () {
    verifyWritableVirtualChassisRequestUpdated(e.id);
  });
});

bthread("WritableVirtualChassisRequest delete verification", function () {
  const e = waitForAnyWritableVirtualChassisRequestDeleted();
  block(matchAddWritableVirtualChassisRequest(e.id, ANY), function () {
    verifyWritableVirtualChassisRequestDoesNotExist(e.id);
  });
});

bthread("Location create verification", function () {
  const e = waitForAnyLocationAdded();
  block(matchDeleteLocation(e.id, ANY), function () {
    verifyLocationExists(e.id);
  });
});

bthread("Location update verification", function () {
  const e = waitForAnyLocationUpdated();
  block(matchDeleteLocation(e.id, ANY), function () {
    verifyLocationUpdated(e.id);
  });
});

bthread("Location delete verification", function () {
  const e = waitForAnyLocationDeleted();
  block(matchAddLocation(e.id, ANY), function () {
    verifyLocationDoesNotExist(e.id);
  });
});

bthread("PatchedWritableWirelessLANGroupRequest create verification", function () {
  const e = waitForAnyPatchedWritableWirelessLANGroupRequestAdded();
  block(matchDeletePatchedWritableWirelessLANGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableWirelessLANGroupRequestExists(e.id);
  });
});

bthread("PatchedWritableWirelessLANGroupRequest update verification", function () {
  const e = waitForAnyPatchedWritableWirelessLANGroupRequestUpdated();
  block(matchDeletePatchedWritableWirelessLANGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableWirelessLANGroupRequestUpdated(e.id);
  });
});

bthread("PatchedWritableWirelessLANGroupRequest delete verification", function () {
  const e = waitForAnyPatchedWritableWirelessLANGroupRequestDeleted();
  block(matchAddPatchedWritableWirelessLANGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableWirelessLANGroupRequestDoesNotExist(e.id);
  });
});

bthread("Circuit create verification", function () {
  const e = waitForAnyCircuitAdded();
  block(matchDeleteCircuit(e.id, ANY), function () {
    verifyCircuitExists(e.id);
  });
});

bthread("Circuit update verification", function () {
  const e = waitForAnyCircuitUpdated();
  block(matchDeleteCircuit(e.id, ANY), function () {
    verifyCircuitUpdated(e.id);
  });
});

bthread("Circuit delete verification", function () {
  const e = waitForAnyCircuitDeleted();
  block(matchAddCircuit(e.id, ANY), function () {
    verifyCircuitDoesNotExist(e.id);
  });
});

bthread("PatchedMACAddressRequest create verification", function () {
  const e = waitForAnyPatchedMACAddressRequestAdded();
  block(matchDeletePatchedMACAddressRequest(e.id, ANY), function () {
    verifyPatchedMACAddressRequestExists(e.id);
  });
});

bthread("PatchedMACAddressRequest update verification", function () {
  const e = waitForAnyPatchedMACAddressRequestUpdated();
  block(matchDeletePatchedMACAddressRequest(e.id, ANY), function () {
    verifyPatchedMACAddressRequestUpdated(e.id);
  });
});

bthread("PatchedMACAddressRequest delete verification", function () {
  const e = waitForAnyPatchedMACAddressRequestDeleted();
  block(matchAddPatchedMACAddressRequest(e.id, ANY), function () {
    verifyPatchedMACAddressRequestDoesNotExist(e.id);
  });
});

bthread("TokenRequest create verification", function () {
  const e = waitForAnyTokenRequestAdded();
  block(matchDeleteTokenRequest(e.id, ANY), function () {
    verifyTokenRequestExists(e.id);
  });
});

bthread("TokenRequest update verification", function () {
  const e = waitForAnyTokenRequestUpdated();
  block(matchDeleteTokenRequest(e.id, ANY), function () {
    verifyTokenRequestUpdated(e.id);
  });
});

bthread("TokenRequest delete verification", function () {
  const e = waitForAnyTokenRequestDeleted();
  block(matchAddTokenRequest(e.id, ANY), function () {
    verifyTokenRequestDoesNotExist(e.id);
  });
});

bthread("InterfaceTemplate create verification", function () {
  const e = waitForAnyInterfaceTemplateAdded();
  block(matchDeleteInterfaceTemplate(e.id, ANY), function () {
    verifyInterfaceTemplateExists(e.id);
  });
});

bthread("InterfaceTemplate update verification", function () {
  const e = waitForAnyInterfaceTemplateUpdated();
  block(matchDeleteInterfaceTemplate(e.id, ANY), function () {
    verifyInterfaceTemplateUpdated(e.id);
  });
});

bthread("InterfaceTemplate delete verification", function () {
  const e = waitForAnyInterfaceTemplateDeleted();
  block(matchAddInterfaceTemplate(e.id, ANY), function () {
    verifyInterfaceTemplateDoesNotExist(e.id);
  });
});

bthread("PaginatedTunnelList create verification", function () {
  const e = waitForAnyPaginatedTunnelListAdded();
  block(matchDeletePaginatedTunnelList(e.id, ANY), function () {
    verifyPaginatedTunnelListExists(e.id);
  });
});

bthread("PaginatedTunnelList update verification", function () {
  const e = waitForAnyPaginatedTunnelListUpdated();
  block(matchDeletePaginatedTunnelList(e.id, ANY), function () {
    verifyPaginatedTunnelListUpdated(e.id);
  });
});

bthread("PaginatedTunnelList delete verification", function () {
  const e = waitForAnyPaginatedTunnelListDeleted();
  block(matchAddPaginatedTunnelList(e.id, ANY), function () {
    verifyPaginatedTunnelListDoesNotExist(e.id);
  });
});

bthread("BriefIKEPolicyRequest create verification", function () {
  const e = waitForAnyBriefIKEPolicyRequestAdded();
  block(matchDeleteBriefIKEPolicyRequest(e.id, ANY), function () {
    verifyBriefIKEPolicyRequestExists(e.id);
  });
});

bthread("BriefIKEPolicyRequest update verification", function () {
  const e = waitForAnyBriefIKEPolicyRequestUpdated();
  block(matchDeleteBriefIKEPolicyRequest(e.id, ANY), function () {
    verifyBriefIKEPolicyRequestUpdated(e.id);
  });
});

bthread("BriefIKEPolicyRequest delete verification", function () {
  const e = waitForAnyBriefIKEPolicyRequestDeleted();
  block(matchAddBriefIKEPolicyRequest(e.id, ANY), function () {
    verifyBriefIKEPolicyRequestDoesNotExist(e.id);
  });
});

bthread("BriefManufacturer create verification", function () {
  const e = waitForAnyBriefManufacturerAdded();
  block(matchDeleteBriefManufacturer(e.id, ANY), function () {
    verifyBriefManufacturerExists(e.id);
  });
});

bthread("BriefManufacturer update verification", function () {
  const e = waitForAnyBriefManufacturerUpdated();
  block(matchDeleteBriefManufacturer(e.id, ANY), function () {
    verifyBriefManufacturerUpdated(e.id);
  });
});

bthread("BriefManufacturer delete verification", function () {
  const e = waitForAnyBriefManufacturerDeleted();
  block(matchAddBriefManufacturer(e.id, ANY), function () {
    verifyBriefManufacturerDoesNotExist(e.id);
  });
});

bthread("Aggregate create verification", function () {
  const e = waitForAnyAggregateAdded();
  block(matchDeleteAggregate(e.id, ANY), function () {
    verifyAggregateExists(e.id);
  });
});

bthread("Aggregate update verification", function () {
  const e = waitForAnyAggregateUpdated();
  block(matchDeleteAggregate(e.id, ANY), function () {
    verifyAggregateUpdated(e.id);
  });
});

bthread("Aggregate delete verification", function () {
  const e = waitForAnyAggregateDeleted();
  block(matchAddAggregate(e.id, ANY), function () {
    verifyAggregateDoesNotExist(e.id);
  });
});

bthread("PatchedWritableRearPortRequest create verification", function () {
  const e = waitForAnyPatchedWritableRearPortRequestAdded();
  block(matchDeletePatchedWritableRearPortRequest(e.id, ANY), function () {
    verifyPatchedWritableRearPortRequestExists(e.id);
  });
});

bthread("PatchedWritableRearPortRequest update verification", function () {
  const e = waitForAnyPatchedWritableRearPortRequestUpdated();
  block(matchDeletePatchedWritableRearPortRequest(e.id, ANY), function () {
    verifyPatchedWritableRearPortRequestUpdated(e.id);
  });
});

bthread("PatchedWritableRearPortRequest delete verification", function () {
  const e = waitForAnyPatchedWritableRearPortRequestDeleted();
  block(matchAddPatchedWritableRearPortRequest(e.id, ANY), function () {
    verifyPatchedWritableRearPortRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedContactAssignmentList create verification", function () {
  const e = waitForAnyPaginatedContactAssignmentListAdded();
  block(matchDeletePaginatedContactAssignmentList(e.id, ANY), function () {
    verifyPaginatedContactAssignmentListExists(e.id);
  });
});

bthread("PaginatedContactAssignmentList update verification", function () {
  const e = waitForAnyPaginatedContactAssignmentListUpdated();
  block(matchDeletePaginatedContactAssignmentList(e.id, ANY), function () {
    verifyPaginatedContactAssignmentListUpdated(e.id);
  });
});

bthread("PaginatedContactAssignmentList delete verification", function () {
  const e = waitForAnyPaginatedContactAssignmentListDeleted();
  block(matchAddPaginatedContactAssignmentList(e.id, ANY), function () {
    verifyPaginatedContactAssignmentListDoesNotExist(e.id);
  });
});

bthread("Device create verification", function () {
  const e = waitForAnyDeviceAdded();
  block(matchDeleteDevice(e.id, ANY), function () {
    verifyDeviceExists(e.id);
  });
});

bthread("Device update verification", function () {
  const e = waitForAnyDeviceUpdated();
  block(matchDeleteDevice(e.id, ANY), function () {
    verifyDeviceUpdated(e.id);
  });
});

bthread("Device delete verification", function () {
  const e = waitForAnyDeviceDeleted();
  block(matchAddDevice(e.id, ANY), function () {
    verifyDeviceDoesNotExist(e.id);
  });
});

bthread("WritableCustomFieldRequest create verification", function () {
  const e = waitForAnyWritableCustomFieldRequestAdded();
  block(matchDeleteWritableCustomFieldRequest(e.id, ANY), function () {
    verifyWritableCustomFieldRequestExists(e.id);
  });
});

bthread("WritableCustomFieldRequest update verification", function () {
  const e = waitForAnyWritableCustomFieldRequestUpdated();
  block(matchDeleteWritableCustomFieldRequest(e.id, ANY), function () {
    verifyWritableCustomFieldRequestUpdated(e.id);
  });
});

bthread("WritableCustomFieldRequest delete verification", function () {
  const e = waitForAnyWritableCustomFieldRequestDeleted();
  block(matchAddWritableCustomFieldRequest(e.id, ANY), function () {
    verifyWritableCustomFieldRequestDoesNotExist(e.id);
  });
});

bthread("WritablePowerFeedRequest create verification", function () {
  const e = waitForAnyWritablePowerFeedRequestAdded();
  block(matchDeleteWritablePowerFeedRequest(e.id, ANY), function () {
    verifyWritablePowerFeedRequestExists(e.id);
  });
});

bthread("WritablePowerFeedRequest update verification", function () {
  const e = waitForAnyWritablePowerFeedRequestUpdated();
  block(matchDeleteWritablePowerFeedRequest(e.id, ANY), function () {
    verifyWritablePowerFeedRequestUpdated(e.id);
  });
});

bthread("WritablePowerFeedRequest delete verification", function () {
  const e = waitForAnyWritablePowerFeedRequestDeleted();
  block(matchAddWritablePowerFeedRequest(e.id, ANY), function () {
    verifyWritablePowerFeedRequestDoesNotExist(e.id);
  });
});

bthread("WirelessLinkRequest create verification", function () {
  const e = waitForAnyWirelessLinkRequestAdded();
  block(matchDeleteWirelessLinkRequest(e.id, ANY), function () {
    verifyWirelessLinkRequestExists(e.id);
  });
});

bthread("WirelessLinkRequest update verification", function () {
  const e = waitForAnyWirelessLinkRequestUpdated();
  block(matchDeleteWirelessLinkRequest(e.id, ANY), function () {
    verifyWirelessLinkRequestUpdated(e.id);
  });
});

bthread("WirelessLinkRequest delete verification", function () {
  const e = waitForAnyWirelessLinkRequestDeleted();
  block(matchAddWirelessLinkRequest(e.id, ANY), function () {
    verifyWirelessLinkRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedVRFList create verification", function () {
  const e = waitForAnyPaginatedVRFListAdded();
  block(matchDeletePaginatedVRFList(e.id, ANY), function () {
    verifyPaginatedVRFListExists(e.id);
  });
});

bthread("PaginatedVRFList update verification", function () {
  const e = waitForAnyPaginatedVRFListUpdated();
  block(matchDeletePaginatedVRFList(e.id, ANY), function () {
    verifyPaginatedVRFListUpdated(e.id);
  });
});

bthread("PaginatedVRFList delete verification", function () {
  const e = waitForAnyPaginatedVRFListDeleted();
  block(matchAddPaginatedVRFList(e.id, ANY), function () {
    verifyPaginatedVRFListDoesNotExist(e.id);
  });
});

bthread("WritableInventoryItemRequest create verification", function () {
  const e = waitForAnyWritableInventoryItemRequestAdded();
  block(matchDeleteWritableInventoryItemRequest(e.id, ANY), function () {
    verifyWritableInventoryItemRequestExists(e.id);
  });
});

bthread("WritableInventoryItemRequest update verification", function () {
  const e = waitForAnyWritableInventoryItemRequestUpdated();
  block(matchDeleteWritableInventoryItemRequest(e.id, ANY), function () {
    verifyWritableInventoryItemRequestUpdated(e.id);
  });
});

bthread("WritableInventoryItemRequest delete verification", function () {
  const e = waitForAnyWritableInventoryItemRequestDeleted();
  block(matchAddWritableInventoryItemRequest(e.id, ANY), function () {
    verifyWritableInventoryItemRequestDoesNotExist(e.id);
  });
});

bthread("CircuitCircuitTermination create verification", function () {
  const e = waitForAnyCircuitCircuitTerminationAdded();
  block(matchDeleteCircuitCircuitTermination(e.id, ANY), function () {
    verifyCircuitCircuitTerminationExists(e.id);
  });
});

bthread("CircuitCircuitTermination update verification", function () {
  const e = waitForAnyCircuitCircuitTerminationUpdated();
  block(matchDeleteCircuitCircuitTermination(e.id, ANY), function () {
    verifyCircuitCircuitTerminationUpdated(e.id);
  });
});

bthread("CircuitCircuitTermination delete verification", function () {
  const e = waitForAnyCircuitCircuitTerminationDeleted();
  block(matchAddCircuitCircuitTermination(e.id, ANY), function () {
    verifyCircuitCircuitTerminationDoesNotExist(e.id);
  });
});

bthread("BriefProviderAccountRequest create verification", function () {
  const e = waitForAnyBriefProviderAccountRequestAdded();
  block(matchDeleteBriefProviderAccountRequest(e.id, ANY), function () {
    verifyBriefProviderAccountRequestExists(e.id);
  });
});

bthread("BriefProviderAccountRequest update verification", function () {
  const e = waitForAnyBriefProviderAccountRequestUpdated();
  block(matchDeleteBriefProviderAccountRequest(e.id, ANY), function () {
    verifyBriefProviderAccountRequestUpdated(e.id);
  });
});

bthread("BriefProviderAccountRequest delete verification", function () {
  const e = waitForAnyBriefProviderAccountRequestDeleted();
  block(matchAddBriefProviderAccountRequest(e.id, ANY), function () {
    verifyBriefProviderAccountRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableContactAssignmentRequest create verification", function () {
  const e = waitForAnyPatchedWritableContactAssignmentRequestAdded();
  block(matchDeletePatchedWritableContactAssignmentRequest(e.id, ANY), function () {
    verifyPatchedWritableContactAssignmentRequestExists(e.id);
  });
});

bthread("PatchedWritableContactAssignmentRequest update verification", function () {
  const e = waitForAnyPatchedWritableContactAssignmentRequestUpdated();
  block(matchDeletePatchedWritableContactAssignmentRequest(e.id, ANY), function () {
    verifyPatchedWritableContactAssignmentRequestUpdated(e.id);
  });
});

bthread("PatchedWritableContactAssignmentRequest delete verification", function () {
  const e = waitForAnyPatchedWritableContactAssignmentRequestDeleted();
  block(matchAddPatchedWritableContactAssignmentRequest(e.id, ANY), function () {
    verifyPatchedWritableContactAssignmentRequestDoesNotExist(e.id);
  });
});

bthread("TableConfigRequest create verification", function () {
  const e = waitForAnyTableConfigRequestAdded();
  block(matchDeleteTableConfigRequest(e.id, ANY), function () {
    verifyTableConfigRequestExists(e.id);
  });
});

bthread("TableConfigRequest update verification", function () {
  const e = waitForAnyTableConfigRequestUpdated();
  block(matchDeleteTableConfigRequest(e.id, ANY), function () {
    verifyTableConfigRequestUpdated(e.id);
  });
});

bthread("TableConfigRequest delete verification", function () {
  const e = waitForAnyTableConfigRequestDeleted();
  block(matchAddTableConfigRequest(e.id, ANY), function () {
    verifyTableConfigRequestDoesNotExist(e.id);
  });
});

bthread("EventRule create verification", function () {
  const e = waitForAnyEventRuleAdded();
  block(matchDeleteEventRule(e.id, ANY), function () {
    verifyEventRuleExists(e.id);
  });
});

bthread("EventRule update verification", function () {
  const e = waitForAnyEventRuleUpdated();
  block(matchDeleteEventRule(e.id, ANY), function () {
    verifyEventRuleUpdated(e.id);
  });
});

bthread("EventRule delete verification", function () {
  const e = waitForAnyEventRuleDeleted();
  block(matchAddEventRule(e.id, ANY), function () {
    verifyEventRuleDoesNotExist(e.id);
  });
});

bthread("VirtualCircuit create verification", function () {
  const e = waitForAnyVirtualCircuitAdded();
  block(matchDeleteVirtualCircuit(e.id, ANY), function () {
    verifyVirtualCircuitExists(e.id);
  });
});

bthread("VirtualCircuit update verification", function () {
  const e = waitForAnyVirtualCircuitUpdated();
  block(matchDeleteVirtualCircuit(e.id, ANY), function () {
    verifyVirtualCircuitUpdated(e.id);
  });
});

bthread("VirtualCircuit delete verification", function () {
  const e = waitForAnyVirtualCircuitDeleted();
  block(matchAddVirtualCircuit(e.id, ANY), function () {
    verifyVirtualCircuitDoesNotExist(e.id);
  });
});

bthread("BriefProviderRequest create verification", function () {
  const e = waitForAnyBriefProviderRequestAdded();
  block(matchDeleteBriefProviderRequest(e.id, ANY), function () {
    verifyBriefProviderRequestExists(e.id);
  });
});

bthread("BriefProviderRequest update verification", function () {
  const e = waitForAnyBriefProviderRequestUpdated();
  block(matchDeleteBriefProviderRequest(e.id, ANY), function () {
    verifyBriefProviderRequestUpdated(e.id);
  });
});

bthread("BriefProviderRequest delete verification", function () {
  const e = waitForAnyBriefProviderRequestDeleted();
  block(matchAddBriefProviderRequest(e.id, ANY), function () {
    verifyBriefProviderRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedProviderNetworkList create verification", function () {
  const e = waitForAnyPaginatedProviderNetworkListAdded();
  block(matchDeletePaginatedProviderNetworkList(e.id, ANY), function () {
    verifyPaginatedProviderNetworkListExists(e.id);
  });
});

bthread("PaginatedProviderNetworkList update verification", function () {
  const e = waitForAnyPaginatedProviderNetworkListUpdated();
  block(matchDeletePaginatedProviderNetworkList(e.id, ANY), function () {
    verifyPaginatedProviderNetworkListUpdated(e.id);
  });
});

bthread("PaginatedProviderNetworkList delete verification", function () {
  const e = waitForAnyPaginatedProviderNetworkListDeleted();
  block(matchAddPaginatedProviderNetworkList(e.id, ANY), function () {
    verifyPaginatedProviderNetworkListDoesNotExist(e.id);
  });
});

bthread("PaginatedScriptList create verification", function () {
  const e = waitForAnyPaginatedScriptListAdded();
  block(matchDeletePaginatedScriptList(e.id, ANY), function () {
    verifyPaginatedScriptListExists(e.id);
  });
});

bthread("PaginatedScriptList update verification", function () {
  const e = waitForAnyPaginatedScriptListUpdated();
  block(matchDeletePaginatedScriptList(e.id, ANY), function () {
    verifyPaginatedScriptListUpdated(e.id);
  });
});

bthread("PaginatedScriptList delete verification", function () {
  const e = waitForAnyPaginatedScriptListDeleted();
  block(matchAddPaginatedScriptList(e.id, ANY), function () {
    verifyPaginatedScriptListDoesNotExist(e.id);
  });
});

bthread("PatchedWritablePowerPortRequest create verification", function () {
  const e = waitForAnyPatchedWritablePowerPortRequestAdded();
  block(matchDeletePatchedWritablePowerPortRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerPortRequestExists(e.id);
  });
});

bthread("PatchedWritablePowerPortRequest update verification", function () {
  const e = waitForAnyPatchedWritablePowerPortRequestUpdated();
  block(matchDeletePatchedWritablePowerPortRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerPortRequestUpdated(e.id);
  });
});

bthread("PatchedWritablePowerPortRequest delete verification", function () {
  const e = waitForAnyPatchedWritablePowerPortRequestDeleted();
  block(matchAddPatchedWritablePowerPortRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerPortRequestDoesNotExist(e.id);
  });
});

bthread("VirtualDeviceContext create verification", function () {
  const e = waitForAnyVirtualDeviceContextAdded();
  block(matchDeleteVirtualDeviceContext(e.id, ANY), function () {
    verifyVirtualDeviceContextExists(e.id);
  });
});

bthread("VirtualDeviceContext update verification", function () {
  const e = waitForAnyVirtualDeviceContextUpdated();
  block(matchDeleteVirtualDeviceContext(e.id, ANY), function () {
    verifyVirtualDeviceContextUpdated(e.id);
  });
});

bthread("VirtualDeviceContext delete verification", function () {
  const e = waitForAnyVirtualDeviceContextDeleted();
  block(matchAddVirtualDeviceContext(e.id, ANY), function () {
    verifyVirtualDeviceContextDoesNotExist(e.id);
  });
});

bthread("PowerPort create verification", function () {
  const e = waitForAnyPowerPortAdded();
  block(matchDeletePowerPort(e.id, ANY), function () {
    verifyPowerPortExists(e.id);
  });
});

bthread("PowerPort update verification", function () {
  const e = waitForAnyPowerPortUpdated();
  block(matchDeletePowerPort(e.id, ANY), function () {
    verifyPowerPortUpdated(e.id);
  });
});

bthread("PowerPort delete verification", function () {
  const e = waitForAnyPowerPortDeleted();
  block(matchAddPowerPort(e.id, ANY), function () {
    verifyPowerPortDoesNotExist(e.id);
  });
});

bthread("BriefSiteRequest create verification", function () {
  const e = waitForAnyBriefSiteRequestAdded();
  block(matchDeleteBriefSiteRequest(e.id, ANY), function () {
    verifyBriefSiteRequestExists(e.id);
  });
});

bthread("BriefSiteRequest update verification", function () {
  const e = waitForAnyBriefSiteRequestUpdated();
  block(matchDeleteBriefSiteRequest(e.id, ANY), function () {
    verifyBriefSiteRequestUpdated(e.id);
  });
});

bthread("BriefSiteRequest delete verification", function () {
  const e = waitForAnyBriefSiteRequestDeleted();
  block(matchAddBriefSiteRequest(e.id, ANY), function () {
    verifyBriefSiteRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedModuleList create verification", function () {
  const e = waitForAnyPaginatedModuleListAdded();
  block(matchDeletePaginatedModuleList(e.id, ANY), function () {
    verifyPaginatedModuleListExists(e.id);
  });
});

bthread("PaginatedModuleList update verification", function () {
  const e = waitForAnyPaginatedModuleListUpdated();
  block(matchDeletePaginatedModuleList(e.id, ANY), function () {
    verifyPaginatedModuleListUpdated(e.id);
  });
});

bthread("PaginatedModuleList delete verification", function () {
  const e = waitForAnyPaginatedModuleListDeleted();
  block(matchAddPaginatedModuleList(e.id, ANY), function () {
    verifyPaginatedModuleListDoesNotExist(e.id);
  });
});

bthread("PaginatedVLANTranslationRuleList create verification", function () {
  const e = waitForAnyPaginatedVLANTranslationRuleListAdded();
  block(matchDeletePaginatedVLANTranslationRuleList(e.id, ANY), function () {
    verifyPaginatedVLANTranslationRuleListExists(e.id);
  });
});

bthread("PaginatedVLANTranslationRuleList update verification", function () {
  const e = waitForAnyPaginatedVLANTranslationRuleListUpdated();
  block(matchDeletePaginatedVLANTranslationRuleList(e.id, ANY), function () {
    verifyPaginatedVLANTranslationRuleListUpdated(e.id);
  });
});

bthread("PaginatedVLANTranslationRuleList delete verification", function () {
  const e = waitForAnyPaginatedVLANTranslationRuleListDeleted();
  block(matchAddPaginatedVLANTranslationRuleList(e.id, ANY), function () {
    verifyPaginatedVLANTranslationRuleListDoesNotExist(e.id);
  });
});

bthread("ASNRequest create verification", function () {
  const e = waitForAnyASNRequestAdded();
  block(matchDeleteASNRequest(e.id, ANY), function () {
    verifyASNRequestExists(e.id);
  });
});

bthread("ASNRequest update verification", function () {
  const e = waitForAnyASNRequestUpdated();
  block(matchDeleteASNRequest(e.id, ANY), function () {
    verifyASNRequestUpdated(e.id);
  });
});

bthread("ASNRequest delete verification", function () {
  const e = waitForAnyASNRequestDeleted();
  block(matchAddASNRequest(e.id, ANY), function () {
    verifyASNRequestDoesNotExist(e.id);
  });
});

bthread("SavedFilter create verification", function () {
  const e = waitForAnySavedFilterAdded();
  block(matchDeleteSavedFilter(e.id, ANY), function () {
    verifySavedFilterExists(e.id);
  });
});

bthread("SavedFilter update verification", function () {
  const e = waitForAnySavedFilterUpdated();
  block(matchDeleteSavedFilter(e.id, ANY), function () {
    verifySavedFilterUpdated(e.id);
  });
});

bthread("SavedFilter delete verification", function () {
  const e = waitForAnySavedFilterDeleted();
  block(matchAddSavedFilter(e.id, ANY), function () {
    verifySavedFilterDoesNotExist(e.id);
  });
});

bthread("PaginatedRouteTargetList create verification", function () {
  const e = waitForAnyPaginatedRouteTargetListAdded();
  block(matchDeletePaginatedRouteTargetList(e.id, ANY), function () {
    verifyPaginatedRouteTargetListExists(e.id);
  });
});

bthread("PaginatedRouteTargetList update verification", function () {
  const e = waitForAnyPaginatedRouteTargetListUpdated();
  block(matchDeletePaginatedRouteTargetList(e.id, ANY), function () {
    verifyPaginatedRouteTargetListUpdated(e.id);
  });
});

bthread("PaginatedRouteTargetList delete verification", function () {
  const e = waitForAnyPaginatedRouteTargetListDeleted();
  block(matchAddPaginatedRouteTargetList(e.id, ANY), function () {
    verifyPaginatedRouteTargetListDoesNotExist(e.id);
  });
});

bthread("TenantRequest create verification", function () {
  const e = waitForAnyTenantRequestAdded();
  block(matchDeleteTenantRequest(e.id, ANY), function () {
    verifyTenantRequestExists(e.id);
  });
});

bthread("TenantRequest update verification", function () {
  const e = waitForAnyTenantRequestUpdated();
  block(matchDeleteTenantRequest(e.id, ANY), function () {
    verifyTenantRequestUpdated(e.id);
  });
});

bthread("TenantRequest delete verification", function () {
  const e = waitForAnyTenantRequestDeleted();
  block(matchAddTenantRequest(e.id, ANY), function () {
    verifyTenantRequestDoesNotExist(e.id);
  });
});

bthread("NestedModuleBay create verification", function () {
  const e = waitForAnyNestedModuleBayAdded();
  block(matchDeleteNestedModuleBay(e.id, ANY), function () {
    verifyNestedModuleBayExists(e.id);
  });
});

bthread("NestedModuleBay update verification", function () {
  const e = waitForAnyNestedModuleBayUpdated();
  block(matchDeleteNestedModuleBay(e.id, ANY), function () {
    verifyNestedModuleBayUpdated(e.id);
  });
});

bthread("NestedModuleBay delete verification", function () {
  const e = waitForAnyNestedModuleBayDeleted();
  block(matchAddNestedModuleBay(e.id, ANY), function () {
    verifyNestedModuleBayDoesNotExist(e.id);
  });
});

bthread("PatchedVLANTranslationRuleRequest create verification", function () {
  const e = waitForAnyPatchedVLANTranslationRuleRequestAdded();
  block(matchDeletePatchedVLANTranslationRuleRequest(e.id, ANY), function () {
    verifyPatchedVLANTranslationRuleRequestExists(e.id);
  });
});

bthread("PatchedVLANTranslationRuleRequest update verification", function () {
  const e = waitForAnyPatchedVLANTranslationRuleRequestUpdated();
  block(matchDeletePatchedVLANTranslationRuleRequest(e.id, ANY), function () {
    verifyPatchedVLANTranslationRuleRequestUpdated(e.id);
  });
});

bthread("PatchedVLANTranslationRuleRequest delete verification", function () {
  const e = waitForAnyPatchedVLANTranslationRuleRequestDeleted();
  block(matchAddPatchedVLANTranslationRuleRequest(e.id, ANY), function () {
    verifyPatchedVLANTranslationRuleRequestDoesNotExist(e.id);
  });
});

bthread("WritableVLANRequest create verification", function () {
  const e = waitForAnyWritableVLANRequestAdded();
  block(matchDeleteWritableVLANRequest(e.id, ANY), function () {
    verifyWritableVLANRequestExists(e.id);
  });
});

bthread("WritableVLANRequest update verification", function () {
  const e = waitForAnyWritableVLANRequestUpdated();
  block(matchDeleteWritableVLANRequest(e.id, ANY), function () {
    verifyWritableVLANRequestUpdated(e.id);
  });
});

bthread("WritableVLANRequest delete verification", function () {
  const e = waitForAnyWritableVLANRequestDeleted();
  block(matchAddWritableVLANRequest(e.id, ANY), function () {
    verifyWritableVLANRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableRackRequest create verification", function () {
  const e = waitForAnyPatchedWritableRackRequestAdded();
  block(matchDeletePatchedWritableRackRequest(e.id, ANY), function () {
    verifyPatchedWritableRackRequestExists(e.id);
  });
});

bthread("PatchedWritableRackRequest update verification", function () {
  const e = waitForAnyPatchedWritableRackRequestUpdated();
  block(matchDeletePatchedWritableRackRequest(e.id, ANY), function () {
    verifyPatchedWritableRackRequestUpdated(e.id);
  });
});

bthread("PatchedWritableRackRequest delete verification", function () {
  const e = waitForAnyPatchedWritableRackRequestDeleted();
  block(matchAddPatchedWritableRackRequest(e.id, ANY), function () {
    verifyPatchedWritableRackRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableJournalEntryRequest create verification", function () {
  const e = waitForAnyPatchedWritableJournalEntryRequestAdded();
  block(matchDeletePatchedWritableJournalEntryRequest(e.id, ANY), function () {
    verifyPatchedWritableJournalEntryRequestExists(e.id);
  });
});

bthread("PatchedWritableJournalEntryRequest update verification", function () {
  const e = waitForAnyPatchedWritableJournalEntryRequestUpdated();
  block(matchDeletePatchedWritableJournalEntryRequest(e.id, ANY), function () {
    verifyPatchedWritableJournalEntryRequestUpdated(e.id);
  });
});

bthread("PatchedWritableJournalEntryRequest delete verification", function () {
  const e = waitForAnyPatchedWritableJournalEntryRequestDeleted();
  block(matchAddPatchedWritableJournalEntryRequest(e.id, ANY), function () {
    verifyPatchedWritableJournalEntryRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedProviderAccountList create verification", function () {
  const e = waitForAnyPaginatedProviderAccountListAdded();
  block(matchDeletePaginatedProviderAccountList(e.id, ANY), function () {
    verifyPaginatedProviderAccountListExists(e.id);
  });
});

bthread("PaginatedProviderAccountList update verification", function () {
  const e = waitForAnyPaginatedProviderAccountListUpdated();
  block(matchDeletePaginatedProviderAccountList(e.id, ANY), function () {
    verifyPaginatedProviderAccountListUpdated(e.id);
  });
});

bthread("PaginatedProviderAccountList delete verification", function () {
  const e = waitForAnyPaginatedProviderAccountListDeleted();
  block(matchAddPaginatedProviderAccountList(e.id, ANY), function () {
    verifyPaginatedProviderAccountListDoesNotExist(e.id);
  });
});

bthread("Token create verification", function () {
  const e = waitForAnyTokenAdded();
  block(matchDeleteToken(e.id, ANY), function () {
    verifyTokenExists(e.id);
  });
});

bthread("Token update verification", function () {
  const e = waitForAnyTokenUpdated();
  block(matchDeleteToken(e.id, ANY), function () {
    verifyTokenUpdated(e.id);
  });
});

bthread("Token delete verification", function () {
  const e = waitForAnyTokenDeleted();
  block(matchAddToken(e.id, ANY), function () {
    verifyTokenDoesNotExist(e.id);
  });
});

bthread("PaginatedPowerFeedList create verification", function () {
  const e = waitForAnyPaginatedPowerFeedListAdded();
  block(matchDeletePaginatedPowerFeedList(e.id, ANY), function () {
    verifyPaginatedPowerFeedListExists(e.id);
  });
});

bthread("PaginatedPowerFeedList update verification", function () {
  const e = waitForAnyPaginatedPowerFeedListUpdated();
  block(matchDeletePaginatedPowerFeedList(e.id, ANY), function () {
    verifyPaginatedPowerFeedListUpdated(e.id);
  });
});

bthread("PaginatedPowerFeedList delete verification", function () {
  const e = waitForAnyPaginatedPowerFeedListDeleted();
  block(matchAddPaginatedPowerFeedList(e.id, ANY), function () {
    verifyPaginatedPowerFeedListDoesNotExist(e.id);
  });
});

bthread("PatchedClusterTypeRequest create verification", function () {
  const e = waitForAnyPatchedClusterTypeRequestAdded();
  block(matchDeletePatchedClusterTypeRequest(e.id, ANY), function () {
    verifyPatchedClusterTypeRequestExists(e.id);
  });
});

bthread("PatchedClusterTypeRequest update verification", function () {
  const e = waitForAnyPatchedClusterTypeRequestUpdated();
  block(matchDeletePatchedClusterTypeRequest(e.id, ANY), function () {
    verifyPatchedClusterTypeRequestUpdated(e.id);
  });
});

bthread("PatchedClusterTypeRequest delete verification", function () {
  const e = waitForAnyPatchedClusterTypeRequestDeleted();
  block(matchAddPatchedClusterTypeRequest(e.id, ANY), function () {
    verifyPatchedClusterTypeRequestDoesNotExist(e.id);
  });
});

bthread("PowerOutletRequest create verification", function () {
  const e = waitForAnyPowerOutletRequestAdded();
  block(matchDeletePowerOutletRequest(e.id, ANY), function () {
    verifyPowerOutletRequestExists(e.id);
  });
});

bthread("PowerOutletRequest update verification", function () {
  const e = waitForAnyPowerOutletRequestUpdated();
  block(matchDeletePowerOutletRequest(e.id, ANY), function () {
    verifyPowerOutletRequestUpdated(e.id);
  });
});

bthread("PowerOutletRequest delete verification", function () {
  const e = waitForAnyPowerOutletRequestDeleted();
  block(matchAddPowerOutletRequest(e.id, ANY), function () {
    verifyPowerOutletRequestDoesNotExist(e.id);
  });
});

bthread("BriefDeviceRequest create verification", function () {
  const e = waitForAnyBriefDeviceRequestAdded();
  block(matchDeleteBriefDeviceRequest(e.id, ANY), function () {
    verifyBriefDeviceRequestExists(e.id);
  });
});

bthread("BriefDeviceRequest update verification", function () {
  const e = waitForAnyBriefDeviceRequestUpdated();
  block(matchDeleteBriefDeviceRequest(e.id, ANY), function () {
    verifyBriefDeviceRequestUpdated(e.id);
  });
});

bthread("BriefDeviceRequest delete verification", function () {
  const e = waitForAnyBriefDeviceRequestDeleted();
  block(matchAddBriefDeviceRequest(e.id, ANY), function () {
    verifyBriefDeviceRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedTenantGroupList create verification", function () {
  const e = waitForAnyPaginatedTenantGroupListAdded();
  block(matchDeletePaginatedTenantGroupList(e.id, ANY), function () {
    verifyPaginatedTenantGroupListExists(e.id);
  });
});

bthread("PaginatedTenantGroupList update verification", function () {
  const e = waitForAnyPaginatedTenantGroupListUpdated();
  block(matchDeletePaginatedTenantGroupList(e.id, ANY), function () {
    verifyPaginatedTenantGroupListUpdated(e.id);
  });
});

bthread("PaginatedTenantGroupList delete verification", function () {
  const e = waitForAnyPaginatedTenantGroupListDeleted();
  block(matchAddPaginatedTenantGroupList(e.id, ANY), function () {
    verifyPaginatedTenantGroupListDoesNotExist(e.id);
  });
});

bthread("PatchedWritableLocationRequest create verification", function () {
  const e = waitForAnyPatchedWritableLocationRequestAdded();
  block(matchDeletePatchedWritableLocationRequest(e.id, ANY), function () {
    verifyPatchedWritableLocationRequestExists(e.id);
  });
});

bthread("PatchedWritableLocationRequest update verification", function () {
  const e = waitForAnyPatchedWritableLocationRequestUpdated();
  block(matchDeletePatchedWritableLocationRequest(e.id, ANY), function () {
    verifyPatchedWritableLocationRequestUpdated(e.id);
  });
});

bthread("PatchedWritableLocationRequest delete verification", function () {
  const e = waitForAnyPatchedWritableLocationRequestDeleted();
  block(matchAddPatchedWritableLocationRequest(e.id, ANY), function () {
    verifyPatchedWritableLocationRequestDoesNotExist(e.id);
  });
});

bthread("BriefProviderNetworkRequest create verification", function () {
  const e = waitForAnyBriefProviderNetworkRequestAdded();
  block(matchDeleteBriefProviderNetworkRequest(e.id, ANY), function () {
    verifyBriefProviderNetworkRequestExists(e.id);
  });
});

bthread("BriefProviderNetworkRequest update verification", function () {
  const e = waitForAnyBriefProviderNetworkRequestUpdated();
  block(matchDeleteBriefProviderNetworkRequest(e.id, ANY), function () {
    verifyBriefProviderNetworkRequestUpdated(e.id);
  });
});

bthread("BriefProviderNetworkRequest delete verification", function () {
  const e = waitForAnyBriefProviderNetworkRequestDeleted();
  block(matchAddBriefProviderNetworkRequest(e.id, ANY), function () {
    verifyBriefProviderNetworkRequestDoesNotExist(e.id);
  });
});

bthread("SiteGroup create verification", function () {
  const e = waitForAnySiteGroupAdded();
  block(matchDeleteSiteGroup(e.id, ANY), function () {
    verifySiteGroupExists(e.id);
  });
});

bthread("SiteGroup update verification", function () {
  const e = waitForAnySiteGroupUpdated();
  block(matchDeleteSiteGroup(e.id, ANY), function () {
    verifySiteGroupUpdated(e.id);
  });
});

bthread("SiteGroup delete verification", function () {
  const e = waitForAnySiteGroupDeleted();
  block(matchAddSiteGroup(e.id, ANY), function () {
    verifySiteGroupDoesNotExist(e.id);
  });
});

bthread("BriefCircuitGroupAssignmentSerializer_Request create verification", function () {
  const e = waitForAnyBriefCircuitGroupAssignmentSerializer_RequestAdded();
  block(matchDeleteBriefCircuitGroupAssignmentSerializer_Request(e.id, ANY), function () {
    verifyBriefCircuitGroupAssignmentSerializer_RequestExists(e.id);
  });
});

bthread("BriefCircuitGroupAssignmentSerializer_Request update verification", function () {
  const e = waitForAnyBriefCircuitGroupAssignmentSerializer_RequestUpdated();
  block(matchDeleteBriefCircuitGroupAssignmentSerializer_Request(e.id, ANY), function () {
    verifyBriefCircuitGroupAssignmentSerializer_RequestUpdated(e.id);
  });
});

bthread("BriefCircuitGroupAssignmentSerializer_Request delete verification", function () {
  const e = waitForAnyBriefCircuitGroupAssignmentSerializer_RequestDeleted();
  block(matchAddBriefCircuitGroupAssignmentSerializer_Request(e.id, ANY), function () {
    verifyBriefCircuitGroupAssignmentSerializer_RequestDoesNotExist(e.id);
  });
});

bthread("PatchedImageAttachmentRequest create verification", function () {
  const e = waitForAnyPatchedImageAttachmentRequestAdded();
  block(matchDeletePatchedImageAttachmentRequest(e.id, ANY), function () {
    verifyPatchedImageAttachmentRequestExists(e.id);
  });
});

bthread("PatchedImageAttachmentRequest update verification", function () {
  const e = waitForAnyPatchedImageAttachmentRequestUpdated();
  block(matchDeletePatchedImageAttachmentRequest(e.id, ANY), function () {
    verifyPatchedImageAttachmentRequestUpdated(e.id);
  });
});

bthread("PatchedImageAttachmentRequest delete verification", function () {
  const e = waitForAnyPatchedImageAttachmentRequestDeleted();
  block(matchAddPatchedImageAttachmentRequest(e.id, ANY), function () {
    verifyPatchedImageAttachmentRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedPrefixList create verification", function () {
  const e = waitForAnyPaginatedPrefixListAdded();
  block(matchDeletePaginatedPrefixList(e.id, ANY), function () {
    verifyPaginatedPrefixListExists(e.id);
  });
});

bthread("PaginatedPrefixList update verification", function () {
  const e = waitForAnyPaginatedPrefixListUpdated();
  block(matchDeletePaginatedPrefixList(e.id, ANY), function () {
    verifyPaginatedPrefixListUpdated(e.id);
  });
});

bthread("PaginatedPrefixList delete verification", function () {
  const e = waitForAnyPaginatedPrefixListDeleted();
  block(matchAddPaginatedPrefixList(e.id, ANY), function () {
    verifyPaginatedPrefixListDoesNotExist(e.id);
  });
});

bthread("JournalEntry create verification", function () {
  const e = waitForAnyJournalEntryAdded();
  block(matchDeleteJournalEntry(e.id, ANY), function () {
    verifyJournalEntryExists(e.id);
  });
});

bthread("JournalEntry update verification", function () {
  const e = waitForAnyJournalEntryUpdated();
  block(matchDeleteJournalEntry(e.id, ANY), function () {
    verifyJournalEntryUpdated(e.id);
  });
});

bthread("JournalEntry delete verification", function () {
  const e = waitForAnyJournalEntryDeleted();
  block(matchAddJournalEntry(e.id, ANY), function () {
    verifyJournalEntryDoesNotExist(e.id);
  });
});

bthread("PatchedWritableVirtualCircuitRequest create verification", function () {
  const e = waitForAnyPatchedWritableVirtualCircuitRequestAdded();
  block(matchDeletePatchedWritableVirtualCircuitRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualCircuitRequestExists(e.id);
  });
});

bthread("PatchedWritableVirtualCircuitRequest update verification", function () {
  const e = waitForAnyPatchedWritableVirtualCircuitRequestUpdated();
  block(matchDeletePatchedWritableVirtualCircuitRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualCircuitRequestUpdated(e.id);
  });
});

bthread("PatchedWritableVirtualCircuitRequest delete verification", function () {
  const e = waitForAnyPatchedWritableVirtualCircuitRequestDeleted();
  block(matchAddPatchedWritableVirtualCircuitRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualCircuitRequestDoesNotExist(e.id);
  });
});

bthread("BriefTenantGroup create verification", function () {
  const e = waitForAnyBriefTenantGroupAdded();
  block(matchDeleteBriefTenantGroup(e.id, ANY), function () {
    verifyBriefTenantGroupExists(e.id);
  });
});

bthread("BriefTenantGroup update verification", function () {
  const e = waitForAnyBriefTenantGroupUpdated();
  block(matchDeleteBriefTenantGroup(e.id, ANY), function () {
    verifyBriefTenantGroupUpdated(e.id);
  });
});

bthread("BriefTenantGroup delete verification", function () {
  const e = waitForAnyBriefTenantGroupDeleted();
  block(matchAddBriefTenantGroup(e.id, ANY), function () {
    verifyBriefTenantGroupDoesNotExist(e.id);
  });
});

bthread("PatchedTableConfigRequest create verification", function () {
  const e = waitForAnyPatchedTableConfigRequestAdded();
  block(matchDeletePatchedTableConfigRequest(e.id, ANY), function () {
    verifyPatchedTableConfigRequestExists(e.id);
  });
});

bthread("PatchedTableConfigRequest update verification", function () {
  const e = waitForAnyPatchedTableConfigRequestUpdated();
  block(matchDeletePatchedTableConfigRequest(e.id, ANY), function () {
    verifyPatchedTableConfigRequestUpdated(e.id);
  });
});

bthread("PatchedTableConfigRequest delete verification", function () {
  const e = waitForAnyPatchedTableConfigRequestDeleted();
  block(matchAddPatchedTableConfigRequest(e.id, ANY), function () {
    verifyPatchedTableConfigRequestDoesNotExist(e.id);
  });
});

bthread("NestedContactGroupRequest create verification", function () {
  const e = waitForAnyNestedContactGroupRequestAdded();
  block(matchDeleteNestedContactGroupRequest(e.id, ANY), function () {
    verifyNestedContactGroupRequestExists(e.id);
  });
});

bthread("NestedContactGroupRequest update verification", function () {
  const e = waitForAnyNestedContactGroupRequestUpdated();
  block(matchDeleteNestedContactGroupRequest(e.id, ANY), function () {
    verifyNestedContactGroupRequestUpdated(e.id);
  });
});

bthread("NestedContactGroupRequest delete verification", function () {
  const e = waitForAnyNestedContactGroupRequestDeleted();
  block(matchAddNestedContactGroupRequest(e.id, ANY), function () {
    verifyNestedContactGroupRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableDataSourceRequest create verification", function () {
  const e = waitForAnyPatchedWritableDataSourceRequestAdded();
  block(matchDeletePatchedWritableDataSourceRequest(e.id, ANY), function () {
    verifyPatchedWritableDataSourceRequestExists(e.id);
  });
});

bthread("PatchedWritableDataSourceRequest update verification", function () {
  const e = waitForAnyPatchedWritableDataSourceRequestUpdated();
  block(matchDeletePatchedWritableDataSourceRequest(e.id, ANY), function () {
    verifyPatchedWritableDataSourceRequestUpdated(e.id);
  });
});

bthread("PatchedWritableDataSourceRequest delete verification", function () {
  const e = waitForAnyPatchedWritableDataSourceRequestDeleted();
  block(matchAddPatchedWritableDataSourceRequest(e.id, ANY), function () {
    verifyPatchedWritableDataSourceRequestDoesNotExist(e.id);
  });
});

bthread("BriefCircuitGroupRequest create verification", function () {
  const e = waitForAnyBriefCircuitGroupRequestAdded();
  block(matchDeleteBriefCircuitGroupRequest(e.id, ANY), function () {
    verifyBriefCircuitGroupRequestExists(e.id);
  });
});

bthread("BriefCircuitGroupRequest update verification", function () {
  const e = waitForAnyBriefCircuitGroupRequestUpdated();
  block(matchDeleteBriefCircuitGroupRequest(e.id, ANY), function () {
    verifyBriefCircuitGroupRequestUpdated(e.id);
  });
});

bthread("BriefCircuitGroupRequest delete verification", function () {
  const e = waitForAnyBriefCircuitGroupRequestDeleted();
  block(matchAddBriefCircuitGroupRequest(e.id, ANY), function () {
    verifyBriefCircuitGroupRequestDoesNotExist(e.id);
  });
});

bthread("WritableDeviceTypeRequest create verification", function () {
  const e = waitForAnyWritableDeviceTypeRequestAdded();
  block(matchDeleteWritableDeviceTypeRequest(e.id, ANY), function () {
    verifyWritableDeviceTypeRequestExists(e.id);
  });
});

bthread("WritableDeviceTypeRequest update verification", function () {
  const e = waitForAnyWritableDeviceTypeRequestUpdated();
  block(matchDeleteWritableDeviceTypeRequest(e.id, ANY), function () {
    verifyWritableDeviceTypeRequestUpdated(e.id);
  });
});

bthread("WritableDeviceTypeRequest delete verification", function () {
  const e = waitForAnyWritableDeviceTypeRequestDeleted();
  block(matchAddWritableDeviceTypeRequest(e.id, ANY), function () {
    verifyWritableDeviceTypeRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedConfigContextProfileList create verification", function () {
  const e = waitForAnyPaginatedConfigContextProfileListAdded();
  block(matchDeletePaginatedConfigContextProfileList(e.id, ANY), function () {
    verifyPaginatedConfigContextProfileListExists(e.id);
  });
});

bthread("PaginatedConfigContextProfileList update verification", function () {
  const e = waitForAnyPaginatedConfigContextProfileListUpdated();
  block(matchDeletePaginatedConfigContextProfileList(e.id, ANY), function () {
    verifyPaginatedConfigContextProfileListUpdated(e.id);
  });
});

bthread("PaginatedConfigContextProfileList delete verification", function () {
  const e = waitForAnyPaginatedConfigContextProfileListDeleted();
  block(matchAddPaginatedConfigContextProfileList(e.id, ANY), function () {
    verifyPaginatedConfigContextProfileListDoesNotExist(e.id);
  });
});

bthread("PaginatedIPRangeList create verification", function () {
  const e = waitForAnyPaginatedIPRangeListAdded();
  block(matchDeletePaginatedIPRangeList(e.id, ANY), function () {
    verifyPaginatedIPRangeListExists(e.id);
  });
});

bthread("PaginatedIPRangeList update verification", function () {
  const e = waitForAnyPaginatedIPRangeListUpdated();
  block(matchDeletePaginatedIPRangeList(e.id, ANY), function () {
    verifyPaginatedIPRangeListUpdated(e.id);
  });
});

bthread("PaginatedIPRangeList delete verification", function () {
  const e = waitForAnyPaginatedIPRangeListDeleted();
  block(matchAddPaginatedIPRangeList(e.id, ANY), function () {
    verifyPaginatedIPRangeListDoesNotExist(e.id);
  });
});

bthread("SavedFilterRequest create verification", function () {
  const e = waitForAnySavedFilterRequestAdded();
  block(matchDeleteSavedFilterRequest(e.id, ANY), function () {
    verifySavedFilterRequestExists(e.id);
  });
});

bthread("SavedFilterRequest update verification", function () {
  const e = waitForAnySavedFilterRequestUpdated();
  block(matchDeleteSavedFilterRequest(e.id, ANY), function () {
    verifySavedFilterRequestUpdated(e.id);
  });
});

bthread("SavedFilterRequest delete verification", function () {
  const e = waitForAnySavedFilterRequestDeleted();
  block(matchAddSavedFilterRequest(e.id, ANY), function () {
    verifySavedFilterRequestDoesNotExist(e.id);
  });
});

bthread("Site create verification", function () {
  const e = waitForAnySiteAdded();
  block(matchDeleteSite(e.id, ANY), function () {
    verifySiteExists(e.id);
  });
});

bthread("Site update verification", function () {
  const e = waitForAnySiteUpdated();
  block(matchDeleteSite(e.id, ANY), function () {
    verifySiteUpdated(e.id);
  });
});

bthread("Site delete verification", function () {
  const e = waitForAnySiteDeleted();
  block(matchAddSite(e.id, ANY), function () {
    verifySiteDoesNotExist(e.id);
  });
});

bthread("BriefL2VPN create verification", function () {
  const e = waitForAnyBriefL2VPNAdded();
  block(matchDeleteBriefL2VPN(e.id, ANY), function () {
    verifyBriefL2VPNExists(e.id);
  });
});

bthread("BriefL2VPN update verification", function () {
  const e = waitForAnyBriefL2VPNUpdated();
  block(matchDeleteBriefL2VPN(e.id, ANY), function () {
    verifyBriefL2VPNUpdated(e.id);
  });
});

bthread("BriefL2VPN delete verification", function () {
  const e = waitForAnyBriefL2VPNDeleted();
  block(matchAddBriefL2VPN(e.id, ANY), function () {
    verifyBriefL2VPNDoesNotExist(e.id);
  });
});

bthread("BriefRegion create verification", function () {
  const e = waitForAnyBriefRegionAdded();
  block(matchDeleteBriefRegion(e.id, ANY), function () {
    verifyBriefRegionExists(e.id);
  });
});

bthread("BriefRegion update verification", function () {
  const e = waitForAnyBriefRegionUpdated();
  block(matchDeleteBriefRegion(e.id, ANY), function () {
    verifyBriefRegionUpdated(e.id);
  });
});

bthread("BriefRegion delete verification", function () {
  const e = waitForAnyBriefRegionDeleted();
  block(matchAddBriefRegion(e.id, ANY), function () {
    verifyBriefRegionDoesNotExist(e.id);
  });
});

bthread("GenericObject create verification", function () {
  const e = waitForAnyGenericObjectAdded();
  block(matchDeleteGenericObject(e.id, ANY), function () {
    verifyGenericObjectExists(e.id);
  });
});

bthread("GenericObject update verification", function () {
  const e = waitForAnyGenericObjectUpdated();
  block(matchDeleteGenericObject(e.id, ANY), function () {
    verifyGenericObjectUpdated(e.id);
  });
});

bthread("GenericObject delete verification", function () {
  const e = waitForAnyGenericObjectDeleted();
  block(matchAddGenericObject(e.id, ANY), function () {
    verifyGenericObjectDoesNotExist(e.id);
  });
});

bthread("WritableConsoleServerPortRequest create verification", function () {
  const e = waitForAnyWritableConsoleServerPortRequestAdded();
  block(matchDeleteWritableConsoleServerPortRequest(e.id, ANY), function () {
    verifyWritableConsoleServerPortRequestExists(e.id);
  });
});

bthread("WritableConsoleServerPortRequest update verification", function () {
  const e = waitForAnyWritableConsoleServerPortRequestUpdated();
  block(matchDeleteWritableConsoleServerPortRequest(e.id, ANY), function () {
    verifyWritableConsoleServerPortRequestUpdated(e.id);
  });
});

bthread("WritableConsoleServerPortRequest delete verification", function () {
  const e = waitForAnyWritableConsoleServerPortRequestDeleted();
  block(matchAddWritableConsoleServerPortRequest(e.id, ANY), function () {
    verifyWritableConsoleServerPortRequestDoesNotExist(e.id);
  });
});

bthread("BriefL2VPNRequest create verification", function () {
  const e = waitForAnyBriefL2VPNRequestAdded();
  block(matchDeleteBriefL2VPNRequest(e.id, ANY), function () {
    verifyBriefL2VPNRequestExists(e.id);
  });
});

bthread("BriefL2VPNRequest update verification", function () {
  const e = waitForAnyBriefL2VPNRequestUpdated();
  block(matchDeleteBriefL2VPNRequest(e.id, ANY), function () {
    verifyBriefL2VPNRequestUpdated(e.id);
  });
});

bthread("BriefL2VPNRequest delete verification", function () {
  const e = waitForAnyBriefL2VPNRequestDeleted();
  block(matchAddBriefL2VPNRequest(e.id, ANY), function () {
    verifyBriefL2VPNRequestDoesNotExist(e.id);
  });
});

bthread("VLANGroup create verification", function () {
  const e = waitForAnyVLANGroupAdded();
  block(matchDeleteVLANGroup(e.id, ANY), function () {
    verifyVLANGroupExists(e.id);
  });
});

bthread("VLANGroup update verification", function () {
  const e = waitForAnyVLANGroupUpdated();
  block(matchDeleteVLANGroup(e.id, ANY), function () {
    verifyVLANGroupUpdated(e.id);
  });
});

bthread("VLANGroup delete verification", function () {
  const e = waitForAnyVLANGroupDeleted();
  block(matchAddVLANGroup(e.id, ANY), function () {
    verifyVLANGroupDoesNotExist(e.id);
  });
});

bthread("VLANTranslationRuleRequest create verification", function () {
  const e = waitForAnyVLANTranslationRuleRequestAdded();
  block(matchDeleteVLANTranslationRuleRequest(e.id, ANY), function () {
    verifyVLANTranslationRuleRequestExists(e.id);
  });
});

bthread("VLANTranslationRuleRequest update verification", function () {
  const e = waitForAnyVLANTranslationRuleRequestUpdated();
  block(matchDeleteVLANTranslationRuleRequest(e.id, ANY), function () {
    verifyVLANTranslationRuleRequestUpdated(e.id);
  });
});

bthread("VLANTranslationRuleRequest delete verification", function () {
  const e = waitForAnyVLANTranslationRuleRequestDeleted();
  block(matchAddVLANTranslationRuleRequest(e.id, ANY), function () {
    verifyVLANTranslationRuleRequestDoesNotExist(e.id);
  });
});

bthread("DataSourceRequest create verification", function () {
  const e = waitForAnyDataSourceRequestAdded();
  block(matchDeleteDataSourceRequest(e.id, ANY), function () {
    verifyDataSourceRequestExists(e.id);
  });
});

bthread("DataSourceRequest update verification", function () {
  const e = waitForAnyDataSourceRequestUpdated();
  block(matchDeleteDataSourceRequest(e.id, ANY), function () {
    verifyDataSourceRequestUpdated(e.id);
  });
});

bthread("DataSourceRequest delete verification", function () {
  const e = waitForAnyDataSourceRequestDeleted();
  block(matchAddDataSourceRequest(e.id, ANY), function () {
    verifyDataSourceRequestDoesNotExist(e.id);
  });
});

bthread("ClusterGroupRequest create verification", function () {
  const e = waitForAnyClusterGroupRequestAdded();
  block(matchDeleteClusterGroupRequest(e.id, ANY), function () {
    verifyClusterGroupRequestExists(e.id);
  });
});

bthread("ClusterGroupRequest update verification", function () {
  const e = waitForAnyClusterGroupRequestUpdated();
  block(matchDeleteClusterGroupRequest(e.id, ANY), function () {
    verifyClusterGroupRequestUpdated(e.id);
  });
});

bthread("ClusterGroupRequest delete verification", function () {
  const e = waitForAnyClusterGroupRequestDeleted();
  block(matchAddClusterGroupRequest(e.id, ANY), function () {
    verifyClusterGroupRequestDoesNotExist(e.id);
  });
});

bthread("L2VPNTermination create verification", function () {
  const e = waitForAnyL2VPNTerminationAdded();
  block(matchDeleteL2VPNTermination(e.id, ANY), function () {
    verifyL2VPNTerminationExists(e.id);
  });
});

bthread("L2VPNTermination update verification", function () {
  const e = waitForAnyL2VPNTerminationUpdated();
  block(matchDeleteL2VPNTermination(e.id, ANY), function () {
    verifyL2VPNTerminationUpdated(e.id);
  });
});

bthread("L2VPNTermination delete verification", function () {
  const e = waitForAnyL2VPNTerminationDeleted();
  block(matchAddL2VPNTermination(e.id, ANY), function () {
    verifyL2VPNTerminationDoesNotExist(e.id);
  });
});

bthread("ServiceTemplate create verification", function () {
  const e = waitForAnyServiceTemplateAdded();
  block(matchDeleteServiceTemplate(e.id, ANY), function () {
    verifyServiceTemplateExists(e.id);
  });
});

bthread("ServiceTemplate update verification", function () {
  const e = waitForAnyServiceTemplateUpdated();
  block(matchDeleteServiceTemplate(e.id, ANY), function () {
    verifyServiceTemplateUpdated(e.id);
  });
});

bthread("ServiceTemplate delete verification", function () {
  const e = waitForAnyServiceTemplateDeleted();
  block(matchAddServiceTemplate(e.id, ANY), function () {
    verifyServiceTemplateDoesNotExist(e.id);
  });
});

bthread("NestedGroup create verification", function () {
  const e = waitForAnyNestedGroupAdded();
  block(matchDeleteNestedGroup(e.id, ANY), function () {
    verifyNestedGroupExists(e.id);
  });
});

bthread("NestedGroup update verification", function () {
  const e = waitForAnyNestedGroupUpdated();
  block(matchDeleteNestedGroup(e.id, ANY), function () {
    verifyNestedGroupUpdated(e.id);
  });
});

bthread("NestedGroup delete verification", function () {
  const e = waitForAnyNestedGroupDeleted();
  block(matchAddNestedGroup(e.id, ANY), function () {
    verifyNestedGroupDoesNotExist(e.id);
  });
});

bthread("DeviceBayTemplate create verification", function () {
  const e = waitForAnyDeviceBayTemplateAdded();
  block(matchDeleteDeviceBayTemplate(e.id, ANY), function () {
    verifyDeviceBayTemplateExists(e.id);
  });
});

bthread("DeviceBayTemplate update verification", function () {
  const e = waitForAnyDeviceBayTemplateUpdated();
  block(matchDeleteDeviceBayTemplate(e.id, ANY), function () {
    verifyDeviceBayTemplateUpdated(e.id);
  });
});

bthread("DeviceBayTemplate delete verification", function () {
  const e = waitForAnyDeviceBayTemplateDeleted();
  block(matchAddDeviceBayTemplate(e.id, ANY), function () {
    verifyDeviceBayTemplateDoesNotExist(e.id);
  });
});

bthread("ASN create verification", function () {
  const e = waitForAnyASNAdded();
  block(matchDeleteASN(e.id, ANY), function () {
    verifyASNExists(e.id);
  });
});

bthread("ASN update verification", function () {
  const e = waitForAnyASNUpdated();
  block(matchDeleteASN(e.id, ANY), function () {
    verifyASNUpdated(e.id);
  });
});

bthread("ASN delete verification", function () {
  const e = waitForAnyASNDeleted();
  block(matchAddASN(e.id, ANY), function () {
    verifyASNDoesNotExist(e.id);
  });
});

bthread("BriefConfigContextProfileRequest create verification", function () {
  const e = waitForAnyBriefConfigContextProfileRequestAdded();
  block(matchDeleteBriefConfigContextProfileRequest(e.id, ANY), function () {
    verifyBriefConfigContextProfileRequestExists(e.id);
  });
});

bthread("BriefConfigContextProfileRequest update verification", function () {
  const e = waitForAnyBriefConfigContextProfileRequestUpdated();
  block(matchDeleteBriefConfigContextProfileRequest(e.id, ANY), function () {
    verifyBriefConfigContextProfileRequestUpdated(e.id);
  });
});

bthread("BriefConfigContextProfileRequest delete verification", function () {
  const e = waitForAnyBriefConfigContextProfileRequestDeleted();
  block(matchAddBriefConfigContextProfileRequest(e.id, ANY), function () {
    verifyBriefConfigContextProfileRequestDoesNotExist(e.id);
  });
});

bthread("PatchedSubscriptionRequest create verification", function () {
  const e = waitForAnyPatchedSubscriptionRequestAdded();
  block(matchDeletePatchedSubscriptionRequest(e.id, ANY), function () {
    verifyPatchedSubscriptionRequestExists(e.id);
  });
});

bthread("PatchedSubscriptionRequest update verification", function () {
  const e = waitForAnyPatchedSubscriptionRequestUpdated();
  block(matchDeletePatchedSubscriptionRequest(e.id, ANY), function () {
    verifyPatchedSubscriptionRequestUpdated(e.id);
  });
});

bthread("PatchedSubscriptionRequest delete verification", function () {
  const e = waitForAnyPatchedSubscriptionRequestDeleted();
  block(matchAddPatchedSubscriptionRequest(e.id, ANY), function () {
    verifyPatchedSubscriptionRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableVMInterfaceRequest create verification", function () {
  const e = waitForAnyPatchedWritableVMInterfaceRequestAdded();
  block(matchDeletePatchedWritableVMInterfaceRequest(e.id, ANY), function () {
    verifyPatchedWritableVMInterfaceRequestExists(e.id);
  });
});

bthread("PatchedWritableVMInterfaceRequest update verification", function () {
  const e = waitForAnyPatchedWritableVMInterfaceRequestUpdated();
  block(matchDeletePatchedWritableVMInterfaceRequest(e.id, ANY), function () {
    verifyPatchedWritableVMInterfaceRequestUpdated(e.id);
  });
});

bthread("PatchedWritableVMInterfaceRequest delete verification", function () {
  const e = waitForAnyPatchedWritableVMInterfaceRequestDeleted();
  block(matchAddPatchedWritableVMInterfaceRequest(e.id, ANY), function () {
    verifyPatchedWritableVMInterfaceRequestDoesNotExist(e.id);
  });
});

bthread("ConfigTemplateRequest create verification", function () {
  const e = waitForAnyConfigTemplateRequestAdded();
  block(matchDeleteConfigTemplateRequest(e.id, ANY), function () {
    verifyConfigTemplateRequestExists(e.id);
  });
});

bthread("ConfigTemplateRequest update verification", function () {
  const e = waitForAnyConfigTemplateRequestUpdated();
  block(matchDeleteConfigTemplateRequest(e.id, ANY), function () {
    verifyConfigTemplateRequestUpdated(e.id);
  });
});

bthread("ConfigTemplateRequest delete verification", function () {
  const e = waitForAnyConfigTemplateRequestDeleted();
  block(matchAddConfigTemplateRequest(e.id, ANY), function () {
    verifyConfigTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedSiteList create verification", function () {
  const e = waitForAnyPaginatedSiteListAdded();
  block(matchDeletePaginatedSiteList(e.id, ANY), function () {
    verifyPaginatedSiteListExists(e.id);
  });
});

bthread("PaginatedSiteList update verification", function () {
  const e = waitForAnyPaginatedSiteListUpdated();
  block(matchDeletePaginatedSiteList(e.id, ANY), function () {
    verifyPaginatedSiteListUpdated(e.id);
  });
});

bthread("PaginatedSiteList delete verification", function () {
  const e = waitForAnyPaginatedSiteListDeleted();
  block(matchAddPaginatedSiteList(e.id, ANY), function () {
    verifyPaginatedSiteListDoesNotExist(e.id);
  });
});

bthread("PaginatedL2VPNTerminationList create verification", function () {
  const e = waitForAnyPaginatedL2VPNTerminationListAdded();
  block(matchDeletePaginatedL2VPNTerminationList(e.id, ANY), function () {
    verifyPaginatedL2VPNTerminationListExists(e.id);
  });
});

bthread("PaginatedL2VPNTerminationList update verification", function () {
  const e = waitForAnyPaginatedL2VPNTerminationListUpdated();
  block(matchDeletePaginatedL2VPNTerminationList(e.id, ANY), function () {
    verifyPaginatedL2VPNTerminationListUpdated(e.id);
  });
});

bthread("PaginatedL2VPNTerminationList delete verification", function () {
  const e = waitForAnyPaginatedL2VPNTerminationListDeleted();
  block(matchAddPaginatedL2VPNTerminationList(e.id, ANY), function () {
    verifyPaginatedL2VPNTerminationListDoesNotExist(e.id);
  });
});

bthread("RackRequest create verification", function () {
  const e = waitForAnyRackRequestAdded();
  block(matchDeleteRackRequest(e.id, ANY), function () {
    verifyRackRequestExists(e.id);
  });
});

bthread("RackRequest update verification", function () {
  const e = waitForAnyRackRequestUpdated();
  block(matchDeleteRackRequest(e.id, ANY), function () {
    verifyRackRequestUpdated(e.id);
  });
});

bthread("RackRequest delete verification", function () {
  const e = waitForAnyRackRequestDeleted();
  block(matchAddRackRequest(e.id, ANY), function () {
    verifyRackRequestDoesNotExist(e.id);
  });
});

bthread("WritablePrefixRequest create verification", function () {
  const e = waitForAnyWritablePrefixRequestAdded();
  block(matchDeleteWritablePrefixRequest(e.id, ANY), function () {
    verifyWritablePrefixRequestExists(e.id);
  });
});

bthread("WritablePrefixRequest update verification", function () {
  const e = waitForAnyWritablePrefixRequestUpdated();
  block(matchDeleteWritablePrefixRequest(e.id, ANY), function () {
    verifyWritablePrefixRequestUpdated(e.id);
  });
});

bthread("WritablePrefixRequest delete verification", function () {
  const e = waitForAnyWritablePrefixRequestDeleted();
  block(matchAddWritablePrefixRequest(e.id, ANY), function () {
    verifyWritablePrefixRequestDoesNotExist(e.id);
  });
});

bthread("InventoryItemRole create verification", function () {
  const e = waitForAnyInventoryItemRoleAdded();
  block(matchDeleteInventoryItemRole(e.id, ANY), function () {
    verifyInventoryItemRoleExists(e.id);
  });
});

bthread("InventoryItemRole update verification", function () {
  const e = waitForAnyInventoryItemRoleUpdated();
  block(matchDeleteInventoryItemRole(e.id, ANY), function () {
    verifyInventoryItemRoleUpdated(e.id);
  });
});

bthread("InventoryItemRole delete verification", function () {
  const e = waitForAnyInventoryItemRoleDeleted();
  block(matchAddInventoryItemRole(e.id, ANY), function () {
    verifyInventoryItemRoleDoesNotExist(e.id);
  });
});

bthread("L2VPNRequest create verification", function () {
  const e = waitForAnyL2VPNRequestAdded();
  block(matchDeleteL2VPNRequest(e.id, ANY), function () {
    verifyL2VPNRequestExists(e.id);
  });
});

bthread("L2VPNRequest update verification", function () {
  const e = waitForAnyL2VPNRequestUpdated();
  block(matchDeleteL2VPNRequest(e.id, ANY), function () {
    verifyL2VPNRequestUpdated(e.id);
  });
});

bthread("L2VPNRequest delete verification", function () {
  const e = waitForAnyL2VPNRequestDeleted();
  block(matchAddL2VPNRequest(e.id, ANY), function () {
    verifyL2VPNRequestDoesNotExist(e.id);
  });
});

bthread("BriefClusterTypeRequest create verification", function () {
  const e = waitForAnyBriefClusterTypeRequestAdded();
  block(matchDeleteBriefClusterTypeRequest(e.id, ANY), function () {
    verifyBriefClusterTypeRequestExists(e.id);
  });
});

bthread("BriefClusterTypeRequest update verification", function () {
  const e = waitForAnyBriefClusterTypeRequestUpdated();
  block(matchDeleteBriefClusterTypeRequest(e.id, ANY), function () {
    verifyBriefClusterTypeRequestUpdated(e.id);
  });
});

bthread("BriefClusterTypeRequest delete verification", function () {
  const e = waitForAnyBriefClusterTypeRequestDeleted();
  block(matchAddBriefClusterTypeRequest(e.id, ANY), function () {
    verifyBriefClusterTypeRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableVirtualCircuitTerminationRequest create verification", function () {
  const e = waitForAnyPatchedWritableVirtualCircuitTerminationRequestAdded();
  block(matchDeletePatchedWritableVirtualCircuitTerminationRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualCircuitTerminationRequestExists(e.id);
  });
});

bthread("PatchedWritableVirtualCircuitTerminationRequest update verification", function () {
  const e = waitForAnyPatchedWritableVirtualCircuitTerminationRequestUpdated();
  block(matchDeletePatchedWritableVirtualCircuitTerminationRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualCircuitTerminationRequestUpdated(e.id);
  });
});

bthread("PatchedWritableVirtualCircuitTerminationRequest delete verification", function () {
  const e = waitForAnyPatchedWritableVirtualCircuitTerminationRequestDeleted();
  block(matchAddPatchedWritableVirtualCircuitTerminationRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualCircuitTerminationRequestDoesNotExist(e.id);
  });
});

bthread("FHRPGroupRequest create verification", function () {
  const e = waitForAnyFHRPGroupRequestAdded();
  block(matchDeleteFHRPGroupRequest(e.id, ANY), function () {
    verifyFHRPGroupRequestExists(e.id);
  });
});

bthread("FHRPGroupRequest update verification", function () {
  const e = waitForAnyFHRPGroupRequestUpdated();
  block(matchDeleteFHRPGroupRequest(e.id, ANY), function () {
    verifyFHRPGroupRequestUpdated(e.id);
  });
});

bthread("FHRPGroupRequest delete verification", function () {
  const e = waitForAnyFHRPGroupRequestDeleted();
  block(matchAddFHRPGroupRequest(e.id, ANY), function () {
    verifyFHRPGroupRequestDoesNotExist(e.id);
  });
});

bthread("NestedLocation create verification", function () {
  const e = waitForAnyNestedLocationAdded();
  block(matchDeleteNestedLocation(e.id, ANY), function () {
    verifyNestedLocationExists(e.id);
  });
});

bthread("NestedLocation update verification", function () {
  const e = waitForAnyNestedLocationUpdated();
  block(matchDeleteNestedLocation(e.id, ANY), function () {
    verifyNestedLocationUpdated(e.id);
  });
});

bthread("NestedLocation delete verification", function () {
  const e = waitForAnyNestedLocationDeleted();
  block(matchAddNestedLocation(e.id, ANY), function () {
    verifyNestedLocationDoesNotExist(e.id);
  });
});

bthread("BriefSite create verification", function () {
  const e = waitForAnyBriefSiteAdded();
  block(matchDeleteBriefSite(e.id, ANY), function () {
    verifyBriefSiteExists(e.id);
  });
});

bthread("BriefSite update verification", function () {
  const e = waitForAnyBriefSiteUpdated();
  block(matchDeleteBriefSite(e.id, ANY), function () {
    verifyBriefSiteUpdated(e.id);
  });
});

bthread("BriefSite delete verification", function () {
  const e = waitForAnyBriefSiteDeleted();
  block(matchAddBriefSite(e.id, ANY), function () {
    verifyBriefSiteDoesNotExist(e.id);
  });
});

bthread("ConfigContext create verification", function () {
  const e = waitForAnyConfigContextAdded();
  block(matchDeleteConfigContext(e.id, ANY), function () {
    verifyConfigContextExists(e.id);
  });
});

bthread("ConfigContext update verification", function () {
  const e = waitForAnyConfigContextUpdated();
  block(matchDeleteConfigContext(e.id, ANY), function () {
    verifyConfigContextUpdated(e.id);
  });
});

bthread("ConfigContext delete verification", function () {
  const e = waitForAnyConfigContextDeleted();
  block(matchAddConfigContext(e.id, ANY), function () {
    verifyConfigContextDoesNotExist(e.id);
  });
});

bthread("DeviceRoleRequest create verification", function () {
  const e = waitForAnyDeviceRoleRequestAdded();
  block(matchDeleteDeviceRoleRequest(e.id, ANY), function () {
    verifyDeviceRoleRequestExists(e.id);
  });
});

bthread("DeviceRoleRequest update verification", function () {
  const e = waitForAnyDeviceRoleRequestUpdated();
  block(matchDeleteDeviceRoleRequest(e.id, ANY), function () {
    verifyDeviceRoleRequestUpdated(e.id);
  });
});

bthread("DeviceRoleRequest delete verification", function () {
  const e = waitForAnyDeviceRoleRequestDeleted();
  block(matchAddDeviceRoleRequest(e.id, ANY), function () {
    verifyDeviceRoleRequestDoesNotExist(e.id);
  });
});

bthread("IPAddress create verification", function () {
  const e = waitForAnyIPAddressAdded();
  block(matchDeleteIPAddress(e.id, ANY), function () {
    verifyIPAddressExists(e.id);
  });
});

bthread("IPAddress update verification", function () {
  const e = waitForAnyIPAddressUpdated();
  block(matchDeleteIPAddress(e.id, ANY), function () {
    verifyIPAddressUpdated(e.id);
  });
});

bthread("IPAddress delete verification", function () {
  const e = waitForAnyIPAddressDeleted();
  block(matchAddIPAddress(e.id, ANY), function () {
    verifyIPAddressDoesNotExist(e.id);
  });
});

bthread("NestedTag create verification", function () {
  const e = waitForAnyNestedTagAdded();
  block(matchDeleteNestedTag(e.id, ANY), function () {
    verifyNestedTagExists(e.id);
  });
});

bthread("NestedTag update verification", function () {
  const e = waitForAnyNestedTagUpdated();
  block(matchDeleteNestedTag(e.id, ANY), function () {
    verifyNestedTagUpdated(e.id);
  });
});

bthread("NestedTag delete verification", function () {
  const e = waitForAnyNestedTagDeleted();
  block(matchAddNestedTag(e.id, ANY), function () {
    verifyNestedTagDoesNotExist(e.id);
  });
});

bthread("ObjectType create verification", function () {
  const e = waitForAnyObjectTypeAdded();
  block(matchDeleteObjectType(e.id, ANY), function () {
    verifyObjectTypeExists(e.id);
  });
});

bthread("ObjectType update verification", function () {
  const e = waitForAnyObjectTypeUpdated();
  block(matchDeleteObjectType(e.id, ANY), function () {
    verifyObjectTypeUpdated(e.id);
  });
});

bthread("ObjectType delete verification", function () {
  const e = waitForAnyObjectTypeDeleted();
  block(matchAddObjectType(e.id, ANY), function () {
    verifyObjectTypeDoesNotExist(e.id);
  });
});

bthread("PaginatedDeviceTypeList create verification", function () {
  const e = waitForAnyPaginatedDeviceTypeListAdded();
  block(matchDeletePaginatedDeviceTypeList(e.id, ANY), function () {
    verifyPaginatedDeviceTypeListExists(e.id);
  });
});

bthread("PaginatedDeviceTypeList update verification", function () {
  const e = waitForAnyPaginatedDeviceTypeListUpdated();
  block(matchDeletePaginatedDeviceTypeList(e.id, ANY), function () {
    verifyPaginatedDeviceTypeListUpdated(e.id);
  });
});

bthread("PaginatedDeviceTypeList delete verification", function () {
  const e = waitForAnyPaginatedDeviceTypeListDeleted();
  block(matchAddPaginatedDeviceTypeList(e.id, ANY), function () {
    verifyPaginatedDeviceTypeListDoesNotExist(e.id);
  });
});

bthread("WritableIKEPolicyRequest create verification", function () {
  const e = waitForAnyWritableIKEPolicyRequestAdded();
  block(matchDeleteWritableIKEPolicyRequest(e.id, ANY), function () {
    verifyWritableIKEPolicyRequestExists(e.id);
  });
});

bthread("WritableIKEPolicyRequest update verification", function () {
  const e = waitForAnyWritableIKEPolicyRequestUpdated();
  block(matchDeleteWritableIKEPolicyRequest(e.id, ANY), function () {
    verifyWritableIKEPolicyRequestUpdated(e.id);
  });
});

bthread("WritableIKEPolicyRequest delete verification", function () {
  const e = waitForAnyWritableIKEPolicyRequestDeleted();
  block(matchAddWritableIKEPolicyRequest(e.id, ANY), function () {
    verifyWritableIKEPolicyRequestDoesNotExist(e.id);
  });
});

bthread("BriefClusterType create verification", function () {
  const e = waitForAnyBriefClusterTypeAdded();
  block(matchDeleteBriefClusterType(e.id, ANY), function () {
    verifyBriefClusterTypeExists(e.id);
  });
});

bthread("BriefClusterType update verification", function () {
  const e = waitForAnyBriefClusterTypeUpdated();
  block(matchDeleteBriefClusterType(e.id, ANY), function () {
    verifyBriefClusterTypeUpdated(e.id);
  });
});

bthread("BriefClusterType delete verification", function () {
  const e = waitForAnyBriefClusterTypeDeleted();
  block(matchAddBriefClusterType(e.id, ANY), function () {
    verifyBriefClusterTypeDoesNotExist(e.id);
  });
});

bthread("ConsolePortRequest create verification", function () {
  const e = waitForAnyConsolePortRequestAdded();
  block(matchDeleteConsolePortRequest(e.id, ANY), function () {
    verifyConsolePortRequestExists(e.id);
  });
});

bthread("ConsolePortRequest update verification", function () {
  const e = waitForAnyConsolePortRequestUpdated();
  block(matchDeleteConsolePortRequest(e.id, ANY), function () {
    verifyConsolePortRequestUpdated(e.id);
  });
});

bthread("ConsolePortRequest delete verification", function () {
  const e = waitForAnyConsolePortRequestDeleted();
  block(matchAddConsolePortRequest(e.id, ANY), function () {
    verifyConsolePortRequestDoesNotExist(e.id);
  });
});

bthread("GroupRequest create verification", function () {
  const e = waitForAnyGroupRequestAdded();
  block(matchDeleteGroupRequest(e.id, ANY), function () {
    verifyGroupRequestExists(e.id);
  });
});

bthread("GroupRequest update verification", function () {
  const e = waitForAnyGroupRequestUpdated();
  block(matchDeleteGroupRequest(e.id, ANY), function () {
    verifyGroupRequestUpdated(e.id);
  });
});

bthread("GroupRequest delete verification", function () {
  const e = waitForAnyGroupRequestDeleted();
  block(matchAddGroupRequest(e.id, ANY), function () {
    verifyGroupRequestDoesNotExist(e.id);
  });
});

bthread("NestedIPAddressRequest create verification", function () {
  const e = waitForAnyNestedIPAddressRequestAdded();
  block(matchDeleteNestedIPAddressRequest(e.id, ANY), function () {
    verifyNestedIPAddressRequestExists(e.id);
  });
});

bthread("NestedIPAddressRequest update verification", function () {
  const e = waitForAnyNestedIPAddressRequestUpdated();
  block(matchDeleteNestedIPAddressRequest(e.id, ANY), function () {
    verifyNestedIPAddressRequestUpdated(e.id);
  });
});

bthread("NestedIPAddressRequest delete verification", function () {
  const e = waitForAnyNestedIPAddressRequestDeleted();
  block(matchAddNestedIPAddressRequest(e.id, ANY), function () {
    verifyNestedIPAddressRequestDoesNotExist(e.id);
  });
});

bthread("VirtualCircuitRequest create verification", function () {
  const e = waitForAnyVirtualCircuitRequestAdded();
  block(matchDeleteVirtualCircuitRequest(e.id, ANY), function () {
    verifyVirtualCircuitRequestExists(e.id);
  });
});

bthread("VirtualCircuitRequest update verification", function () {
  const e = waitForAnyVirtualCircuitRequestUpdated();
  block(matchDeleteVirtualCircuitRequest(e.id, ANY), function () {
    verifyVirtualCircuitRequestUpdated(e.id);
  });
});

bthread("VirtualCircuitRequest delete verification", function () {
  const e = waitForAnyVirtualCircuitRequestDeleted();
  block(matchAddVirtualCircuitRequest(e.id, ANY), function () {
    verifyVirtualCircuitRequestDoesNotExist(e.id);
  });
});

bthread("Role create verification", function () {
  const e = waitForAnyRoleAdded();
  block(matchDeleteRole(e.id, ANY), function () {
    verifyRoleExists(e.id);
  });
});

bthread("Role update verification", function () {
  const e = waitForAnyRoleUpdated();
  block(matchDeleteRole(e.id, ANY), function () {
    verifyRoleUpdated(e.id);
  });
});

bthread("Role delete verification", function () {
  const e = waitForAnyRoleDeleted();
  block(matchAddRole(e.id, ANY), function () {
    verifyRoleDoesNotExist(e.id);
  });
});

bthread("PatchedWritableDeviceWithConfigContextRequest create verification", function () {
  const e = waitForAnyPatchedWritableDeviceWithConfigContextRequestAdded();
  block(matchDeletePatchedWritableDeviceWithConfigContextRequest(e.id, ANY), function () {
    verifyPatchedWritableDeviceWithConfigContextRequestExists(e.id);
  });
});

bthread("PatchedWritableDeviceWithConfigContextRequest update verification", function () {
  const e = waitForAnyPatchedWritableDeviceWithConfigContextRequestUpdated();
  block(matchDeletePatchedWritableDeviceWithConfigContextRequest(e.id, ANY), function () {
    verifyPatchedWritableDeviceWithConfigContextRequestUpdated(e.id);
  });
});

bthread("PatchedWritableDeviceWithConfigContextRequest delete verification", function () {
  const e = waitForAnyPatchedWritableDeviceWithConfigContextRequestDeleted();
  block(matchAddPatchedWritableDeviceWithConfigContextRequest(e.id, ANY), function () {
    verifyPatchedWritableDeviceWithConfigContextRequestDoesNotExist(e.id);
  });
});

bthread("BriefInterface create verification", function () {
  const e = waitForAnyBriefInterfaceAdded();
  block(matchDeleteBriefInterface(e.id, ANY), function () {
    verifyBriefInterfaceExists(e.id);
  });
});

bthread("BriefInterface update verification", function () {
  const e = waitForAnyBriefInterfaceUpdated();
  block(matchDeleteBriefInterface(e.id, ANY), function () {
    verifyBriefInterfaceUpdated(e.id);
  });
});

bthread("BriefInterface delete verification", function () {
  const e = waitForAnyBriefInterfaceDeleted();
  block(matchAddBriefInterface(e.id, ANY), function () {
    verifyBriefInterfaceDoesNotExist(e.id);
  });
});

bthread("PatchedRouteTargetRequest create verification", function () {
  const e = waitForAnyPatchedRouteTargetRequestAdded();
  block(matchDeletePatchedRouteTargetRequest(e.id, ANY), function () {
    verifyPatchedRouteTargetRequestExists(e.id);
  });
});

bthread("PatchedRouteTargetRequest update verification", function () {
  const e = waitForAnyPatchedRouteTargetRequestUpdated();
  block(matchDeletePatchedRouteTargetRequest(e.id, ANY), function () {
    verifyPatchedRouteTargetRequestUpdated(e.id);
  });
});

bthread("PatchedRouteTargetRequest delete verification", function () {
  const e = waitForAnyPatchedRouteTargetRequestDeleted();
  block(matchAddPatchedRouteTargetRequest(e.id, ANY), function () {
    verifyPatchedRouteTargetRequestDoesNotExist(e.id);
  });
});

bthread("PatchedContactRoleRequest create verification", function () {
  const e = waitForAnyPatchedContactRoleRequestAdded();
  block(matchDeletePatchedContactRoleRequest(e.id, ANY), function () {
    verifyPatchedContactRoleRequestExists(e.id);
  });
});

bthread("PatchedContactRoleRequest update verification", function () {
  const e = waitForAnyPatchedContactRoleRequestUpdated();
  block(matchDeletePatchedContactRoleRequest(e.id, ANY), function () {
    verifyPatchedContactRoleRequestUpdated(e.id);
  });
});

bthread("PatchedContactRoleRequest delete verification", function () {
  const e = waitForAnyPatchedContactRoleRequestDeleted();
  block(matchAddPatchedContactRoleRequest(e.id, ANY), function () {
    verifyPatchedContactRoleRequestDoesNotExist(e.id);
  });
});

bthread("PatchedModuleBayTemplateRequest create verification", function () {
  const e = waitForAnyPatchedModuleBayTemplateRequestAdded();
  block(matchDeletePatchedModuleBayTemplateRequest(e.id, ANY), function () {
    verifyPatchedModuleBayTemplateRequestExists(e.id);
  });
});

bthread("PatchedModuleBayTemplateRequest update verification", function () {
  const e = waitForAnyPatchedModuleBayTemplateRequestUpdated();
  block(matchDeletePatchedModuleBayTemplateRequest(e.id, ANY), function () {
    verifyPatchedModuleBayTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedModuleBayTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedModuleBayTemplateRequestDeleted();
  block(matchAddPatchedModuleBayTemplateRequest(e.id, ANY), function () {
    verifyPatchedModuleBayTemplateRequestDoesNotExist(e.id);
  });
});

bthread("BriefMACAddress create verification", function () {
  const e = waitForAnyBriefMACAddressAdded();
  block(matchDeleteBriefMACAddress(e.id, ANY), function () {
    verifyBriefMACAddressExists(e.id);
  });
});

bthread("BriefMACAddress update verification", function () {
  const e = waitForAnyBriefMACAddressUpdated();
  block(matchDeleteBriefMACAddress(e.id, ANY), function () {
    verifyBriefMACAddressUpdated(e.id);
  });
});

bthread("BriefMACAddress delete verification", function () {
  const e = waitForAnyBriefMACAddressDeleted();
  block(matchAddBriefMACAddress(e.id, ANY), function () {
    verifyBriefMACAddressDoesNotExist(e.id);
  });
});

bthread("BriefModuleTypeRequest create verification", function () {
  const e = waitForAnyBriefModuleTypeRequestAdded();
  block(matchDeleteBriefModuleTypeRequest(e.id, ANY), function () {
    verifyBriefModuleTypeRequestExists(e.id);
  });
});

bthread("BriefModuleTypeRequest update verification", function () {
  const e = waitForAnyBriefModuleTypeRequestUpdated();
  block(matchDeleteBriefModuleTypeRequest(e.id, ANY), function () {
    verifyBriefModuleTypeRequestUpdated(e.id);
  });
});

bthread("BriefModuleTypeRequest delete verification", function () {
  const e = waitForAnyBriefModuleTypeRequestDeleted();
  block(matchAddBriefModuleTypeRequest(e.id, ANY), function () {
    verifyBriefModuleTypeRequestDoesNotExist(e.id);
  });
});

bthread("RackRole create verification", function () {
  const e = waitForAnyRackRoleAdded();
  block(matchDeleteRackRole(e.id, ANY), function () {
    verifyRackRoleExists(e.id);
  });
});

bthread("RackRole update verification", function () {
  const e = waitForAnyRackRoleUpdated();
  block(matchDeleteRackRole(e.id, ANY), function () {
    verifyRackRoleUpdated(e.id);
  });
});

bthread("RackRole delete verification", function () {
  const e = waitForAnyRackRoleDeleted();
  block(matchAddRackRole(e.id, ANY), function () {
    verifyRackRoleDoesNotExist(e.id);
  });
});

bthread("WritableFrontPortTemplateRequest create verification", function () {
  const e = waitForAnyWritableFrontPortTemplateRequestAdded();
  block(matchDeleteWritableFrontPortTemplateRequest(e.id, ANY), function () {
    verifyWritableFrontPortTemplateRequestExists(e.id);
  });
});

bthread("WritableFrontPortTemplateRequest update verification", function () {
  const e = waitForAnyWritableFrontPortTemplateRequestUpdated();
  block(matchDeleteWritableFrontPortTemplateRequest(e.id, ANY), function () {
    verifyWritableFrontPortTemplateRequestUpdated(e.id);
  });
});

bthread("WritableFrontPortTemplateRequest delete verification", function () {
  const e = waitForAnyWritableFrontPortTemplateRequestDeleted();
  block(matchAddWritableFrontPortTemplateRequest(e.id, ANY), function () {
    verifyWritableFrontPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedCustomFieldList create verification", function () {
  const e = waitForAnyPaginatedCustomFieldListAdded();
  block(matchDeletePaginatedCustomFieldList(e.id, ANY), function () {
    verifyPaginatedCustomFieldListExists(e.id);
  });
});

bthread("PaginatedCustomFieldList update verification", function () {
  const e = waitForAnyPaginatedCustomFieldListUpdated();
  block(matchDeletePaginatedCustomFieldList(e.id, ANY), function () {
    verifyPaginatedCustomFieldListUpdated(e.id);
  });
});

bthread("PaginatedCustomFieldList delete verification", function () {
  const e = waitForAnyPaginatedCustomFieldListDeleted();
  block(matchAddPaginatedCustomFieldList(e.id, ANY), function () {
    verifyPaginatedCustomFieldListDoesNotExist(e.id);
  });
});

bthread("NestedSiteGroup create verification", function () {
  const e = waitForAnyNestedSiteGroupAdded();
  block(matchDeleteNestedSiteGroup(e.id, ANY), function () {
    verifyNestedSiteGroupExists(e.id);
  });
});

bthread("NestedSiteGroup update verification", function () {
  const e = waitForAnyNestedSiteGroupUpdated();
  block(matchDeleteNestedSiteGroup(e.id, ANY), function () {
    verifyNestedSiteGroupUpdated(e.id);
  });
});

bthread("NestedSiteGroup delete verification", function () {
  const e = waitForAnyNestedSiteGroupDeleted();
  block(matchAddNestedSiteGroup(e.id, ANY), function () {
    verifyNestedSiteGroupDoesNotExist(e.id);
  });
});

bthread("NestedSiteGroupRequest create verification", function () {
  const e = waitForAnyNestedSiteGroupRequestAdded();
  block(matchDeleteNestedSiteGroupRequest(e.id, ANY), function () {
    verifyNestedSiteGroupRequestExists(e.id);
  });
});

bthread("NestedSiteGroupRequest update verification", function () {
  const e = waitForAnyNestedSiteGroupRequestUpdated();
  block(matchDeleteNestedSiteGroupRequest(e.id, ANY), function () {
    verifyNestedSiteGroupRequestUpdated(e.id);
  });
});

bthread("NestedSiteGroupRequest delete verification", function () {
  const e = waitForAnyNestedSiteGroupRequestDeleted();
  block(matchAddNestedSiteGroupRequest(e.id, ANY), function () {
    verifyNestedSiteGroupRequestDoesNotExist(e.id);
  });
});

bthread("PatchedFHRPGroupAssignmentRequest create verification", function () {
  const e = waitForAnyPatchedFHRPGroupAssignmentRequestAdded();
  block(matchDeletePatchedFHRPGroupAssignmentRequest(e.id, ANY), function () {
    verifyPatchedFHRPGroupAssignmentRequestExists(e.id);
  });
});

bthread("PatchedFHRPGroupAssignmentRequest update verification", function () {
  const e = waitForAnyPatchedFHRPGroupAssignmentRequestUpdated();
  block(matchDeletePatchedFHRPGroupAssignmentRequest(e.id, ANY), function () {
    verifyPatchedFHRPGroupAssignmentRequestUpdated(e.id);
  });
});

bthread("PatchedFHRPGroupAssignmentRequest delete verification", function () {
  const e = waitForAnyPatchedFHRPGroupAssignmentRequestDeleted();
  block(matchAddPatchedFHRPGroupAssignmentRequest(e.id, ANY), function () {
    verifyPatchedFHRPGroupAssignmentRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedNotificationGroupList create verification", function () {
  const e = waitForAnyPaginatedNotificationGroupListAdded();
  block(matchDeletePaginatedNotificationGroupList(e.id, ANY), function () {
    verifyPaginatedNotificationGroupListExists(e.id);
  });
});

bthread("PaginatedNotificationGroupList update verification", function () {
  const e = waitForAnyPaginatedNotificationGroupListUpdated();
  block(matchDeletePaginatedNotificationGroupList(e.id, ANY), function () {
    verifyPaginatedNotificationGroupListUpdated(e.id);
  });
});

bthread("PaginatedNotificationGroupList delete verification", function () {
  const e = waitForAnyPaginatedNotificationGroupListDeleted();
  block(matchAddPaginatedNotificationGroupList(e.id, ANY), function () {
    verifyPaginatedNotificationGroupListDoesNotExist(e.id);
  });
});

bthread("WritableRackReservationRequest create verification", function () {
  const e = waitForAnyWritableRackReservationRequestAdded();
  block(matchDeleteWritableRackReservationRequest(e.id, ANY), function () {
    verifyWritableRackReservationRequestExists(e.id);
  });
});

bthread("WritableRackReservationRequest update verification", function () {
  const e = waitForAnyWritableRackReservationRequestUpdated();
  block(matchDeleteWritableRackReservationRequest(e.id, ANY), function () {
    verifyWritableRackReservationRequestUpdated(e.id);
  });
});

bthread("WritableRackReservationRequest delete verification", function () {
  const e = waitForAnyWritableRackReservationRequestDeleted();
  block(matchAddWritableRackReservationRequest(e.id, ANY), function () {
    verifyWritableRackReservationRequestDoesNotExist(e.id);
  });
});

bthread("Bookmark create verification", function () {
  const e = waitForAnyBookmarkAdded();
  block(matchDeleteBookmark(e.id, ANY), function () {
    verifyBookmarkExists(e.id);
  });
});

bthread("Bookmark update verification", function () {
  const e = waitForAnyBookmarkUpdated();
  block(matchDeleteBookmark(e.id, ANY), function () {
    verifyBookmarkUpdated(e.id);
  });
});

bthread("Bookmark delete verification", function () {
  const e = waitForAnyBookmarkDeleted();
  block(matchAddBookmark(e.id, ANY), function () {
    verifyBookmarkDoesNotExist(e.id);
  });
});

bthread("PatchedWritableIPRangeRequest create verification", function () {
  const e = waitForAnyPatchedWritableIPRangeRequestAdded();
  block(matchDeletePatchedWritableIPRangeRequest(e.id, ANY), function () {
    verifyPatchedWritableIPRangeRequestExists(e.id);
  });
});

bthread("PatchedWritableIPRangeRequest update verification", function () {
  const e = waitForAnyPatchedWritableIPRangeRequestUpdated();
  block(matchDeletePatchedWritableIPRangeRequest(e.id, ANY), function () {
    verifyPatchedWritableIPRangeRequestUpdated(e.id);
  });
});

bthread("PatchedWritableIPRangeRequest delete verification", function () {
  const e = waitForAnyPatchedWritableIPRangeRequestDeleted();
  block(matchAddPatchedWritableIPRangeRequest(e.id, ANY), function () {
    verifyPatchedWritableIPRangeRequestDoesNotExist(e.id);
  });
});

bthread("BriefCluster create verification", function () {
  const e = waitForAnyBriefClusterAdded();
  block(matchDeleteBriefCluster(e.id, ANY), function () {
    verifyBriefClusterExists(e.id);
  });
});

bthread("BriefCluster update verification", function () {
  const e = waitForAnyBriefClusterUpdated();
  block(matchDeleteBriefCluster(e.id, ANY), function () {
    verifyBriefClusterUpdated(e.id);
  });
});

bthread("BriefCluster delete verification", function () {
  const e = waitForAnyBriefClusterDeleted();
  block(matchAddBriefCluster(e.id, ANY), function () {
    verifyBriefClusterDoesNotExist(e.id);
  });
});

bthread("BriefClusterGroup create verification", function () {
  const e = waitForAnyBriefClusterGroupAdded();
  block(matchDeleteBriefClusterGroup(e.id, ANY), function () {
    verifyBriefClusterGroupExists(e.id);
  });
});

bthread("BriefClusterGroup update verification", function () {
  const e = waitForAnyBriefClusterGroupUpdated();
  block(matchDeleteBriefClusterGroup(e.id, ANY), function () {
    verifyBriefClusterGroupUpdated(e.id);
  });
});

bthread("BriefClusterGroup delete verification", function () {
  const e = waitForAnyBriefClusterGroupDeleted();
  block(matchAddBriefClusterGroup(e.id, ANY), function () {
    verifyBriefClusterGroupDoesNotExist(e.id);
  });
});

bthread("PaginatedClusterTypeList create verification", function () {
  const e = waitForAnyPaginatedClusterTypeListAdded();
  block(matchDeletePaginatedClusterTypeList(e.id, ANY), function () {
    verifyPaginatedClusterTypeListExists(e.id);
  });
});

bthread("PaginatedClusterTypeList update verification", function () {
  const e = waitForAnyPaginatedClusterTypeListUpdated();
  block(matchDeletePaginatedClusterTypeList(e.id, ANY), function () {
    verifyPaginatedClusterTypeListUpdated(e.id);
  });
});

bthread("PaginatedClusterTypeList delete verification", function () {
  const e = waitForAnyPaginatedClusterTypeListDeleted();
  block(matchAddPaginatedClusterTypeList(e.id, ANY), function () {
    verifyPaginatedClusterTypeListDoesNotExist(e.id);
  });
});

bthread("PaginatedWirelessLANGroupList create verification", function () {
  const e = waitForAnyPaginatedWirelessLANGroupListAdded();
  block(matchDeletePaginatedWirelessLANGroupList(e.id, ANY), function () {
    verifyPaginatedWirelessLANGroupListExists(e.id);
  });
});

bthread("PaginatedWirelessLANGroupList update verification", function () {
  const e = waitForAnyPaginatedWirelessLANGroupListUpdated();
  block(matchDeletePaginatedWirelessLANGroupList(e.id, ANY), function () {
    verifyPaginatedWirelessLANGroupListUpdated(e.id);
  });
});

bthread("PaginatedWirelessLANGroupList delete verification", function () {
  const e = waitForAnyPaginatedWirelessLANGroupListDeleted();
  block(matchAddPaginatedWirelessLANGroupList(e.id, ANY), function () {
    verifyPaginatedWirelessLANGroupListDoesNotExist(e.id);
  });
});

bthread("RearPort create verification", function () {
  const e = waitForAnyRearPortAdded();
  block(matchDeleteRearPort(e.id, ANY), function () {
    verifyRearPortExists(e.id);
  });
});

bthread("RearPort update verification", function () {
  const e = waitForAnyRearPortUpdated();
  block(matchDeleteRearPort(e.id, ANY), function () {
    verifyRearPortUpdated(e.id);
  });
});

bthread("RearPort delete verification", function () {
  const e = waitForAnyRearPortDeleted();
  block(matchAddRearPort(e.id, ANY), function () {
    verifyRearPortDoesNotExist(e.id);
  });
});

bthread("ImageAttachment create verification", function () {
  const e = waitForAnyImageAttachmentAdded();
  block(matchDeleteImageAttachment(e.id, ANY), function () {
    verifyImageAttachmentExists(e.id);
  });
});

bthread("ImageAttachment update verification", function () {
  const e = waitForAnyImageAttachmentUpdated();
  block(matchDeleteImageAttachment(e.id, ANY), function () {
    verifyImageAttachmentUpdated(e.id);
  });
});

bthread("ImageAttachment delete verification", function () {
  const e = waitForAnyImageAttachmentDeleted();
  block(matchAddImageAttachment(e.id, ANY), function () {
    verifyImageAttachmentDoesNotExist(e.id);
  });
});

bthread("BackgroundTaskRequest create verification", function () {
  const e = waitForAnyBackgroundTaskRequestAdded();
  block(matchDeleteBackgroundTaskRequest(e.id, ANY), function () {
    verifyBackgroundTaskRequestExists(e.id);
  });
});

bthread("BackgroundTaskRequest update verification", function () {
  const e = waitForAnyBackgroundTaskRequestUpdated();
  block(matchDeleteBackgroundTaskRequest(e.id, ANY), function () {
    verifyBackgroundTaskRequestUpdated(e.id);
  });
});

bthread("BackgroundTaskRequest delete verification", function () {
  const e = waitForAnyBackgroundTaskRequestDeleted();
  block(matchAddBackgroundTaskRequest(e.id, ANY), function () {
    verifyBackgroundTaskRequestDoesNotExist(e.id);
  });
});

bthread("VirtualCircuitTerminationRequest create verification", function () {
  const e = waitForAnyVirtualCircuitTerminationRequestAdded();
  block(matchDeleteVirtualCircuitTerminationRequest(e.id, ANY), function () {
    verifyVirtualCircuitTerminationRequestExists(e.id);
  });
});

bthread("VirtualCircuitTerminationRequest update verification", function () {
  const e = waitForAnyVirtualCircuitTerminationRequestUpdated();
  block(matchDeleteVirtualCircuitTerminationRequest(e.id, ANY), function () {
    verifyVirtualCircuitTerminationRequestUpdated(e.id);
  });
});

bthread("VirtualCircuitTerminationRequest delete verification", function () {
  const e = waitForAnyVirtualCircuitTerminationRequestDeleted();
  block(matchAddVirtualCircuitTerminationRequest(e.id, ANY), function () {
    verifyVirtualCircuitTerminationRequestDoesNotExist(e.id);
  });
});

bthread("ContactAssignment create verification", function () {
  const e = waitForAnyContactAssignmentAdded();
  block(matchDeleteContactAssignment(e.id, ANY), function () {
    verifyContactAssignmentExists(e.id);
  });
});

bthread("ContactAssignment update verification", function () {
  const e = waitForAnyContactAssignmentUpdated();
  block(matchDeleteContactAssignment(e.id, ANY), function () {
    verifyContactAssignmentUpdated(e.id);
  });
});

bthread("ContactAssignment delete verification", function () {
  const e = waitForAnyContactAssignmentDeleted();
  block(matchAddContactAssignment(e.id, ANY), function () {
    verifyContactAssignmentDoesNotExist(e.id);
  });
});

bthread("BriefIPAddress create verification", function () {
  const e = waitForAnyBriefIPAddressAdded();
  block(matchDeleteBriefIPAddress(e.id, ANY), function () {
    verifyBriefIPAddressExists(e.id);
  });
});

bthread("BriefIPAddress update verification", function () {
  const e = waitForAnyBriefIPAddressUpdated();
  block(matchDeleteBriefIPAddress(e.id, ANY), function () {
    verifyBriefIPAddressUpdated(e.id);
  });
});

bthread("BriefIPAddress delete verification", function () {
  const e = waitForAnyBriefIPAddressDeleted();
  block(matchAddBriefIPAddress(e.id, ANY), function () {
    verifyBriefIPAddressDoesNotExist(e.id);
  });
});

bthread("IKEPolicy create verification", function () {
  const e = waitForAnyIKEPolicyAdded();
  block(matchDeleteIKEPolicy(e.id, ANY), function () {
    verifyIKEPolicyExists(e.id);
  });
});

bthread("IKEPolicy update verification", function () {
  const e = waitForAnyIKEPolicyUpdated();
  block(matchDeleteIKEPolicy(e.id, ANY), function () {
    verifyIKEPolicyUpdated(e.id);
  });
});

bthread("IKEPolicy delete verification", function () {
  const e = waitForAnyIKEPolicyDeleted();
  block(matchAddIKEPolicy(e.id, ANY), function () {
    verifyIKEPolicyDoesNotExist(e.id);
  });
});

bthread("PaginatedVirtualDeviceContextList create verification", function () {
  const e = waitForAnyPaginatedVirtualDeviceContextListAdded();
  block(matchDeletePaginatedVirtualDeviceContextList(e.id, ANY), function () {
    verifyPaginatedVirtualDeviceContextListExists(e.id);
  });
});

bthread("PaginatedVirtualDeviceContextList update verification", function () {
  const e = waitForAnyPaginatedVirtualDeviceContextListUpdated();
  block(matchDeletePaginatedVirtualDeviceContextList(e.id, ANY), function () {
    verifyPaginatedVirtualDeviceContextListUpdated(e.id);
  });
});

bthread("PaginatedVirtualDeviceContextList delete verification", function () {
  const e = waitForAnyPaginatedVirtualDeviceContextListDeleted();
  block(matchAddPaginatedVirtualDeviceContextList(e.id, ANY), function () {
    verifyPaginatedVirtualDeviceContextListDoesNotExist(e.id);
  });
});

bthread("BriefRackTypeRequest create verification", function () {
  const e = waitForAnyBriefRackTypeRequestAdded();
  block(matchDeleteBriefRackTypeRequest(e.id, ANY), function () {
    verifyBriefRackTypeRequestExists(e.id);
  });
});

bthread("BriefRackTypeRequest update verification", function () {
  const e = waitForAnyBriefRackTypeRequestUpdated();
  block(matchDeleteBriefRackTypeRequest(e.id, ANY), function () {
    verifyBriefRackTypeRequestUpdated(e.id);
  });
});

bthread("BriefRackTypeRequest delete verification", function () {
  const e = waitForAnyBriefRackTypeRequestDeleted();
  block(matchAddBriefRackTypeRequest(e.id, ANY), function () {
    verifyBriefRackTypeRequestDoesNotExist(e.id);
  });
});

bthread("BriefConfigContextProfile create verification", function () {
  const e = waitForAnyBriefConfigContextProfileAdded();
  block(matchDeleteBriefConfigContextProfile(e.id, ANY), function () {
    verifyBriefConfigContextProfileExists(e.id);
  });
});

bthread("BriefConfigContextProfile update verification", function () {
  const e = waitForAnyBriefConfigContextProfileUpdated();
  block(matchDeleteBriefConfigContextProfile(e.id, ANY), function () {
    verifyBriefConfigContextProfileUpdated(e.id);
  });
});

bthread("BriefConfigContextProfile delete verification", function () {
  const e = waitForAnyBriefConfigContextProfileDeleted();
  block(matchAddBriefConfigContextProfile(e.id, ANY), function () {
    verifyBriefConfigContextProfileDoesNotExist(e.id);
  });
});

bthread("IKEPolicyRequest create verification", function () {
  const e = waitForAnyIKEPolicyRequestAdded();
  block(matchDeleteIKEPolicyRequest(e.id, ANY), function () {
    verifyIKEPolicyRequestExists(e.id);
  });
});

bthread("IKEPolicyRequest update verification", function () {
  const e = waitForAnyIKEPolicyRequestUpdated();
  block(matchDeleteIKEPolicyRequest(e.id, ANY), function () {
    verifyIKEPolicyRequestUpdated(e.id);
  });
});

bthread("IKEPolicyRequest delete verification", function () {
  const e = waitForAnyIKEPolicyRequestDeleted();
  block(matchAddIKEPolicyRequest(e.id, ANY), function () {
    verifyIKEPolicyRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedVirtualMachineWithConfigContextList create verification", function () {
  const e = waitForAnyPaginatedVirtualMachineWithConfigContextListAdded();
  block(matchDeletePaginatedVirtualMachineWithConfigContextList(e.id, ANY), function () {
    verifyPaginatedVirtualMachineWithConfigContextListExists(e.id);
  });
});

bthread("PaginatedVirtualMachineWithConfigContextList update verification", function () {
  const e = waitForAnyPaginatedVirtualMachineWithConfigContextListUpdated();
  block(matchDeletePaginatedVirtualMachineWithConfigContextList(e.id, ANY), function () {
    verifyPaginatedVirtualMachineWithConfigContextListUpdated(e.id);
  });
});

bthread("PaginatedVirtualMachineWithConfigContextList delete verification", function () {
  const e = waitForAnyPaginatedVirtualMachineWithConfigContextListDeleted();
  block(matchAddPaginatedVirtualMachineWithConfigContextList(e.id, ANY), function () {
    verifyPaginatedVirtualMachineWithConfigContextListDoesNotExist(e.id);
  });
});

bthread("CircuitTypeRequest create verification", function () {
  const e = waitForAnyCircuitTypeRequestAdded();
  block(matchDeleteCircuitTypeRequest(e.id, ANY), function () {
    verifyCircuitTypeRequestExists(e.id);
  });
});

bthread("CircuitTypeRequest update verification", function () {
  const e = waitForAnyCircuitTypeRequestUpdated();
  block(matchDeleteCircuitTypeRequest(e.id, ANY), function () {
    verifyCircuitTypeRequestUpdated(e.id);
  });
});

bthread("CircuitTypeRequest delete verification", function () {
  const e = waitForAnyCircuitTypeRequestDeleted();
  block(matchAddCircuitTypeRequest(e.id, ANY), function () {
    verifyCircuitTypeRequestDoesNotExist(e.id);
  });
});

bthread("WritableIPSecProfileRequest create verification", function () {
  const e = waitForAnyWritableIPSecProfileRequestAdded();
  block(matchDeleteWritableIPSecProfileRequest(e.id, ANY), function () {
    verifyWritableIPSecProfileRequestExists(e.id);
  });
});

bthread("WritableIPSecProfileRequest update verification", function () {
  const e = waitForAnyWritableIPSecProfileRequestUpdated();
  block(matchDeleteWritableIPSecProfileRequest(e.id, ANY), function () {
    verifyWritableIPSecProfileRequestUpdated(e.id);
  });
});

bthread("WritableIPSecProfileRequest delete verification", function () {
  const e = waitForAnyWritableIPSecProfileRequestDeleted();
  block(matchAddWritableIPSecProfileRequest(e.id, ANY), function () {
    verifyWritableIPSecProfileRequestDoesNotExist(e.id);
  });
});

bthread("ServiceRequest create verification", function () {
  const e = waitForAnyServiceRequestAdded();
  block(matchDeleteServiceRequest(e.id, ANY), function () {
    verifyServiceRequestExists(e.id);
  });
});

bthread("ServiceRequest update verification", function () {
  const e = waitForAnyServiceRequestUpdated();
  block(matchDeleteServiceRequest(e.id, ANY), function () {
    verifyServiceRequestUpdated(e.id);
  });
});

bthread("ServiceRequest delete verification", function () {
  const e = waitForAnyServiceRequestDeleted();
  block(matchAddServiceRequest(e.id, ANY), function () {
    verifyServiceRequestDoesNotExist(e.id);
  });
});

bthread("VirtualMachineWithConfigContextRequest create verification", function () {
  const e = waitForAnyVirtualMachineWithConfigContextRequestAdded();
  block(matchDeleteVirtualMachineWithConfigContextRequest(e.id, ANY), function () {
    verifyVirtualMachineWithConfigContextRequestExists(e.id);
  });
});

bthread("VirtualMachineWithConfigContextRequest update verification", function () {
  const e = waitForAnyVirtualMachineWithConfigContextRequestUpdated();
  block(matchDeleteVirtualMachineWithConfigContextRequest(e.id, ANY), function () {
    verifyVirtualMachineWithConfigContextRequestUpdated(e.id);
  });
});

bthread("VirtualMachineWithConfigContextRequest delete verification", function () {
  const e = waitForAnyVirtualMachineWithConfigContextRequestDeleted();
  block(matchAddVirtualMachineWithConfigContextRequest(e.id, ANY), function () {
    verifyVirtualMachineWithConfigContextRequestDoesNotExist(e.id);
  });
});

bthread("EventRuleRequest create verification", function () {
  const e = waitForAnyEventRuleRequestAdded();
  block(matchDeleteEventRuleRequest(e.id, ANY), function () {
    verifyEventRuleRequestExists(e.id);
  });
});

bthread("EventRuleRequest update verification", function () {
  const e = waitForAnyEventRuleRequestUpdated();
  block(matchDeleteEventRuleRequest(e.id, ANY), function () {
    verifyEventRuleRequestUpdated(e.id);
  });
});

bthread("EventRuleRequest delete verification", function () {
  const e = waitForAnyEventRuleRequestDeleted();
  block(matchAddEventRuleRequest(e.id, ANY), function () {
    verifyEventRuleRequestDoesNotExist(e.id);
  });
});

bthread("BriefTunnelRequest create verification", function () {
  const e = waitForAnyBriefTunnelRequestAdded();
  block(matchDeleteBriefTunnelRequest(e.id, ANY), function () {
    verifyBriefTunnelRequestExists(e.id);
  });
});

bthread("BriefTunnelRequest update verification", function () {
  const e = waitForAnyBriefTunnelRequestUpdated();
  block(matchDeleteBriefTunnelRequest(e.id, ANY), function () {
    verifyBriefTunnelRequestUpdated(e.id);
  });
});

bthread("BriefTunnelRequest delete verification", function () {
  const e = waitForAnyBriefTunnelRequestDeleted();
  block(matchAddBriefTunnelRequest(e.id, ANY), function () {
    verifyBriefTunnelRequestDoesNotExist(e.id);
  });
});

bthread("BriefTenant create verification", function () {
  const e = waitForAnyBriefTenantAdded();
  block(matchDeleteBriefTenant(e.id, ANY), function () {
    verifyBriefTenantExists(e.id);
  });
});

bthread("BriefTenant update verification", function () {
  const e = waitForAnyBriefTenantUpdated();
  block(matchDeleteBriefTenant(e.id, ANY), function () {
    verifyBriefTenantUpdated(e.id);
  });
});

bthread("BriefTenant delete verification", function () {
  const e = waitForAnyBriefTenantDeleted();
  block(matchAddBriefTenant(e.id, ANY), function () {
    verifyBriefTenantDoesNotExist(e.id);
  });
});

bthread("PatchedWritableIPSecProfileRequest create verification", function () {
  const e = waitForAnyPatchedWritableIPSecProfileRequestAdded();
  block(matchDeletePatchedWritableIPSecProfileRequest(e.id, ANY), function () {
    verifyPatchedWritableIPSecProfileRequestExists(e.id);
  });
});

bthread("PatchedWritableIPSecProfileRequest update verification", function () {
  const e = waitForAnyPatchedWritableIPSecProfileRequestUpdated();
  block(matchDeletePatchedWritableIPSecProfileRequest(e.id, ANY), function () {
    verifyPatchedWritableIPSecProfileRequestUpdated(e.id);
  });
});

bthread("PatchedWritableIPSecProfileRequest delete verification", function () {
  const e = waitForAnyPatchedWritableIPSecProfileRequestDeleted();
  block(matchAddPatchedWritableIPSecProfileRequest(e.id, ANY), function () {
    verifyPatchedWritableIPSecProfileRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedFHRPGroupAssignmentList create verification", function () {
  const e = waitForAnyPaginatedFHRPGroupAssignmentListAdded();
  block(matchDeletePaginatedFHRPGroupAssignmentList(e.id, ANY), function () {
    verifyPaginatedFHRPGroupAssignmentListExists(e.id);
  });
});

bthread("PaginatedFHRPGroupAssignmentList update verification", function () {
  const e = waitForAnyPaginatedFHRPGroupAssignmentListUpdated();
  block(matchDeletePaginatedFHRPGroupAssignmentList(e.id, ANY), function () {
    verifyPaginatedFHRPGroupAssignmentListUpdated(e.id);
  });
});

bthread("PaginatedFHRPGroupAssignmentList delete verification", function () {
  const e = waitForAnyPaginatedFHRPGroupAssignmentListDeleted();
  block(matchAddPaginatedFHRPGroupAssignmentList(e.id, ANY), function () {
    verifyPaginatedFHRPGroupAssignmentListDoesNotExist(e.id);
  });
});

bthread("PaginatedModuleBayList create verification", function () {
  const e = waitForAnyPaginatedModuleBayListAdded();
  block(matchDeletePaginatedModuleBayList(e.id, ANY), function () {
    verifyPaginatedModuleBayListExists(e.id);
  });
});

bthread("PaginatedModuleBayList update verification", function () {
  const e = waitForAnyPaginatedModuleBayListUpdated();
  block(matchDeletePaginatedModuleBayList(e.id, ANY), function () {
    verifyPaginatedModuleBayListUpdated(e.id);
  });
});

bthread("PaginatedModuleBayList delete verification", function () {
  const e = waitForAnyPaginatedModuleBayListDeleted();
  block(matchAddPaginatedModuleBayList(e.id, ANY), function () {
    verifyPaginatedModuleBayListDoesNotExist(e.id);
  });
});

bthread("PaginatedDeviceWithConfigContextList create verification", function () {
  const e = waitForAnyPaginatedDeviceWithConfigContextListAdded();
  block(matchDeletePaginatedDeviceWithConfigContextList(e.id, ANY), function () {
    verifyPaginatedDeviceWithConfigContextListExists(e.id);
  });
});

bthread("PaginatedDeviceWithConfigContextList update verification", function () {
  const e = waitForAnyPaginatedDeviceWithConfigContextListUpdated();
  block(matchDeletePaginatedDeviceWithConfigContextList(e.id, ANY), function () {
    verifyPaginatedDeviceWithConfigContextListUpdated(e.id);
  });
});

bthread("PaginatedDeviceWithConfigContextList delete verification", function () {
  const e = waitForAnyPaginatedDeviceWithConfigContextListDeleted();
  block(matchAddPaginatedDeviceWithConfigContextList(e.id, ANY), function () {
    verifyPaginatedDeviceWithConfigContextListDoesNotExist(e.id);
  });
});

bthread("VirtualChassisRequest create verification", function () {
  const e = waitForAnyVirtualChassisRequestAdded();
  block(matchDeleteVirtualChassisRequest(e.id, ANY), function () {
    verifyVirtualChassisRequestExists(e.id);
  });
});

bthread("VirtualChassisRequest update verification", function () {
  const e = waitForAnyVirtualChassisRequestUpdated();
  block(matchDeleteVirtualChassisRequest(e.id, ANY), function () {
    verifyVirtualChassisRequestUpdated(e.id);
  });
});

bthread("VirtualChassisRequest delete verification", function () {
  const e = waitForAnyVirtualChassisRequestDeleted();
  block(matchAddVirtualChassisRequest(e.id, ANY), function () {
    verifyVirtualChassisRequestDoesNotExist(e.id);
  });
});

bthread("WritableSiteGroupRequest create verification", function () {
  const e = waitForAnyWritableSiteGroupRequestAdded();
  block(matchDeleteWritableSiteGroupRequest(e.id, ANY), function () {
    verifyWritableSiteGroupRequestExists(e.id);
  });
});

bthread("WritableSiteGroupRequest update verification", function () {
  const e = waitForAnyWritableSiteGroupRequestUpdated();
  block(matchDeleteWritableSiteGroupRequest(e.id, ANY), function () {
    verifyWritableSiteGroupRequestUpdated(e.id);
  });
});

bthread("WritableSiteGroupRequest delete verification", function () {
  const e = waitForAnyWritableSiteGroupRequestDeleted();
  block(matchAddWritableSiteGroupRequest(e.id, ANY), function () {
    verifyWritableSiteGroupRequestDoesNotExist(e.id);
  });
});

bthread("IPSecProfile create verification", function () {
  const e = waitForAnyIPSecProfileAdded();
  block(matchDeleteIPSecProfile(e.id, ANY), function () {
    verifyIPSecProfileExists(e.id);
  });
});

bthread("IPSecProfile update verification", function () {
  const e = waitForAnyIPSecProfileUpdated();
  block(matchDeleteIPSecProfile(e.id, ANY), function () {
    verifyIPSecProfileUpdated(e.id);
  });
});

bthread("IPSecProfile delete verification", function () {
  const e = waitForAnyIPSecProfileDeleted();
  block(matchAddIPSecProfile(e.id, ANY), function () {
    verifyIPSecProfileDoesNotExist(e.id);
  });
});

bthread("BriefL2VPNTermination create verification", function () {
  const e = waitForAnyBriefL2VPNTerminationAdded();
  block(matchDeleteBriefL2VPNTermination(e.id, ANY), function () {
    verifyBriefL2VPNTerminationExists(e.id);
  });
});

bthread("BriefL2VPNTermination update verification", function () {
  const e = waitForAnyBriefL2VPNTerminationUpdated();
  block(matchDeleteBriefL2VPNTermination(e.id, ANY), function () {
    verifyBriefL2VPNTerminationUpdated(e.id);
  });
});

bthread("BriefL2VPNTermination delete verification", function () {
  const e = waitForAnyBriefL2VPNTerminationDeleted();
  block(matchAddBriefL2VPNTermination(e.id, ANY), function () {
    verifyBriefL2VPNTerminationDoesNotExist(e.id);
  });
});

bthread("BriefConfigTemplateRequest create verification", function () {
  const e = waitForAnyBriefConfigTemplateRequestAdded();
  block(matchDeleteBriefConfigTemplateRequest(e.id, ANY), function () {
    verifyBriefConfigTemplateRequestExists(e.id);
  });
});

bthread("BriefConfigTemplateRequest update verification", function () {
  const e = waitForAnyBriefConfigTemplateRequestUpdated();
  block(matchDeleteBriefConfigTemplateRequest(e.id, ANY), function () {
    verifyBriefConfigTemplateRequestUpdated(e.id);
  });
});

bthread("BriefConfigTemplateRequest delete verification", function () {
  const e = waitForAnyBriefConfigTemplateRequestDeleted();
  block(matchAddBriefConfigTemplateRequest(e.id, ANY), function () {
    verifyBriefConfigTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedVLANGroupList create verification", function () {
  const e = waitForAnyPaginatedVLANGroupListAdded();
  block(matchDeletePaginatedVLANGroupList(e.id, ANY), function () {
    verifyPaginatedVLANGroupListExists(e.id);
  });
});

bthread("PaginatedVLANGroupList update verification", function () {
  const e = waitForAnyPaginatedVLANGroupListUpdated();
  block(matchDeletePaginatedVLANGroupList(e.id, ANY), function () {
    verifyPaginatedVLANGroupListUpdated(e.id);
  });
});

bthread("PaginatedVLANGroupList delete verification", function () {
  const e = waitForAnyPaginatedVLANGroupListDeleted();
  block(matchAddPaginatedVLANGroupList(e.id, ANY), function () {
    verifyPaginatedVLANGroupListDoesNotExist(e.id);
  });
});

bthread("PatchedRackRoleRequest create verification", function () {
  const e = waitForAnyPatchedRackRoleRequestAdded();
  block(matchDeletePatchedRackRoleRequest(e.id, ANY), function () {
    verifyPatchedRackRoleRequestExists(e.id);
  });
});

bthread("PatchedRackRoleRequest update verification", function () {
  const e = waitForAnyPatchedRackRoleRequestUpdated();
  block(matchDeletePatchedRackRoleRequest(e.id, ANY), function () {
    verifyPatchedRackRoleRequestUpdated(e.id);
  });
});

bthread("PatchedRackRoleRequest delete verification", function () {
  const e = waitForAnyPatchedRackRoleRequestDeleted();
  block(matchAddPatchedRackRoleRequest(e.id, ANY), function () {
    verifyPatchedRackRoleRequestDoesNotExist(e.id);
  });
});

bthread("VMInterfaceRequest create verification", function () {
  const e = waitForAnyVMInterfaceRequestAdded();
  block(matchDeleteVMInterfaceRequest(e.id, ANY), function () {
    verifyVMInterfaceRequestExists(e.id);
  });
});

bthread("VMInterfaceRequest update verification", function () {
  const e = waitForAnyVMInterfaceRequestUpdated();
  block(matchDeleteVMInterfaceRequest(e.id, ANY), function () {
    verifyVMInterfaceRequestUpdated(e.id);
  });
});

bthread("VMInterfaceRequest delete verification", function () {
  const e = waitForAnyVMInterfaceRequestDeleted();
  block(matchAddVMInterfaceRequest(e.id, ANY), function () {
    verifyVMInterfaceRequestDoesNotExist(e.id);
  });
});

bthread("Tag create verification", function () {
  const e = waitForAnyTagAdded();
  block(matchDeleteTag(e.id, ANY), function () {
    verifyTagExists(e.id);
  });
});

bthread("Tag update verification", function () {
  const e = waitForAnyTagUpdated();
  block(matchDeleteTag(e.id, ANY), function () {
    verifyTagUpdated(e.id);
  });
});

bthread("Tag delete verification", function () {
  const e = waitForAnyTagDeleted();
  block(matchAddTag(e.id, ANY), function () {
    verifyTagDoesNotExist(e.id);
  });
});

bthread("BriefTenantRequest create verification", function () {
  const e = waitForAnyBriefTenantRequestAdded();
  block(matchDeleteBriefTenantRequest(e.id, ANY), function () {
    verifyBriefTenantRequestExists(e.id);
  });
});

bthread("BriefTenantRequest update verification", function () {
  const e = waitForAnyBriefTenantRequestUpdated();
  block(matchDeleteBriefTenantRequest(e.id, ANY), function () {
    verifyBriefTenantRequestUpdated(e.id);
  });
});

bthread("BriefTenantRequest delete verification", function () {
  const e = waitForAnyBriefTenantRequestDeleted();
  block(matchAddBriefTenantRequest(e.id, ANY), function () {
    verifyBriefTenantRequestDoesNotExist(e.id);
  });
});

bthread("Cable create verification", function () {
  const e = waitForAnyCableAdded();
  block(matchDeleteCable(e.id, ANY), function () {
    verifyCableExists(e.id);
  });
});

bthread("Cable update verification", function () {
  const e = waitForAnyCableUpdated();
  block(matchDeleteCable(e.id, ANY), function () {
    verifyCableUpdated(e.id);
  });
});

bthread("Cable delete verification", function () {
  const e = waitForAnyCableDeleted();
  block(matchAddCable(e.id, ANY), function () {
    verifyCableDoesNotExist(e.id);
  });
});

bthread("CircuitGroup create verification", function () {
  const e = waitForAnyCircuitGroupAdded();
  block(matchDeleteCircuitGroup(e.id, ANY), function () {
    verifyCircuitGroupExists(e.id);
  });
});

bthread("CircuitGroup update verification", function () {
  const e = waitForAnyCircuitGroupUpdated();
  block(matchDeleteCircuitGroup(e.id, ANY), function () {
    verifyCircuitGroupUpdated(e.id);
  });
});

bthread("CircuitGroup delete verification", function () {
  const e = waitForAnyCircuitGroupDeleted();
  block(matchAddCircuitGroup(e.id, ANY), function () {
    verifyCircuitGroupDoesNotExist(e.id);
  });
});

bthread("PatchedObjectPermissionRequest create verification", function () {
  const e = waitForAnyPatchedObjectPermissionRequestAdded();
  block(matchDeletePatchedObjectPermissionRequest(e.id, ANY), function () {
    verifyPatchedObjectPermissionRequestExists(e.id);
  });
});

bthread("PatchedObjectPermissionRequest update verification", function () {
  const e = waitForAnyPatchedObjectPermissionRequestUpdated();
  block(matchDeletePatchedObjectPermissionRequest(e.id, ANY), function () {
    verifyPatchedObjectPermissionRequestUpdated(e.id);
  });
});

bthread("PatchedObjectPermissionRequest delete verification", function () {
  const e = waitForAnyPatchedObjectPermissionRequestDeleted();
  block(matchAddPatchedObjectPermissionRequest(e.id, ANY), function () {
    verifyPatchedObjectPermissionRequestDoesNotExist(e.id);
  });
});

bthread("FHRPGroup create verification", function () {
  const e = waitForAnyFHRPGroupAdded();
  block(matchDeleteFHRPGroup(e.id, ANY), function () {
    verifyFHRPGroupExists(e.id);
  });
});

bthread("FHRPGroup update verification", function () {
  const e = waitForAnyFHRPGroupUpdated();
  block(matchDeleteFHRPGroup(e.id, ANY), function () {
    verifyFHRPGroupUpdated(e.id);
  });
});

bthread("FHRPGroup delete verification", function () {
  const e = waitForAnyFHRPGroupDeleted();
  block(matchAddFHRPGroup(e.id, ANY), function () {
    verifyFHRPGroupDoesNotExist(e.id);
  });
});

bthread("IPRange create verification", function () {
  const e = waitForAnyIPRangeAdded();
  block(matchDeleteIPRange(e.id, ANY), function () {
    verifyIPRangeExists(e.id);
  });
});

bthread("IPRange update verification", function () {
  const e = waitForAnyIPRangeUpdated();
  block(matchDeleteIPRange(e.id, ANY), function () {
    verifyIPRangeUpdated(e.id);
  });
});

bthread("IPRange delete verification", function () {
  const e = waitForAnyIPRangeDeleted();
  block(matchAddIPRange(e.id, ANY), function () {
    verifyIPRangeDoesNotExist(e.id);
  });
});

bthread("ModuleBayRequest create verification", function () {
  const e = waitForAnyModuleBayRequestAdded();
  block(matchDeleteModuleBayRequest(e.id, ANY), function () {
    verifyModuleBayRequestExists(e.id);
  });
});

bthread("ModuleBayRequest update verification", function () {
  const e = waitForAnyModuleBayRequestUpdated();
  block(matchDeleteModuleBayRequest(e.id, ANY), function () {
    verifyModuleBayRequestUpdated(e.id);
  });
});

bthread("ModuleBayRequest delete verification", function () {
  const e = waitForAnyModuleBayRequestDeleted();
  block(matchAddModuleBayRequest(e.id, ANY), function () {
    verifyModuleBayRequestDoesNotExist(e.id);
  });
});

bthread("ModuleType create verification", function () {
  const e = waitForAnyModuleTypeAdded();
  block(matchDeleteModuleType(e.id, ANY), function () {
    verifyModuleTypeExists(e.id);
  });
});

bthread("ModuleType update verification", function () {
  const e = waitForAnyModuleTypeUpdated();
  block(matchDeleteModuleType(e.id, ANY), function () {
    verifyModuleTypeUpdated(e.id);
  });
});

bthread("ModuleType delete verification", function () {
  const e = waitForAnyModuleTypeDeleted();
  block(matchAddModuleType(e.id, ANY), function () {
    verifyModuleTypeDoesNotExist(e.id);
  });
});

bthread("BriefVirtualCircuitType create verification", function () {
  const e = waitForAnyBriefVirtualCircuitTypeAdded();
  block(matchDeleteBriefVirtualCircuitType(e.id, ANY), function () {
    verifyBriefVirtualCircuitTypeExists(e.id);
  });
});

bthread("BriefVirtualCircuitType update verification", function () {
  const e = waitForAnyBriefVirtualCircuitTypeUpdated();
  block(matchDeleteBriefVirtualCircuitType(e.id, ANY), function () {
    verifyBriefVirtualCircuitTypeUpdated(e.id);
  });
});

bthread("BriefVirtualCircuitType delete verification", function () {
  const e = waitForAnyBriefVirtualCircuitTypeDeleted();
  block(matchAddBriefVirtualCircuitType(e.id, ANY), function () {
    verifyBriefVirtualCircuitTypeDoesNotExist(e.id);
  });
});

bthread("PaginatedRoleList create verification", function () {
  const e = waitForAnyPaginatedRoleListAdded();
  block(matchDeletePaginatedRoleList(e.id, ANY), function () {
    verifyPaginatedRoleListExists(e.id);
  });
});

bthread("PaginatedRoleList update verification", function () {
  const e = waitForAnyPaginatedRoleListUpdated();
  block(matchDeletePaginatedRoleList(e.id, ANY), function () {
    verifyPaginatedRoleListUpdated(e.id);
  });
});

bthread("PaginatedRoleList delete verification", function () {
  const e = waitForAnyPaginatedRoleListDeleted();
  block(matchAddPaginatedRoleList(e.id, ANY), function () {
    verifyPaginatedRoleListDoesNotExist(e.id);
  });
});

bthread("Tunnel create verification", function () {
  const e = waitForAnyTunnelAdded();
  block(matchDeleteTunnel(e.id, ANY), function () {
    verifyTunnelExists(e.id);
  });
});

bthread("Tunnel update verification", function () {
  const e = waitForAnyTunnelUpdated();
  block(matchDeleteTunnel(e.id, ANY), function () {
    verifyTunnelUpdated(e.id);
  });
});

bthread("Tunnel delete verification", function () {
  const e = waitForAnyTunnelDeleted();
  block(matchAddTunnel(e.id, ANY), function () {
    verifyTunnelDoesNotExist(e.id);
  });
});

bthread("BriefVRFRequest create verification", function () {
  const e = waitForAnyBriefVRFRequestAdded();
  block(matchDeleteBriefVRFRequest(e.id, ANY), function () {
    verifyBriefVRFRequestExists(e.id);
  });
});

bthread("BriefVRFRequest update verification", function () {
  const e = waitForAnyBriefVRFRequestUpdated();
  block(matchDeleteBriefVRFRequest(e.id, ANY), function () {
    verifyBriefVRFRequestUpdated(e.id);
  });
});

bthread("BriefVRFRequest delete verification", function () {
  const e = waitForAnyBriefVRFRequestDeleted();
  block(matchAddBriefVRFRequest(e.id, ANY), function () {
    verifyBriefVRFRequestDoesNotExist(e.id);
  });
});

bthread("RoleRequest create verification", function () {
  const e = waitForAnyRoleRequestAdded();
  block(matchDeleteRoleRequest(e.id, ANY), function () {
    verifyRoleRequestExists(e.id);
  });
});

bthread("RoleRequest update verification", function () {
  const e = waitForAnyRoleRequestUpdated();
  block(matchDeleteRoleRequest(e.id, ANY), function () {
    verifyRoleRequestUpdated(e.id);
  });
});

bthread("RoleRequest delete verification", function () {
  const e = waitForAnyRoleRequestDeleted();
  block(matchAddRoleRequest(e.id, ANY), function () {
    verifyRoleRequestDoesNotExist(e.id);
  });
});

bthread("ConsolePortTemplate create verification", function () {
  const e = waitForAnyConsolePortTemplateAdded();
  block(matchDeleteConsolePortTemplate(e.id, ANY), function () {
    verifyConsolePortTemplateExists(e.id);
  });
});

bthread("ConsolePortTemplate update verification", function () {
  const e = waitForAnyConsolePortTemplateUpdated();
  block(matchDeleteConsolePortTemplate(e.id, ANY), function () {
    verifyConsolePortTemplateUpdated(e.id);
  });
});

bthread("ConsolePortTemplate delete verification", function () {
  const e = waitForAnyConsolePortTemplateDeleted();
  block(matchAddConsolePortTemplate(e.id, ANY), function () {
    verifyConsolePortTemplateDoesNotExist(e.id);
  });
});

bthread("UserRequest create verification", function () {
  const e = waitForAnyUserRequestAdded();
  block(matchDeleteUserRequest(e.id, ANY), function () {
    verifyUserRequestExists(e.id);
  });
});

bthread("UserRequest update verification", function () {
  const e = waitForAnyUserRequestUpdated();
  block(matchDeleteUserRequest(e.id, ANY), function () {
    verifyUserRequestUpdated(e.id);
  });
});

bthread("UserRequest delete verification", function () {
  const e = waitForAnyUserRequestDeleted();
  block(matchAddUserRequest(e.id, ANY), function () {
    verifyUserRequestDoesNotExist(e.id);
  });
});

bthread("WritableContactAssignmentRequest create verification", function () {
  const e = waitForAnyWritableContactAssignmentRequestAdded();
  block(matchDeleteWritableContactAssignmentRequest(e.id, ANY), function () {
    verifyWritableContactAssignmentRequestExists(e.id);
  });
});

bthread("WritableContactAssignmentRequest update verification", function () {
  const e = waitForAnyWritableContactAssignmentRequestUpdated();
  block(matchDeleteWritableContactAssignmentRequest(e.id, ANY), function () {
    verifyWritableContactAssignmentRequestUpdated(e.id);
  });
});

bthread("WritableContactAssignmentRequest delete verification", function () {
  const e = waitForAnyWritableContactAssignmentRequestDeleted();
  block(matchAddWritableContactAssignmentRequest(e.id, ANY), function () {
    verifyWritableContactAssignmentRequestDoesNotExist(e.id);
  });
});

bthread("Cluster create verification", function () {
  const e = waitForAnyClusterAdded();
  block(matchDeleteCluster(e.id, ANY), function () {
    verifyClusterExists(e.id);
  });
});

bthread("Cluster update verification", function () {
  const e = waitForAnyClusterUpdated();
  block(matchDeleteCluster(e.id, ANY), function () {
    verifyClusterUpdated(e.id);
  });
});

bthread("Cluster delete verification", function () {
  const e = waitForAnyClusterDeleted();
  block(matchAddCluster(e.id, ANY), function () {
    verifyClusterDoesNotExist(e.id);
  });
});

bthread("IPSecProposal create verification", function () {
  const e = waitForAnyIPSecProposalAdded();
  block(matchDeleteIPSecProposal(e.id, ANY), function () {
    verifyIPSecProposalExists(e.id);
  });
});

bthread("IPSecProposal update verification", function () {
  const e = waitForAnyIPSecProposalUpdated();
  block(matchDeleteIPSecProposal(e.id, ANY), function () {
    verifyIPSecProposalUpdated(e.id);
  });
});

bthread("IPSecProposal delete verification", function () {
  const e = waitForAnyIPSecProposalDeleted();
  block(matchAddIPSecProposal(e.id, ANY), function () {
    verifyIPSecProposalDoesNotExist(e.id);
  });
});

bthread("PaginatedPowerOutletTemplateList create verification", function () {
  const e = waitForAnyPaginatedPowerOutletTemplateListAdded();
  block(matchDeletePaginatedPowerOutletTemplateList(e.id, ANY), function () {
    verifyPaginatedPowerOutletTemplateListExists(e.id);
  });
});

bthread("PaginatedPowerOutletTemplateList update verification", function () {
  const e = waitForAnyPaginatedPowerOutletTemplateListUpdated();
  block(matchDeletePaginatedPowerOutletTemplateList(e.id, ANY), function () {
    verifyPaginatedPowerOutletTemplateListUpdated(e.id);
  });
});

bthread("PaginatedPowerOutletTemplateList delete verification", function () {
  const e = waitForAnyPaginatedPowerOutletTemplateListDeleted();
  block(matchAddPaginatedPowerOutletTemplateList(e.id, ANY), function () {
    verifyPaginatedPowerOutletTemplateListDoesNotExist(e.id);
  });
});

bthread("FrontPortRearPortRequest create verification", function () {
  const e = waitForAnyFrontPortRearPortRequestAdded();
  block(matchDeleteFrontPortRearPortRequest(e.id, ANY), function () {
    verifyFrontPortRearPortRequestExists(e.id);
  });
});

bthread("FrontPortRearPortRequest update verification", function () {
  const e = waitForAnyFrontPortRearPortRequestUpdated();
  block(matchDeleteFrontPortRearPortRequest(e.id, ANY), function () {
    verifyFrontPortRearPortRequestUpdated(e.id);
  });
});

bthread("FrontPortRearPortRequest delete verification", function () {
  const e = waitForAnyFrontPortRearPortRequestDeleted();
  block(matchAddFrontPortRearPortRequest(e.id, ANY), function () {
    verifyFrontPortRearPortRequestDoesNotExist(e.id);
  });
});

bthread("WritableClusterRequest create verification", function () {
  const e = waitForAnyWritableClusterRequestAdded();
  block(matchDeleteWritableClusterRequest(e.id, ANY), function () {
    verifyWritableClusterRequestExists(e.id);
  });
});

bthread("WritableClusterRequest update verification", function () {
  const e = waitForAnyWritableClusterRequestUpdated();
  block(matchDeleteWritableClusterRequest(e.id, ANY), function () {
    verifyWritableClusterRequestUpdated(e.id);
  });
});

bthread("WritableClusterRequest delete verification", function () {
  const e = waitForAnyWritableClusterRequestDeleted();
  block(matchAddWritableClusterRequest(e.id, ANY), function () {
    verifyWritableClusterRequestDoesNotExist(e.id);
  });
});

bthread("NestedProviderAccount create verification", function () {
  const e = waitForAnyNestedProviderAccountAdded();
  block(matchDeleteNestedProviderAccount(e.id, ANY), function () {
    verifyNestedProviderAccountExists(e.id);
  });
});

bthread("NestedProviderAccount update verification", function () {
  const e = waitForAnyNestedProviderAccountUpdated();
  block(matchDeleteNestedProviderAccount(e.id, ANY), function () {
    verifyNestedProviderAccountUpdated(e.id);
  });
});

bthread("NestedProviderAccount delete verification", function () {
  const e = waitForAnyNestedProviderAccountDeleted();
  block(matchAddNestedProviderAccount(e.id, ANY), function () {
    verifyNestedProviderAccountDoesNotExist(e.id);
  });
});

bthread("PatchedDashboardRequest create verification", function () {
  const e = waitForAnyPatchedDashboardRequestAdded();
  block(matchDeletePatchedDashboardRequest(e.id, ANY), function () {
    verifyPatchedDashboardRequestExists(e.id);
  });
});

bthread("PatchedDashboardRequest update verification", function () {
  const e = waitForAnyPatchedDashboardRequestUpdated();
  block(matchDeletePatchedDashboardRequest(e.id, ANY), function () {
    verifyPatchedDashboardRequestUpdated(e.id);
  });
});

bthread("PatchedDashboardRequest delete verification", function () {
  const e = waitForAnyPatchedDashboardRequestDeleted();
  block(matchAddPatchedDashboardRequest(e.id, ANY), function () {
    verifyPatchedDashboardRequestDoesNotExist(e.id);
  });
});

bthread("PowerPanelRequest create verification", function () {
  const e = waitForAnyPowerPanelRequestAdded();
  block(matchDeletePowerPanelRequest(e.id, ANY), function () {
    verifyPowerPanelRequestExists(e.id);
  });
});

bthread("PowerPanelRequest update verification", function () {
  const e = waitForAnyPowerPanelRequestUpdated();
  block(matchDeletePowerPanelRequest(e.id, ANY), function () {
    verifyPowerPanelRequestUpdated(e.id);
  });
});

bthread("PowerPanelRequest delete verification", function () {
  const e = waitForAnyPowerPanelRequestDeleted();
  block(matchAddPowerPanelRequest(e.id, ANY), function () {
    verifyPowerPanelRequestDoesNotExist(e.id);
  });
});

bthread("NestedVirtualMachineRequest create verification", function () {
  const e = waitForAnyNestedVirtualMachineRequestAdded();
  block(matchDeleteNestedVirtualMachineRequest(e.id, ANY), function () {
    verifyNestedVirtualMachineRequestExists(e.id);
  });
});

bthread("NestedVirtualMachineRequest update verification", function () {
  const e = waitForAnyNestedVirtualMachineRequestUpdated();
  block(matchDeleteNestedVirtualMachineRequest(e.id, ANY), function () {
    verifyNestedVirtualMachineRequestUpdated(e.id);
  });
});

bthread("NestedVirtualMachineRequest delete verification", function () {
  const e = waitForAnyNestedVirtualMachineRequestDeleted();
  block(matchAddNestedVirtualMachineRequest(e.id, ANY), function () {
    verifyNestedVirtualMachineRequestDoesNotExist(e.id);
  });
});

bthread("BriefPowerPanel create verification", function () {
  const e = waitForAnyBriefPowerPanelAdded();
  block(matchDeleteBriefPowerPanel(e.id, ANY), function () {
    verifyBriefPowerPanelExists(e.id);
  });
});

bthread("BriefPowerPanel update verification", function () {
  const e = waitForAnyBriefPowerPanelUpdated();
  block(matchDeleteBriefPowerPanel(e.id, ANY), function () {
    verifyBriefPowerPanelUpdated(e.id);
  });
});

bthread("BriefPowerPanel delete verification", function () {
  const e = waitForAnyBriefPowerPanelDeleted();
  block(matchAddBriefPowerPanel(e.id, ANY), function () {
    verifyBriefPowerPanelDoesNotExist(e.id);
  });
});

bthread("WritableIKEProposalRequest create verification", function () {
  const e = waitForAnyWritableIKEProposalRequestAdded();
  block(matchDeleteWritableIKEProposalRequest(e.id, ANY), function () {
    verifyWritableIKEProposalRequestExists(e.id);
  });
});

bthread("WritableIKEProposalRequest update verification", function () {
  const e = waitForAnyWritableIKEProposalRequestUpdated();
  block(matchDeleteWritableIKEProposalRequest(e.id, ANY), function () {
    verifyWritableIKEProposalRequestUpdated(e.id);
  });
});

bthread("WritableIKEProposalRequest delete verification", function () {
  const e = waitForAnyWritableIKEProposalRequestDeleted();
  block(matchAddWritableIKEProposalRequest(e.id, ANY), function () {
    verifyWritableIKEProposalRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedFHRPGroupList create verification", function () {
  const e = waitForAnyPaginatedFHRPGroupListAdded();
  block(matchDeletePaginatedFHRPGroupList(e.id, ANY), function () {
    verifyPaginatedFHRPGroupListExists(e.id);
  });
});

bthread("PaginatedFHRPGroupList update verification", function () {
  const e = waitForAnyPaginatedFHRPGroupListUpdated();
  block(matchDeletePaginatedFHRPGroupList(e.id, ANY), function () {
    verifyPaginatedFHRPGroupListUpdated(e.id);
  });
});

bthread("PaginatedFHRPGroupList delete verification", function () {
  const e = waitForAnyPaginatedFHRPGroupListDeleted();
  block(matchAddPaginatedFHRPGroupList(e.id, ANY), function () {
    verifyPaginatedFHRPGroupListDoesNotExist(e.id);
  });
});

bthread("BriefRole create verification", function () {
  const e = waitForAnyBriefRoleAdded();
  block(matchDeleteBriefRole(e.id, ANY), function () {
    verifyBriefRoleExists(e.id);
  });
});

bthread("BriefRole update verification", function () {
  const e = waitForAnyBriefRoleUpdated();
  block(matchDeleteBriefRole(e.id, ANY), function () {
    verifyBriefRoleUpdated(e.id);
  });
});

bthread("BriefRole delete verification", function () {
  const e = waitForAnyBriefRoleDeleted();
  block(matchAddBriefRole(e.id, ANY), function () {
    verifyBriefRoleDoesNotExist(e.id);
  });
});

bthread("PaginatedCircuitList create verification", function () {
  const e = waitForAnyPaginatedCircuitListAdded();
  block(matchDeletePaginatedCircuitList(e.id, ANY), function () {
    verifyPaginatedCircuitListExists(e.id);
  });
});

bthread("PaginatedCircuitList update verification", function () {
  const e = waitForAnyPaginatedCircuitListUpdated();
  block(matchDeletePaginatedCircuitList(e.id, ANY), function () {
    verifyPaginatedCircuitListUpdated(e.id);
  });
});

bthread("PaginatedCircuitList delete verification", function () {
  const e = waitForAnyPaginatedCircuitListDeleted();
  block(matchAddPaginatedCircuitList(e.id, ANY), function () {
    verifyPaginatedCircuitListDoesNotExist(e.id);
  });
});

bthread("PatchedWritableSiteRequest create verification", function () {
  const e = waitForAnyPatchedWritableSiteRequestAdded();
  block(matchDeletePatchedWritableSiteRequest(e.id, ANY), function () {
    verifyPatchedWritableSiteRequestExists(e.id);
  });
});

bthread("PatchedWritableSiteRequest update verification", function () {
  const e = waitForAnyPatchedWritableSiteRequestUpdated();
  block(matchDeletePatchedWritableSiteRequest(e.id, ANY), function () {
    verifyPatchedWritableSiteRequestUpdated(e.id);
  });
});

bthread("PatchedWritableSiteRequest delete verification", function () {
  const e = waitForAnyPatchedWritableSiteRequestDeleted();
  block(matchAddPatchedWritableSiteRequest(e.id, ANY), function () {
    verifyPatchedWritableSiteRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedTunnelGroupList create verification", function () {
  const e = waitForAnyPaginatedTunnelGroupListAdded();
  block(matchDeletePaginatedTunnelGroupList(e.id, ANY), function () {
    verifyPaginatedTunnelGroupListExists(e.id);
  });
});

bthread("PaginatedTunnelGroupList update verification", function () {
  const e = waitForAnyPaginatedTunnelGroupListUpdated();
  block(matchDeletePaginatedTunnelGroupList(e.id, ANY), function () {
    verifyPaginatedTunnelGroupListUpdated(e.id);
  });
});

bthread("PaginatedTunnelGroupList delete verification", function () {
  const e = waitForAnyPaginatedTunnelGroupListDeleted();
  block(matchAddPaginatedTunnelGroupList(e.id, ANY), function () {
    verifyPaginatedTunnelGroupListDoesNotExist(e.id);
  });
});

bthread("VirtualCircuitTypeRequest create verification", function () {
  const e = waitForAnyVirtualCircuitTypeRequestAdded();
  block(matchDeleteVirtualCircuitTypeRequest(e.id, ANY), function () {
    verifyVirtualCircuitTypeRequestExists(e.id);
  });
});

bthread("VirtualCircuitTypeRequest update verification", function () {
  const e = waitForAnyVirtualCircuitTypeRequestUpdated();
  block(matchDeleteVirtualCircuitTypeRequest(e.id, ANY), function () {
    verifyVirtualCircuitTypeRequestUpdated(e.id);
  });
});

bthread("VirtualCircuitTypeRequest delete verification", function () {
  const e = waitForAnyVirtualCircuitTypeRequestDeleted();
  block(matchAddVirtualCircuitTypeRequest(e.id, ANY), function () {
    verifyVirtualCircuitTypeRequestDoesNotExist(e.id);
  });
});

bthread("BriefCircuitType create verification", function () {
  const e = waitForAnyBriefCircuitTypeAdded();
  block(matchDeleteBriefCircuitType(e.id, ANY), function () {
    verifyBriefCircuitTypeExists(e.id);
  });
});

bthread("BriefCircuitType update verification", function () {
  const e = waitForAnyBriefCircuitTypeUpdated();
  block(matchDeleteBriefCircuitType(e.id, ANY), function () {
    verifyBriefCircuitTypeUpdated(e.id);
  });
});

bthread("BriefCircuitType delete verification", function () {
  const e = waitForAnyBriefCircuitTypeDeleted();
  block(matchAddBriefCircuitType(e.id, ANY), function () {
    verifyBriefCircuitTypeDoesNotExist(e.id);
  });
});

bthread("TunnelGroup create verification", function () {
  const e = waitForAnyTunnelGroupAdded();
  block(matchDeleteTunnelGroup(e.id, ANY), function () {
    verifyTunnelGroupExists(e.id);
  });
});

bthread("TunnelGroup update verification", function () {
  const e = waitForAnyTunnelGroupUpdated();
  block(matchDeleteTunnelGroup(e.id, ANY), function () {
    verifyTunnelGroupUpdated(e.id);
  });
});

bthread("TunnelGroup delete verification", function () {
  const e = waitForAnyTunnelGroupDeleted();
  block(matchAddTunnelGroup(e.id, ANY), function () {
    verifyTunnelGroupDoesNotExist(e.id);
  });
});

bthread("BriefProvider create verification", function () {
  const e = waitForAnyBriefProviderAdded();
  block(matchDeleteBriefProvider(e.id, ANY), function () {
    verifyBriefProviderExists(e.id);
  });
});

bthread("BriefProvider update verification", function () {
  const e = waitForAnyBriefProviderUpdated();
  block(matchDeleteBriefProvider(e.id, ANY), function () {
    verifyBriefProviderUpdated(e.id);
  });
});

bthread("BriefProvider delete verification", function () {
  const e = waitForAnyBriefProviderDeleted();
  block(matchAddBriefProvider(e.id, ANY), function () {
    verifyBriefProviderDoesNotExist(e.id);
  });
});

bthread("L2VPNTerminationRequest create verification", function () {
  const e = waitForAnyL2VPNTerminationRequestAdded();
  block(matchDeleteL2VPNTerminationRequest(e.id, ANY), function () {
    verifyL2VPNTerminationRequestExists(e.id);
  });
});

bthread("L2VPNTerminationRequest update verification", function () {
  const e = waitForAnyL2VPNTerminationRequestUpdated();
  block(matchDeleteL2VPNTerminationRequest(e.id, ANY), function () {
    verifyL2VPNTerminationRequestUpdated(e.id);
  });
});

bthread("L2VPNTerminationRequest delete verification", function () {
  const e = waitForAnyL2VPNTerminationRequestDeleted();
  block(matchAddL2VPNTerminationRequest(e.id, ANY), function () {
    verifyL2VPNTerminationRequestDoesNotExist(e.id);
  });
});

bthread("PatchedGroupRequest create verification", function () {
  const e = waitForAnyPatchedGroupRequestAdded();
  block(matchDeletePatchedGroupRequest(e.id, ANY), function () {
    verifyPatchedGroupRequestExists(e.id);
  });
});

bthread("PatchedGroupRequest update verification", function () {
  const e = waitForAnyPatchedGroupRequestUpdated();
  block(matchDeletePatchedGroupRequest(e.id, ANY), function () {
    verifyPatchedGroupRequestUpdated(e.id);
  });
});

bthread("PatchedGroupRequest delete verification", function () {
  const e = waitForAnyPatchedGroupRequestDeleted();
  block(matchAddPatchedGroupRequest(e.id, ANY), function () {
    verifyPatchedGroupRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableConsolePortTemplateRequest create verification", function () {
  const e = waitForAnyPatchedWritableConsolePortTemplateRequestAdded();
  block(matchDeletePatchedWritableConsolePortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableConsolePortTemplateRequestExists(e.id);
  });
});

bthread("PatchedWritableConsolePortTemplateRequest update verification", function () {
  const e = waitForAnyPatchedWritableConsolePortTemplateRequestUpdated();
  block(matchDeletePatchedWritableConsolePortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableConsolePortTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedWritableConsolePortTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedWritableConsolePortTemplateRequestDeleted();
  block(matchAddPatchedWritableConsolePortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableConsolePortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("AvailableASN create verification", function () {
  const e = waitForAnyAvailableASNAdded();
  block(matchDeleteAvailableASN(e.id, ANY), function () {
    verifyAvailableASNExists(e.id);
  });
});

bthread("AvailableASN update verification", function () {
  const e = waitForAnyAvailableASNUpdated();
  block(matchDeleteAvailableASN(e.id, ANY), function () {
    verifyAvailableASNUpdated(e.id);
  });
});

bthread("AvailableASN delete verification", function () {
  const e = waitForAnyAvailableASNDeleted();
  block(matchAddAvailableASN(e.id, ANY), function () {
    verifyAvailableASNDoesNotExist(e.id);
  });
});

bthread("BriefDeviceRole create verification", function () {
  const e = waitForAnyBriefDeviceRoleAdded();
  block(matchDeleteBriefDeviceRole(e.id, ANY), function () {
    verifyBriefDeviceRoleExists(e.id);
  });
});

bthread("BriefDeviceRole update verification", function () {
  const e = waitForAnyBriefDeviceRoleUpdated();
  block(matchDeleteBriefDeviceRole(e.id, ANY), function () {
    verifyBriefDeviceRoleUpdated(e.id);
  });
});

bthread("BriefDeviceRole delete verification", function () {
  const e = waitForAnyBriefDeviceRoleDeleted();
  block(matchAddBriefDeviceRole(e.id, ANY), function () {
    verifyBriefDeviceRoleDoesNotExist(e.id);
  });
});

bthread("VirtualDisk create verification", function () {
  const e = waitForAnyVirtualDiskAdded();
  block(matchDeleteVirtualDisk(e.id, ANY), function () {
    verifyVirtualDiskExists(e.id);
  });
});

bthread("VirtualDisk update verification", function () {
  const e = waitForAnyVirtualDiskUpdated();
  block(matchDeleteVirtualDisk(e.id, ANY), function () {
    verifyVirtualDiskUpdated(e.id);
  });
});

bthread("VirtualDisk delete verification", function () {
  const e = waitForAnyVirtualDiskDeleted();
  block(matchAddVirtualDisk(e.id, ANY), function () {
    verifyVirtualDiskDoesNotExist(e.id);
  });
});

bthread("IKEProposalRequest create verification", function () {
  const e = waitForAnyIKEProposalRequestAdded();
  block(matchDeleteIKEProposalRequest(e.id, ANY), function () {
    verifyIKEProposalRequestExists(e.id);
  });
});

bthread("IKEProposalRequest update verification", function () {
  const e = waitForAnyIKEProposalRequestUpdated();
  block(matchDeleteIKEProposalRequest(e.id, ANY), function () {
    verifyIKEProposalRequestUpdated(e.id);
  });
});

bthread("IKEProposalRequest delete verification", function () {
  const e = waitForAnyIKEProposalRequestDeleted();
  block(matchAddIKEProposalRequest(e.id, ANY), function () {
    verifyIKEProposalRequestDoesNotExist(e.id);
  });
});

bthread("PatchedTunnelGroupRequest create verification", function () {
  const e = waitForAnyPatchedTunnelGroupRequestAdded();
  block(matchDeletePatchedTunnelGroupRequest(e.id, ANY), function () {
    verifyPatchedTunnelGroupRequestExists(e.id);
  });
});

bthread("PatchedTunnelGroupRequest update verification", function () {
  const e = waitForAnyPatchedTunnelGroupRequestUpdated();
  block(matchDeletePatchedTunnelGroupRequest(e.id, ANY), function () {
    verifyPatchedTunnelGroupRequestUpdated(e.id);
  });
});

bthread("PatchedTunnelGroupRequest delete verification", function () {
  const e = waitForAnyPatchedTunnelGroupRequestDeleted();
  block(matchAddPatchedTunnelGroupRequest(e.id, ANY), function () {
    verifyPatchedTunnelGroupRequestDoesNotExist(e.id);
  });
});

bthread("BriefModuleRequest create verification", function () {
  const e = waitForAnyBriefModuleRequestAdded();
  block(matchDeleteBriefModuleRequest(e.id, ANY), function () {
    verifyBriefModuleRequestExists(e.id);
  });
});

bthread("BriefModuleRequest update verification", function () {
  const e = waitForAnyBriefModuleRequestUpdated();
  block(matchDeleteBriefModuleRequest(e.id, ANY), function () {
    verifyBriefModuleRequestUpdated(e.id);
  });
});

bthread("BriefModuleRequest delete verification", function () {
  const e = waitForAnyBriefModuleRequestDeleted();
  block(matchAddBriefModuleRequest(e.id, ANY), function () {
    verifyBriefModuleRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedFrontPortList create verification", function () {
  const e = waitForAnyPaginatedFrontPortListAdded();
  block(matchDeletePaginatedFrontPortList(e.id, ANY), function () {
    verifyPaginatedFrontPortListExists(e.id);
  });
});

bthread("PaginatedFrontPortList update verification", function () {
  const e = waitForAnyPaginatedFrontPortListUpdated();
  block(matchDeletePaginatedFrontPortList(e.id, ANY), function () {
    verifyPaginatedFrontPortListUpdated(e.id);
  });
});

bthread("PaginatedFrontPortList delete verification", function () {
  const e = waitForAnyPaginatedFrontPortListDeleted();
  block(matchAddPaginatedFrontPortList(e.id, ANY), function () {
    verifyPaginatedFrontPortListDoesNotExist(e.id);
  });
});

bthread("BriefVLANGroup create verification", function () {
  const e = waitForAnyBriefVLANGroupAdded();
  block(matchDeleteBriefVLANGroup(e.id, ANY), function () {
    verifyBriefVLANGroupExists(e.id);
  });
});

bthread("BriefVLANGroup update verification", function () {
  const e = waitForAnyBriefVLANGroupUpdated();
  block(matchDeleteBriefVLANGroup(e.id, ANY), function () {
    verifyBriefVLANGroupUpdated(e.id);
  });
});

bthread("BriefVLANGroup delete verification", function () {
  const e = waitForAnyBriefVLANGroupDeleted();
  block(matchAddBriefVLANGroup(e.id, ANY), function () {
    verifyBriefVLANGroupDoesNotExist(e.id);
  });
});

bthread("NotificationGroup create verification", function () {
  const e = waitForAnyNotificationGroupAdded();
  block(matchDeleteNotificationGroup(e.id, ANY), function () {
    verifyNotificationGroupExists(e.id);
  });
});

bthread("NotificationGroup update verification", function () {
  const e = waitForAnyNotificationGroupUpdated();
  block(matchDeleteNotificationGroup(e.id, ANY), function () {
    verifyNotificationGroupUpdated(e.id);
  });
});

bthread("NotificationGroup delete verification", function () {
  const e = waitForAnyNotificationGroupDeleted();
  block(matchAddNotificationGroup(e.id, ANY), function () {
    verifyNotificationGroupDoesNotExist(e.id);
  });
});

bthread("PaginatedMACAddressList create verification", function () {
  const e = waitForAnyPaginatedMACAddressListAdded();
  block(matchDeletePaginatedMACAddressList(e.id, ANY), function () {
    verifyPaginatedMACAddressListExists(e.id);
  });
});

bthread("PaginatedMACAddressList update verification", function () {
  const e = waitForAnyPaginatedMACAddressListUpdated();
  block(matchDeletePaginatedMACAddressList(e.id, ANY), function () {
    verifyPaginatedMACAddressListUpdated(e.id);
  });
});

bthread("PaginatedMACAddressList delete verification", function () {
  const e = waitForAnyPaginatedMACAddressListDeleted();
  block(matchAddPaginatedMACAddressList(e.id, ANY), function () {
    verifyPaginatedMACAddressListDoesNotExist(e.id);
  });
});

bthread("PatchedWritableIKEPolicyRequest create verification", function () {
  const e = waitForAnyPatchedWritableIKEPolicyRequestAdded();
  block(matchDeletePatchedWritableIKEPolicyRequest(e.id, ANY), function () {
    verifyPatchedWritableIKEPolicyRequestExists(e.id);
  });
});

bthread("PatchedWritableIKEPolicyRequest update verification", function () {
  const e = waitForAnyPatchedWritableIKEPolicyRequestUpdated();
  block(matchDeletePatchedWritableIKEPolicyRequest(e.id, ANY), function () {
    verifyPatchedWritableIKEPolicyRequestUpdated(e.id);
  });
});

bthread("PatchedWritableIKEPolicyRequest delete verification", function () {
  const e = waitForAnyPatchedWritableIKEPolicyRequestDeleted();
  block(matchAddPatchedWritableIKEPolicyRequest(e.id, ANY), function () {
    verifyPatchedWritableIKEPolicyRequestDoesNotExist(e.id);
  });
});

bthread("MACAddressRequest create verification", function () {
  const e = waitForAnyMACAddressRequestAdded();
  block(matchDeleteMACAddressRequest(e.id, ANY), function () {
    verifyMACAddressRequestExists(e.id);
  });
});

bthread("MACAddressRequest update verification", function () {
  const e = waitForAnyMACAddressRequestUpdated();
  block(matchDeleteMACAddressRequest(e.id, ANY), function () {
    verifyMACAddressRequestUpdated(e.id);
  });
});

bthread("MACAddressRequest delete verification", function () {
  const e = waitForAnyMACAddressRequestDeleted();
  block(matchAddMACAddressRequest(e.id, ANY), function () {
    verifyMACAddressRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedInterfaceTemplateList create verification", function () {
  const e = waitForAnyPaginatedInterfaceTemplateListAdded();
  block(matchDeletePaginatedInterfaceTemplateList(e.id, ANY), function () {
    verifyPaginatedInterfaceTemplateListExists(e.id);
  });
});

bthread("PaginatedInterfaceTemplateList update verification", function () {
  const e = waitForAnyPaginatedInterfaceTemplateListUpdated();
  block(matchDeletePaginatedInterfaceTemplateList(e.id, ANY), function () {
    verifyPaginatedInterfaceTemplateListUpdated(e.id);
  });
});

bthread("PaginatedInterfaceTemplateList delete verification", function () {
  const e = waitForAnyPaginatedInterfaceTemplateListDeleted();
  block(matchAddPaginatedInterfaceTemplateList(e.id, ANY), function () {
    verifyPaginatedInterfaceTemplateListDoesNotExist(e.id);
  });
});

bthread("BriefPlatform create verification", function () {
  const e = waitForAnyBriefPlatformAdded();
  block(matchDeleteBriefPlatform(e.id, ANY), function () {
    verifyBriefPlatformExists(e.id);
  });
});

bthread("BriefPlatform update verification", function () {
  const e = waitForAnyBriefPlatformUpdated();
  block(matchDeleteBriefPlatform(e.id, ANY), function () {
    verifyBriefPlatformUpdated(e.id);
  });
});

bthread("BriefPlatform delete verification", function () {
  const e = waitForAnyBriefPlatformDeleted();
  block(matchAddBriefPlatform(e.id, ANY), function () {
    verifyBriefPlatformDoesNotExist(e.id);
  });
});

bthread("PowerFeedRequest create verification", function () {
  const e = waitForAnyPowerFeedRequestAdded();
  block(matchDeletePowerFeedRequest(e.id, ANY), function () {
    verifyPowerFeedRequestExists(e.id);
  });
});

bthread("PowerFeedRequest update verification", function () {
  const e = waitForAnyPowerFeedRequestUpdated();
  block(matchDeletePowerFeedRequest(e.id, ANY), function () {
    verifyPowerFeedRequestUpdated(e.id);
  });
});

bthread("PowerFeedRequest delete verification", function () {
  const e = waitForAnyPowerFeedRequestDeleted();
  block(matchAddPowerFeedRequest(e.id, ANY), function () {
    verifyPowerFeedRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedSubscriptionList create verification", function () {
  const e = waitForAnyPaginatedSubscriptionListAdded();
  block(matchDeletePaginatedSubscriptionList(e.id, ANY), function () {
    verifyPaginatedSubscriptionListExists(e.id);
  });
});

bthread("PaginatedSubscriptionList update verification", function () {
  const e = waitForAnyPaginatedSubscriptionListUpdated();
  block(matchDeletePaginatedSubscriptionList(e.id, ANY), function () {
    verifyPaginatedSubscriptionListUpdated(e.id);
  });
});

bthread("PaginatedSubscriptionList delete verification", function () {
  const e = waitForAnyPaginatedSubscriptionListDeleted();
  block(matchAddPaginatedSubscriptionList(e.id, ANY), function () {
    verifyPaginatedSubscriptionListDoesNotExist(e.id);
  });
});

bthread("WritableInterfaceRequest create verification", function () {
  const e = waitForAnyWritableInterfaceRequestAdded();
  block(matchDeleteWritableInterfaceRequest(e.id, ANY), function () {
    verifyWritableInterfaceRequestExists(e.id);
  });
});

bthread("WritableInterfaceRequest update verification", function () {
  const e = waitForAnyWritableInterfaceRequestUpdated();
  block(matchDeleteWritableInterfaceRequest(e.id, ANY), function () {
    verifyWritableInterfaceRequestUpdated(e.id);
  });
});

bthread("WritableInterfaceRequest delete verification", function () {
  const e = waitForAnyWritableInterfaceRequestDeleted();
  block(matchAddWritableInterfaceRequest(e.id, ANY), function () {
    verifyWritableInterfaceRequestDoesNotExist(e.id);
  });
});

bthread("BriefTag create verification", function () {
  const e = waitForAnyBriefTagAdded();
  block(matchDeleteBriefTag(e.id, ANY), function () {
    verifyBriefTagExists(e.id);
  });
});

bthread("BriefTag update verification", function () {
  const e = waitForAnyBriefTagUpdated();
  block(matchDeleteBriefTag(e.id, ANY), function () {
    verifyBriefTagUpdated(e.id);
  });
});

bthread("BriefTag delete verification", function () {
  const e = waitForAnyBriefTagDeleted();
  block(matchAddBriefTag(e.id, ANY), function () {
    verifyBriefTagDoesNotExist(e.id);
  });
});

bthread("ASNRange create verification", function () {
  const e = waitForAnyASNRangeAdded();
  block(matchDeleteASNRange(e.id, ANY), function () {
    verifyASNRangeExists(e.id);
  });
});

bthread("ASNRange update verification", function () {
  const e = waitForAnyASNRangeUpdated();
  block(matchDeleteASNRange(e.id, ANY), function () {
    verifyASNRangeUpdated(e.id);
  });
});

bthread("ASNRange delete verification", function () {
  const e = waitForAnyASNRangeDeleted();
  block(matchAddASNRange(e.id, ANY), function () {
    verifyASNRangeDoesNotExist(e.id);
  });
});

bthread("PaginatedIKEPolicyList create verification", function () {
  const e = waitForAnyPaginatedIKEPolicyListAdded();
  block(matchDeletePaginatedIKEPolicyList(e.id, ANY), function () {
    verifyPaginatedIKEPolicyListExists(e.id);
  });
});

bthread("PaginatedIKEPolicyList update verification", function () {
  const e = waitForAnyPaginatedIKEPolicyListUpdated();
  block(matchDeletePaginatedIKEPolicyList(e.id, ANY), function () {
    verifyPaginatedIKEPolicyListUpdated(e.id);
  });
});

bthread("PaginatedIKEPolicyList delete verification", function () {
  const e = waitForAnyPaginatedIKEPolicyListDeleted();
  block(matchAddPaginatedIKEPolicyList(e.id, ANY), function () {
    verifyPaginatedIKEPolicyListDoesNotExist(e.id);
  });
});

bthread("PatchedVirtualCircuitTypeRequest create verification", function () {
  const e = waitForAnyPatchedVirtualCircuitTypeRequestAdded();
  block(matchDeletePatchedVirtualCircuitTypeRequest(e.id, ANY), function () {
    verifyPatchedVirtualCircuitTypeRequestExists(e.id);
  });
});

bthread("PatchedVirtualCircuitTypeRequest update verification", function () {
  const e = waitForAnyPatchedVirtualCircuitTypeRequestUpdated();
  block(matchDeletePatchedVirtualCircuitTypeRequest(e.id, ANY), function () {
    verifyPatchedVirtualCircuitTypeRequestUpdated(e.id);
  });
});

bthread("PatchedVirtualCircuitTypeRequest delete verification", function () {
  const e = waitForAnyPatchedVirtualCircuitTypeRequestDeleted();
  block(matchAddPatchedVirtualCircuitTypeRequest(e.id, ANY), function () {
    verifyPatchedVirtualCircuitTypeRequestDoesNotExist(e.id);
  });
});

bthread("WritableEventRuleRequest create verification", function () {
  const e = waitForAnyWritableEventRuleRequestAdded();
  block(matchDeleteWritableEventRuleRequest(e.id, ANY), function () {
    verifyWritableEventRuleRequestExists(e.id);
  });
});

bthread("WritableEventRuleRequest update verification", function () {
  const e = waitForAnyWritableEventRuleRequestUpdated();
  block(matchDeleteWritableEventRuleRequest(e.id, ANY), function () {
    verifyWritableEventRuleRequestUpdated(e.id);
  });
});

bthread("WritableEventRuleRequest delete verification", function () {
  const e = waitForAnyWritableEventRuleRequestDeleted();
  block(matchAddWritableEventRuleRequest(e.id, ANY), function () {
    verifyWritableEventRuleRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedAggregateList create verification", function () {
  const e = waitForAnyPaginatedAggregateListAdded();
  block(matchDeletePaginatedAggregateList(e.id, ANY), function () {
    verifyPaginatedAggregateListExists(e.id);
  });
});

bthread("PaginatedAggregateList update verification", function () {
  const e = waitForAnyPaginatedAggregateListUpdated();
  block(matchDeletePaginatedAggregateList(e.id, ANY), function () {
    verifyPaginatedAggregateListUpdated(e.id);
  });
});

bthread("PaginatedAggregateList delete verification", function () {
  const e = waitForAnyPaginatedAggregateListDeleted();
  block(matchAddPaginatedAggregateList(e.id, ANY), function () {
    verifyPaginatedAggregateListDoesNotExist(e.id);
  });
});

bthread("PatchedInventoryItemRoleRequest create verification", function () {
  const e = waitForAnyPatchedInventoryItemRoleRequestAdded();
  block(matchDeletePatchedInventoryItemRoleRequest(e.id, ANY), function () {
    verifyPatchedInventoryItemRoleRequestExists(e.id);
  });
});

bthread("PatchedInventoryItemRoleRequest update verification", function () {
  const e = waitForAnyPatchedInventoryItemRoleRequestUpdated();
  block(matchDeletePatchedInventoryItemRoleRequest(e.id, ANY), function () {
    verifyPatchedInventoryItemRoleRequestUpdated(e.id);
  });
});

bthread("PatchedInventoryItemRoleRequest delete verification", function () {
  const e = waitForAnyPatchedInventoryItemRoleRequestDeleted();
  block(matchAddPatchedInventoryItemRoleRequest(e.id, ANY), function () {
    verifyPatchedInventoryItemRoleRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableWirelessLinkRequest create verification", function () {
  const e = waitForAnyPatchedWritableWirelessLinkRequestAdded();
  block(matchDeletePatchedWritableWirelessLinkRequest(e.id, ANY), function () {
    verifyPatchedWritableWirelessLinkRequestExists(e.id);
  });
});

bthread("PatchedWritableWirelessLinkRequest update verification", function () {
  const e = waitForAnyPatchedWritableWirelessLinkRequestUpdated();
  block(matchDeletePatchedWritableWirelessLinkRequest(e.id, ANY), function () {
    verifyPatchedWritableWirelessLinkRequestUpdated(e.id);
  });
});

bthread("PatchedWritableWirelessLinkRequest delete verification", function () {
  const e = waitForAnyPatchedWritableWirelessLinkRequestDeleted();
  block(matchAddPatchedWritableWirelessLinkRequest(e.id, ANY), function () {
    verifyPatchedWritableWirelessLinkRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedModuleBayTemplateList create verification", function () {
  const e = waitForAnyPaginatedModuleBayTemplateListAdded();
  block(matchDeletePaginatedModuleBayTemplateList(e.id, ANY), function () {
    verifyPaginatedModuleBayTemplateListExists(e.id);
  });
});

bthread("PaginatedModuleBayTemplateList update verification", function () {
  const e = waitForAnyPaginatedModuleBayTemplateListUpdated();
  block(matchDeletePaginatedModuleBayTemplateList(e.id, ANY), function () {
    verifyPaginatedModuleBayTemplateListUpdated(e.id);
  });
});

bthread("PaginatedModuleBayTemplateList delete verification", function () {
  const e = waitForAnyPaginatedModuleBayTemplateListDeleted();
  block(matchAddPaginatedModuleBayTemplateList(e.id, ANY), function () {
    verifyPaginatedModuleBayTemplateListDoesNotExist(e.id);
  });
});

bthread("ProviderRequest create verification", function () {
  const e = waitForAnyProviderRequestAdded();
  block(matchDeleteProviderRequest(e.id, ANY), function () {
    verifyProviderRequestExists(e.id);
  });
});

bthread("ProviderRequest update verification", function () {
  const e = waitForAnyProviderRequestUpdated();
  block(matchDeleteProviderRequest(e.id, ANY), function () {
    verifyProviderRequestUpdated(e.id);
  });
});

bthread("ProviderRequest delete verification", function () {
  const e = waitForAnyProviderRequestDeleted();
  block(matchAddProviderRequest(e.id, ANY), function () {
    verifyProviderRequestDoesNotExist(e.id);
  });
});

bthread("BriefCable create verification", function () {
  const e = waitForAnyBriefCableAdded();
  block(matchDeleteBriefCable(e.id, ANY), function () {
    verifyBriefCableExists(e.id);
  });
});

bthread("BriefCable update verification", function () {
  const e = waitForAnyBriefCableUpdated();
  block(matchDeleteBriefCable(e.id, ANY), function () {
    verifyBriefCableUpdated(e.id);
  });
});

bthread("BriefCable delete verification", function () {
  const e = waitForAnyBriefCableDeleted();
  block(matchAddBriefCable(e.id, ANY), function () {
    verifyBriefCableDoesNotExist(e.id);
  });
});

bthread("PaginatedConsolePortList create verification", function () {
  const e = waitForAnyPaginatedConsolePortListAdded();
  block(matchDeletePaginatedConsolePortList(e.id, ANY), function () {
    verifyPaginatedConsolePortListExists(e.id);
  });
});

bthread("PaginatedConsolePortList update verification", function () {
  const e = waitForAnyPaginatedConsolePortListUpdated();
  block(matchDeletePaginatedConsolePortList(e.id, ANY), function () {
    verifyPaginatedConsolePortListUpdated(e.id);
  });
});

bthread("PaginatedConsolePortList delete verification", function () {
  const e = waitForAnyPaginatedConsolePortListDeleted();
  block(matchAddPaginatedConsolePortList(e.id, ANY), function () {
    verifyPaginatedConsolePortListDoesNotExist(e.id);
  });
});

bthread("PatchedWritablePowerFeedRequest create verification", function () {
  const e = waitForAnyPatchedWritablePowerFeedRequestAdded();
  block(matchDeletePatchedWritablePowerFeedRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerFeedRequestExists(e.id);
  });
});

bthread("PatchedWritablePowerFeedRequest update verification", function () {
  const e = waitForAnyPatchedWritablePowerFeedRequestUpdated();
  block(matchDeletePatchedWritablePowerFeedRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerFeedRequestUpdated(e.id);
  });
});

bthread("PatchedWritablePowerFeedRequest delete verification", function () {
  const e = waitForAnyPatchedWritablePowerFeedRequestDeleted();
  block(matchAddPatchedWritablePowerFeedRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerFeedRequestDoesNotExist(e.id);
  });
});

bthread("ClusterGroup create verification", function () {
  const e = waitForAnyClusterGroupAdded();
  block(matchDeleteClusterGroup(e.id, ANY), function () {
    verifyClusterGroupExists(e.id);
  });
});

bthread("ClusterGroup update verification", function () {
  const e = waitForAnyClusterGroupUpdated();
  block(matchDeleteClusterGroup(e.id, ANY), function () {
    verifyClusterGroupUpdated(e.id);
  });
});

bthread("ClusterGroup delete verification", function () {
  const e = waitForAnyClusterGroupDeleted();
  block(matchAddClusterGroup(e.id, ANY), function () {
    verifyClusterGroupDoesNotExist(e.id);
  });
});

bthread("PaginatedCircuitTerminationList create verification", function () {
  const e = waitForAnyPaginatedCircuitTerminationListAdded();
  block(matchDeletePaginatedCircuitTerminationList(e.id, ANY), function () {
    verifyPaginatedCircuitTerminationListExists(e.id);
  });
});

bthread("PaginatedCircuitTerminationList update verification", function () {
  const e = waitForAnyPaginatedCircuitTerminationListUpdated();
  block(matchDeletePaginatedCircuitTerminationList(e.id, ANY), function () {
    verifyPaginatedCircuitTerminationListUpdated(e.id);
  });
});

bthread("PaginatedCircuitTerminationList delete verification", function () {
  const e = waitForAnyPaginatedCircuitTerminationListDeleted();
  block(matchAddPaginatedCircuitTerminationList(e.id, ANY), function () {
    verifyPaginatedCircuitTerminationListDoesNotExist(e.id);
  });
});

bthread("WritableVirtualCircuitRequest create verification", function () {
  const e = waitForAnyWritableVirtualCircuitRequestAdded();
  block(matchDeleteWritableVirtualCircuitRequest(e.id, ANY), function () {
    verifyWritableVirtualCircuitRequestExists(e.id);
  });
});

bthread("WritableVirtualCircuitRequest update verification", function () {
  const e = waitForAnyWritableVirtualCircuitRequestUpdated();
  block(matchDeleteWritableVirtualCircuitRequest(e.id, ANY), function () {
    verifyWritableVirtualCircuitRequestUpdated(e.id);
  });
});

bthread("WritableVirtualCircuitRequest delete verification", function () {
  const e = waitForAnyWritableVirtualCircuitRequestDeleted();
  block(matchAddWritableVirtualCircuitRequest(e.id, ANY), function () {
    verifyWritableVirtualCircuitRequestDoesNotExist(e.id);
  });
});

bthread("ContactGroupRequest create verification", function () {
  const e = waitForAnyContactGroupRequestAdded();
  block(matchDeleteContactGroupRequest(e.id, ANY), function () {
    verifyContactGroupRequestExists(e.id);
  });
});

bthread("ContactGroupRequest update verification", function () {
  const e = waitForAnyContactGroupRequestUpdated();
  block(matchDeleteContactGroupRequest(e.id, ANY), function () {
    verifyContactGroupRequestUpdated(e.id);
  });
});

bthread("ContactGroupRequest delete verification", function () {
  const e = waitForAnyContactGroupRequestDeleted();
  block(matchAddContactGroupRequest(e.id, ANY), function () {
    verifyContactGroupRequestDoesNotExist(e.id);
  });
});

bthread("ContactRequest create verification", function () {
  const e = waitForAnyContactRequestAdded();
  block(matchDeleteContactRequest(e.id, ANY), function () {
    verifyContactRequestExists(e.id);
  });
});

bthread("ContactRequest update verification", function () {
  const e = waitForAnyContactRequestUpdated();
  block(matchDeleteContactRequest(e.id, ANY), function () {
    verifyContactRequestUpdated(e.id);
  });
});

bthread("ContactRequest delete verification", function () {
  const e = waitForAnyContactRequestDeleted();
  block(matchAddContactRequest(e.id, ANY), function () {
    verifyContactRequestDoesNotExist(e.id);
  });
});

bthread("BriefRack create verification", function () {
  const e = waitForAnyBriefRackAdded();
  block(matchDeleteBriefRack(e.id, ANY), function () {
    verifyBriefRackExists(e.id);
  });
});

bthread("BriefRack update verification", function () {
  const e = waitForAnyBriefRackUpdated();
  block(matchDeleteBriefRack(e.id, ANY), function () {
    verifyBriefRackUpdated(e.id);
  });
});

bthread("BriefRack delete verification", function () {
  const e = waitForAnyBriefRackDeleted();
  block(matchAddBriefRack(e.id, ANY), function () {
    verifyBriefRackDoesNotExist(e.id);
  });
});

bthread("ModuleTypeProfile create verification", function () {
  const e = waitForAnyModuleTypeProfileAdded();
  block(matchDeleteModuleTypeProfile(e.id, ANY), function () {
    verifyModuleTypeProfileExists(e.id);
  });
});

bthread("ModuleTypeProfile update verification", function () {
  const e = waitForAnyModuleTypeProfileUpdated();
  block(matchDeleteModuleTypeProfile(e.id, ANY), function () {
    verifyModuleTypeProfileUpdated(e.id);
  });
});

bthread("ModuleTypeProfile delete verification", function () {
  const e = waitForAnyModuleTypeProfileDeleted();
  block(matchAddModuleTypeProfile(e.id, ANY), function () {
    verifyModuleTypeProfileDoesNotExist(e.id);
  });
});

bthread("BriefConfigTemplate create verification", function () {
  const e = waitForAnyBriefConfigTemplateAdded();
  block(matchDeleteBriefConfigTemplate(e.id, ANY), function () {
    verifyBriefConfigTemplateExists(e.id);
  });
});

bthread("BriefConfigTemplate update verification", function () {
  const e = waitForAnyBriefConfigTemplateUpdated();
  block(matchDeleteBriefConfigTemplate(e.id, ANY), function () {
    verifyBriefConfigTemplateUpdated(e.id);
  });
});

bthread("BriefConfigTemplate delete verification", function () {
  const e = waitForAnyBriefConfigTemplateDeleted();
  block(matchAddBriefConfigTemplate(e.id, ANY), function () {
    verifyBriefConfigTemplateDoesNotExist(e.id);
  });
});

bthread("PaginatedRearPortList create verification", function () {
  const e = waitForAnyPaginatedRearPortListAdded();
  block(matchDeletePaginatedRearPortList(e.id, ANY), function () {
    verifyPaginatedRearPortListExists(e.id);
  });
});

bthread("PaginatedRearPortList update verification", function () {
  const e = waitForAnyPaginatedRearPortListUpdated();
  block(matchDeletePaginatedRearPortList(e.id, ANY), function () {
    verifyPaginatedRearPortListUpdated(e.id);
  });
});

bthread("PaginatedRearPortList delete verification", function () {
  const e = waitForAnyPaginatedRearPortListDeleted();
  block(matchAddPaginatedRearPortList(e.id, ANY), function () {
    verifyPaginatedRearPortListDoesNotExist(e.id);
  });
});

bthread("PatchedProviderAccountRequest create verification", function () {
  const e = waitForAnyPatchedProviderAccountRequestAdded();
  block(matchDeletePatchedProviderAccountRequest(e.id, ANY), function () {
    verifyPatchedProviderAccountRequestExists(e.id);
  });
});

bthread("PatchedProviderAccountRequest update verification", function () {
  const e = waitForAnyPatchedProviderAccountRequestUpdated();
  block(matchDeletePatchedProviderAccountRequest(e.id, ANY), function () {
    verifyPatchedProviderAccountRequestUpdated(e.id);
  });
});

bthread("PatchedProviderAccountRequest delete verification", function () {
  const e = waitForAnyPatchedProviderAccountRequestDeleted();
  block(matchAddPatchedProviderAccountRequest(e.id, ANY), function () {
    verifyPatchedProviderAccountRequestDoesNotExist(e.id);
  });
});

bthread("BriefLocationRequest create verification", function () {
  const e = waitForAnyBriefLocationRequestAdded();
  block(matchDeleteBriefLocationRequest(e.id, ANY), function () {
    verifyBriefLocationRequestExists(e.id);
  });
});

bthread("BriefLocationRequest update verification", function () {
  const e = waitForAnyBriefLocationRequestUpdated();
  block(matchDeleteBriefLocationRequest(e.id, ANY), function () {
    verifyBriefLocationRequestUpdated(e.id);
  });
});

bthread("BriefLocationRequest delete verification", function () {
  const e = waitForAnyBriefLocationRequestDeleted();
  block(matchAddBriefLocationRequest(e.id, ANY), function () {
    verifyBriefLocationRequestDoesNotExist(e.id);
  });
});

bthread("PatchedASNRequest create verification", function () {
  const e = waitForAnyPatchedASNRequestAdded();
  block(matchDeletePatchedASNRequest(e.id, ANY), function () {
    verifyPatchedASNRequestExists(e.id);
  });
});

bthread("PatchedASNRequest update verification", function () {
  const e = waitForAnyPatchedASNRequestUpdated();
  block(matchDeletePatchedASNRequest(e.id, ANY), function () {
    verifyPatchedASNRequestUpdated(e.id);
  });
});

bthread("PatchedASNRequest delete verification", function () {
  const e = waitForAnyPatchedASNRequestDeleted();
  block(matchAddPatchedASNRequest(e.id, ANY), function () {
    verifyPatchedASNRequestDoesNotExist(e.id);
  });
});

bthread("NestedRegionRequest create verification", function () {
  const e = waitForAnyNestedRegionRequestAdded();
  block(matchDeleteNestedRegionRequest(e.id, ANY), function () {
    verifyNestedRegionRequestExists(e.id);
  });
});

bthread("NestedRegionRequest update verification", function () {
  const e = waitForAnyNestedRegionRequestUpdated();
  block(matchDeleteNestedRegionRequest(e.id, ANY), function () {
    verifyNestedRegionRequestUpdated(e.id);
  });
});

bthread("NestedRegionRequest delete verification", function () {
  const e = waitForAnyNestedRegionRequestDeleted();
  block(matchAddNestedRegionRequest(e.id, ANY), function () {
    verifyNestedRegionRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableFrontPortTemplateRequest create verification", function () {
  const e = waitForAnyPatchedWritableFrontPortTemplateRequestAdded();
  block(matchDeletePatchedWritableFrontPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableFrontPortTemplateRequestExists(e.id);
  });
});

bthread("PatchedWritableFrontPortTemplateRequest update verification", function () {
  const e = waitForAnyPatchedWritableFrontPortTemplateRequestUpdated();
  block(matchDeletePatchedWritableFrontPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableFrontPortTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedWritableFrontPortTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedWritableFrontPortTemplateRequestDeleted();
  block(matchAddPatchedWritableFrontPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableFrontPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("DataSource create verification", function () {
  const e = waitForAnyDataSourceAdded();
  block(matchDeleteDataSource(e.id, ANY), function () {
    verifyDataSourceExists(e.id);
  });
});

bthread("DataSource update verification", function () {
  const e = waitForAnyDataSourceUpdated();
  block(matchDeleteDataSource(e.id, ANY), function () {
    verifyDataSourceUpdated(e.id);
  });
});

bthread("DataSource delete verification", function () {
  const e = waitForAnyDataSourceDeleted();
  block(matchAddDataSource(e.id, ANY), function () {
    verifyDataSourceDoesNotExist(e.id);
  });
});

bthread("PatchedWritableCircuitRequest create verification", function () {
  const e = waitForAnyPatchedWritableCircuitRequestAdded();
  block(matchDeletePatchedWritableCircuitRequest(e.id, ANY), function () {
    verifyPatchedWritableCircuitRequestExists(e.id);
  });
});

bthread("PatchedWritableCircuitRequest update verification", function () {
  const e = waitForAnyPatchedWritableCircuitRequestUpdated();
  block(matchDeletePatchedWritableCircuitRequest(e.id, ANY), function () {
    verifyPatchedWritableCircuitRequestUpdated(e.id);
  });
});

bthread("PatchedWritableCircuitRequest delete verification", function () {
  const e = waitForAnyPatchedWritableCircuitRequestDeleted();
  block(matchAddPatchedWritableCircuitRequest(e.id, ANY), function () {
    verifyPatchedWritableCircuitRequestDoesNotExist(e.id);
  });
});

bthread("RIR create verification", function () {
  const e = waitForAnyRIRAdded();
  block(matchDeleteRIR(e.id, ANY), function () {
    verifyRIRExists(e.id);
  });
});

bthread("RIR update verification", function () {
  const e = waitForAnyRIRUpdated();
  block(matchDeleteRIR(e.id, ANY), function () {
    verifyRIRUpdated(e.id);
  });
});

bthread("RIR delete verification", function () {
  const e = waitForAnyRIRDeleted();
  block(matchAddRIR(e.id, ANY), function () {
    verifyRIRDoesNotExist(e.id);
  });
});

bthread("Module create verification", function () {
  const e = waitForAnyModuleAdded();
  block(matchDeleteModule(e.id, ANY), function () {
    verifyModuleExists(e.id);
  });
});

bthread("Module update verification", function () {
  const e = waitForAnyModuleUpdated();
  block(matchDeleteModule(e.id, ANY), function () {
    verifyModuleUpdated(e.id);
  });
});

bthread("Module delete verification", function () {
  const e = waitForAnyModuleDeleted();
  block(matchAddModule(e.id, ANY), function () {
    verifyModuleDoesNotExist(e.id);
  });
});

bthread("WritableL2VPNRequest create verification", function () {
  const e = waitForAnyWritableL2VPNRequestAdded();
  block(matchDeleteWritableL2VPNRequest(e.id, ANY), function () {
    verifyWritableL2VPNRequestExists(e.id);
  });
});

bthread("WritableL2VPNRequest update verification", function () {
  const e = waitForAnyWritableL2VPNRequestUpdated();
  block(matchDeleteWritableL2VPNRequest(e.id, ANY), function () {
    verifyWritableL2VPNRequestUpdated(e.id);
  });
});

bthread("WritableL2VPNRequest delete verification", function () {
  const e = waitForAnyWritableL2VPNRequestDeleted();
  block(matchAddWritableL2VPNRequest(e.id, ANY), function () {
    verifyWritableL2VPNRequestDoesNotExist(e.id);
  });
});

bthread("BriefCircuitGroupAssignmentSerializer_ create verification", function () {
  const e = waitForAnyBriefCircuitGroupAssignmentSerializer_Added();
  block(matchDeleteBriefCircuitGroupAssignmentSerializer_(e.id, ANY), function () {
    verifyBriefCircuitGroupAssignmentSerializer_Exists(e.id);
  });
});

bthread("BriefCircuitGroupAssignmentSerializer_ update verification", function () {
  const e = waitForAnyBriefCircuitGroupAssignmentSerializer_Updated();
  block(matchDeleteBriefCircuitGroupAssignmentSerializer_(e.id, ANY), function () {
    verifyBriefCircuitGroupAssignmentSerializer_Updated(e.id);
  });
});

bthread("BriefCircuitGroupAssignmentSerializer_ delete verification", function () {
  const e = waitForAnyBriefCircuitGroupAssignmentSerializer_Deleted();
  block(matchAddBriefCircuitGroupAssignmentSerializer_(e.id, ANY), function () {
    verifyBriefCircuitGroupAssignmentSerializer_DoesNotExist(e.id);
  });
});

bthread("PlatformRequest create verification", function () {
  const e = waitForAnyPlatformRequestAdded();
  block(matchDeletePlatformRequest(e.id, ANY), function () {
    verifyPlatformRequestExists(e.id);
  });
});

bthread("PlatformRequest update verification", function () {
  const e = waitForAnyPlatformRequestUpdated();
  block(matchDeletePlatformRequest(e.id, ANY), function () {
    verifyPlatformRequestUpdated(e.id);
  });
});

bthread("PlatformRequest delete verification", function () {
  const e = waitForAnyPlatformRequestDeleted();
  block(matchAddPlatformRequest(e.id, ANY), function () {
    verifyPlatformRequestDoesNotExist(e.id);
  });
});

bthread("VLANTranslationRule create verification", function () {
  const e = waitForAnyVLANTranslationRuleAdded();
  block(matchDeleteVLANTranslationRule(e.id, ANY), function () {
    verifyVLANTranslationRuleExists(e.id);
  });
});

bthread("VLANTranslationRule update verification", function () {
  const e = waitForAnyVLANTranslationRuleUpdated();
  block(matchDeleteVLANTranslationRule(e.id, ANY), function () {
    verifyVLANTranslationRuleUpdated(e.id);
  });
});

bthread("VLANTranslationRule delete verification", function () {
  const e = waitForAnyVLANTranslationRuleDeleted();
  block(matchAddVLANTranslationRule(e.id, ANY), function () {
    verifyVLANTranslationRuleDoesNotExist(e.id);
  });
});

bthread("PatchedCustomLinkRequest create verification", function () {
  const e = waitForAnyPatchedCustomLinkRequestAdded();
  block(matchDeletePatchedCustomLinkRequest(e.id, ANY), function () {
    verifyPatchedCustomLinkRequestExists(e.id);
  });
});

bthread("PatchedCustomLinkRequest update verification", function () {
  const e = waitForAnyPatchedCustomLinkRequestUpdated();
  block(matchDeletePatchedCustomLinkRequest(e.id, ANY), function () {
    verifyPatchedCustomLinkRequestUpdated(e.id);
  });
});

bthread("PatchedCustomLinkRequest delete verification", function () {
  const e = waitForAnyPatchedCustomLinkRequestDeleted();
  block(matchAddPatchedCustomLinkRequest(e.id, ANY), function () {
    verifyPatchedCustomLinkRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedServiceTemplateList create verification", function () {
  const e = waitForAnyPaginatedServiceTemplateListAdded();
  block(matchDeletePaginatedServiceTemplateList(e.id, ANY), function () {
    verifyPaginatedServiceTemplateListExists(e.id);
  });
});

bthread("PaginatedServiceTemplateList update verification", function () {
  const e = waitForAnyPaginatedServiceTemplateListUpdated();
  block(matchDeletePaginatedServiceTemplateList(e.id, ANY), function () {
    verifyPaginatedServiceTemplateListUpdated(e.id);
  });
});

bthread("PaginatedServiceTemplateList delete verification", function () {
  const e = waitForAnyPaginatedServiceTemplateListDeleted();
  block(matchAddPaginatedServiceTemplateList(e.id, ANY), function () {
    verifyPaginatedServiceTemplateListDoesNotExist(e.id);
  });
});

bthread("PatchedPowerPanelRequest create verification", function () {
  const e = waitForAnyPatchedPowerPanelRequestAdded();
  block(matchDeletePatchedPowerPanelRequest(e.id, ANY), function () {
    verifyPatchedPowerPanelRequestExists(e.id);
  });
});

bthread("PatchedPowerPanelRequest update verification", function () {
  const e = waitForAnyPatchedPowerPanelRequestUpdated();
  block(matchDeletePatchedPowerPanelRequest(e.id, ANY), function () {
    verifyPatchedPowerPanelRequestUpdated(e.id);
  });
});

bthread("PatchedPowerPanelRequest delete verification", function () {
  const e = waitForAnyPatchedPowerPanelRequestDeleted();
  block(matchAddPatchedPowerPanelRequest(e.id, ANY), function () {
    verifyPatchedPowerPanelRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableCustomFieldChoiceSetRequest create verification", function () {
  const e = waitForAnyPatchedWritableCustomFieldChoiceSetRequestAdded();
  block(matchDeletePatchedWritableCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyPatchedWritableCustomFieldChoiceSetRequestExists(e.id);
  });
});

bthread("PatchedWritableCustomFieldChoiceSetRequest update verification", function () {
  const e = waitForAnyPatchedWritableCustomFieldChoiceSetRequestUpdated();
  block(matchDeletePatchedWritableCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyPatchedWritableCustomFieldChoiceSetRequestUpdated(e.id);
  });
});

bthread("PatchedWritableCustomFieldChoiceSetRequest delete verification", function () {
  const e = waitForAnyPatchedWritableCustomFieldChoiceSetRequestDeleted();
  block(matchAddPatchedWritableCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyPatchedWritableCustomFieldChoiceSetRequestDoesNotExist(e.id);
  });
});

bthread("BriefUser create verification", function () {
  const e = waitForAnyBriefUserAdded();
  block(matchDeleteBriefUser(e.id, ANY), function () {
    verifyBriefUserExists(e.id);
  });
});

bthread("BriefUser update verification", function () {
  const e = waitForAnyBriefUserUpdated();
  block(matchDeleteBriefUser(e.id, ANY), function () {
    verifyBriefUserUpdated(e.id);
  });
});

bthread("BriefUser delete verification", function () {
  const e = waitForAnyBriefUserDeleted();
  block(matchAddBriefUser(e.id, ANY), function () {
    verifyBriefUserDoesNotExist(e.id);
  });
});

bthread("Contact create verification", function () {
  const e = waitForAnyContactAdded();
  block(matchDeleteContact(e.id, ANY), function () {
    verifyContactExists(e.id);
  });
});

bthread("Contact update verification", function () {
  const e = waitForAnyContactUpdated();
  block(matchDeleteContact(e.id, ANY), function () {
    verifyContactUpdated(e.id);
  });
});

bthread("Contact delete verification", function () {
  const e = waitForAnyContactDeleted();
  block(matchAddContact(e.id, ANY), function () {
    verifyContactDoesNotExist(e.id);
  });
});

bthread("PatchedWritableVLANRequest create verification", function () {
  const e = waitForAnyPatchedWritableVLANRequestAdded();
  block(matchDeletePatchedWritableVLANRequest(e.id, ANY), function () {
    verifyPatchedWritableVLANRequestExists(e.id);
  });
});

bthread("PatchedWritableVLANRequest update verification", function () {
  const e = waitForAnyPatchedWritableVLANRequestUpdated();
  block(matchDeletePatchedWritableVLANRequest(e.id, ANY), function () {
    verifyPatchedWritableVLANRequestUpdated(e.id);
  });
});

bthread("PatchedWritableVLANRequest delete verification", function () {
  const e = waitForAnyPatchedWritableVLANRequestDeleted();
  block(matchAddPatchedWritableVLANRequest(e.id, ANY), function () {
    verifyPatchedWritableVLANRequestDoesNotExist(e.id);
  });
});

bthread("Rack create verification", function () {
  const e = waitForAnyRackAdded();
  block(matchDeleteRack(e.id, ANY), function () {
    verifyRackExists(e.id);
  });
});

bthread("Rack update verification", function () {
  const e = waitForAnyRackUpdated();
  block(matchDeleteRack(e.id, ANY), function () {
    verifyRackUpdated(e.id);
  });
});

bthread("Rack delete verification", function () {
  const e = waitForAnyRackDeleted();
  block(matchAddRack(e.id, ANY), function () {
    verifyRackDoesNotExist(e.id);
  });
});

bthread("RegionRequest create verification", function () {
  const e = waitForAnyRegionRequestAdded();
  block(matchDeleteRegionRequest(e.id, ANY), function () {
    verifyRegionRequestExists(e.id);
  });
});

bthread("RegionRequest update verification", function () {
  const e = waitForAnyRegionRequestUpdated();
  block(matchDeleteRegionRequest(e.id, ANY), function () {
    verifyRegionRequestUpdated(e.id);
  });
});

bthread("RegionRequest delete verification", function () {
  const e = waitForAnyRegionRequestDeleted();
  block(matchAddRegionRequest(e.id, ANY), function () {
    verifyRegionRequestDoesNotExist(e.id);
  });
});

bthread("User create verification", function () {
  const e = waitForAnyUserAdded();
  block(matchDeleteUser(e.id, ANY), function () {
    verifyUserExists(e.id);
  });
});

bthread("User update verification", function () {
  const e = waitForAnyUserUpdated();
  block(matchDeleteUser(e.id, ANY), function () {
    verifyUserUpdated(e.id);
  });
});

bthread("User delete verification", function () {
  const e = waitForAnyUserDeleted();
  block(matchAddUser(e.id, ANY), function () {
    verifyUserDoesNotExist(e.id);
  });
});

bthread("CustomFieldChoiceSet create verification", function () {
  const e = waitForAnyCustomFieldChoiceSetAdded();
  block(matchDeleteCustomFieldChoiceSet(e.id, ANY), function () {
    verifyCustomFieldChoiceSetExists(e.id);
  });
});

bthread("CustomFieldChoiceSet update verification", function () {
  const e = waitForAnyCustomFieldChoiceSetUpdated();
  block(matchDeleteCustomFieldChoiceSet(e.id, ANY), function () {
    verifyCustomFieldChoiceSetUpdated(e.id);
  });
});

bthread("CustomFieldChoiceSet delete verification", function () {
  const e = waitForAnyCustomFieldChoiceSetDeleted();
  block(matchAddCustomFieldChoiceSet(e.id, ANY), function () {
    verifyCustomFieldChoiceSetDoesNotExist(e.id);
  });
});

bthread("PaginatedRackRoleList create verification", function () {
  const e = waitForAnyPaginatedRackRoleListAdded();
  block(matchDeletePaginatedRackRoleList(e.id, ANY), function () {
    verifyPaginatedRackRoleListExists(e.id);
  });
});

bthread("PaginatedRackRoleList update verification", function () {
  const e = waitForAnyPaginatedRackRoleListUpdated();
  block(matchDeletePaginatedRackRoleList(e.id, ANY), function () {
    verifyPaginatedRackRoleListUpdated(e.id);
  });
});

bthread("PaginatedRackRoleList delete verification", function () {
  const e = waitForAnyPaginatedRackRoleListDeleted();
  block(matchAddPaginatedRackRoleList(e.id, ANY), function () {
    verifyPaginatedRackRoleListDoesNotExist(e.id);
  });
});

bthread("Region create verification", function () {
  const e = waitForAnyRegionAdded();
  block(matchDeleteRegion(e.id, ANY), function () {
    verifyRegionExists(e.id);
  });
});

bthread("Region update verification", function () {
  const e = waitForAnyRegionUpdated();
  block(matchDeleteRegion(e.id, ANY), function () {
    verifyRegionUpdated(e.id);
  });
});

bthread("Region delete verification", function () {
  const e = waitForAnyRegionDeleted();
  block(matchAddRegion(e.id, ANY), function () {
    verifyRegionDoesNotExist(e.id);
  });
});

bthread("CircuitGroupRequest create verification", function () {
  const e = waitForAnyCircuitGroupRequestAdded();
  block(matchDeleteCircuitGroupRequest(e.id, ANY), function () {
    verifyCircuitGroupRequestExists(e.id);
  });
});

bthread("CircuitGroupRequest update verification", function () {
  const e = waitForAnyCircuitGroupRequestUpdated();
  block(matchDeleteCircuitGroupRequest(e.id, ANY), function () {
    verifyCircuitGroupRequestUpdated(e.id);
  });
});

bthread("CircuitGroupRequest delete verification", function () {
  const e = waitForAnyCircuitGroupRequestDeleted();
  block(matchAddCircuitGroupRequest(e.id, ANY), function () {
    verifyCircuitGroupRequestDoesNotExist(e.id);
  });
});

bthread("DeviceWithConfigContextRequest create verification", function () {
  const e = waitForAnyDeviceWithConfigContextRequestAdded();
  block(matchDeleteDeviceWithConfigContextRequest(e.id, ANY), function () {
    verifyDeviceWithConfigContextRequestExists(e.id);
  });
});

bthread("DeviceWithConfigContextRequest update verification", function () {
  const e = waitForAnyDeviceWithConfigContextRequestUpdated();
  block(matchDeleteDeviceWithConfigContextRequest(e.id, ANY), function () {
    verifyDeviceWithConfigContextRequestUpdated(e.id);
  });
});

bthread("DeviceWithConfigContextRequest delete verification", function () {
  const e = waitForAnyDeviceWithConfigContextRequestDeleted();
  block(matchAddDeviceWithConfigContextRequest(e.id, ANY), function () {
    verifyDeviceWithConfigContextRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableTenantGroupRequest create verification", function () {
  const e = waitForAnyPatchedWritableTenantGroupRequestAdded();
  block(matchDeletePatchedWritableTenantGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableTenantGroupRequestExists(e.id);
  });
});

bthread("PatchedWritableTenantGroupRequest update verification", function () {
  const e = waitForAnyPatchedWritableTenantGroupRequestUpdated();
  block(matchDeletePatchedWritableTenantGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableTenantGroupRequestUpdated(e.id);
  });
});

bthread("PatchedWritableTenantGroupRequest delete verification", function () {
  const e = waitForAnyPatchedWritableTenantGroupRequestDeleted();
  block(matchAddPatchedWritableTenantGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableTenantGroupRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritablePlatformRequest create verification", function () {
  const e = waitForAnyPatchedWritablePlatformRequestAdded();
  block(matchDeletePatchedWritablePlatformRequest(e.id, ANY), function () {
    verifyPatchedWritablePlatformRequestExists(e.id);
  });
});

bthread("PatchedWritablePlatformRequest update verification", function () {
  const e = waitForAnyPatchedWritablePlatformRequestUpdated();
  block(matchDeletePatchedWritablePlatformRequest(e.id, ANY), function () {
    verifyPatchedWritablePlatformRequestUpdated(e.id);
  });
});

bthread("PatchedWritablePlatformRequest delete verification", function () {
  const e = waitForAnyPatchedWritablePlatformRequestDeleted();
  block(matchAddPatchedWritablePlatformRequest(e.id, ANY), function () {
    verifyPatchedWritablePlatformRequestDoesNotExist(e.id);
  });
});

bthread("AvailablePrefix create verification", function () {
  const e = waitForAnyAvailablePrefixAdded();
  block(matchDeleteAvailablePrefix(e.id, ANY), function () {
    verifyAvailablePrefixExists(e.id);
  });
});

bthread("AvailablePrefix update verification", function () {
  const e = waitForAnyAvailablePrefixUpdated();
  block(matchDeleteAvailablePrefix(e.id, ANY), function () {
    verifyAvailablePrefixUpdated(e.id);
  });
});

bthread("AvailablePrefix delete verification", function () {
  const e = waitForAnyAvailablePrefixDeleted();
  block(matchAddAvailablePrefix(e.id, ANY), function () {
    verifyAvailablePrefixDoesNotExist(e.id);
  });
});

bthread("WritableContactGroupRequest create verification", function () {
  const e = waitForAnyWritableContactGroupRequestAdded();
  block(matchDeleteWritableContactGroupRequest(e.id, ANY), function () {
    verifyWritableContactGroupRequestExists(e.id);
  });
});

bthread("WritableContactGroupRequest update verification", function () {
  const e = waitForAnyWritableContactGroupRequestUpdated();
  block(matchDeleteWritableContactGroupRequest(e.id, ANY), function () {
    verifyWritableContactGroupRequestUpdated(e.id);
  });
});

bthread("WritableContactGroupRequest delete verification", function () {
  const e = waitForAnyWritableContactGroupRequestDeleted();
  block(matchAddWritableContactGroupRequest(e.id, ANY), function () {
    verifyWritableContactGroupRequestDoesNotExist(e.id);
  });
});

bthread("GenericObjectRequest create verification", function () {
  const e = waitForAnyGenericObjectRequestAdded();
  block(matchDeleteGenericObjectRequest(e.id, ANY), function () {
    verifyGenericObjectRequestExists(e.id);
  });
});

bthread("GenericObjectRequest update verification", function () {
  const e = waitForAnyGenericObjectRequestUpdated();
  block(matchDeleteGenericObjectRequest(e.id, ANY), function () {
    verifyGenericObjectRequestUpdated(e.id);
  });
});

bthread("GenericObjectRequest delete verification", function () {
  const e = waitForAnyGenericObjectRequestDeleted();
  block(matchAddGenericObjectRequest(e.id, ANY), function () {
    verifyGenericObjectRequestDoesNotExist(e.id);
  });
});

bthread("BriefProviderAccount create verification", function () {
  const e = waitForAnyBriefProviderAccountAdded();
  block(matchDeleteBriefProviderAccount(e.id, ANY), function () {
    verifyBriefProviderAccountExists(e.id);
  });
});

bthread("BriefProviderAccount update verification", function () {
  const e = waitForAnyBriefProviderAccountUpdated();
  block(matchDeleteBriefProviderAccount(e.id, ANY), function () {
    verifyBriefProviderAccountUpdated(e.id);
  });
});

bthread("BriefProviderAccount delete verification", function () {
  const e = waitForAnyBriefProviderAccountDeleted();
  block(matchAddBriefProviderAccount(e.id, ANY), function () {
    verifyBriefProviderAccountDoesNotExist(e.id);
  });
});

bthread("ConsoleServerPortTemplate create verification", function () {
  const e = waitForAnyConsoleServerPortTemplateAdded();
  block(matchDeleteConsoleServerPortTemplate(e.id, ANY), function () {
    verifyConsoleServerPortTemplateExists(e.id);
  });
});

bthread("ConsoleServerPortTemplate update verification", function () {
  const e = waitForAnyConsoleServerPortTemplateUpdated();
  block(matchDeleteConsoleServerPortTemplate(e.id, ANY), function () {
    verifyConsoleServerPortTemplateUpdated(e.id);
  });
});

bthread("ConsoleServerPortTemplate delete verification", function () {
  const e = waitForAnyConsoleServerPortTemplateDeleted();
  block(matchAddConsoleServerPortTemplate(e.id, ANY), function () {
    verifyConsoleServerPortTemplateDoesNotExist(e.id);
  });
});

bthread("PaginatedPlatformList create verification", function () {
  const e = waitForAnyPaginatedPlatformListAdded();
  block(matchDeletePaginatedPlatformList(e.id, ANY), function () {
    verifyPaginatedPlatformListExists(e.id);
  });
});

bthread("PaginatedPlatformList update verification", function () {
  const e = waitForAnyPaginatedPlatformListUpdated();
  block(matchDeletePaginatedPlatformList(e.id, ANY), function () {
    verifyPaginatedPlatformListUpdated(e.id);
  });
});

bthread("PaginatedPlatformList delete verification", function () {
  const e = waitForAnyPaginatedPlatformListDeleted();
  block(matchAddPaginatedPlatformList(e.id, ANY), function () {
    verifyPaginatedPlatformListDoesNotExist(e.id);
  });
});

bthread("BriefPowerPort create verification", function () {
  const e = waitForAnyBriefPowerPortAdded();
  block(matchDeleteBriefPowerPort(e.id, ANY), function () {
    verifyBriefPowerPortExists(e.id);
  });
});

bthread("BriefPowerPort update verification", function () {
  const e = waitForAnyBriefPowerPortUpdated();
  block(matchDeleteBriefPowerPort(e.id, ANY), function () {
    verifyBriefPowerPortUpdated(e.id);
  });
});

bthread("BriefPowerPort delete verification", function () {
  const e = waitForAnyBriefPowerPortDeleted();
  block(matchAddBriefPowerPort(e.id, ANY), function () {
    verifyBriefPowerPortDoesNotExist(e.id);
  });
});

bthread("NestedTenantGroup create verification", function () {
  const e = waitForAnyNestedTenantGroupAdded();
  block(matchDeleteNestedTenantGroup(e.id, ANY), function () {
    verifyNestedTenantGroupExists(e.id);
  });
});

bthread("NestedTenantGroup update verification", function () {
  const e = waitForAnyNestedTenantGroupUpdated();
  block(matchDeleteNestedTenantGroup(e.id, ANY), function () {
    verifyNestedTenantGroupUpdated(e.id);
  });
});

bthread("NestedTenantGroup delete verification", function () {
  const e = waitForAnyNestedTenantGroupDeleted();
  block(matchAddNestedTenantGroup(e.id, ANY), function () {
    verifyNestedTenantGroupDoesNotExist(e.id);
  });
});

bthread("PatchedModuleTypeProfileRequest create verification", function () {
  const e = waitForAnyPatchedModuleTypeProfileRequestAdded();
  block(matchDeletePatchedModuleTypeProfileRequest(e.id, ANY), function () {
    verifyPatchedModuleTypeProfileRequestExists(e.id);
  });
});

bthread("PatchedModuleTypeProfileRequest update verification", function () {
  const e = waitForAnyPatchedModuleTypeProfileRequestUpdated();
  block(matchDeletePatchedModuleTypeProfileRequest(e.id, ANY), function () {
    verifyPatchedModuleTypeProfileRequestUpdated(e.id);
  });
});

bthread("PatchedModuleTypeProfileRequest delete verification", function () {
  const e = waitForAnyPatchedModuleTypeProfileRequestDeleted();
  block(matchAddPatchedModuleTypeProfileRequest(e.id, ANY), function () {
    verifyPatchedModuleTypeProfileRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableTunnelTerminationRequest create verification", function () {
  const e = waitForAnyPatchedWritableTunnelTerminationRequestAdded();
  block(matchDeletePatchedWritableTunnelTerminationRequest(e.id, ANY), function () {
    verifyPatchedWritableTunnelTerminationRequestExists(e.id);
  });
});

bthread("PatchedWritableTunnelTerminationRequest update verification", function () {
  const e = waitForAnyPatchedWritableTunnelTerminationRequestUpdated();
  block(matchDeletePatchedWritableTunnelTerminationRequest(e.id, ANY), function () {
    verifyPatchedWritableTunnelTerminationRequestUpdated(e.id);
  });
});

bthread("PatchedWritableTunnelTerminationRequest delete verification", function () {
  const e = waitForAnyPatchedWritableTunnelTerminationRequestDeleted();
  block(matchAddPatchedWritableTunnelTerminationRequest(e.id, ANY), function () {
    verifyPatchedWritableTunnelTerminationRequestDoesNotExist(e.id);
  });
});

bthread("BriefInventoryItemRole create verification", function () {
  const e = waitForAnyBriefInventoryItemRoleAdded();
  block(matchDeleteBriefInventoryItemRole(e.id, ANY), function () {
    verifyBriefInventoryItemRoleExists(e.id);
  });
});

bthread("BriefInventoryItemRole update verification", function () {
  const e = waitForAnyBriefInventoryItemRoleUpdated();
  block(matchDeleteBriefInventoryItemRole(e.id, ANY), function () {
    verifyBriefInventoryItemRoleUpdated(e.id);
  });
});

bthread("BriefInventoryItemRole delete verification", function () {
  const e = waitForAnyBriefInventoryItemRoleDeleted();
  block(matchAddBriefInventoryItemRole(e.id, ANY), function () {
    verifyBriefInventoryItemRoleDoesNotExist(e.id);
  });
});

bthread("PaginatedObjectTypeList create verification", function () {
  const e = waitForAnyPaginatedObjectTypeListAdded();
  block(matchDeletePaginatedObjectTypeList(e.id, ANY), function () {
    verifyPaginatedObjectTypeListExists(e.id);
  });
});

bthread("PaginatedObjectTypeList update verification", function () {
  const e = waitForAnyPaginatedObjectTypeListUpdated();
  block(matchDeletePaginatedObjectTypeList(e.id, ANY), function () {
    verifyPaginatedObjectTypeListUpdated(e.id);
  });
});

bthread("PaginatedObjectTypeList delete verification", function () {
  const e = waitForAnyPaginatedObjectTypeListDeleted();
  block(matchAddPaginatedObjectTypeList(e.id, ANY), function () {
    verifyPaginatedObjectTypeListDoesNotExist(e.id);
  });
});

bthread("Subscription create verification", function () {
  const e = waitForAnySubscriptionAdded();
  block(matchDeleteSubscription(e.id, ANY), function () {
    verifySubscriptionExists(e.id);
  });
});

bthread("Subscription update verification", function () {
  const e = waitForAnySubscriptionUpdated();
  block(matchDeleteSubscription(e.id, ANY), function () {
    verifySubscriptionUpdated(e.id);
  });
});

bthread("Subscription delete verification", function () {
  const e = waitForAnySubscriptionDeleted();
  block(matchAddSubscription(e.id, ANY), function () {
    verifySubscriptionDoesNotExist(e.id);
  });
});

bthread("BriefSiteGroupRequest create verification", function () {
  const e = waitForAnyBriefSiteGroupRequestAdded();
  block(matchDeleteBriefSiteGroupRequest(e.id, ANY), function () {
    verifyBriefSiteGroupRequestExists(e.id);
  });
});

bthread("BriefSiteGroupRequest update verification", function () {
  const e = waitForAnyBriefSiteGroupRequestUpdated();
  block(matchDeleteBriefSiteGroupRequest(e.id, ANY), function () {
    verifyBriefSiteGroupRequestUpdated(e.id);
  });
});

bthread("BriefSiteGroupRequest delete verification", function () {
  const e = waitForAnyBriefSiteGroupRequestDeleted();
  block(matchAddBriefSiteGroupRequest(e.id, ANY), function () {
    verifyBriefSiteGroupRequestDoesNotExist(e.id);
  });
});

bthread("BriefTunnelGroupRequest create verification", function () {
  const e = waitForAnyBriefTunnelGroupRequestAdded();
  block(matchDeleteBriefTunnelGroupRequest(e.id, ANY), function () {
    verifyBriefTunnelGroupRequestExists(e.id);
  });
});

bthread("BriefTunnelGroupRequest update verification", function () {
  const e = waitForAnyBriefTunnelGroupRequestUpdated();
  block(matchDeleteBriefTunnelGroupRequest(e.id, ANY), function () {
    verifyBriefTunnelGroupRequestUpdated(e.id);
  });
});

bthread("BriefTunnelGroupRequest delete verification", function () {
  const e = waitForAnyBriefTunnelGroupRequestDeleted();
  block(matchAddBriefTunnelGroupRequest(e.id, ANY), function () {
    verifyBriefTunnelGroupRequestDoesNotExist(e.id);
  });
});

bthread("WritableRearPortTemplateRequest create verification", function () {
  const e = waitForAnyWritableRearPortTemplateRequestAdded();
  block(matchDeleteWritableRearPortTemplateRequest(e.id, ANY), function () {
    verifyWritableRearPortTemplateRequestExists(e.id);
  });
});

bthread("WritableRearPortTemplateRequest update verification", function () {
  const e = waitForAnyWritableRearPortTemplateRequestUpdated();
  block(matchDeleteWritableRearPortTemplateRequest(e.id, ANY), function () {
    verifyWritableRearPortTemplateRequestUpdated(e.id);
  });
});

bthread("WritableRearPortTemplateRequest delete verification", function () {
  const e = waitForAnyWritableRearPortTemplateRequestDeleted();
  block(matchAddWritableRearPortTemplateRequest(e.id, ANY), function () {
    verifyWritableRearPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("NestedInterface create verification", function () {
  const e = waitForAnyNestedInterfaceAdded();
  block(matchDeleteNestedInterface(e.id, ANY), function () {
    verifyNestedInterfaceExists(e.id);
  });
});

bthread("NestedInterface update verification", function () {
  const e = waitForAnyNestedInterfaceUpdated();
  block(matchDeleteNestedInterface(e.id, ANY), function () {
    verifyNestedInterfaceUpdated(e.id);
  });
});

bthread("NestedInterface delete verification", function () {
  const e = waitForAnyNestedInterfaceDeleted();
  block(matchAddNestedInterface(e.id, ANY), function () {
    verifyNestedInterfaceDoesNotExist(e.id);
  });
});

bthread("PatchedWritableConsoleServerPortTemplateRequest create verification", function () {
  const e = waitForAnyPatchedWritableConsoleServerPortTemplateRequestAdded();
  block(matchDeletePatchedWritableConsoleServerPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableConsoleServerPortTemplateRequestExists(e.id);
  });
});

bthread("PatchedWritableConsoleServerPortTemplateRequest update verification", function () {
  const e = waitForAnyPatchedWritableConsoleServerPortTemplateRequestUpdated();
  block(matchDeletePatchedWritableConsoleServerPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableConsoleServerPortTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedWritableConsoleServerPortTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedWritableConsoleServerPortTemplateRequestDeleted();
  block(matchAddPatchedWritableConsoleServerPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableConsoleServerPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("NestedContactGroup create verification", function () {
  const e = waitForAnyNestedContactGroupAdded();
  block(matchDeleteNestedContactGroup(e.id, ANY), function () {
    verifyNestedContactGroupExists(e.id);
  });
});

bthread("NestedContactGroup update verification", function () {
  const e = waitForAnyNestedContactGroupUpdated();
  block(matchDeleteNestedContactGroup(e.id, ANY), function () {
    verifyNestedContactGroupUpdated(e.id);
  });
});

bthread("NestedContactGroup delete verification", function () {
  const e = waitForAnyNestedContactGroupDeleted();
  block(matchAddNestedContactGroup(e.id, ANY), function () {
    verifyNestedContactGroupDoesNotExist(e.id);
  });
});

bthread("InventoryItemRoleRequest create verification", function () {
  const e = waitForAnyInventoryItemRoleRequestAdded();
  block(matchDeleteInventoryItemRoleRequest(e.id, ANY), function () {
    verifyInventoryItemRoleRequestExists(e.id);
  });
});

bthread("InventoryItemRoleRequest update verification", function () {
  const e = waitForAnyInventoryItemRoleRequestUpdated();
  block(matchDeleteInventoryItemRoleRequest(e.id, ANY), function () {
    verifyInventoryItemRoleRequestUpdated(e.id);
  });
});

bthread("InventoryItemRoleRequest delete verification", function () {
  const e = waitForAnyInventoryItemRoleRequestDeleted();
  block(matchAddInventoryItemRoleRequest(e.id, ANY), function () {
    verifyInventoryItemRoleRequestDoesNotExist(e.id);
  });
});

bthread("InterfaceTemplateRequest create verification", function () {
  const e = waitForAnyInterfaceTemplateRequestAdded();
  block(matchDeleteInterfaceTemplateRequest(e.id, ANY), function () {
    verifyInterfaceTemplateRequestExists(e.id);
  });
});

bthread("InterfaceTemplateRequest update verification", function () {
  const e = waitForAnyInterfaceTemplateRequestUpdated();
  block(matchDeleteInterfaceTemplateRequest(e.id, ANY), function () {
    verifyInterfaceTemplateRequestUpdated(e.id);
  });
});

bthread("InterfaceTemplateRequest delete verification", function () {
  const e = waitForAnyInterfaceTemplateRequestDeleted();
  block(matchAddInterfaceTemplateRequest(e.id, ANY), function () {
    verifyInterfaceTemplateRequestDoesNotExist(e.id);
  });
});

bthread("WirelessLink create verification", function () {
  const e = waitForAnyWirelessLinkAdded();
  block(matchDeleteWirelessLink(e.id, ANY), function () {
    verifyWirelessLinkExists(e.id);
  });
});

bthread("WirelessLink update verification", function () {
  const e = waitForAnyWirelessLinkUpdated();
  block(matchDeleteWirelessLink(e.id, ANY), function () {
    verifyWirelessLinkUpdated(e.id);
  });
});

bthread("WirelessLink delete verification", function () {
  const e = waitForAnyWirelessLinkDeleted();
  block(matchAddWirelessLink(e.id, ANY), function () {
    verifyWirelessLinkDoesNotExist(e.id);
  });
});

bthread("WritableVirtualCircuitTerminationRequest create verification", function () {
  const e = waitForAnyWritableVirtualCircuitTerminationRequestAdded();
  block(matchDeleteWritableVirtualCircuitTerminationRequest(e.id, ANY), function () {
    verifyWritableVirtualCircuitTerminationRequestExists(e.id);
  });
});

bthread("WritableVirtualCircuitTerminationRequest update verification", function () {
  const e = waitForAnyWritableVirtualCircuitTerminationRequestUpdated();
  block(matchDeleteWritableVirtualCircuitTerminationRequest(e.id, ANY), function () {
    verifyWritableVirtualCircuitTerminationRequestUpdated(e.id);
  });
});

bthread("WritableVirtualCircuitTerminationRequest delete verification", function () {
  const e = waitForAnyWritableVirtualCircuitTerminationRequestDeleted();
  block(matchAddWritableVirtualCircuitTerminationRequest(e.id, ANY), function () {
    verifyWritableVirtualCircuitTerminationRequestDoesNotExist(e.id);
  });
});

bthread("PowerPortTemplate create verification", function () {
  const e = waitForAnyPowerPortTemplateAdded();
  block(matchDeletePowerPortTemplate(e.id, ANY), function () {
    verifyPowerPortTemplateExists(e.id);
  });
});

bthread("PowerPortTemplate update verification", function () {
  const e = waitForAnyPowerPortTemplateUpdated();
  block(matchDeletePowerPortTemplate(e.id, ANY), function () {
    verifyPowerPortTemplateUpdated(e.id);
  });
});

bthread("PowerPortTemplate delete verification", function () {
  const e = waitForAnyPowerPortTemplateDeleted();
  block(matchAddPowerPortTemplate(e.id, ANY), function () {
    verifyPowerPortTemplateDoesNotExist(e.id);
  });
});

bthread("ProviderAccount create verification", function () {
  const e = waitForAnyProviderAccountAdded();
  block(matchDeleteProviderAccount(e.id, ANY), function () {
    verifyProviderAccountExists(e.id);
  });
});

bthread("ProviderAccount update verification", function () {
  const e = waitForAnyProviderAccountUpdated();
  block(matchDeleteProviderAccount(e.id, ANY), function () {
    verifyProviderAccountUpdated(e.id);
  });
});

bthread("ProviderAccount delete verification", function () {
  const e = waitForAnyProviderAccountDeleted();
  block(matchAddProviderAccount(e.id, ANY), function () {
    verifyProviderAccountDoesNotExist(e.id);
  });
});

bthread("ScriptInputRequest create verification", function () {
  const e = waitForAnyScriptInputRequestAdded();
  block(matchDeleteScriptInputRequest(e.id, ANY), function () {
    verifyScriptInputRequestExists(e.id);
  });
});

bthread("ScriptInputRequest update verification", function () {
  const e = waitForAnyScriptInputRequestUpdated();
  block(matchDeleteScriptInputRequest(e.id, ANY), function () {
    verifyScriptInputRequestUpdated(e.id);
  });
});

bthread("ScriptInputRequest delete verification", function () {
  const e = waitForAnyScriptInputRequestDeleted();
  block(matchAddScriptInputRequest(e.id, ANY), function () {
    verifyScriptInputRequestDoesNotExist(e.id);
  });
});

bthread("ProviderNetwork create verification", function () {
  const e = waitForAnyProviderNetworkAdded();
  block(matchDeleteProviderNetwork(e.id, ANY), function () {
    verifyProviderNetworkExists(e.id);
  });
});

bthread("ProviderNetwork update verification", function () {
  const e = waitForAnyProviderNetworkUpdated();
  block(matchDeleteProviderNetwork(e.id, ANY), function () {
    verifyProviderNetworkUpdated(e.id);
  });
});

bthread("ProviderNetwork delete verification", function () {
  const e = waitForAnyProviderNetworkDeleted();
  block(matchAddProviderNetwork(e.id, ANY), function () {
    verifyProviderNetworkDoesNotExist(e.id);
  });
});

bthread("IntegerRange create verification", function () {
  const e = waitForAnyIntegerRangeAdded();
  block(matchDeleteIntegerRange(e.id, ANY), function () {
    verifyIntegerRangeExists(e.id);
  });
});

bthread("IntegerRange update verification", function () {
  const e = waitForAnyIntegerRangeUpdated();
  block(matchDeleteIntegerRange(e.id, ANY), function () {
    verifyIntegerRangeUpdated(e.id);
  });
});

bthread("IntegerRange delete verification", function () {
  const e = waitForAnyIntegerRangeDeleted();
  block(matchAddIntegerRange(e.id, ANY), function () {
    verifyIntegerRangeDoesNotExist(e.id);
  });
});

bthread("InventoryItem create verification", function () {
  const e = waitForAnyInventoryItemAdded();
  block(matchDeleteInventoryItem(e.id, ANY), function () {
    verifyInventoryItemExists(e.id);
  });
});

bthread("InventoryItem update verification", function () {
  const e = waitForAnyInventoryItemUpdated();
  block(matchDeleteInventoryItem(e.id, ANY), function () {
    verifyInventoryItemUpdated(e.id);
  });
});

bthread("InventoryItem delete verification", function () {
  const e = waitForAnyInventoryItemDeleted();
  block(matchAddInventoryItem(e.id, ANY), function () {
    verifyInventoryItemDoesNotExist(e.id);
  });
});

bthread("PaginatedConfigTemplateList create verification", function () {
  const e = waitForAnyPaginatedConfigTemplateListAdded();
  block(matchDeletePaginatedConfigTemplateList(e.id, ANY), function () {
    verifyPaginatedConfigTemplateListExists(e.id);
  });
});

bthread("PaginatedConfigTemplateList update verification", function () {
  const e = waitForAnyPaginatedConfigTemplateListUpdated();
  block(matchDeletePaginatedConfigTemplateList(e.id, ANY), function () {
    verifyPaginatedConfigTemplateListUpdated(e.id);
  });
});

bthread("PaginatedConfigTemplateList delete verification", function () {
  const e = waitForAnyPaginatedConfigTemplateListDeleted();
  block(matchAddPaginatedConfigTemplateList(e.id, ANY), function () {
    verifyPaginatedConfigTemplateListDoesNotExist(e.id);
  });
});

bthread("VirtualDeviceContextRequest create verification", function () {
  const e = waitForAnyVirtualDeviceContextRequestAdded();
  block(matchDeleteVirtualDeviceContextRequest(e.id, ANY), function () {
    verifyVirtualDeviceContextRequestExists(e.id);
  });
});

bthread("VirtualDeviceContextRequest update verification", function () {
  const e = waitForAnyVirtualDeviceContextRequestUpdated();
  block(matchDeleteVirtualDeviceContextRequest(e.id, ANY), function () {
    verifyVirtualDeviceContextRequestUpdated(e.id);
  });
});

bthread("VirtualDeviceContextRequest delete verification", function () {
  const e = waitForAnyVirtualDeviceContextRequestDeleted();
  block(matchAddVirtualDeviceContextRequest(e.id, ANY), function () {
    verifyVirtualDeviceContextRequestDoesNotExist(e.id);
  });
});

bthread("WritableConsolePortTemplateRequest create verification", function () {
  const e = waitForAnyWritableConsolePortTemplateRequestAdded();
  block(matchDeleteWritableConsolePortTemplateRequest(e.id, ANY), function () {
    verifyWritableConsolePortTemplateRequestExists(e.id);
  });
});

bthread("WritableConsolePortTemplateRequest update verification", function () {
  const e = waitForAnyWritableConsolePortTemplateRequestUpdated();
  block(matchDeleteWritableConsolePortTemplateRequest(e.id, ANY), function () {
    verifyWritableConsolePortTemplateRequestUpdated(e.id);
  });
});

bthread("WritableConsolePortTemplateRequest delete verification", function () {
  const e = waitForAnyWritableConsolePortTemplateRequestDeleted();
  block(matchAddWritableConsolePortTemplateRequest(e.id, ANY), function () {
    verifyWritableConsolePortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedWirelessLANList create verification", function () {
  const e = waitForAnyPaginatedWirelessLANListAdded();
  block(matchDeletePaginatedWirelessLANList(e.id, ANY), function () {
    verifyPaginatedWirelessLANListExists(e.id);
  });
});

bthread("PaginatedWirelessLANList update verification", function () {
  const e = waitForAnyPaginatedWirelessLANListUpdated();
  block(matchDeletePaginatedWirelessLANList(e.id, ANY), function () {
    verifyPaginatedWirelessLANListUpdated(e.id);
  });
});

bthread("PaginatedWirelessLANList delete verification", function () {
  const e = waitForAnyPaginatedWirelessLANListDeleted();
  block(matchAddPaginatedWirelessLANList(e.id, ANY), function () {
    verifyPaginatedWirelessLANListDoesNotExist(e.id);
  });
});

bthread("SiteGroupRequest create verification", function () {
  const e = waitForAnySiteGroupRequestAdded();
  block(matchDeleteSiteGroupRequest(e.id, ANY), function () {
    verifySiteGroupRequestExists(e.id);
  });
});

bthread("SiteGroupRequest update verification", function () {
  const e = waitForAnySiteGroupRequestUpdated();
  block(matchDeleteSiteGroupRequest(e.id, ANY), function () {
    verifySiteGroupRequestUpdated(e.id);
  });
});

bthread("SiteGroupRequest delete verification", function () {
  const e = waitForAnySiteGroupRequestDeleted();
  block(matchAddSiteGroupRequest(e.id, ANY), function () {
    verifySiteGroupRequestDoesNotExist(e.id);
  });
});

bthread("BriefFHRPGroupRequest create verification", function () {
  const e = waitForAnyBriefFHRPGroupRequestAdded();
  block(matchDeleteBriefFHRPGroupRequest(e.id, ANY), function () {
    verifyBriefFHRPGroupRequestExists(e.id);
  });
});

bthread("BriefFHRPGroupRequest update verification", function () {
  const e = waitForAnyBriefFHRPGroupRequestUpdated();
  block(matchDeleteBriefFHRPGroupRequest(e.id, ANY), function () {
    verifyBriefFHRPGroupRequestUpdated(e.id);
  });
});

bthread("BriefFHRPGroupRequest delete verification", function () {
  const e = waitForAnyBriefFHRPGroupRequestDeleted();
  block(matchAddBriefFHRPGroupRequest(e.id, ANY), function () {
    verifyBriefFHRPGroupRequestDoesNotExist(e.id);
  });
});

bthread("PowerOutlet create verification", function () {
  const e = waitForAnyPowerOutletAdded();
  block(matchDeletePowerOutlet(e.id, ANY), function () {
    verifyPowerOutletExists(e.id);
  });
});

bthread("PowerOutlet update verification", function () {
  const e = waitForAnyPowerOutletUpdated();
  block(matchDeletePowerOutlet(e.id, ANY), function () {
    verifyPowerOutletUpdated(e.id);
  });
});

bthread("PowerOutlet delete verification", function () {
  const e = waitForAnyPowerOutletDeleted();
  block(matchAddPowerOutlet(e.id, ANY), function () {
    verifyPowerOutletDoesNotExist(e.id);
  });
});

bthread("VirtualChassis create verification", function () {
  const e = waitForAnyVirtualChassisAdded();
  block(matchDeleteVirtualChassis(e.id, ANY), function () {
    verifyVirtualChassisExists(e.id);
  });
});

bthread("VirtualChassis update verification", function () {
  const e = waitForAnyVirtualChassisUpdated();
  block(matchDeleteVirtualChassis(e.id, ANY), function () {
    verifyVirtualChassisUpdated(e.id);
  });
});

bthread("VirtualChassis delete verification", function () {
  const e = waitForAnyVirtualChassisDeleted();
  block(matchAddVirtualChassis(e.id, ANY), function () {
    verifyVirtualChassisDoesNotExist(e.id);
  });
});

bthread("PatchedWritableContactGroupRequest create verification", function () {
  const e = waitForAnyPatchedWritableContactGroupRequestAdded();
  block(matchDeletePatchedWritableContactGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableContactGroupRequestExists(e.id);
  });
});

bthread("PatchedWritableContactGroupRequest update verification", function () {
  const e = waitForAnyPatchedWritableContactGroupRequestUpdated();
  block(matchDeletePatchedWritableContactGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableContactGroupRequestUpdated(e.id);
  });
});

bthread("PatchedWritableContactGroupRequest delete verification", function () {
  const e = waitForAnyPatchedWritableContactGroupRequestDeleted();
  block(matchAddPatchedWritableContactGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableContactGroupRequestDoesNotExist(e.id);
  });
});

bthread("NestedDevice create verification", function () {
  const e = waitForAnyNestedDeviceAdded();
  block(matchDeleteNestedDevice(e.id, ANY), function () {
    verifyNestedDeviceExists(e.id);
  });
});

bthread("NestedDevice update verification", function () {
  const e = waitForAnyNestedDeviceUpdated();
  block(matchDeleteNestedDevice(e.id, ANY), function () {
    verifyNestedDeviceUpdated(e.id);
  });
});

bthread("NestedDevice delete verification", function () {
  const e = waitForAnyNestedDeviceDeleted();
  block(matchAddNestedDevice(e.id, ANY), function () {
    verifyNestedDeviceDoesNotExist(e.id);
  });
});

bthread("PaginatedIPSecProposalList create verification", function () {
  const e = waitForAnyPaginatedIPSecProposalListAdded();
  block(matchDeletePaginatedIPSecProposalList(e.id, ANY), function () {
    verifyPaginatedIPSecProposalListExists(e.id);
  });
});

bthread("PaginatedIPSecProposalList update verification", function () {
  const e = waitForAnyPaginatedIPSecProposalListUpdated();
  block(matchDeletePaginatedIPSecProposalList(e.id, ANY), function () {
    verifyPaginatedIPSecProposalListUpdated(e.id);
  });
});

bthread("PaginatedIPSecProposalList delete verification", function () {
  const e = waitForAnyPaginatedIPSecProposalListDeleted();
  block(matchAddPaginatedIPSecProposalList(e.id, ANY), function () {
    verifyPaginatedIPSecProposalListDoesNotExist(e.id);
  });
});

bthread("ContactRole create verification", function () {
  const e = waitForAnyContactRoleAdded();
  block(matchDeleteContactRole(e.id, ANY), function () {
    verifyContactRoleExists(e.id);
  });
});

bthread("ContactRole update verification", function () {
  const e = waitForAnyContactRoleUpdated();
  block(matchDeleteContactRole(e.id, ANY), function () {
    verifyContactRoleUpdated(e.id);
  });
});

bthread("ContactRole delete verification", function () {
  const e = waitForAnyContactRoleDeleted();
  block(matchAddContactRole(e.id, ANY), function () {
    verifyContactRoleDoesNotExist(e.id);
  });
});

bthread("TokenProvision create verification", function () {
  const e = waitForAnyTokenProvisionAdded();
  block(matchDeleteTokenProvision(e.id, ANY), function () {
    verifyTokenProvisionExists(e.id);
  });
});

bthread("TokenProvision update verification", function () {
  const e = waitForAnyTokenProvisionUpdated();
  block(matchDeleteTokenProvision(e.id, ANY), function () {
    verifyTokenProvisionUpdated(e.id);
  });
});

bthread("TokenProvision delete verification", function () {
  const e = waitForAnyTokenProvisionDeleted();
  block(matchAddTokenProvision(e.id, ANY), function () {
    verifyTokenProvisionDoesNotExist(e.id);
  });
});

bthread("PaginatedBookmarkList create verification", function () {
  const e = waitForAnyPaginatedBookmarkListAdded();
  block(matchDeletePaginatedBookmarkList(e.id, ANY), function () {
    verifyPaginatedBookmarkListExists(e.id);
  });
});

bthread("PaginatedBookmarkList update verification", function () {
  const e = waitForAnyPaginatedBookmarkListUpdated();
  block(matchDeletePaginatedBookmarkList(e.id, ANY), function () {
    verifyPaginatedBookmarkListUpdated(e.id);
  });
});

bthread("PaginatedBookmarkList delete verification", function () {
  const e = waitForAnyPaginatedBookmarkListDeleted();
  block(matchAddPaginatedBookmarkList(e.id, ANY), function () {
    verifyPaginatedBookmarkListDoesNotExist(e.id);
  });
});

bthread("WirelessLANGroupRequest create verification", function () {
  const e = waitForAnyWirelessLANGroupRequestAdded();
  block(matchDeleteWirelessLANGroupRequest(e.id, ANY), function () {
    verifyWirelessLANGroupRequestExists(e.id);
  });
});

bthread("WirelessLANGroupRequest update verification", function () {
  const e = waitForAnyWirelessLANGroupRequestUpdated();
  block(matchDeleteWirelessLANGroupRequest(e.id, ANY), function () {
    verifyWirelessLANGroupRequestUpdated(e.id);
  });
});

bthread("WirelessLANGroupRequest delete verification", function () {
  const e = waitForAnyWirelessLANGroupRequestDeleted();
  block(matchAddWirelessLANGroupRequest(e.id, ANY), function () {
    verifyWirelessLANGroupRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedLocationList create verification", function () {
  const e = waitForAnyPaginatedLocationListAdded();
  block(matchDeletePaginatedLocationList(e.id, ANY), function () {
    verifyPaginatedLocationListExists(e.id);
  });
});

bthread("PaginatedLocationList update verification", function () {
  const e = waitForAnyPaginatedLocationListUpdated();
  block(matchDeletePaginatedLocationList(e.id, ANY), function () {
    verifyPaginatedLocationListUpdated(e.id);
  });
});

bthread("PaginatedLocationList delete verification", function () {
  const e = waitForAnyPaginatedLocationListDeleted();
  block(matchAddPaginatedLocationList(e.id, ANY), function () {
    verifyPaginatedLocationListDoesNotExist(e.id);
  });
});

bthread("NestedTagRequest create verification", function () {
  const e = waitForAnyNestedTagRequestAdded();
  block(matchDeleteNestedTagRequest(e.id, ANY), function () {
    verifyNestedTagRequestExists(e.id);
  });
});

bthread("NestedTagRequest update verification", function () {
  const e = waitForAnyNestedTagRequestUpdated();
  block(matchDeleteNestedTagRequest(e.id, ANY), function () {
    verifyNestedTagRequestUpdated(e.id);
  });
});

bthread("NestedTagRequest delete verification", function () {
  const e = waitForAnyNestedTagRequestDeleted();
  block(matchAddNestedTagRequest(e.id, ANY), function () {
    verifyNestedTagRequestDoesNotExist(e.id);
  });
});

bthread("NestedPlatformRequest create verification", function () {
  const e = waitForAnyNestedPlatformRequestAdded();
  block(matchDeleteNestedPlatformRequest(e.id, ANY), function () {
    verifyNestedPlatformRequestExists(e.id);
  });
});

bthread("NestedPlatformRequest update verification", function () {
  const e = waitForAnyNestedPlatformRequestUpdated();
  block(matchDeleteNestedPlatformRequest(e.id, ANY), function () {
    verifyNestedPlatformRequestUpdated(e.id);
  });
});

bthread("NestedPlatformRequest delete verification", function () {
  const e = waitForAnyNestedPlatformRequestDeleted();
  block(matchAddNestedPlatformRequest(e.id, ANY), function () {
    verifyNestedPlatformRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedRearPortTemplateList create verification", function () {
  const e = waitForAnyPaginatedRearPortTemplateListAdded();
  block(matchDeletePaginatedRearPortTemplateList(e.id, ANY), function () {
    verifyPaginatedRearPortTemplateListExists(e.id);
  });
});

bthread("PaginatedRearPortTemplateList update verification", function () {
  const e = waitForAnyPaginatedRearPortTemplateListUpdated();
  block(matchDeletePaginatedRearPortTemplateList(e.id, ANY), function () {
    verifyPaginatedRearPortTemplateListUpdated(e.id);
  });
});

bthread("PaginatedRearPortTemplateList delete verification", function () {
  const e = waitForAnyPaginatedRearPortTemplateListDeleted();
  block(matchAddPaginatedRearPortTemplateList(e.id, ANY), function () {
    verifyPaginatedRearPortTemplateListDoesNotExist(e.id);
  });
});

bthread("PowerFeed create verification", function () {
  const e = waitForAnyPowerFeedAdded();
  block(matchDeletePowerFeed(e.id, ANY), function () {
    verifyPowerFeedExists(e.id);
  });
});

bthread("PowerFeed update verification", function () {
  const e = waitForAnyPowerFeedUpdated();
  block(matchDeletePowerFeed(e.id, ANY), function () {
    verifyPowerFeedUpdated(e.id);
  });
});

bthread("PowerFeed delete verification", function () {
  const e = waitForAnyPowerFeedDeleted();
  block(matchAddPowerFeed(e.id, ANY), function () {
    verifyPowerFeedDoesNotExist(e.id);
  });
});

bthread("WritableRegionRequest create verification", function () {
  const e = waitForAnyWritableRegionRequestAdded();
  block(matchDeleteWritableRegionRequest(e.id, ANY), function () {
    verifyWritableRegionRequestExists(e.id);
  });
});

bthread("WritableRegionRequest update verification", function () {
  const e = waitForAnyWritableRegionRequestUpdated();
  block(matchDeleteWritableRegionRequest(e.id, ANY), function () {
    verifyWritableRegionRequestUpdated(e.id);
  });
});

bthread("WritableRegionRequest delete verification", function () {
  const e = waitForAnyWritableRegionRequestDeleted();
  block(matchAddWritableRegionRequest(e.id, ANY), function () {
    verifyWritableRegionRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedCircuitTypeList create verification", function () {
  const e = waitForAnyPaginatedCircuitTypeListAdded();
  block(matchDeletePaginatedCircuitTypeList(e.id, ANY), function () {
    verifyPaginatedCircuitTypeListExists(e.id);
  });
});

bthread("PaginatedCircuitTypeList update verification", function () {
  const e = waitForAnyPaginatedCircuitTypeListUpdated();
  block(matchDeletePaginatedCircuitTypeList(e.id, ANY), function () {
    verifyPaginatedCircuitTypeListUpdated(e.id);
  });
});

bthread("PaginatedCircuitTypeList delete verification", function () {
  const e = waitForAnyPaginatedCircuitTypeListDeleted();
  block(matchAddPaginatedCircuitTypeList(e.id, ANY), function () {
    verifyPaginatedCircuitTypeListDoesNotExist(e.id);
  });
});

bthread("BriefVirtualMachine create verification", function () {
  const e = waitForAnyBriefVirtualMachineAdded();
  block(matchDeleteBriefVirtualMachine(e.id, ANY), function () {
    verifyBriefVirtualMachineExists(e.id);
  });
});

bthread("BriefVirtualMachine update verification", function () {
  const e = waitForAnyBriefVirtualMachineUpdated();
  block(matchDeleteBriefVirtualMachine(e.id, ANY), function () {
    verifyBriefVirtualMachineUpdated(e.id);
  });
});

bthread("BriefVirtualMachine delete verification", function () {
  const e = waitForAnyBriefVirtualMachineDeleted();
  block(matchAddBriefVirtualMachine(e.id, ANY), function () {
    verifyBriefVirtualMachineDoesNotExist(e.id);
  });
});

bthread("CircuitGroupAssignmentRequest create verification", function () {
  const e = waitForAnyCircuitGroupAssignmentRequestAdded();
  block(matchDeleteCircuitGroupAssignmentRequest(e.id, ANY), function () {
    verifyCircuitGroupAssignmentRequestExists(e.id);
  });
});

bthread("CircuitGroupAssignmentRequest update verification", function () {
  const e = waitForAnyCircuitGroupAssignmentRequestUpdated();
  block(matchDeleteCircuitGroupAssignmentRequest(e.id, ANY), function () {
    verifyCircuitGroupAssignmentRequestUpdated(e.id);
  });
});

bthread("CircuitGroupAssignmentRequest delete verification", function () {
  const e = waitForAnyCircuitGroupAssignmentRequestDeleted();
  block(matchAddCircuitGroupAssignmentRequest(e.id, ANY), function () {
    verifyCircuitGroupAssignmentRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritablePowerOutletRequest create verification", function () {
  const e = waitForAnyPatchedWritablePowerOutletRequestAdded();
  block(matchDeletePatchedWritablePowerOutletRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerOutletRequestExists(e.id);
  });
});

bthread("PatchedWritablePowerOutletRequest update verification", function () {
  const e = waitForAnyPatchedWritablePowerOutletRequestUpdated();
  block(matchDeletePatchedWritablePowerOutletRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerOutletRequestUpdated(e.id);
  });
});

bthread("PatchedWritablePowerOutletRequest delete verification", function () {
  const e = waitForAnyPatchedWritablePowerOutletRequestDeleted();
  block(matchAddPatchedWritablePowerOutletRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerOutletRequestDoesNotExist(e.id);
  });
});

bthread("BriefDeviceType create verification", function () {
  const e = waitForAnyBriefDeviceTypeAdded();
  block(matchDeleteBriefDeviceType(e.id, ANY), function () {
    verifyBriefDeviceTypeExists(e.id);
  });
});

bthread("BriefDeviceType update verification", function () {
  const e = waitForAnyBriefDeviceTypeUpdated();
  block(matchDeleteBriefDeviceType(e.id, ANY), function () {
    verifyBriefDeviceTypeUpdated(e.id);
  });
});

bthread("BriefDeviceType delete verification", function () {
  const e = waitForAnyBriefDeviceTypeDeleted();
  block(matchAddBriefDeviceType(e.id, ANY), function () {
    verifyBriefDeviceTypeDoesNotExist(e.id);
  });
});

bthread("TokenProvisionRequest create verification", function () {
  const e = waitForAnyTokenProvisionRequestAdded();
  block(matchDeleteTokenProvisionRequest(e.id, ANY), function () {
    verifyTokenProvisionRequestExists(e.id);
  });
});

bthread("TokenProvisionRequest update verification", function () {
  const e = waitForAnyTokenProvisionRequestUpdated();
  block(matchDeleteTokenProvisionRequest(e.id, ANY), function () {
    verifyTokenProvisionRequestUpdated(e.id);
  });
});

bthread("TokenProvisionRequest delete verification", function () {
  const e = waitForAnyTokenProvisionRequestDeleted();
  block(matchAddTokenProvisionRequest(e.id, ANY), function () {
    verifyTokenProvisionRequestDoesNotExist(e.id);
  });
});

bthread("TunnelTermination create verification", function () {
  const e = waitForAnyTunnelTerminationAdded();
  block(matchDeleteTunnelTermination(e.id, ANY), function () {
    verifyTunnelTerminationExists(e.id);
  });
});

bthread("TunnelTermination update verification", function () {
  const e = waitForAnyTunnelTerminationUpdated();
  block(matchDeleteTunnelTermination(e.id, ANY), function () {
    verifyTunnelTerminationUpdated(e.id);
  });
});

bthread("TunnelTermination delete verification", function () {
  const e = waitForAnyTunnelTerminationDeleted();
  block(matchAddTunnelTermination(e.id, ANY), function () {
    verifyTunnelTerminationDoesNotExist(e.id);
  });
});

bthread("PaginatedProviderList create verification", function () {
  const e = waitForAnyPaginatedProviderListAdded();
  block(matchDeletePaginatedProviderList(e.id, ANY), function () {
    verifyPaginatedProviderListExists(e.id);
  });
});

bthread("PaginatedProviderList update verification", function () {
  const e = waitForAnyPaginatedProviderListUpdated();
  block(matchDeletePaginatedProviderList(e.id, ANY), function () {
    verifyPaginatedProviderListUpdated(e.id);
  });
});

bthread("PaginatedProviderList delete verification", function () {
  const e = waitForAnyPaginatedProviderListDeleted();
  block(matchAddPaginatedProviderList(e.id, ANY), function () {
    verifyPaginatedProviderListDoesNotExist(e.id);
  });
});

bthread("WritableRearPortRequest create verification", function () {
  const e = waitForAnyWritableRearPortRequestAdded();
  block(matchDeleteWritableRearPortRequest(e.id, ANY), function () {
    verifyWritableRearPortRequestExists(e.id);
  });
});

bthread("WritableRearPortRequest update verification", function () {
  const e = waitForAnyWritableRearPortRequestUpdated();
  block(matchDeleteWritableRearPortRequest(e.id, ANY), function () {
    verifyWritableRearPortRequestUpdated(e.id);
  });
});

bthread("WritableRearPortRequest delete verification", function () {
  const e = waitForAnyWritableRearPortRequestDeleted();
  block(matchAddWritableRearPortRequest(e.id, ANY), function () {
    verifyWritableRearPortRequestDoesNotExist(e.id);
  });
});

bthread("BriefPowerPortRequest create verification", function () {
  const e = waitForAnyBriefPowerPortRequestAdded();
  block(matchDeleteBriefPowerPortRequest(e.id, ANY), function () {
    verifyBriefPowerPortRequestExists(e.id);
  });
});

bthread("BriefPowerPortRequest update verification", function () {
  const e = waitForAnyBriefPowerPortRequestUpdated();
  block(matchDeleteBriefPowerPortRequest(e.id, ANY), function () {
    verifyBriefPowerPortRequestUpdated(e.id);
  });
});

bthread("BriefPowerPortRequest delete verification", function () {
  const e = waitForAnyBriefPowerPortRequestDeleted();
  block(matchAddBriefPowerPortRequest(e.id, ANY), function () {
    verifyBriefPowerPortRequestDoesNotExist(e.id);
  });
});

bthread("BriefRoleRequest create verification", function () {
  const e = waitForAnyBriefRoleRequestAdded();
  block(matchDeleteBriefRoleRequest(e.id, ANY), function () {
    verifyBriefRoleRequestExists(e.id);
  });
});

bthread("BriefRoleRequest update verification", function () {
  const e = waitForAnyBriefRoleRequestUpdated();
  block(matchDeleteBriefRoleRequest(e.id, ANY), function () {
    verifyBriefRoleRequestUpdated(e.id);
  });
});

bthread("BriefRoleRequest delete verification", function () {
  const e = waitForAnyBriefRoleRequestDeleted();
  block(matchAddBriefRoleRequest(e.id, ANY), function () {
    verifyBriefRoleRequestDoesNotExist(e.id);
  });
});

bthread("BriefJobRequest create verification", function () {
  const e = waitForAnyBriefJobRequestAdded();
  block(matchDeleteBriefJobRequest(e.id, ANY), function () {
    verifyBriefJobRequestExists(e.id);
  });
});

bthread("BriefJobRequest update verification", function () {
  const e = waitForAnyBriefJobRequestUpdated();
  block(matchDeleteBriefJobRequest(e.id, ANY), function () {
    verifyBriefJobRequestUpdated(e.id);
  });
});

bthread("BriefJobRequest delete verification", function () {
  const e = waitForAnyBriefJobRequestDeleted();
  block(matchAddBriefJobRequest(e.id, ANY), function () {
    verifyBriefJobRequestDoesNotExist(e.id);
  });
});

bthread("BriefUserRequest create verification", function () {
  const e = waitForAnyBriefUserRequestAdded();
  block(matchDeleteBriefUserRequest(e.id, ANY), function () {
    verifyBriefUserRequestExists(e.id);
  });
});

bthread("BriefUserRequest update verification", function () {
  const e = waitForAnyBriefUserRequestUpdated();
  block(matchDeleteBriefUserRequest(e.id, ANY), function () {
    verifyBriefUserRequestUpdated(e.id);
  });
});

bthread("BriefUserRequest delete verification", function () {
  const e = waitForAnyBriefUserRequestDeleted();
  block(matchAddBriefUserRequest(e.id, ANY), function () {
    verifyBriefUserRequestDoesNotExist(e.id);
  });
});

bthread("VMInterface create verification", function () {
  const e = waitForAnyVMInterfaceAdded();
  block(matchDeleteVMInterface(e.id, ANY), function () {
    verifyVMInterfaceExists(e.id);
  });
});

bthread("VMInterface update verification", function () {
  const e = waitForAnyVMInterfaceUpdated();
  block(matchDeleteVMInterface(e.id, ANY), function () {
    verifyVMInterfaceUpdated(e.id);
  });
});

bthread("VMInterface delete verification", function () {
  const e = waitForAnyVMInterfaceDeleted();
  block(matchAddVMInterface(e.id, ANY), function () {
    verifyVMInterfaceDoesNotExist(e.id);
  });
});

bthread("FHRPGroupAssignmentRequest create verification", function () {
  const e = waitForAnyFHRPGroupAssignmentRequestAdded();
  block(matchDeleteFHRPGroupAssignmentRequest(e.id, ANY), function () {
    verifyFHRPGroupAssignmentRequestExists(e.id);
  });
});

bthread("FHRPGroupAssignmentRequest update verification", function () {
  const e = waitForAnyFHRPGroupAssignmentRequestUpdated();
  block(matchDeleteFHRPGroupAssignmentRequest(e.id, ANY), function () {
    verifyFHRPGroupAssignmentRequestUpdated(e.id);
  });
});

bthread("FHRPGroupAssignmentRequest delete verification", function () {
  const e = waitForAnyFHRPGroupAssignmentRequestDeleted();
  block(matchAddFHRPGroupAssignmentRequest(e.id, ANY), function () {
    verifyFHRPGroupAssignmentRequestDoesNotExist(e.id);
  });
});

bthread("BriefCircuitTypeRequest create verification", function () {
  const e = waitForAnyBriefCircuitTypeRequestAdded();
  block(matchDeleteBriefCircuitTypeRequest(e.id, ANY), function () {
    verifyBriefCircuitTypeRequestExists(e.id);
  });
});

bthread("BriefCircuitTypeRequest update verification", function () {
  const e = waitForAnyBriefCircuitTypeRequestUpdated();
  block(matchDeleteBriefCircuitTypeRequest(e.id, ANY), function () {
    verifyBriefCircuitTypeRequestUpdated(e.id);
  });
});

bthread("BriefCircuitTypeRequest delete verification", function () {
  const e = waitForAnyBriefCircuitTypeRequestDeleted();
  block(matchAddBriefCircuitTypeRequest(e.id, ANY), function () {
    verifyBriefCircuitTypeRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedL2VPNList create verification", function () {
  const e = waitForAnyPaginatedL2VPNListAdded();
  block(matchDeletePaginatedL2VPNList(e.id, ANY), function () {
    verifyPaginatedL2VPNListExists(e.id);
  });
});

bthread("PaginatedL2VPNList update verification", function () {
  const e = waitForAnyPaginatedL2VPNListUpdated();
  block(matchDeletePaginatedL2VPNList(e.id, ANY), function () {
    verifyPaginatedL2VPNListUpdated(e.id);
  });
});

bthread("PaginatedL2VPNList delete verification", function () {
  const e = waitForAnyPaginatedL2VPNListDeleted();
  block(matchAddPaginatedL2VPNList(e.id, ANY), function () {
    verifyPaginatedL2VPNListDoesNotExist(e.id);
  });
});

bthread("PaginatedManufacturerList create verification", function () {
  const e = waitForAnyPaginatedManufacturerListAdded();
  block(matchDeletePaginatedManufacturerList(e.id, ANY), function () {
    verifyPaginatedManufacturerListExists(e.id);
  });
});

bthread("PaginatedManufacturerList update verification", function () {
  const e = waitForAnyPaginatedManufacturerListUpdated();
  block(matchDeletePaginatedManufacturerList(e.id, ANY), function () {
    verifyPaginatedManufacturerListUpdated(e.id);
  });
});

bthread("PaginatedManufacturerList delete verification", function () {
  const e = waitForAnyPaginatedManufacturerListDeleted();
  block(matchAddPaginatedManufacturerList(e.id, ANY), function () {
    verifyPaginatedManufacturerListDoesNotExist(e.id);
  });
});

bthread("VLANGroupRequest create verification", function () {
  const e = waitForAnyVLANGroupRequestAdded();
  block(matchDeleteVLANGroupRequest(e.id, ANY), function () {
    verifyVLANGroupRequestExists(e.id);
  });
});

bthread("VLANGroupRequest update verification", function () {
  const e = waitForAnyVLANGroupRequestUpdated();
  block(matchDeleteVLANGroupRequest(e.id, ANY), function () {
    verifyVLANGroupRequestUpdated(e.id);
  });
});

bthread("VLANGroupRequest delete verification", function () {
  const e = waitForAnyVLANGroupRequestDeleted();
  block(matchAddVLANGroupRequest(e.id, ANY), function () {
    verifyVLANGroupRequestDoesNotExist(e.id);
  });
});

bthread("WritableAggregateRequest create verification", function () {
  const e = waitForAnyWritableAggregateRequestAdded();
  block(matchDeleteWritableAggregateRequest(e.id, ANY), function () {
    verifyWritableAggregateRequestExists(e.id);
  });
});

bthread("WritableAggregateRequest update verification", function () {
  const e = waitForAnyWritableAggregateRequestUpdated();
  block(matchDeleteWritableAggregateRequest(e.id, ANY), function () {
    verifyWritableAggregateRequestUpdated(e.id);
  });
});

bthread("WritableAggregateRequest delete verification", function () {
  const e = waitForAnyWritableAggregateRequestDeleted();
  block(matchAddWritableAggregateRequest(e.id, ANY), function () {
    verifyWritableAggregateRequestDoesNotExist(e.id);
  });
});

bthread("BriefIKEPolicy create verification", function () {
  const e = waitForAnyBriefIKEPolicyAdded();
  block(matchDeleteBriefIKEPolicy(e.id, ANY), function () {
    verifyBriefIKEPolicyExists(e.id);
  });
});

bthread("BriefIKEPolicy update verification", function () {
  const e = waitForAnyBriefIKEPolicyUpdated();
  block(matchDeleteBriefIKEPolicy(e.id, ANY), function () {
    verifyBriefIKEPolicyUpdated(e.id);
  });
});

bthread("BriefIKEPolicy delete verification", function () {
  const e = waitForAnyBriefIKEPolicyDeleted();
  block(matchAddBriefIKEPolicy(e.id, ANY), function () {
    verifyBriefIKEPolicyDoesNotExist(e.id);
  });
});

bthread("BriefDataSource create verification", function () {
  const e = waitForAnyBriefDataSourceAdded();
  block(matchDeleteBriefDataSource(e.id, ANY), function () {
    verifyBriefDataSourceExists(e.id);
  });
});

bthread("BriefDataSource update verification", function () {
  const e = waitForAnyBriefDataSourceUpdated();
  block(matchDeleteBriefDataSource(e.id, ANY), function () {
    verifyBriefDataSourceUpdated(e.id);
  });
});

bthread("BriefDataSource delete verification", function () {
  const e = waitForAnyBriefDataSourceDeleted();
  block(matchAddBriefDataSource(e.id, ANY), function () {
    verifyBriefDataSourceDoesNotExist(e.id);
  });
});

bthread("RackReservationRequest create verification", function () {
  const e = waitForAnyRackReservationRequestAdded();
  block(matchDeleteRackReservationRequest(e.id, ANY), function () {
    verifyRackReservationRequestExists(e.id);
  });
});

bthread("RackReservationRequest update verification", function () {
  const e = waitForAnyRackReservationRequestUpdated();
  block(matchDeleteRackReservationRequest(e.id, ANY), function () {
    verifyRackReservationRequestUpdated(e.id);
  });
});

bthread("RackReservationRequest delete verification", function () {
  const e = waitForAnyRackReservationRequestDeleted();
  block(matchAddRackReservationRequest(e.id, ANY), function () {
    verifyRackReservationRequestDoesNotExist(e.id);
  });
});

bthread("DeviceBay create verification", function () {
  const e = waitForAnyDeviceBayAdded();
  block(matchDeleteDeviceBay(e.id, ANY), function () {
    verifyDeviceBayExists(e.id);
  });
});

bthread("DeviceBay update verification", function () {
  const e = waitForAnyDeviceBayUpdated();
  block(matchDeleteDeviceBay(e.id, ANY), function () {
    verifyDeviceBayUpdated(e.id);
  });
});

bthread("DeviceBay delete verification", function () {
  const e = waitForAnyDeviceBayDeleted();
  block(matchAddDeviceBay(e.id, ANY), function () {
    verifyDeviceBayDoesNotExist(e.id);
  });
});

bthread("BriefCircuitGroup create verification", function () {
  const e = waitForAnyBriefCircuitGroupAdded();
  block(matchDeleteBriefCircuitGroup(e.id, ANY), function () {
    verifyBriefCircuitGroupExists(e.id);
  });
});

bthread("BriefCircuitGroup update verification", function () {
  const e = waitForAnyBriefCircuitGroupUpdated();
  block(matchDeleteBriefCircuitGroup(e.id, ANY), function () {
    verifyBriefCircuitGroupUpdated(e.id);
  });
});

bthread("BriefCircuitGroup delete verification", function () {
  const e = waitForAnyBriefCircuitGroupDeleted();
  block(matchAddBriefCircuitGroup(e.id, ANY), function () {
    verifyBriefCircuitGroupDoesNotExist(e.id);
  });
});

bthread("NestedWirelessLink create verification", function () {
  const e = waitForAnyNestedWirelessLinkAdded();
  block(matchDeleteNestedWirelessLink(e.id, ANY), function () {
    verifyNestedWirelessLinkExists(e.id);
  });
});

bthread("NestedWirelessLink update verification", function () {
  const e = waitForAnyNestedWirelessLinkUpdated();
  block(matchDeleteNestedWirelessLink(e.id, ANY), function () {
    verifyNestedWirelessLinkUpdated(e.id);
  });
});

bthread("NestedWirelessLink delete verification", function () {
  const e = waitForAnyNestedWirelessLinkDeleted();
  block(matchAddNestedWirelessLink(e.id, ANY), function () {
    verifyNestedWirelessLinkDoesNotExist(e.id);
  });
});

bthread("BriefRIRRequest create verification", function () {
  const e = waitForAnyBriefRIRRequestAdded();
  block(matchDeleteBriefRIRRequest(e.id, ANY), function () {
    verifyBriefRIRRequestExists(e.id);
  });
});

bthread("BriefRIRRequest update verification", function () {
  const e = waitForAnyBriefRIRRequestUpdated();
  block(matchDeleteBriefRIRRequest(e.id, ANY), function () {
    verifyBriefRIRRequestUpdated(e.id);
  });
});

bthread("BriefRIRRequest delete verification", function () {
  const e = waitForAnyBriefRIRRequestDeleted();
  block(matchAddBriefRIRRequest(e.id, ANY), function () {
    verifyBriefRIRRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedTagList create verification", function () {
  const e = waitForAnyPaginatedTagListAdded();
  block(matchDeletePaginatedTagList(e.id, ANY), function () {
    verifyPaginatedTagListExists(e.id);
  });
});

bthread("PaginatedTagList update verification", function () {
  const e = waitForAnyPaginatedTagListUpdated();
  block(matchDeletePaginatedTagList(e.id, ANY), function () {
    verifyPaginatedTagListUpdated(e.id);
  });
});

bthread("PaginatedTagList delete verification", function () {
  const e = waitForAnyPaginatedTagListDeleted();
  block(matchAddPaginatedTagList(e.id, ANY), function () {
    verifyPaginatedTagListDoesNotExist(e.id);
  });
});

bthread("BriefTunnel create verification", function () {
  const e = waitForAnyBriefTunnelAdded();
  block(matchDeleteBriefTunnel(e.id, ANY), function () {
    verifyBriefTunnelExists(e.id);
  });
});

bthread("BriefTunnel update verification", function () {
  const e = waitForAnyBriefTunnelUpdated();
  block(matchDeleteBriefTunnel(e.id, ANY), function () {
    verifyBriefTunnelUpdated(e.id);
  });
});

bthread("BriefTunnel delete verification", function () {
  const e = waitForAnyBriefTunnelDeleted();
  block(matchAddBriefTunnel(e.id, ANY), function () {
    verifyBriefTunnelDoesNotExist(e.id);
  });
});

bthread("NestedLocationRequest create verification", function () {
  const e = waitForAnyNestedLocationRequestAdded();
  block(matchDeleteNestedLocationRequest(e.id, ANY), function () {
    verifyNestedLocationRequestExists(e.id);
  });
});

bthread("NestedLocationRequest update verification", function () {
  const e = waitForAnyNestedLocationRequestUpdated();
  block(matchDeleteNestedLocationRequest(e.id, ANY), function () {
    verifyNestedLocationRequestUpdated(e.id);
  });
});

bthread("NestedLocationRequest delete verification", function () {
  const e = waitForAnyNestedLocationRequestDeleted();
  block(matchAddNestedLocationRequest(e.id, ANY), function () {
    verifyNestedLocationRequestDoesNotExist(e.id);
  });
});

bthread("NestedWirelessLANGroup create verification", function () {
  const e = waitForAnyNestedWirelessLANGroupAdded();
  block(matchDeleteNestedWirelessLANGroup(e.id, ANY), function () {
    verifyNestedWirelessLANGroupExists(e.id);
  });
});

bthread("NestedWirelessLANGroup update verification", function () {
  const e = waitForAnyNestedWirelessLANGroupUpdated();
  block(matchDeleteNestedWirelessLANGroup(e.id, ANY), function () {
    verifyNestedWirelessLANGroupUpdated(e.id);
  });
});

bthread("NestedWirelessLANGroup delete verification", function () {
  const e = waitForAnyNestedWirelessLANGroupDeleted();
  block(matchAddNestedWirelessLANGroup(e.id, ANY), function () {
    verifyNestedWirelessLANGroupDoesNotExist(e.id);
  });
});

bthread("PaginatedIKEProposalList create verification", function () {
  const e = waitForAnyPaginatedIKEProposalListAdded();
  block(matchDeletePaginatedIKEProposalList(e.id, ANY), function () {
    verifyPaginatedIKEProposalListExists(e.id);
  });
});

bthread("PaginatedIKEProposalList update verification", function () {
  const e = waitForAnyPaginatedIKEProposalListUpdated();
  block(matchDeletePaginatedIKEProposalList(e.id, ANY), function () {
    verifyPaginatedIKEProposalListUpdated(e.id);
  });
});

bthread("PaginatedIKEProposalList delete verification", function () {
  const e = waitForAnyPaginatedIKEProposalListDeleted();
  block(matchAddPaginatedIKEProposalList(e.id, ANY), function () {
    verifyPaginatedIKEProposalListDoesNotExist(e.id);
  });
});

bthread("PaginatedVMInterfaceList create verification", function () {
  const e = waitForAnyPaginatedVMInterfaceListAdded();
  block(matchDeletePaginatedVMInterfaceList(e.id, ANY), function () {
    verifyPaginatedVMInterfaceListExists(e.id);
  });
});

bthread("PaginatedVMInterfaceList update verification", function () {
  const e = waitForAnyPaginatedVMInterfaceListUpdated();
  block(matchDeletePaginatedVMInterfaceList(e.id, ANY), function () {
    verifyPaginatedVMInterfaceListUpdated(e.id);
  });
});

bthread("PaginatedVMInterfaceList delete verification", function () {
  const e = waitForAnyPaginatedVMInterfaceListDeleted();
  block(matchAddPaginatedVMInterfaceList(e.id, ANY), function () {
    verifyPaginatedVMInterfaceListDoesNotExist(e.id);
  });
});

bthread("NestedVLANRequest create verification", function () {
  const e = waitForAnyNestedVLANRequestAdded();
  block(matchDeleteNestedVLANRequest(e.id, ANY), function () {
    verifyNestedVLANRequestExists(e.id);
  });
});

bthread("NestedVLANRequest update verification", function () {
  const e = waitForAnyNestedVLANRequestUpdated();
  block(matchDeleteNestedVLANRequest(e.id, ANY), function () {
    verifyNestedVLANRequestUpdated(e.id);
  });
});

bthread("NestedVLANRequest delete verification", function () {
  const e = waitForAnyNestedVLANRequestDeleted();
  block(matchAddNestedVLANRequest(e.id, ANY), function () {
    verifyNestedVLANRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWebhookRequest create verification", function () {
  const e = waitForAnyPatchedWebhookRequestAdded();
  block(matchDeletePatchedWebhookRequest(e.id, ANY), function () {
    verifyPatchedWebhookRequestExists(e.id);
  });
});

bthread("PatchedWebhookRequest update verification", function () {
  const e = waitForAnyPatchedWebhookRequestUpdated();
  block(matchDeletePatchedWebhookRequest(e.id, ANY), function () {
    verifyPatchedWebhookRequestUpdated(e.id);
  });
});

bthread("PatchedWebhookRequest delete verification", function () {
  const e = waitForAnyPatchedWebhookRequestDeleted();
  block(matchAddPatchedWebhookRequest(e.id, ANY), function () {
    verifyPatchedWebhookRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableIPAddressRequest create verification", function () {
  const e = waitForAnyPatchedWritableIPAddressRequestAdded();
  block(matchDeletePatchedWritableIPAddressRequest(e.id, ANY), function () {
    verifyPatchedWritableIPAddressRequestExists(e.id);
  });
});

bthread("PatchedWritableIPAddressRequest update verification", function () {
  const e = waitForAnyPatchedWritableIPAddressRequestUpdated();
  block(matchDeletePatchedWritableIPAddressRequest(e.id, ANY), function () {
    verifyPatchedWritableIPAddressRequestUpdated(e.id);
  });
});

bthread("PatchedWritableIPAddressRequest delete verification", function () {
  const e = waitForAnyPatchedWritableIPAddressRequestDeleted();
  block(matchAddPatchedWritableIPAddressRequest(e.id, ANY), function () {
    verifyPatchedWritableIPAddressRequestDoesNotExist(e.id);
  });
});

bthread("WritableIPSecProposalRequest create verification", function () {
  const e = waitForAnyWritableIPSecProposalRequestAdded();
  block(matchDeleteWritableIPSecProposalRequest(e.id, ANY), function () {
    verifyWritableIPSecProposalRequestExists(e.id);
  });
});

bthread("WritableIPSecProposalRequest update verification", function () {
  const e = waitForAnyWritableIPSecProposalRequestUpdated();
  block(matchDeleteWritableIPSecProposalRequest(e.id, ANY), function () {
    verifyWritableIPSecProposalRequestUpdated(e.id);
  });
});

bthread("WritableIPSecProposalRequest delete verification", function () {
  const e = waitForAnyWritableIPSecProposalRequestDeleted();
  block(matchAddWritableIPSecProposalRequest(e.id, ANY), function () {
    verifyWritableIPSecProposalRequestDoesNotExist(e.id);
  });
});

bthread("PatchedNotificationRequest create verification", function () {
  const e = waitForAnyPatchedNotificationRequestAdded();
  block(matchDeletePatchedNotificationRequest(e.id, ANY), function () {
    verifyPatchedNotificationRequestExists(e.id);
  });
});

bthread("PatchedNotificationRequest update verification", function () {
  const e = waitForAnyPatchedNotificationRequestUpdated();
  block(matchDeletePatchedNotificationRequest(e.id, ANY), function () {
    verifyPatchedNotificationRequestUpdated(e.id);
  });
});

bthread("PatchedNotificationRequest delete verification", function () {
  const e = waitForAnyPatchedNotificationRequestDeleted();
  block(matchAddPatchedNotificationRequest(e.id, ANY), function () {
    verifyPatchedNotificationRequestDoesNotExist(e.id);
  });
});

bthread("WritablePlatformRequest create verification", function () {
  const e = waitForAnyWritablePlatformRequestAdded();
  block(matchDeleteWritablePlatformRequest(e.id, ANY), function () {
    verifyWritablePlatformRequestExists(e.id);
  });
});

bthread("WritablePlatformRequest update verification", function () {
  const e = waitForAnyWritablePlatformRequestUpdated();
  block(matchDeleteWritablePlatformRequest(e.id, ANY), function () {
    verifyWritablePlatformRequestUpdated(e.id);
  });
});

bthread("WritablePlatformRequest delete verification", function () {
  const e = waitForAnyWritablePlatformRequestDeleted();
  block(matchAddWritablePlatformRequest(e.id, ANY), function () {
    verifyWritablePlatformRequestDoesNotExist(e.id);
  });
});

bthread("PowerOutletTemplate create verification", function () {
  const e = waitForAnyPowerOutletTemplateAdded();
  block(matchDeletePowerOutletTemplate(e.id, ANY), function () {
    verifyPowerOutletTemplateExists(e.id);
  });
});

bthread("PowerOutletTemplate update verification", function () {
  const e = waitForAnyPowerOutletTemplateUpdated();
  block(matchDeletePowerOutletTemplate(e.id, ANY), function () {
    verifyPowerOutletTemplateUpdated(e.id);
  });
});

bthread("PowerOutletTemplate delete verification", function () {
  const e = waitForAnyPowerOutletTemplateDeleted();
  block(matchAddPowerOutletTemplate(e.id, ANY), function () {
    verifyPowerOutletTemplateDoesNotExist(e.id);
  });
});

bthread("PatchedDeviceBayRequest create verification", function () {
  const e = waitForAnyPatchedDeviceBayRequestAdded();
  block(matchDeletePatchedDeviceBayRequest(e.id, ANY), function () {
    verifyPatchedDeviceBayRequestExists(e.id);
  });
});

bthread("PatchedDeviceBayRequest update verification", function () {
  const e = waitForAnyPatchedDeviceBayRequestUpdated();
  block(matchDeletePatchedDeviceBayRequest(e.id, ANY), function () {
    verifyPatchedDeviceBayRequestUpdated(e.id);
  });
});

bthread("PatchedDeviceBayRequest delete verification", function () {
  const e = waitForAnyPatchedDeviceBayRequestDeleted();
  block(matchAddPatchedDeviceBayRequest(e.id, ANY), function () {
    verifyPatchedDeviceBayRequestDoesNotExist(e.id);
  });
});

bthread("PatchedBookmarkRequest create verification", function () {
  const e = waitForAnyPatchedBookmarkRequestAdded();
  block(matchDeletePatchedBookmarkRequest(e.id, ANY), function () {
    verifyPatchedBookmarkRequestExists(e.id);
  });
});

bthread("PatchedBookmarkRequest update verification", function () {
  const e = waitForAnyPatchedBookmarkRequestUpdated();
  block(matchDeletePatchedBookmarkRequest(e.id, ANY), function () {
    verifyPatchedBookmarkRequestUpdated(e.id);
  });
});

bthread("PatchedBookmarkRequest delete verification", function () {
  const e = waitForAnyPatchedBookmarkRequestDeleted();
  block(matchAddPatchedBookmarkRequest(e.id, ANY), function () {
    verifyPatchedBookmarkRequestDoesNotExist(e.id);
  });
});

bthread("BriefDeviceRoleRequest create verification", function () {
  const e = waitForAnyBriefDeviceRoleRequestAdded();
  block(matchDeleteBriefDeviceRoleRequest(e.id, ANY), function () {
    verifyBriefDeviceRoleRequestExists(e.id);
  });
});

bthread("BriefDeviceRoleRequest update verification", function () {
  const e = waitForAnyBriefDeviceRoleRequestUpdated();
  block(matchDeleteBriefDeviceRoleRequest(e.id, ANY), function () {
    verifyBriefDeviceRoleRequestUpdated(e.id);
  });
});

bthread("BriefDeviceRoleRequest delete verification", function () {
  const e = waitForAnyBriefDeviceRoleRequestDeleted();
  block(matchAddBriefDeviceRoleRequest(e.id, ANY), function () {
    verifyBriefDeviceRoleRequestDoesNotExist(e.id);
  });
});

bthread("WritableIPSecPolicyRequest create verification", function () {
  const e = waitForAnyWritableIPSecPolicyRequestAdded();
  block(matchDeleteWritableIPSecPolicyRequest(e.id, ANY), function () {
    verifyWritableIPSecPolicyRequestExists(e.id);
  });
});

bthread("WritableIPSecPolicyRequest update verification", function () {
  const e = waitForAnyWritableIPSecPolicyRequestUpdated();
  block(matchDeleteWritableIPSecPolicyRequest(e.id, ANY), function () {
    verifyWritableIPSecPolicyRequestUpdated(e.id);
  });
});

bthread("WritableIPSecPolicyRequest delete verification", function () {
  const e = waitForAnyWritableIPSecPolicyRequestDeleted();
  block(matchAddWritableIPSecPolicyRequest(e.id, ANY), function () {
    verifyWritableIPSecPolicyRequestDoesNotExist(e.id);
  });
});

bthread("CircuitRequest create verification", function () {
  const e = waitForAnyCircuitRequestAdded();
  block(matchDeleteCircuitRequest(e.id, ANY), function () {
    verifyCircuitRequestExists(e.id);
  });
});

bthread("CircuitRequest update verification", function () {
  const e = waitForAnyCircuitRequestUpdated();
  block(matchDeleteCircuitRequest(e.id, ANY), function () {
    verifyCircuitRequestUpdated(e.id);
  });
});

bthread("CircuitRequest delete verification", function () {
  const e = waitForAnyCircuitRequestDeleted();
  block(matchAddCircuitRequest(e.id, ANY), function () {
    verifyCircuitRequestDoesNotExist(e.id);
  });
});

bthread("MACAddress create verification", function () {
  const e = waitForAnyMACAddressAdded();
  block(matchDeleteMACAddress(e.id, ANY), function () {
    verifyMACAddressExists(e.id);
  });
});

bthread("MACAddress update verification", function () {
  const e = waitForAnyMACAddressUpdated();
  block(matchDeleteMACAddress(e.id, ANY), function () {
    verifyMACAddressUpdated(e.id);
  });
});

bthread("MACAddress delete verification", function () {
  const e = waitForAnyMACAddressDeleted();
  block(matchAddMACAddress(e.id, ANY), function () {
    verifyMACAddressDoesNotExist(e.id);
  });
});

bthread("DataFile create verification", function () {
  const e = waitForAnyDataFileAdded();
  block(matchDeleteDataFile(e.id, ANY), function () {
    verifyDataFileExists(e.id);
  });
});

bthread("DataFile update verification", function () {
  const e = waitForAnyDataFileUpdated();
  block(matchDeleteDataFile(e.id, ANY), function () {
    verifyDataFileUpdated(e.id);
  });
});

bthread("DataFile delete verification", function () {
  const e = waitForAnyDataFileDeleted();
  block(matchAddDataFile(e.id, ANY), function () {
    verifyDataFileDoesNotExist(e.id);
  });
});

bthread("WritableConsolePortRequest create verification", function () {
  const e = waitForAnyWritableConsolePortRequestAdded();
  block(matchDeleteWritableConsolePortRequest(e.id, ANY), function () {
    verifyWritableConsolePortRequestExists(e.id);
  });
});

bthread("WritableConsolePortRequest update verification", function () {
  const e = waitForAnyWritableConsolePortRequestUpdated();
  block(matchDeleteWritableConsolePortRequest(e.id, ANY), function () {
    verifyWritableConsolePortRequestUpdated(e.id);
  });
});

bthread("WritableConsolePortRequest delete verification", function () {
  const e = waitForAnyWritableConsolePortRequestDeleted();
  block(matchAddWritableConsolePortRequest(e.id, ANY), function () {
    verifyWritableConsolePortRequestDoesNotExist(e.id);
  });
});

bthread("DeviceTypeRequest create verification", function () {
  const e = waitForAnyDeviceTypeRequestAdded();
  block(matchDeleteDeviceTypeRequest(e.id, ANY), function () {
    verifyDeviceTypeRequestExists(e.id);
  });
});

bthread("DeviceTypeRequest update verification", function () {
  const e = waitForAnyDeviceTypeRequestUpdated();
  block(matchDeleteDeviceTypeRequest(e.id, ANY), function () {
    verifyDeviceTypeRequestUpdated(e.id);
  });
});

bthread("DeviceTypeRequest delete verification", function () {
  const e = waitForAnyDeviceTypeRequestDeleted();
  block(matchAddDeviceTypeRequest(e.id, ANY), function () {
    verifyDeviceTypeRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedCustomLinkList create verification", function () {
  const e = waitForAnyPaginatedCustomLinkListAdded();
  block(matchDeletePaginatedCustomLinkList(e.id, ANY), function () {
    verifyPaginatedCustomLinkListExists(e.id);
  });
});

bthread("PaginatedCustomLinkList update verification", function () {
  const e = waitForAnyPaginatedCustomLinkListUpdated();
  block(matchDeletePaginatedCustomLinkList(e.id, ANY), function () {
    verifyPaginatedCustomLinkListUpdated(e.id);
  });
});

bthread("PaginatedCustomLinkList delete verification", function () {
  const e = waitForAnyPaginatedCustomLinkListDeleted();
  block(matchAddPaginatedCustomLinkList(e.id, ANY), function () {
    verifyPaginatedCustomLinkListDoesNotExist(e.id);
  });
});

bthread("DeviceType create verification", function () {
  const e = waitForAnyDeviceTypeAdded();
  block(matchDeleteDeviceType(e.id, ANY), function () {
    verifyDeviceTypeExists(e.id);
  });
});

bthread("DeviceType update verification", function () {
  const e = waitForAnyDeviceTypeUpdated();
  block(matchDeleteDeviceType(e.id, ANY), function () {
    verifyDeviceTypeUpdated(e.id);
  });
});

bthread("DeviceType delete verification", function () {
  const e = waitForAnyDeviceTypeDeleted();
  block(matchAddDeviceType(e.id, ANY), function () {
    verifyDeviceTypeDoesNotExist(e.id);
  });
});

bthread("PatchedTokenRequest create verification", function () {
  const e = waitForAnyPatchedTokenRequestAdded();
  block(matchDeletePatchedTokenRequest(e.id, ANY), function () {
    verifyPatchedTokenRequestExists(e.id);
  });
});

bthread("PatchedTokenRequest update verification", function () {
  const e = waitForAnyPatchedTokenRequestUpdated();
  block(matchDeletePatchedTokenRequest(e.id, ANY), function () {
    verifyPatchedTokenRequestUpdated(e.id);
  });
});

bthread("PatchedTokenRequest delete verification", function () {
  const e = waitForAnyPatchedTokenRequestDeleted();
  block(matchAddPatchedTokenRequest(e.id, ANY), function () {
    verifyPatchedTokenRequestDoesNotExist(e.id);
  });
});

bthread("BriefModuleTypeProfileRequest create verification", function () {
  const e = waitForAnyBriefModuleTypeProfileRequestAdded();
  block(matchDeleteBriefModuleTypeProfileRequest(e.id, ANY), function () {
    verifyBriefModuleTypeProfileRequestExists(e.id);
  });
});

bthread("BriefModuleTypeProfileRequest update verification", function () {
  const e = waitForAnyBriefModuleTypeProfileRequestUpdated();
  block(matchDeleteBriefModuleTypeProfileRequest(e.id, ANY), function () {
    verifyBriefModuleTypeProfileRequestUpdated(e.id);
  });
});

bthread("BriefModuleTypeProfileRequest delete verification", function () {
  const e = waitForAnyBriefModuleTypeProfileRequestDeleted();
  block(matchAddBriefModuleTypeProfileRequest(e.id, ANY), function () {
    verifyBriefModuleTypeProfileRequestDoesNotExist(e.id);
  });
});

bthread("DeviceWithConfigContext create verification", function () {
  const e = waitForAnyDeviceWithConfigContextAdded();
  block(matchDeleteDeviceWithConfigContext(e.id, ANY), function () {
    verifyDeviceWithConfigContextExists(e.id);
  });
});

bthread("DeviceWithConfigContext update verification", function () {
  const e = waitForAnyDeviceWithConfigContextUpdated();
  block(matchDeleteDeviceWithConfigContext(e.id, ANY), function () {
    verifyDeviceWithConfigContextUpdated(e.id);
  });
});

bthread("DeviceWithConfigContext delete verification", function () {
  const e = waitForAnyDeviceWithConfigContextDeleted();
  block(matchAddDeviceWithConfigContext(e.id, ANY), function () {
    verifyDeviceWithConfigContextDoesNotExist(e.id);
  });
});

bthread("ModuleBayTemplateRequest create verification", function () {
  const e = waitForAnyModuleBayTemplateRequestAdded();
  block(matchDeleteModuleBayTemplateRequest(e.id, ANY), function () {
    verifyModuleBayTemplateRequestExists(e.id);
  });
});

bthread("ModuleBayTemplateRequest update verification", function () {
  const e = waitForAnyModuleBayTemplateRequestUpdated();
  block(matchDeleteModuleBayTemplateRequest(e.id, ANY), function () {
    verifyModuleBayTemplateRequestUpdated(e.id);
  });
});

bthread("ModuleBayTemplateRequest delete verification", function () {
  const e = waitForAnyModuleBayTemplateRequestDeleted();
  block(matchAddModuleBayTemplateRequest(e.id, ANY), function () {
    verifyModuleBayTemplateRequestDoesNotExist(e.id);
  });
});

bthread("ProviderAccountRequest create verification", function () {
  const e = waitForAnyProviderAccountRequestAdded();
  block(matchDeleteProviderAccountRequest(e.id, ANY), function () {
    verifyProviderAccountRequestExists(e.id);
  });
});

bthread("ProviderAccountRequest update verification", function () {
  const e = waitForAnyProviderAccountRequestUpdated();
  block(matchDeleteProviderAccountRequest(e.id, ANY), function () {
    verifyProviderAccountRequestUpdated(e.id);
  });
});

bthread("ProviderAccountRequest delete verification", function () {
  const e = waitForAnyProviderAccountRequestDeleted();
  block(matchAddProviderAccountRequest(e.id, ANY), function () {
    verifyProviderAccountRequestDoesNotExist(e.id);
  });
});

bthread("WritableRackTypeRequest create verification", function () {
  const e = waitForAnyWritableRackTypeRequestAdded();
  block(matchDeleteWritableRackTypeRequest(e.id, ANY), function () {
    verifyWritableRackTypeRequestExists(e.id);
  });
});

bthread("WritableRackTypeRequest update verification", function () {
  const e = waitForAnyWritableRackTypeRequestUpdated();
  block(matchDeleteWritableRackTypeRequest(e.id, ANY), function () {
    verifyWritableRackTypeRequestUpdated(e.id);
  });
});

bthread("WritableRackTypeRequest delete verification", function () {
  const e = waitForAnyWritableRackTypeRequestDeleted();
  block(matchAddWritableRackTypeRequest(e.id, ANY), function () {
    verifyWritableRackTypeRequestDoesNotExist(e.id);
  });
});

bthread("BriefInventoryItemRoleRequest create verification", function () {
  const e = waitForAnyBriefInventoryItemRoleRequestAdded();
  block(matchDeleteBriefInventoryItemRoleRequest(e.id, ANY), function () {
    verifyBriefInventoryItemRoleRequestExists(e.id);
  });
});

bthread("BriefInventoryItemRoleRequest update verification", function () {
  const e = waitForAnyBriefInventoryItemRoleRequestUpdated();
  block(matchDeleteBriefInventoryItemRoleRequest(e.id, ANY), function () {
    verifyBriefInventoryItemRoleRequestUpdated(e.id);
  });
});

bthread("BriefInventoryItemRoleRequest delete verification", function () {
  const e = waitForAnyBriefInventoryItemRoleRequestDeleted();
  block(matchAddBriefInventoryItemRoleRequest(e.id, ANY), function () {
    verifyBriefInventoryItemRoleRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedUserList create verification", function () {
  const e = waitForAnyPaginatedUserListAdded();
  block(matchDeletePaginatedUserList(e.id, ANY), function () {
    verifyPaginatedUserListExists(e.id);
  });
});

bthread("PaginatedUserList update verification", function () {
  const e = waitForAnyPaginatedUserListUpdated();
  block(matchDeletePaginatedUserList(e.id, ANY), function () {
    verifyPaginatedUserListUpdated(e.id);
  });
});

bthread("PaginatedUserList delete verification", function () {
  const e = waitForAnyPaginatedUserListDeleted();
  block(matchAddPaginatedUserList(e.id, ANY), function () {
    verifyPaginatedUserListDoesNotExist(e.id);
  });
});

bthread("IPSecProfileRequest create verification", function () {
  const e = waitForAnyIPSecProfileRequestAdded();
  block(matchDeleteIPSecProfileRequest(e.id, ANY), function () {
    verifyIPSecProfileRequestExists(e.id);
  });
});

bthread("IPSecProfileRequest update verification", function () {
  const e = waitForAnyIPSecProfileRequestUpdated();
  block(matchDeleteIPSecProfileRequest(e.id, ANY), function () {
    verifyIPSecProfileRequestUpdated(e.id);
  });
});

bthread("IPSecProfileRequest delete verification", function () {
  const e = waitForAnyIPSecProfileRequestDeleted();
  block(matchAddIPSecProfileRequest(e.id, ANY), function () {
    verifyIPSecProfileRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedInventoryItemList create verification", function () {
  const e = waitForAnyPaginatedInventoryItemListAdded();
  block(matchDeletePaginatedInventoryItemList(e.id, ANY), function () {
    verifyPaginatedInventoryItemListExists(e.id);
  });
});

bthread("PaginatedInventoryItemList update verification", function () {
  const e = waitForAnyPaginatedInventoryItemListUpdated();
  block(matchDeletePaginatedInventoryItemList(e.id, ANY), function () {
    verifyPaginatedInventoryItemListUpdated(e.id);
  });
});

bthread("PaginatedInventoryItemList delete verification", function () {
  const e = waitForAnyPaginatedInventoryItemListDeleted();
  block(matchAddPaginatedInventoryItemList(e.id, ANY), function () {
    verifyPaginatedInventoryItemListDoesNotExist(e.id);
  });
});

bthread("RackRoleRequest create verification", function () {
  const e = waitForAnyRackRoleRequestAdded();
  block(matchDeleteRackRoleRequest(e.id, ANY), function () {
    verifyRackRoleRequestExists(e.id);
  });
});

bthread("RackRoleRequest update verification", function () {
  const e = waitForAnyRackRoleRequestUpdated();
  block(matchDeleteRackRoleRequest(e.id, ANY), function () {
    verifyRackRoleRequestUpdated(e.id);
  });
});

bthread("RackRoleRequest delete verification", function () {
  const e = waitForAnyRackRoleRequestDeleted();
  block(matchAddRackRoleRequest(e.id, ANY), function () {
    verifyRackRoleRequestDoesNotExist(e.id);
  });
});

bthread("BriefModule create verification", function () {
  const e = waitForAnyBriefModuleAdded();
  block(matchDeleteBriefModule(e.id, ANY), function () {
    verifyBriefModuleExists(e.id);
  });
});

bthread("BriefModule update verification", function () {
  const e = waitForAnyBriefModuleUpdated();
  block(matchDeleteBriefModule(e.id, ANY), function () {
    verifyBriefModuleUpdated(e.id);
  });
});

bthread("BriefModule delete verification", function () {
  const e = waitForAnyBriefModuleDeleted();
  block(matchAddBriefModule(e.id, ANY), function () {
    verifyBriefModuleDoesNotExist(e.id);
  });
});

bthread("PatchedWritableSiteGroupRequest create verification", function () {
  const e = waitForAnyPatchedWritableSiteGroupRequestAdded();
  block(matchDeletePatchedWritableSiteGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableSiteGroupRequestExists(e.id);
  });
});

bthread("PatchedWritableSiteGroupRequest update verification", function () {
  const e = waitForAnyPatchedWritableSiteGroupRequestUpdated();
  block(matchDeletePatchedWritableSiteGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableSiteGroupRequestUpdated(e.id);
  });
});

bthread("PatchedWritableSiteGroupRequest delete verification", function () {
  const e = waitForAnyPatchedWritableSiteGroupRequestDeleted();
  block(matchAddPatchedWritableSiteGroupRequest(e.id, ANY), function () {
    verifyPatchedWritableSiteGroupRequestDoesNotExist(e.id);
  });
});

bthread("WirelessLANRequest create verification", function () {
  const e = waitForAnyWirelessLANRequestAdded();
  block(matchDeleteWirelessLANRequest(e.id, ANY), function () {
    verifyWirelessLANRequestExists(e.id);
  });
});

bthread("WirelessLANRequest update verification", function () {
  const e = waitForAnyWirelessLANRequestUpdated();
  block(matchDeleteWirelessLANRequest(e.id, ANY), function () {
    verifyWirelessLANRequestUpdated(e.id);
  });
});

bthread("WirelessLANRequest delete verification", function () {
  const e = waitForAnyWirelessLANRequestDeleted();
  block(matchAddWirelessLANRequest(e.id, ANY), function () {
    verifyWirelessLANRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedDataFileList create verification", function () {
  const e = waitForAnyPaginatedDataFileListAdded();
  block(matchDeletePaginatedDataFileList(e.id, ANY), function () {
    verifyPaginatedDataFileListExists(e.id);
  });
});

bthread("PaginatedDataFileList update verification", function () {
  const e = waitForAnyPaginatedDataFileListUpdated();
  block(matchDeletePaginatedDataFileList(e.id, ANY), function () {
    verifyPaginatedDataFileListUpdated(e.id);
  });
});

bthread("PaginatedDataFileList delete verification", function () {
  const e = waitForAnyPaginatedDataFileListDeleted();
  block(matchAddPaginatedDataFileList(e.id, ANY), function () {
    verifyPaginatedDataFileListDoesNotExist(e.id);
  });
});

bthread("PaginatedVLANTranslationPolicyList create verification", function () {
  const e = waitForAnyPaginatedVLANTranslationPolicyListAdded();
  block(matchDeletePaginatedVLANTranslationPolicyList(e.id, ANY), function () {
    verifyPaginatedVLANTranslationPolicyListExists(e.id);
  });
});

bthread("PaginatedVLANTranslationPolicyList update verification", function () {
  const e = waitForAnyPaginatedVLANTranslationPolicyListUpdated();
  block(matchDeletePaginatedVLANTranslationPolicyList(e.id, ANY), function () {
    verifyPaginatedVLANTranslationPolicyListUpdated(e.id);
  });
});

bthread("PaginatedVLANTranslationPolicyList delete verification", function () {
  const e = waitForAnyPaginatedVLANTranslationPolicyListDeleted();
  block(matchAddPaginatedVLANTranslationPolicyList(e.id, ANY), function () {
    verifyPaginatedVLANTranslationPolicyListDoesNotExist(e.id);
  });
});

bthread("Provider create verification", function () {
  const e = waitForAnyProviderAdded();
  block(matchDeleteProvider(e.id, ANY), function () {
    verifyProviderExists(e.id);
  });
});

bthread("Provider update verification", function () {
  const e = waitForAnyProviderUpdated();
  block(matchDeleteProvider(e.id, ANY), function () {
    verifyProviderUpdated(e.id);
  });
});

bthread("Provider delete verification", function () {
  const e = waitForAnyProviderDeleted();
  block(matchAddProvider(e.id, ANY), function () {
    verifyProviderDoesNotExist(e.id);
  });
});

bthread("TagRequest create verification", function () {
  const e = waitForAnyTagRequestAdded();
  block(matchDeleteTagRequest(e.id, ANY), function () {
    verifyTagRequestExists(e.id);
  });
});

bthread("TagRequest update verification", function () {
  const e = waitForAnyTagRequestUpdated();
  block(matchDeleteTagRequest(e.id, ANY), function () {
    verifyTagRequestUpdated(e.id);
  });
});

bthread("TagRequest delete verification", function () {
  const e = waitForAnyTagRequestDeleted();
  block(matchAddTagRequest(e.id, ANY), function () {
    verifyTagRequestDoesNotExist(e.id);
  });
});

bthread("BriefInterfaceRequest create verification", function () {
  const e = waitForAnyBriefInterfaceRequestAdded();
  block(matchDeleteBriefInterfaceRequest(e.id, ANY), function () {
    verifyBriefInterfaceRequestExists(e.id);
  });
});

bthread("BriefInterfaceRequest update verification", function () {
  const e = waitForAnyBriefInterfaceRequestUpdated();
  block(matchDeleteBriefInterfaceRequest(e.id, ANY), function () {
    verifyBriefInterfaceRequestUpdated(e.id);
  });
});

bthread("BriefInterfaceRequest delete verification", function () {
  const e = waitForAnyBriefInterfaceRequestDeleted();
  block(matchAddBriefInterfaceRequest(e.id, ANY), function () {
    verifyBriefInterfaceRequestDoesNotExist(e.id);
  });
});

bthread("ContactRoleRequest create verification", function () {
  const e = waitForAnyContactRoleRequestAdded();
  block(matchDeleteContactRoleRequest(e.id, ANY), function () {
    verifyContactRoleRequestExists(e.id);
  });
});

bthread("ContactRoleRequest update verification", function () {
  const e = waitForAnyContactRoleRequestUpdated();
  block(matchDeleteContactRoleRequest(e.id, ANY), function () {
    verifyContactRoleRequestUpdated(e.id);
  });
});

bthread("ContactRoleRequest delete verification", function () {
  const e = waitForAnyContactRoleRequestDeleted();
  block(matchAddContactRoleRequest(e.id, ANY), function () {
    verifyContactRoleRequestDoesNotExist(e.id);
  });
});

bthread("IntegerRangeRequest create verification", function () {
  const e = waitForAnyIntegerRangeRequestAdded();
  block(matchDeleteIntegerRangeRequest(e.id, ANY), function () {
    verifyIntegerRangeRequestExists(e.id);
  });
});

bthread("IntegerRangeRequest update verification", function () {
  const e = waitForAnyIntegerRangeRequestUpdated();
  block(matchDeleteIntegerRangeRequest(e.id, ANY), function () {
    verifyIntegerRangeRequestUpdated(e.id);
  });
});

bthread("IntegerRangeRequest delete verification", function () {
  const e = waitForAnyIntegerRangeRequestDeleted();
  block(matchAddIntegerRangeRequest(e.id, ANY), function () {
    verifyIntegerRangeRequestDoesNotExist(e.id);
  });
});

bthread("NestedTenantGroupRequest create verification", function () {
  const e = waitForAnyNestedTenantGroupRequestAdded();
  block(matchDeleteNestedTenantGroupRequest(e.id, ANY), function () {
    verifyNestedTenantGroupRequestExists(e.id);
  });
});

bthread("NestedTenantGroupRequest update verification", function () {
  const e = waitForAnyNestedTenantGroupRequestUpdated();
  block(matchDeleteNestedTenantGroupRequest(e.id, ANY), function () {
    verifyNestedTenantGroupRequestUpdated(e.id);
  });
});

bthread("NestedTenantGroupRequest delete verification", function () {
  const e = waitForAnyNestedTenantGroupRequestDeleted();
  block(matchAddNestedTenantGroupRequest(e.id, ANY), function () {
    verifyNestedTenantGroupRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableDeviceRoleRequest create verification", function () {
  const e = waitForAnyPatchedWritableDeviceRoleRequestAdded();
  block(matchDeletePatchedWritableDeviceRoleRequest(e.id, ANY), function () {
    verifyPatchedWritableDeviceRoleRequestExists(e.id);
  });
});

bthread("PatchedWritableDeviceRoleRequest update verification", function () {
  const e = waitForAnyPatchedWritableDeviceRoleRequestUpdated();
  block(matchDeletePatchedWritableDeviceRoleRequest(e.id, ANY), function () {
    verifyPatchedWritableDeviceRoleRequestUpdated(e.id);
  });
});

bthread("PatchedWritableDeviceRoleRequest delete verification", function () {
  const e = waitForAnyPatchedWritableDeviceRoleRequestDeleted();
  block(matchAddPatchedWritableDeviceRoleRequest(e.id, ANY), function () {
    verifyPatchedWritableDeviceRoleRequestDoesNotExist(e.id);
  });
});

bthread("NotificationRequest create verification", function () {
  const e = waitForAnyNotificationRequestAdded();
  block(matchDeleteNotificationRequest(e.id, ANY), function () {
    verifyNotificationRequestExists(e.id);
  });
});

bthread("NotificationRequest update verification", function () {
  const e = waitForAnyNotificationRequestUpdated();
  block(matchDeleteNotificationRequest(e.id, ANY), function () {
    verifyNotificationRequestUpdated(e.id);
  });
});

bthread("NotificationRequest delete verification", function () {
  const e = waitForAnyNotificationRequestDeleted();
  block(matchAddNotificationRequest(e.id, ANY), function () {
    verifyNotificationRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableDeviceTypeRequest create verification", function () {
  const e = waitForAnyPatchedWritableDeviceTypeRequestAdded();
  block(matchDeletePatchedWritableDeviceTypeRequest(e.id, ANY), function () {
    verifyPatchedWritableDeviceTypeRequestExists(e.id);
  });
});

bthread("PatchedWritableDeviceTypeRequest update verification", function () {
  const e = waitForAnyPatchedWritableDeviceTypeRequestUpdated();
  block(matchDeletePatchedWritableDeviceTypeRequest(e.id, ANY), function () {
    verifyPatchedWritableDeviceTypeRequestUpdated(e.id);
  });
});

bthread("PatchedWritableDeviceTypeRequest delete verification", function () {
  const e = waitForAnyPatchedWritableDeviceTypeRequestDeleted();
  block(matchAddPatchedWritableDeviceTypeRequest(e.id, ANY), function () {
    verifyPatchedWritableDeviceTypeRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableModuleRequest create verification", function () {
  const e = waitForAnyPatchedWritableModuleRequestAdded();
  block(matchDeletePatchedWritableModuleRequest(e.id, ANY), function () {
    verifyPatchedWritableModuleRequestExists(e.id);
  });
});

bthread("PatchedWritableModuleRequest update verification", function () {
  const e = waitForAnyPatchedWritableModuleRequestUpdated();
  block(matchDeletePatchedWritableModuleRequest(e.id, ANY), function () {
    verifyPatchedWritableModuleRequestUpdated(e.id);
  });
});

bthread("PatchedWritableModuleRequest delete verification", function () {
  const e = waitForAnyPatchedWritableModuleRequestDeleted();
  block(matchAddPatchedWritableModuleRequest(e.id, ANY), function () {
    verifyPatchedWritableModuleRequestDoesNotExist(e.id);
  });
});

bthread("RackUnit create verification", function () {
  const e = waitForAnyRackUnitAdded();
  block(matchDeleteRackUnit(e.id, ANY), function () {
    verifyRackUnitExists(e.id);
  });
});

bthread("RackUnit update verification", function () {
  const e = waitForAnyRackUnitUpdated();
  block(matchDeleteRackUnit(e.id, ANY), function () {
    verifyRackUnitUpdated(e.id);
  });
});

bthread("RackUnit delete verification", function () {
  const e = waitForAnyRackUnitDeleted();
  block(matchAddRackUnit(e.id, ANY), function () {
    verifyRackUnitDoesNotExist(e.id);
  });
});

bthread("PaginatedVirtualChassisList create verification", function () {
  const e = waitForAnyPaginatedVirtualChassisListAdded();
  block(matchDeletePaginatedVirtualChassisList(e.id, ANY), function () {
    verifyPaginatedVirtualChassisListExists(e.id);
  });
});

bthread("PaginatedVirtualChassisList update verification", function () {
  const e = waitForAnyPaginatedVirtualChassisListUpdated();
  block(matchDeletePaginatedVirtualChassisList(e.id, ANY), function () {
    verifyPaginatedVirtualChassisListUpdated(e.id);
  });
});

bthread("PaginatedVirtualChassisList delete verification", function () {
  const e = waitForAnyPaginatedVirtualChassisListDeleted();
  block(matchAddPaginatedVirtualChassisList(e.id, ANY), function () {
    verifyPaginatedVirtualChassisListDoesNotExist(e.id);
  });
});

bthread("BriefDevice create verification", function () {
  const e = waitForAnyBriefDeviceAdded();
  block(matchDeleteBriefDevice(e.id, ANY), function () {
    verifyBriefDeviceExists(e.id);
  });
});

bthread("BriefDevice update verification", function () {
  const e = waitForAnyBriefDeviceUpdated();
  block(matchDeleteBriefDevice(e.id, ANY), function () {
    verifyBriefDeviceUpdated(e.id);
  });
});

bthread("BriefDevice delete verification", function () {
  const e = waitForAnyBriefDeviceDeleted();
  block(matchAddBriefDevice(e.id, ANY), function () {
    verifyBriefDeviceDoesNotExist(e.id);
  });
});

bthread("PaginatedEventRuleList create verification", function () {
  const e = waitForAnyPaginatedEventRuleListAdded();
  block(matchDeletePaginatedEventRuleList(e.id, ANY), function () {
    verifyPaginatedEventRuleListExists(e.id);
  });
});

bthread("PaginatedEventRuleList update verification", function () {
  const e = waitForAnyPaginatedEventRuleListUpdated();
  block(matchDeletePaginatedEventRuleList(e.id, ANY), function () {
    verifyPaginatedEventRuleListUpdated(e.id);
  });
});

bthread("PaginatedEventRuleList delete verification", function () {
  const e = waitForAnyPaginatedEventRuleListDeleted();
  block(matchAddPaginatedEventRuleList(e.id, ANY), function () {
    verifyPaginatedEventRuleListDoesNotExist(e.id);
  });
});

bthread("BriefVLANGroupRequest create verification", function () {
  const e = waitForAnyBriefVLANGroupRequestAdded();
  block(matchDeleteBriefVLANGroupRequest(e.id, ANY), function () {
    verifyBriefVLANGroupRequestExists(e.id);
  });
});

bthread("BriefVLANGroupRequest update verification", function () {
  const e = waitForAnyBriefVLANGroupRequestUpdated();
  block(matchDeleteBriefVLANGroupRequest(e.id, ANY), function () {
    verifyBriefVLANGroupRequestUpdated(e.id);
  });
});

bthread("BriefVLANGroupRequest delete verification", function () {
  const e = waitForAnyBriefVLANGroupRequestDeleted();
  block(matchAddBriefVLANGroupRequest(e.id, ANY), function () {
    verifyBriefVLANGroupRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableModuleTypeRequest create verification", function () {
  const e = waitForAnyPatchedWritableModuleTypeRequestAdded();
  block(matchDeletePatchedWritableModuleTypeRequest(e.id, ANY), function () {
    verifyPatchedWritableModuleTypeRequestExists(e.id);
  });
});

bthread("PatchedWritableModuleTypeRequest update verification", function () {
  const e = waitForAnyPatchedWritableModuleTypeRequestUpdated();
  block(matchDeletePatchedWritableModuleTypeRequest(e.id, ANY), function () {
    verifyPatchedWritableModuleTypeRequestUpdated(e.id);
  });
});

bthread("PatchedWritableModuleTypeRequest delete verification", function () {
  const e = waitForAnyPatchedWritableModuleTypeRequestDeleted();
  block(matchAddPatchedWritableModuleTypeRequest(e.id, ANY), function () {
    verifyPatchedWritableModuleTypeRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableInterfaceTemplateRequest create verification", function () {
  const e = waitForAnyPatchedWritableInterfaceTemplateRequestAdded();
  block(matchDeletePatchedWritableInterfaceTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableInterfaceTemplateRequestExists(e.id);
  });
});

bthread("PatchedWritableInterfaceTemplateRequest update verification", function () {
  const e = waitForAnyPatchedWritableInterfaceTemplateRequestUpdated();
  block(matchDeletePatchedWritableInterfaceTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableInterfaceTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedWritableInterfaceTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedWritableInterfaceTemplateRequestDeleted();
  block(matchAddPatchedWritableInterfaceTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableInterfaceTemplateRequestDoesNotExist(e.id);
  });
});

bthread("ClusterType create verification", function () {
  const e = waitForAnyClusterTypeAdded();
  block(matchDeleteClusterType(e.id, ANY), function () {
    verifyClusterTypeExists(e.id);
  });
});

bthread("ClusterType update verification", function () {
  const e = waitForAnyClusterTypeUpdated();
  block(matchDeleteClusterType(e.id, ANY), function () {
    verifyClusterTypeUpdated(e.id);
  });
});

bthread("ClusterType delete verification", function () {
  const e = waitForAnyClusterTypeDeleted();
  block(matchAddClusterType(e.id, ANY), function () {
    verifyClusterTypeDoesNotExist(e.id);
  });
});

bthread("Notification create verification", function () {
  const e = waitForAnyNotificationAdded();
  block(matchDeleteNotification(e.id, ANY), function () {
    verifyNotificationExists(e.id);
  });
});

bthread("Notification update verification", function () {
  const e = waitForAnyNotificationUpdated();
  block(matchDeleteNotification(e.id, ANY), function () {
    verifyNotificationUpdated(e.id);
  });
});

bthread("Notification delete verification", function () {
  const e = waitForAnyNotificationDeleted();
  block(matchAddNotification(e.id, ANY), function () {
    verifyNotificationDoesNotExist(e.id);
  });
});

bthread("WritableWirelessLANGroupRequest create verification", function () {
  const e = waitForAnyWritableWirelessLANGroupRequestAdded();
  block(matchDeleteWritableWirelessLANGroupRequest(e.id, ANY), function () {
    verifyWritableWirelessLANGroupRequestExists(e.id);
  });
});

bthread("WritableWirelessLANGroupRequest update verification", function () {
  const e = waitForAnyWritableWirelessLANGroupRequestUpdated();
  block(matchDeleteWritableWirelessLANGroupRequest(e.id, ANY), function () {
    verifyWritableWirelessLANGroupRequestUpdated(e.id);
  });
});

bthread("WritableWirelessLANGroupRequest delete verification", function () {
  const e = waitForAnyWritableWirelessLANGroupRequestDeleted();
  block(matchAddWritableWirelessLANGroupRequest(e.id, ANY), function () {
    verifyWritableWirelessLANGroupRequestDoesNotExist(e.id);
  });
});

bthread("TunnelTerminationRequest create verification", function () {
  const e = waitForAnyTunnelTerminationRequestAdded();
  block(matchDeleteTunnelTerminationRequest(e.id, ANY), function () {
    verifyTunnelTerminationRequestExists(e.id);
  });
});

bthread("TunnelTerminationRequest update verification", function () {
  const e = waitForAnyTunnelTerminationRequestUpdated();
  block(matchDeleteTunnelTerminationRequest(e.id, ANY), function () {
    verifyTunnelTerminationRequestUpdated(e.id);
  });
});

bthread("TunnelTerminationRequest delete verification", function () {
  const e = waitForAnyTunnelTerminationRequestDeleted();
  block(matchAddTunnelTerminationRequest(e.id, ANY), function () {
    verifyTunnelTerminationRequestDoesNotExist(e.id);
  });
});

bthread("ObjectPermissionRequest create verification", function () {
  const e = waitForAnyObjectPermissionRequestAdded();
  block(matchDeleteObjectPermissionRequest(e.id, ANY), function () {
    verifyObjectPermissionRequestExists(e.id);
  });
});

bthread("ObjectPermissionRequest update verification", function () {
  const e = waitForAnyObjectPermissionRequestUpdated();
  block(matchDeleteObjectPermissionRequest(e.id, ANY), function () {
    verifyObjectPermissionRequestUpdated(e.id);
  });
});

bthread("ObjectPermissionRequest delete verification", function () {
  const e = waitForAnyObjectPermissionRequestDeleted();
  block(matchAddObjectPermissionRequest(e.id, ANY), function () {
    verifyObjectPermissionRequestDoesNotExist(e.id);
  });
});

bthread("VLAN create verification", function () {
  const e = waitForAnyVLANAdded();
  block(matchDeleteVLAN(e.id, ANY), function () {
    verifyVLANExists(e.id);
  });
});

bthread("VLAN update verification", function () {
  const e = waitForAnyVLANUpdated();
  block(matchDeleteVLAN(e.id, ANY), function () {
    verifyVLANUpdated(e.id);
  });
});

bthread("VLAN delete verification", function () {
  const e = waitForAnyVLANDeleted();
  block(matchAddVLAN(e.id, ANY), function () {
    verifyVLANDoesNotExist(e.id);
  });
});

bthread("FrontPortTemplateRequest create verification", function () {
  const e = waitForAnyFrontPortTemplateRequestAdded();
  block(matchDeleteFrontPortTemplateRequest(e.id, ANY), function () {
    verifyFrontPortTemplateRequestExists(e.id);
  });
});

bthread("FrontPortTemplateRequest update verification", function () {
  const e = waitForAnyFrontPortTemplateRequestUpdated();
  block(matchDeleteFrontPortTemplateRequest(e.id, ANY), function () {
    verifyFrontPortTemplateRequestUpdated(e.id);
  });
});

bthread("FrontPortTemplateRequest delete verification", function () {
  const e = waitForAnyFrontPortTemplateRequestDeleted();
  block(matchAddFrontPortTemplateRequest(e.id, ANY), function () {
    verifyFrontPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("NestedVLAN create verification", function () {
  const e = waitForAnyNestedVLANAdded();
  block(matchDeleteNestedVLAN(e.id, ANY), function () {
    verifyNestedVLANExists(e.id);
  });
});

bthread("NestedVLAN update verification", function () {
  const e = waitForAnyNestedVLANUpdated();
  block(matchDeleteNestedVLAN(e.id, ANY), function () {
    verifyNestedVLANUpdated(e.id);
  });
});

bthread("NestedVLAN delete verification", function () {
  const e = waitForAnyNestedVLANDeleted();
  block(matchAddNestedVLAN(e.id, ANY), function () {
    verifyNestedVLANDoesNotExist(e.id);
  });
});

bthread("BriefManufacturerRequest create verification", function () {
  const e = waitForAnyBriefManufacturerRequestAdded();
  block(matchDeleteBriefManufacturerRequest(e.id, ANY), function () {
    verifyBriefManufacturerRequestExists(e.id);
  });
});

bthread("BriefManufacturerRequest update verification", function () {
  const e = waitForAnyBriefManufacturerRequestUpdated();
  block(matchDeleteBriefManufacturerRequest(e.id, ANY), function () {
    verifyBriefManufacturerRequestUpdated(e.id);
  });
});

bthread("BriefManufacturerRequest delete verification", function () {
  const e = waitForAnyBriefManufacturerRequestDeleted();
  block(matchAddBriefManufacturerRequest(e.id, ANY), function () {
    verifyBriefManufacturerRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableCircuitGroupAssignmentRequest create verification", function () {
  const e = waitForAnyPatchedWritableCircuitGroupAssignmentRequestAdded();
  block(matchDeletePatchedWritableCircuitGroupAssignmentRequest(e.id, ANY), function () {
    verifyPatchedWritableCircuitGroupAssignmentRequestExists(e.id);
  });
});

bthread("PatchedWritableCircuitGroupAssignmentRequest update verification", function () {
  const e = waitForAnyPatchedWritableCircuitGroupAssignmentRequestUpdated();
  block(matchDeletePatchedWritableCircuitGroupAssignmentRequest(e.id, ANY), function () {
    verifyPatchedWritableCircuitGroupAssignmentRequestUpdated(e.id);
  });
});

bthread("PatchedWritableCircuitGroupAssignmentRequest delete verification", function () {
  const e = waitForAnyPatchedWritableCircuitGroupAssignmentRequestDeleted();
  block(matchAddPatchedWritableCircuitGroupAssignmentRequest(e.id, ANY), function () {
    verifyPatchedWritableCircuitGroupAssignmentRequestDoesNotExist(e.id);
  });
});

bthread("InventoryItemRequest create verification", function () {
  const e = waitForAnyInventoryItemRequestAdded();
  block(matchDeleteInventoryItemRequest(e.id, ANY), function () {
    verifyInventoryItemRequestExists(e.id);
  });
});

bthread("InventoryItemRequest update verification", function () {
  const e = waitForAnyInventoryItemRequestUpdated();
  block(matchDeleteInventoryItemRequest(e.id, ANY), function () {
    verifyInventoryItemRequestUpdated(e.id);
  });
});

bthread("InventoryItemRequest delete verification", function () {
  const e = waitForAnyInventoryItemRequestDeleted();
  block(matchAddInventoryItemRequest(e.id, ANY), function () {
    verifyInventoryItemRequestDoesNotExist(e.id);
  });
});

bthread("L2VPN create verification", function () {
  const e = waitForAnyL2VPNAdded();
  block(matchDeleteL2VPN(e.id, ANY), function () {
    verifyL2VPNExists(e.id);
  });
});

bthread("L2VPN update verification", function () {
  const e = waitForAnyL2VPNUpdated();
  block(matchDeleteL2VPN(e.id, ANY), function () {
    verifyL2VPNUpdated(e.id);
  });
});

bthread("L2VPN delete verification", function () {
  const e = waitForAnyL2VPNDeleted();
  block(matchAddL2VPN(e.id, ANY), function () {
    verifyL2VPNDoesNotExist(e.id);
  });
});

bthread("NestedUser create verification", function () {
  const e = waitForAnyNestedUserAdded();
  block(matchDeleteNestedUser(e.id, ANY), function () {
    verifyNestedUserExists(e.id);
  });
});

bthread("NestedUser update verification", function () {
  const e = waitForAnyNestedUserUpdated();
  block(matchDeleteNestedUser(e.id, ANY), function () {
    verifyNestedUserUpdated(e.id);
  });
});

bthread("NestedUser delete verification", function () {
  const e = waitForAnyNestedUserDeleted();
  block(matchAddNestedUser(e.id, ANY), function () {
    verifyNestedUserDoesNotExist(e.id);
  });
});

bthread("ConsolePort create verification", function () {
  const e = waitForAnyConsolePortAdded();
  block(matchDeleteConsolePort(e.id, ANY), function () {
    verifyConsolePortExists(e.id);
  });
});

bthread("ConsolePort update verification", function () {
  const e = waitForAnyConsolePortUpdated();
  block(matchDeleteConsolePort(e.id, ANY), function () {
    verifyConsolePortUpdated(e.id);
  });
});

bthread("ConsolePort delete verification", function () {
  const e = waitForAnyConsolePortDeleted();
  block(matchAddConsolePort(e.id, ANY), function () {
    verifyConsolePortDoesNotExist(e.id);
  });
});

bthread("WritableCustomFieldChoiceSetRequest create verification", function () {
  const e = waitForAnyWritableCustomFieldChoiceSetRequestAdded();
  block(matchDeleteWritableCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyWritableCustomFieldChoiceSetRequestExists(e.id);
  });
});

bthread("WritableCustomFieldChoiceSetRequest update verification", function () {
  const e = waitForAnyWritableCustomFieldChoiceSetRequestUpdated();
  block(matchDeleteWritableCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyWritableCustomFieldChoiceSetRequestUpdated(e.id);
  });
});

bthread("WritableCustomFieldChoiceSetRequest delete verification", function () {
  const e = waitForAnyWritableCustomFieldChoiceSetRequestDeleted();
  block(matchAddWritableCustomFieldChoiceSetRequest(e.id, ANY), function () {
    verifyWritableCustomFieldChoiceSetRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedTaggedItemList create verification", function () {
  const e = waitForAnyPaginatedTaggedItemListAdded();
  block(matchDeletePaginatedTaggedItemList(e.id, ANY), function () {
    verifyPaginatedTaggedItemListExists(e.id);
  });
});

bthread("PaginatedTaggedItemList update verification", function () {
  const e = waitForAnyPaginatedTaggedItemListUpdated();
  block(matchDeletePaginatedTaggedItemList(e.id, ANY), function () {
    verifyPaginatedTaggedItemListUpdated(e.id);
  });
});

bthread("PaginatedTaggedItemList delete verification", function () {
  const e = waitForAnyPaginatedTaggedItemListDeleted();
  block(matchAddPaginatedTaggedItemList(e.id, ANY), function () {
    verifyPaginatedTaggedItemListDoesNotExist(e.id);
  });
});

bthread("BriefVirtualCircuitTypeRequest create verification", function () {
  const e = waitForAnyBriefVirtualCircuitTypeRequestAdded();
  block(matchDeleteBriefVirtualCircuitTypeRequest(e.id, ANY), function () {
    verifyBriefVirtualCircuitTypeRequestExists(e.id);
  });
});

bthread("BriefVirtualCircuitTypeRequest update verification", function () {
  const e = waitForAnyBriefVirtualCircuitTypeRequestUpdated();
  block(matchDeleteBriefVirtualCircuitTypeRequest(e.id, ANY), function () {
    verifyBriefVirtualCircuitTypeRequestUpdated(e.id);
  });
});

bthread("BriefVirtualCircuitTypeRequest delete verification", function () {
  const e = waitForAnyBriefVirtualCircuitTypeRequestDeleted();
  block(matchAddBriefVirtualCircuitTypeRequest(e.id, ANY), function () {
    verifyBriefVirtualCircuitTypeRequestDoesNotExist(e.id);
  });
});

bthread("Manufacturer create verification", function () {
  const e = waitForAnyManufacturerAdded();
  block(matchDeleteManufacturer(e.id, ANY), function () {
    verifyManufacturerExists(e.id);
  });
});

bthread("Manufacturer update verification", function () {
  const e = waitForAnyManufacturerUpdated();
  block(matchDeleteManufacturer(e.id, ANY), function () {
    verifyManufacturerUpdated(e.id);
  });
});

bthread("Manufacturer delete verification", function () {
  const e = waitForAnyManufacturerDeleted();
  block(matchAddManufacturer(e.id, ANY), function () {
    verifyManufacturerDoesNotExist(e.id);
  });
});

bthread("ModuleTypeRequest create verification", function () {
  const e = waitForAnyModuleTypeRequestAdded();
  block(matchDeleteModuleTypeRequest(e.id, ANY), function () {
    verifyModuleTypeRequestExists(e.id);
  });
});

bthread("ModuleTypeRequest update verification", function () {
  const e = waitForAnyModuleTypeRequestUpdated();
  block(matchDeleteModuleTypeRequest(e.id, ANY), function () {
    verifyModuleTypeRequestUpdated(e.id);
  });
});

bthread("ModuleTypeRequest delete verification", function () {
  const e = waitForAnyModuleTypeRequestDeleted();
  block(matchAddModuleTypeRequest(e.id, ANY), function () {
    verifyModuleTypeRequestDoesNotExist(e.id);
  });
});

bthread("WritableTenantGroupRequest create verification", function () {
  const e = waitForAnyWritableTenantGroupRequestAdded();
  block(matchDeleteWritableTenantGroupRequest(e.id, ANY), function () {
    verifyWritableTenantGroupRequestExists(e.id);
  });
});

bthread("WritableTenantGroupRequest update verification", function () {
  const e = waitForAnyWritableTenantGroupRequestUpdated();
  block(matchDeleteWritableTenantGroupRequest(e.id, ANY), function () {
    verifyWritableTenantGroupRequestUpdated(e.id);
  });
});

bthread("WritableTenantGroupRequest delete verification", function () {
  const e = waitForAnyWritableTenantGroupRequestDeleted();
  block(matchAddWritableTenantGroupRequest(e.id, ANY), function () {
    verifyWritableTenantGroupRequestDoesNotExist(e.id);
  });
});

bthread("RearPortTemplate create verification", function () {
  const e = waitForAnyRearPortTemplateAdded();
  block(matchDeleteRearPortTemplate(e.id, ANY), function () {
    verifyRearPortTemplateExists(e.id);
  });
});

bthread("RearPortTemplate update verification", function () {
  const e = waitForAnyRearPortTemplateUpdated();
  block(matchDeleteRearPortTemplate(e.id, ANY), function () {
    verifyRearPortTemplateUpdated(e.id);
  });
});

bthread("RearPortTemplate delete verification", function () {
  const e = waitForAnyRearPortTemplateDeleted();
  block(matchAddRearPortTemplate(e.id, ANY), function () {
    verifyRearPortTemplateDoesNotExist(e.id);
  });
});

bthread("BriefProviderNetwork create verification", function () {
  const e = waitForAnyBriefProviderNetworkAdded();
  block(matchDeleteBriefProviderNetwork(e.id, ANY), function () {
    verifyBriefProviderNetworkExists(e.id);
  });
});

bthread("BriefProviderNetwork update verification", function () {
  const e = waitForAnyBriefProviderNetworkUpdated();
  block(matchDeleteBriefProviderNetwork(e.id, ANY), function () {
    verifyBriefProviderNetworkUpdated(e.id);
  });
});

bthread("BriefProviderNetwork delete verification", function () {
  const e = waitForAnyBriefProviderNetworkDeleted();
  block(matchAddBriefProviderNetwork(e.id, ANY), function () {
    verifyBriefProviderNetworkDoesNotExist(e.id);
  });
});

bthread("NotificationGroupRequest create verification", function () {
  const e = waitForAnyNotificationGroupRequestAdded();
  block(matchDeleteNotificationGroupRequest(e.id, ANY), function () {
    verifyNotificationGroupRequestExists(e.id);
  });
});

bthread("NotificationGroupRequest update verification", function () {
  const e = waitForAnyNotificationGroupRequestUpdated();
  block(matchDeleteNotificationGroupRequest(e.id, ANY), function () {
    verifyNotificationGroupRequestUpdated(e.id);
  });
});

bthread("NotificationGroupRequest delete verification", function () {
  const e = waitForAnyNotificationGroupRequestDeleted();
  block(matchAddNotificationGroupRequest(e.id, ANY), function () {
    verifyNotificationGroupRequestDoesNotExist(e.id);
  });
});

bthread("PatchedClusterGroupRequest create verification", function () {
  const e = waitForAnyPatchedClusterGroupRequestAdded();
  block(matchDeletePatchedClusterGroupRequest(e.id, ANY), function () {
    verifyPatchedClusterGroupRequestExists(e.id);
  });
});

bthread("PatchedClusterGroupRequest update verification", function () {
  const e = waitForAnyPatchedClusterGroupRequestUpdated();
  block(matchDeletePatchedClusterGroupRequest(e.id, ANY), function () {
    verifyPatchedClusterGroupRequestUpdated(e.id);
  });
});

bthread("PatchedClusterGroupRequest delete verification", function () {
  const e = waitForAnyPatchedClusterGroupRequestDeleted();
  block(matchAddPatchedClusterGroupRequest(e.id, ANY), function () {
    verifyPatchedClusterGroupRequestDoesNotExist(e.id);
  });
});

bthread("ClusterRequest create verification", function () {
  const e = waitForAnyClusterRequestAdded();
  block(matchDeleteClusterRequest(e.id, ANY), function () {
    verifyClusterRequestExists(e.id);
  });
});

bthread("ClusterRequest update verification", function () {
  const e = waitForAnyClusterRequestUpdated();
  block(matchDeleteClusterRequest(e.id, ANY), function () {
    verifyClusterRequestUpdated(e.id);
  });
});

bthread("ClusterRequest delete verification", function () {
  const e = waitForAnyClusterRequestDeleted();
  block(matchAddClusterRequest(e.id, ANY), function () {
    verifyClusterRequestDoesNotExist(e.id);
  });
});

bthread("PatchedCircuitGroupRequest create verification", function () {
  const e = waitForAnyPatchedCircuitGroupRequestAdded();
  block(matchDeletePatchedCircuitGroupRequest(e.id, ANY), function () {
    verifyPatchedCircuitGroupRequestExists(e.id);
  });
});

bthread("PatchedCircuitGroupRequest update verification", function () {
  const e = waitForAnyPatchedCircuitGroupRequestUpdated();
  block(matchDeletePatchedCircuitGroupRequest(e.id, ANY), function () {
    verifyPatchedCircuitGroupRequestUpdated(e.id);
  });
});

bthread("PatchedCircuitGroupRequest delete verification", function () {
  const e = waitForAnyPatchedCircuitGroupRequestDeleted();
  block(matchAddPatchedCircuitGroupRequest(e.id, ANY), function () {
    verifyPatchedCircuitGroupRequestDoesNotExist(e.id);
  });
});

bthread("WritableTunnelRequest create verification", function () {
  const e = waitForAnyWritableTunnelRequestAdded();
  block(matchDeleteWritableTunnelRequest(e.id, ANY), function () {
    verifyWritableTunnelRequestExists(e.id);
  });
});

bthread("WritableTunnelRequest update verification", function () {
  const e = waitForAnyWritableTunnelRequestUpdated();
  block(matchDeleteWritableTunnelRequest(e.id, ANY), function () {
    verifyWritableTunnelRequestUpdated(e.id);
  });
});

bthread("WritableTunnelRequest delete verification", function () {
  const e = waitForAnyWritableTunnelRequestDeleted();
  block(matchAddWritableTunnelRequest(e.id, ANY), function () {
    verifyWritableTunnelRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedInterfaceList create verification", function () {
  const e = waitForAnyPaginatedInterfaceListAdded();
  block(matchDeletePaginatedInterfaceList(e.id, ANY), function () {
    verifyPaginatedInterfaceListExists(e.id);
  });
});

bthread("PaginatedInterfaceList update verification", function () {
  const e = waitForAnyPaginatedInterfaceListUpdated();
  block(matchDeletePaginatedInterfaceList(e.id, ANY), function () {
    verifyPaginatedInterfaceListUpdated(e.id);
  });
});

bthread("PaginatedInterfaceList delete verification", function () {
  const e = waitForAnyPaginatedInterfaceListDeleted();
  block(matchAddPaginatedInterfaceList(e.id, ANY), function () {
    verifyPaginatedInterfaceListDoesNotExist(e.id);
  });
});

bthread("WirelessLANGroup create verification", function () {
  const e = waitForAnyWirelessLANGroupAdded();
  block(matchDeleteWirelessLANGroup(e.id, ANY), function () {
    verifyWirelessLANGroupExists(e.id);
  });
});

bthread("WirelessLANGroup update verification", function () {
  const e = waitForAnyWirelessLANGroupUpdated();
  block(matchDeleteWirelessLANGroup(e.id, ANY), function () {
    verifyWirelessLANGroupUpdated(e.id);
  });
});

bthread("WirelessLANGroup delete verification", function () {
  const e = waitForAnyWirelessLANGroupDeleted();
  block(matchAddWirelessLANGroup(e.id, ANY), function () {
    verifyWirelessLANGroupDoesNotExist(e.id);
  });
});

bthread("PatchedWritableServiceTemplateRequest create verification", function () {
  const e = waitForAnyPatchedWritableServiceTemplateRequestAdded();
  block(matchDeletePatchedWritableServiceTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableServiceTemplateRequestExists(e.id);
  });
});

bthread("PatchedWritableServiceTemplateRequest update verification", function () {
  const e = waitForAnyPatchedWritableServiceTemplateRequestUpdated();
  block(matchDeletePatchedWritableServiceTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableServiceTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedWritableServiceTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedWritableServiceTemplateRequestDeleted();
  block(matchAddPatchedWritableServiceTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableServiceTemplateRequestDoesNotExist(e.id);
  });
});

bthread("IKEProposal create verification", function () {
  const e = waitForAnyIKEProposalAdded();
  block(matchDeleteIKEProposal(e.id, ANY), function () {
    verifyIKEProposalExists(e.id);
  });
});

bthread("IKEProposal update verification", function () {
  const e = waitForAnyIKEProposalUpdated();
  block(matchDeleteIKEProposal(e.id, ANY), function () {
    verifyIKEProposalUpdated(e.id);
  });
});

bthread("IKEProposal delete verification", function () {
  const e = waitForAnyIKEProposalDeleted();
  block(matchAddIKEProposal(e.id, ANY), function () {
    verifyIKEProposalDoesNotExist(e.id);
  });
});

bthread("PatchedWritableTunnelRequest create verification", function () {
  const e = waitForAnyPatchedWritableTunnelRequestAdded();
  block(matchDeletePatchedWritableTunnelRequest(e.id, ANY), function () {
    verifyPatchedWritableTunnelRequestExists(e.id);
  });
});

bthread("PatchedWritableTunnelRequest update verification", function () {
  const e = waitForAnyPatchedWritableTunnelRequestUpdated();
  block(matchDeletePatchedWritableTunnelRequest(e.id, ANY), function () {
    verifyPatchedWritableTunnelRequestUpdated(e.id);
  });
});

bthread("PatchedWritableTunnelRequest delete verification", function () {
  const e = waitForAnyPatchedWritableTunnelRequestDeleted();
  block(matchAddPatchedWritableTunnelRequest(e.id, ANY), function () {
    verifyPatchedWritableTunnelRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableInterfaceRequest create verification", function () {
  const e = waitForAnyPatchedWritableInterfaceRequestAdded();
  block(matchDeletePatchedWritableInterfaceRequest(e.id, ANY), function () {
    verifyPatchedWritableInterfaceRequestExists(e.id);
  });
});

bthread("PatchedWritableInterfaceRequest update verification", function () {
  const e = waitForAnyPatchedWritableInterfaceRequestUpdated();
  block(matchDeletePatchedWritableInterfaceRequest(e.id, ANY), function () {
    verifyPatchedWritableInterfaceRequestUpdated(e.id);
  });
});

bthread("PatchedWritableInterfaceRequest delete verification", function () {
  const e = waitForAnyPatchedWritableInterfaceRequestDeleted();
  block(matchAddPatchedWritableInterfaceRequest(e.id, ANY), function () {
    verifyPatchedWritableInterfaceRequestDoesNotExist(e.id);
  });
});

bthread("NestedPlatform create verification", function () {
  const e = waitForAnyNestedPlatformAdded();
  block(matchDeleteNestedPlatform(e.id, ANY), function () {
    verifyNestedPlatformExists(e.id);
  });
});

bthread("NestedPlatform update verification", function () {
  const e = waitForAnyNestedPlatformUpdated();
  block(matchDeleteNestedPlatform(e.id, ANY), function () {
    verifyNestedPlatformUpdated(e.id);
  });
});

bthread("NestedPlatform delete verification", function () {
  const e = waitForAnyNestedPlatformDeleted();
  block(matchAddNestedPlatform(e.id, ANY), function () {
    verifyNestedPlatformDoesNotExist(e.id);
  });
});

bthread("Dashboard create verification", function () {
  const e = waitForAnyDashboardAdded();
  block(matchDeleteDashboard(e.id, ANY), function () {
    verifyDashboardExists(e.id);
  });
});

bthread("Dashboard update verification", function () {
  const e = waitForAnyDashboardUpdated();
  block(matchDeleteDashboard(e.id, ANY), function () {
    verifyDashboardUpdated(e.id);
  });
});

bthread("Dashboard delete verification", function () {
  const e = waitForAnyDashboardDeleted();
  block(matchAddDashboard(e.id, ANY), function () {
    verifyDashboardDoesNotExist(e.id);
  });
});

bthread("ConsoleServerPortTemplateRequest create verification", function () {
  const e = waitForAnyConsoleServerPortTemplateRequestAdded();
  block(matchDeleteConsoleServerPortTemplateRequest(e.id, ANY), function () {
    verifyConsoleServerPortTemplateRequestExists(e.id);
  });
});

bthread("ConsoleServerPortTemplateRequest update verification", function () {
  const e = waitForAnyConsoleServerPortTemplateRequestUpdated();
  block(matchDeleteConsoleServerPortTemplateRequest(e.id, ANY), function () {
    verifyConsoleServerPortTemplateRequestUpdated(e.id);
  });
});

bthread("ConsoleServerPortTemplateRequest delete verification", function () {
  const e = waitForAnyConsoleServerPortTemplateRequestDeleted();
  block(matchAddConsoleServerPortTemplateRequest(e.id, ANY), function () {
    verifyConsoleServerPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PatchedL2VPNTerminationRequest create verification", function () {
  const e = waitForAnyPatchedL2VPNTerminationRequestAdded();
  block(matchDeletePatchedL2VPNTerminationRequest(e.id, ANY), function () {
    verifyPatchedL2VPNTerminationRequestExists(e.id);
  });
});

bthread("PatchedL2VPNTerminationRequest update verification", function () {
  const e = waitForAnyPatchedL2VPNTerminationRequestUpdated();
  block(matchDeletePatchedL2VPNTerminationRequest(e.id, ANY), function () {
    verifyPatchedL2VPNTerminationRequestUpdated(e.id);
  });
});

bthread("PatchedL2VPNTerminationRequest delete verification", function () {
  const e = waitForAnyPatchedL2VPNTerminationRequestDeleted();
  block(matchAddPatchedL2VPNTerminationRequest(e.id, ANY), function () {
    verifyPatchedL2VPNTerminationRequestDoesNotExist(e.id);
  });
});

bthread("BriefModuleType create verification", function () {
  const e = waitForAnyBriefModuleTypeAdded();
  block(matchDeleteBriefModuleType(e.id, ANY), function () {
    verifyBriefModuleTypeExists(e.id);
  });
});

bthread("BriefModuleType update verification", function () {
  const e = waitForAnyBriefModuleTypeUpdated();
  block(matchDeleteBriefModuleType(e.id, ANY), function () {
    verifyBriefModuleTypeUpdated(e.id);
  });
});

bthread("BriefModuleType delete verification", function () {
  const e = waitForAnyBriefModuleTypeDeleted();
  block(matchAddBriefModuleType(e.id, ANY), function () {
    verifyBriefModuleTypeDoesNotExist(e.id);
  });
});

bthread("BriefContact create verification", function () {
  const e = waitForAnyBriefContactAdded();
  block(matchDeleteBriefContact(e.id, ANY), function () {
    verifyBriefContactExists(e.id);
  });
});

bthread("BriefContact update verification", function () {
  const e = waitForAnyBriefContactUpdated();
  block(matchDeleteBriefContact(e.id, ANY), function () {
    verifyBriefContactUpdated(e.id);
  });
});

bthread("BriefContact delete verification", function () {
  const e = waitForAnyBriefContactDeleted();
  block(matchAddBriefContact(e.id, ANY), function () {
    verifyBriefContactDoesNotExist(e.id);
  });
});

bthread("PatchedWritableCableRequest create verification", function () {
  const e = waitForAnyPatchedWritableCableRequestAdded();
  block(matchDeletePatchedWritableCableRequest(e.id, ANY), function () {
    verifyPatchedWritableCableRequestExists(e.id);
  });
});

bthread("PatchedWritableCableRequest update verification", function () {
  const e = waitForAnyPatchedWritableCableRequestUpdated();
  block(matchDeletePatchedWritableCableRequest(e.id, ANY), function () {
    verifyPatchedWritableCableRequestUpdated(e.id);
  });
});

bthread("PatchedWritableCableRequest delete verification", function () {
  const e = waitForAnyPatchedWritableCableRequestDeleted();
  block(matchAddPatchedWritableCableRequest(e.id, ANY), function () {
    verifyPatchedWritableCableRequestDoesNotExist(e.id);
  });
});

bthread("ConfigContextProfileRequest create verification", function () {
  const e = waitForAnyConfigContextProfileRequestAdded();
  block(matchDeleteConfigContextProfileRequest(e.id, ANY), function () {
    verifyConfigContextProfileRequestExists(e.id);
  });
});

bthread("ConfigContextProfileRequest update verification", function () {
  const e = waitForAnyConfigContextProfileRequestUpdated();
  block(matchDeleteConfigContextProfileRequest(e.id, ANY), function () {
    verifyConfigContextProfileRequestUpdated(e.id);
  });
});

bthread("ConfigContextProfileRequest delete verification", function () {
  const e = waitForAnyConfigContextProfileRequestDeleted();
  block(matchAddConfigContextProfileRequest(e.id, ANY), function () {
    verifyConfigContextProfileRequestDoesNotExist(e.id);
  });
});

bthread("ASNRangeRequest create verification", function () {
  const e = waitForAnyASNRangeRequestAdded();
  block(matchDeleteASNRangeRequest(e.id, ANY), function () {
    verifyASNRangeRequestExists(e.id);
  });
});

bthread("ASNRangeRequest update verification", function () {
  const e = waitForAnyASNRangeRequestUpdated();
  block(matchDeleteASNRangeRequest(e.id, ANY), function () {
    verifyASNRangeRequestUpdated(e.id);
  });
});

bthread("ASNRangeRequest delete verification", function () {
  const e = waitForAnyASNRangeRequestDeleted();
  block(matchAddASNRangeRequest(e.id, ANY), function () {
    verifyASNRangeRequestDoesNotExist(e.id);
  });
});

bthread("ObjectChange create verification", function () {
  const e = waitForAnyObjectChangeAdded();
  block(matchDeleteObjectChange(e.id, ANY), function () {
    verifyObjectChangeExists(e.id);
  });
});

bthread("ObjectChange update verification", function () {
  const e = waitForAnyObjectChangeUpdated();
  block(matchDeleteObjectChange(e.id, ANY), function () {
    verifyObjectChangeUpdated(e.id);
  });
});

bthread("ObjectChange delete verification", function () {
  const e = waitForAnyObjectChangeDeleted();
  block(matchAddObjectChange(e.id, ANY), function () {
    verifyObjectChangeDoesNotExist(e.id);
  });
});

bthread("PatchedRoleRequest create verification", function () {
  const e = waitForAnyPatchedRoleRequestAdded();
  block(matchDeletePatchedRoleRequest(e.id, ANY), function () {
    verifyPatchedRoleRequestExists(e.id);
  });
});

bthread("PatchedRoleRequest update verification", function () {
  const e = waitForAnyPatchedRoleRequestUpdated();
  block(matchDeletePatchedRoleRequest(e.id, ANY), function () {
    verifyPatchedRoleRequestUpdated(e.id);
  });
});

bthread("PatchedRoleRequest delete verification", function () {
  const e = waitForAnyPatchedRoleRequestDeleted();
  block(matchAddPatchedRoleRequest(e.id, ANY), function () {
    verifyPatchedRoleRequestDoesNotExist(e.id);
  });
});

bthread("BriefPlatformRequest create verification", function () {
  const e = waitForAnyBriefPlatformRequestAdded();
  block(matchDeleteBriefPlatformRequest(e.id, ANY), function () {
    verifyBriefPlatformRequestExists(e.id);
  });
});

bthread("BriefPlatformRequest update verification", function () {
  const e = waitForAnyBriefPlatformRequestUpdated();
  block(matchDeleteBriefPlatformRequest(e.id, ANY), function () {
    verifyBriefPlatformRequestUpdated(e.id);
  });
});

bthread("BriefPlatformRequest delete verification", function () {
  const e = waitForAnyBriefPlatformRequestDeleted();
  block(matchAddBriefPlatformRequest(e.id, ANY), function () {
    verifyBriefPlatformRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableVirtualChassisRequest create verification", function () {
  const e = waitForAnyPatchedWritableVirtualChassisRequestAdded();
  block(matchDeletePatchedWritableVirtualChassisRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualChassisRequestExists(e.id);
  });
});

bthread("PatchedWritableVirtualChassisRequest update verification", function () {
  const e = waitForAnyPatchedWritableVirtualChassisRequestUpdated();
  block(matchDeletePatchedWritableVirtualChassisRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualChassisRequestUpdated(e.id);
  });
});

bthread("PatchedWritableVirtualChassisRequest delete verification", function () {
  const e = waitForAnyPatchedWritableVirtualChassisRequestDeleted();
  block(matchAddPatchedWritableVirtualChassisRequest(e.id, ANY), function () {
    verifyPatchedWritableVirtualChassisRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedObjectChangeList create verification", function () {
  const e = waitForAnyPaginatedObjectChangeListAdded();
  block(matchDeletePaginatedObjectChangeList(e.id, ANY), function () {
    verifyPaginatedObjectChangeListExists(e.id);
  });
});

bthread("PaginatedObjectChangeList update verification", function () {
  const e = waitForAnyPaginatedObjectChangeListUpdated();
  block(matchDeletePaginatedObjectChangeList(e.id, ANY), function () {
    verifyPaginatedObjectChangeListUpdated(e.id);
  });
});

bthread("PaginatedObjectChangeList delete verification", function () {
  const e = waitForAnyPaginatedObjectChangeListDeleted();
  block(matchAddPaginatedObjectChangeList(e.id, ANY), function () {
    verifyPaginatedObjectChangeListDoesNotExist(e.id);
  });
});

bthread("RackType create verification", function () {
  const e = waitForAnyRackTypeAdded();
  block(matchDeleteRackType(e.id, ANY), function () {
    verifyRackTypeExists(e.id);
  });
});

bthread("RackType update verification", function () {
  const e = waitForAnyRackTypeUpdated();
  block(matchDeleteRackType(e.id, ANY), function () {
    verifyRackTypeUpdated(e.id);
  });
});

bthread("RackType delete verification", function () {
  const e = waitForAnyRackTypeDeleted();
  block(matchAddRackType(e.id, ANY), function () {
    verifyRackTypeDoesNotExist(e.id);
  });
});

bthread("PaginatedIPSecPolicyList create verification", function () {
  const e = waitForAnyPaginatedIPSecPolicyListAdded();
  block(matchDeletePaginatedIPSecPolicyList(e.id, ANY), function () {
    verifyPaginatedIPSecPolicyListExists(e.id);
  });
});

bthread("PaginatedIPSecPolicyList update verification", function () {
  const e = waitForAnyPaginatedIPSecPolicyListUpdated();
  block(matchDeletePaginatedIPSecPolicyList(e.id, ANY), function () {
    verifyPaginatedIPSecPolicyListUpdated(e.id);
  });
});

bthread("PaginatedIPSecPolicyList delete verification", function () {
  const e = waitForAnyPaginatedIPSecPolicyListDeleted();
  block(matchAddPaginatedIPSecPolicyList(e.id, ANY), function () {
    verifyPaginatedIPSecPolicyListDoesNotExist(e.id);
  });
});

bthread("PaginatedJournalEntryList create verification", function () {
  const e = waitForAnyPaginatedJournalEntryListAdded();
  block(matchDeletePaginatedJournalEntryList(e.id, ANY), function () {
    verifyPaginatedJournalEntryListExists(e.id);
  });
});

bthread("PaginatedJournalEntryList update verification", function () {
  const e = waitForAnyPaginatedJournalEntryListUpdated();
  block(matchDeletePaginatedJournalEntryList(e.id, ANY), function () {
    verifyPaginatedJournalEntryListUpdated(e.id);
  });
});

bthread("PaginatedJournalEntryList delete verification", function () {
  const e = waitForAnyPaginatedJournalEntryListDeleted();
  block(matchAddPaginatedJournalEntryList(e.id, ANY), function () {
    verifyPaginatedJournalEntryListDoesNotExist(e.id);
  });
});

bthread("ModuleBay create verification", function () {
  const e = waitForAnyModuleBayAdded();
  block(matchDeleteModuleBay(e.id, ANY), function () {
    verifyModuleBayExists(e.id);
  });
});

bthread("ModuleBay update verification", function () {
  const e = waitForAnyModuleBayUpdated();
  block(matchDeleteModuleBay(e.id, ANY), function () {
    verifyModuleBayUpdated(e.id);
  });
});

bthread("ModuleBay delete verification", function () {
  const e = waitForAnyModuleBayDeleted();
  block(matchAddModuleBay(e.id, ANY), function () {
    verifyModuleBayDoesNotExist(e.id);
  });
});

bthread("PaginatedPowerPortTemplateList create verification", function () {
  const e = waitForAnyPaginatedPowerPortTemplateListAdded();
  block(matchDeletePaginatedPowerPortTemplateList(e.id, ANY), function () {
    verifyPaginatedPowerPortTemplateListExists(e.id);
  });
});

bthread("PaginatedPowerPortTemplateList update verification", function () {
  const e = waitForAnyPaginatedPowerPortTemplateListUpdated();
  block(matchDeletePaginatedPowerPortTemplateList(e.id, ANY), function () {
    verifyPaginatedPowerPortTemplateListUpdated(e.id);
  });
});

bthread("PaginatedPowerPortTemplateList delete verification", function () {
  const e = waitForAnyPaginatedPowerPortTemplateListDeleted();
  block(matchAddPaginatedPowerPortTemplateList(e.id, ANY), function () {
    verifyPaginatedPowerPortTemplateListDoesNotExist(e.id);
  });
});

bthread("WritableVMInterfaceRequest create verification", function () {
  const e = waitForAnyWritableVMInterfaceRequestAdded();
  block(matchDeleteWritableVMInterfaceRequest(e.id, ANY), function () {
    verifyWritableVMInterfaceRequestExists(e.id);
  });
});

bthread("WritableVMInterfaceRequest update verification", function () {
  const e = waitForAnyWritableVMInterfaceRequestUpdated();
  block(matchDeleteWritableVMInterfaceRequest(e.id, ANY), function () {
    verifyWritableVMInterfaceRequestUpdated(e.id);
  });
});

bthread("WritableVMInterfaceRequest delete verification", function () {
  const e = waitForAnyWritableVMInterfaceRequestDeleted();
  block(matchAddWritableVMInterfaceRequest(e.id, ANY), function () {
    verifyWritableVMInterfaceRequestDoesNotExist(e.id);
  });
});

bthread("NestedModuleBayRequest create verification", function () {
  const e = waitForAnyNestedModuleBayRequestAdded();
  block(matchDeleteNestedModuleBayRequest(e.id, ANY), function () {
    verifyNestedModuleBayRequestExists(e.id);
  });
});

bthread("NestedModuleBayRequest update verification", function () {
  const e = waitForAnyNestedModuleBayRequestUpdated();
  block(matchDeleteNestedModuleBayRequest(e.id, ANY), function () {
    verifyNestedModuleBayRequestUpdated(e.id);
  });
});

bthread("NestedModuleBayRequest delete verification", function () {
  const e = waitForAnyNestedModuleBayRequestDeleted();
  block(matchAddNestedModuleBayRequest(e.id, ANY), function () {
    verifyNestedModuleBayRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedInventoryItemTemplateList create verification", function () {
  const e = waitForAnyPaginatedInventoryItemTemplateListAdded();
  block(matchDeletePaginatedInventoryItemTemplateList(e.id, ANY), function () {
    verifyPaginatedInventoryItemTemplateListExists(e.id);
  });
});

bthread("PaginatedInventoryItemTemplateList update verification", function () {
  const e = waitForAnyPaginatedInventoryItemTemplateListUpdated();
  block(matchDeletePaginatedInventoryItemTemplateList(e.id, ANY), function () {
    verifyPaginatedInventoryItemTemplateListUpdated(e.id);
  });
});

bthread("PaginatedInventoryItemTemplateList delete verification", function () {
  const e = waitForAnyPaginatedInventoryItemTemplateListDeleted();
  block(matchAddPaginatedInventoryItemTemplateList(e.id, ANY), function () {
    verifyPaginatedInventoryItemTemplateListDoesNotExist(e.id);
  });
});

bthread("WirelessLAN create verification", function () {
  const e = waitForAnyWirelessLANAdded();
  block(matchDeleteWirelessLAN(e.id, ANY), function () {
    verifyWirelessLANExists(e.id);
  });
});

bthread("WirelessLAN update verification", function () {
  const e = waitForAnyWirelessLANUpdated();
  block(matchDeleteWirelessLAN(e.id, ANY), function () {
    verifyWirelessLANUpdated(e.id);
  });
});

bthread("WirelessLAN delete verification", function () {
  const e = waitForAnyWirelessLANDeleted();
  block(matchAddWirelessLAN(e.id, ANY), function () {
    verifyWirelessLANDoesNotExist(e.id);
  });
});

bthread("ImageAttachmentRequest create verification", function () {
  const e = waitForAnyImageAttachmentRequestAdded();
  block(matchDeleteImageAttachmentRequest(e.id, ANY), function () {
    verifyImageAttachmentRequestExists(e.id);
  });
});

bthread("ImageAttachmentRequest update verification", function () {
  const e = waitForAnyImageAttachmentRequestUpdated();
  block(matchDeleteImageAttachmentRequest(e.id, ANY), function () {
    verifyImageAttachmentRequestUpdated(e.id);
  });
});

bthread("ImageAttachmentRequest delete verification", function () {
  const e = waitForAnyImageAttachmentRequestDeleted();
  block(matchAddImageAttachmentRequest(e.id, ANY), function () {
    verifyImageAttachmentRequestDoesNotExist(e.id);
  });
});

bthread("JournalEntryRequest create verification", function () {
  const e = waitForAnyJournalEntryRequestAdded();
  block(matchDeleteJournalEntryRequest(e.id, ANY), function () {
    verifyJournalEntryRequestExists(e.id);
  });
});

bthread("JournalEntryRequest update verification", function () {
  const e = waitForAnyJournalEntryRequestUpdated();
  block(matchDeleteJournalEntryRequest(e.id, ANY), function () {
    verifyJournalEntryRequestUpdated(e.id);
  });
});

bthread("JournalEntryRequest delete verification", function () {
  const e = waitForAnyJournalEntryRequestDeleted();
  block(matchAddJournalEntryRequest(e.id, ANY), function () {
    verifyJournalEntryRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedGroupList create verification", function () {
  const e = waitForAnyPaginatedGroupListAdded();
  block(matchDeletePaginatedGroupList(e.id, ANY), function () {
    verifyPaginatedGroupListExists(e.id);
  });
});

bthread("PaginatedGroupList update verification", function () {
  const e = waitForAnyPaginatedGroupListUpdated();
  block(matchDeletePaginatedGroupList(e.id, ANY), function () {
    verifyPaginatedGroupListUpdated(e.id);
  });
});

bthread("PaginatedGroupList delete verification", function () {
  const e = waitForAnyPaginatedGroupListDeleted();
  block(matchAddPaginatedGroupList(e.id, ANY), function () {
    verifyPaginatedGroupListDoesNotExist(e.id);
  });
});

bthread("TenantGroupRequest create verification", function () {
  const e = waitForAnyTenantGroupRequestAdded();
  block(matchDeleteTenantGroupRequest(e.id, ANY), function () {
    verifyTenantGroupRequestExists(e.id);
  });
});

bthread("TenantGroupRequest update verification", function () {
  const e = waitForAnyTenantGroupRequestUpdated();
  block(matchDeleteTenantGroupRequest(e.id, ANY), function () {
    verifyTenantGroupRequestUpdated(e.id);
  });
});

bthread("TenantGroupRequest delete verification", function () {
  const e = waitForAnyTenantGroupRequestDeleted();
  block(matchAddTenantGroupRequest(e.id, ANY), function () {
    verifyTenantGroupRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedSiteGroupList create verification", function () {
  const e = waitForAnyPaginatedSiteGroupListAdded();
  block(matchDeletePaginatedSiteGroupList(e.id, ANY), function () {
    verifyPaginatedSiteGroupListExists(e.id);
  });
});

bthread("PaginatedSiteGroupList update verification", function () {
  const e = waitForAnyPaginatedSiteGroupListUpdated();
  block(matchDeletePaginatedSiteGroupList(e.id, ANY), function () {
    verifyPaginatedSiteGroupListUpdated(e.id);
  });
});

bthread("PaginatedSiteGroupList delete verification", function () {
  const e = waitForAnyPaginatedSiteGroupListDeleted();
  block(matchAddPaginatedSiteGroupList(e.id, ANY), function () {
    verifyPaginatedSiteGroupListDoesNotExist(e.id);
  });
});

bthread("PowerOutletTemplateRequest create verification", function () {
  const e = waitForAnyPowerOutletTemplateRequestAdded();
  block(matchDeletePowerOutletTemplateRequest(e.id, ANY), function () {
    verifyPowerOutletTemplateRequestExists(e.id);
  });
});

bthread("PowerOutletTemplateRequest update verification", function () {
  const e = waitForAnyPowerOutletTemplateRequestUpdated();
  block(matchDeletePowerOutletTemplateRequest(e.id, ANY), function () {
    verifyPowerOutletTemplateRequestUpdated(e.id);
  });
});

bthread("PowerOutletTemplateRequest delete verification", function () {
  const e = waitForAnyPowerOutletTemplateRequestDeleted();
  block(matchAddPowerOutletTemplateRequest(e.id, ANY), function () {
    verifyPowerOutletTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedCableTerminationList create verification", function () {
  const e = waitForAnyPaginatedCableTerminationListAdded();
  block(matchDeletePaginatedCableTerminationList(e.id, ANY), function () {
    verifyPaginatedCableTerminationListExists(e.id);
  });
});

bthread("PaginatedCableTerminationList update verification", function () {
  const e = waitForAnyPaginatedCableTerminationListUpdated();
  block(matchDeletePaginatedCableTerminationList(e.id, ANY), function () {
    verifyPaginatedCableTerminationListUpdated(e.id);
  });
});

bthread("PaginatedCableTerminationList delete verification", function () {
  const e = waitForAnyPaginatedCableTerminationListDeleted();
  block(matchAddPaginatedCableTerminationList(e.id, ANY), function () {
    verifyPaginatedCableTerminationListDoesNotExist(e.id);
  });
});

bthread("BriefVirtualChassisRequest create verification", function () {
  const e = waitForAnyBriefVirtualChassisRequestAdded();
  block(matchDeleteBriefVirtualChassisRequest(e.id, ANY), function () {
    verifyBriefVirtualChassisRequestExists(e.id);
  });
});

bthread("BriefVirtualChassisRequest update verification", function () {
  const e = waitForAnyBriefVirtualChassisRequestUpdated();
  block(matchDeleteBriefVirtualChassisRequest(e.id, ANY), function () {
    verifyBriefVirtualChassisRequestUpdated(e.id);
  });
});

bthread("BriefVirtualChassisRequest delete verification", function () {
  const e = waitForAnyBriefVirtualChassisRequestDeleted();
  block(matchAddBriefVirtualChassisRequest(e.id, ANY), function () {
    verifyBriefVirtualChassisRequestDoesNotExist(e.id);
  });
});

bthread("NestedWirelessLinkRequest create verification", function () {
  const e = waitForAnyNestedWirelessLinkRequestAdded();
  block(matchDeleteNestedWirelessLinkRequest(e.id, ANY), function () {
    verifyNestedWirelessLinkRequestExists(e.id);
  });
});

bthread("NestedWirelessLinkRequest update verification", function () {
  const e = waitForAnyNestedWirelessLinkRequestUpdated();
  block(matchDeleteNestedWirelessLinkRequest(e.id, ANY), function () {
    verifyNestedWirelessLinkRequestUpdated(e.id);
  });
});

bthread("NestedWirelessLinkRequest delete verification", function () {
  const e = waitForAnyNestedWirelessLinkRequestDeleted();
  block(matchAddNestedWirelessLinkRequest(e.id, ANY), function () {
    verifyNestedWirelessLinkRequestDoesNotExist(e.id);
  });
});

bthread("PowerPanel create verification", function () {
  const e = waitForAnyPowerPanelAdded();
  block(matchDeletePowerPanel(e.id, ANY), function () {
    verifyPowerPanelExists(e.id);
  });
});

bthread("PowerPanel update verification", function () {
  const e = waitForAnyPowerPanelUpdated();
  block(matchDeletePowerPanel(e.id, ANY), function () {
    verifyPowerPanelUpdated(e.id);
  });
});

bthread("PowerPanel delete verification", function () {
  const e = waitForAnyPowerPanelDeleted();
  block(matchAddPowerPanel(e.id, ANY), function () {
    verifyPowerPanelDoesNotExist(e.id);
  });
});

bthread("PatchedWritableInventoryItemRequest create verification", function () {
  const e = waitForAnyPatchedWritableInventoryItemRequestAdded();
  block(matchDeletePatchedWritableInventoryItemRequest(e.id, ANY), function () {
    verifyPatchedWritableInventoryItemRequestExists(e.id);
  });
});

bthread("PatchedWritableInventoryItemRequest update verification", function () {
  const e = waitForAnyPatchedWritableInventoryItemRequestUpdated();
  block(matchDeletePatchedWritableInventoryItemRequest(e.id, ANY), function () {
    verifyPatchedWritableInventoryItemRequestUpdated(e.id);
  });
});

bthread("PatchedWritableInventoryItemRequest delete verification", function () {
  const e = waitForAnyPatchedWritableInventoryItemRequestDeleted();
  block(matchAddPatchedWritableInventoryItemRequest(e.id, ANY), function () {
    verifyPatchedWritableInventoryItemRequestDoesNotExist(e.id);
  });
});

bthread("IPSecPolicyRequest create verification", function () {
  const e = waitForAnyIPSecPolicyRequestAdded();
  block(matchDeleteIPSecPolicyRequest(e.id, ANY), function () {
    verifyIPSecPolicyRequestExists(e.id);
  });
});

bthread("IPSecPolicyRequest update verification", function () {
  const e = waitForAnyIPSecPolicyRequestUpdated();
  block(matchDeleteIPSecPolicyRequest(e.id, ANY), function () {
    verifyIPSecPolicyRequestUpdated(e.id);
  });
});

bthread("IPSecPolicyRequest delete verification", function () {
  const e = waitForAnyIPSecPolicyRequestDeleted();
  block(matchAddIPSecPolicyRequest(e.id, ANY), function () {
    verifyIPSecPolicyRequestDoesNotExist(e.id);
  });
});

bthread("PatchedExportTemplateRequest create verification", function () {
  const e = waitForAnyPatchedExportTemplateRequestAdded();
  block(matchDeletePatchedExportTemplateRequest(e.id, ANY), function () {
    verifyPatchedExportTemplateRequestExists(e.id);
  });
});

bthread("PatchedExportTemplateRequest update verification", function () {
  const e = waitForAnyPatchedExportTemplateRequestUpdated();
  block(matchDeletePatchedExportTemplateRequest(e.id, ANY), function () {
    verifyPatchedExportTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedExportTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedExportTemplateRequestDeleted();
  block(matchAddPatchedExportTemplateRequest(e.id, ANY), function () {
    verifyPatchedExportTemplateRequestDoesNotExist(e.id);
  });
});

bthread("FHRPGroupAssignment create verification", function () {
  const e = waitForAnyFHRPGroupAssignmentAdded();
  block(matchDeleteFHRPGroupAssignment(e.id, ANY), function () {
    verifyFHRPGroupAssignmentExists(e.id);
  });
});

bthread("FHRPGroupAssignment update verification", function () {
  const e = waitForAnyFHRPGroupAssignmentUpdated();
  block(matchDeleteFHRPGroupAssignment(e.id, ANY), function () {
    verifyFHRPGroupAssignmentUpdated(e.id);
  });
});

bthread("FHRPGroupAssignment delete verification", function () {
  const e = waitForAnyFHRPGroupAssignmentDeleted();
  block(matchAddFHRPGroupAssignment(e.id, ANY), function () {
    verifyFHRPGroupAssignmentDoesNotExist(e.id);
  });
});

bthread("PatchedDeviceBayTemplateRequest create verification", function () {
  const e = waitForAnyPatchedDeviceBayTemplateRequestAdded();
  block(matchDeletePatchedDeviceBayTemplateRequest(e.id, ANY), function () {
    verifyPatchedDeviceBayTemplateRequestExists(e.id);
  });
});

bthread("PatchedDeviceBayTemplateRequest update verification", function () {
  const e = waitForAnyPatchedDeviceBayTemplateRequestUpdated();
  block(matchDeletePatchedDeviceBayTemplateRequest(e.id, ANY), function () {
    verifyPatchedDeviceBayTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedDeviceBayTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedDeviceBayTemplateRequestDeleted();
  block(matchAddPatchedDeviceBayTemplateRequest(e.id, ANY), function () {
    verifyPatchedDeviceBayTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedNotificationList create verification", function () {
  const e = waitForAnyPaginatedNotificationListAdded();
  block(matchDeletePaginatedNotificationList(e.id, ANY), function () {
    verifyPaginatedNotificationListExists(e.id);
  });
});

bthread("PaginatedNotificationList update verification", function () {
  const e = waitForAnyPaginatedNotificationListUpdated();
  block(matchDeletePaginatedNotificationList(e.id, ANY), function () {
    verifyPaginatedNotificationListUpdated(e.id);
  });
});

bthread("PaginatedNotificationList delete verification", function () {
  const e = waitForAnyPaginatedNotificationListDeleted();
  block(matchAddPaginatedNotificationList(e.id, ANY), function () {
    verifyPaginatedNotificationListDoesNotExist(e.id);
  });
});

bthread("AggregateRequest create verification", function () {
  const e = waitForAnyAggregateRequestAdded();
  block(matchDeleteAggregateRequest(e.id, ANY), function () {
    verifyAggregateRequestExists(e.id);
  });
});

bthread("AggregateRequest update verification", function () {
  const e = waitForAnyAggregateRequestUpdated();
  block(matchDeleteAggregateRequest(e.id, ANY), function () {
    verifyAggregateRequestUpdated(e.id);
  });
});

bthread("AggregateRequest delete verification", function () {
  const e = waitForAnyAggregateRequestDeleted();
  block(matchAddAggregateRequest(e.id, ANY), function () {
    verifyAggregateRequestDoesNotExist(e.id);
  });
});

bthread("BriefDeviceTypeRequest create verification", function () {
  const e = waitForAnyBriefDeviceTypeRequestAdded();
  block(matchDeleteBriefDeviceTypeRequest(e.id, ANY), function () {
    verifyBriefDeviceTypeRequestExists(e.id);
  });
});

bthread("BriefDeviceTypeRequest update verification", function () {
  const e = waitForAnyBriefDeviceTypeRequestUpdated();
  block(matchDeleteBriefDeviceTypeRequest(e.id, ANY), function () {
    verifyBriefDeviceTypeRequestUpdated(e.id);
  });
});

bthread("BriefDeviceTypeRequest delete verification", function () {
  const e = waitForAnyBriefDeviceTypeRequestDeleted();
  block(matchAddBriefDeviceTypeRequest(e.id, ANY), function () {
    verifyBriefDeviceTypeRequestDoesNotExist(e.id);
  });
});

bthread("BriefVirtualMachineRequest create verification", function () {
  const e = waitForAnyBriefVirtualMachineRequestAdded();
  block(matchDeleteBriefVirtualMachineRequest(e.id, ANY), function () {
    verifyBriefVirtualMachineRequestExists(e.id);
  });
});

bthread("BriefVirtualMachineRequest update verification", function () {
  const e = waitForAnyBriefVirtualMachineRequestUpdated();
  block(matchDeleteBriefVirtualMachineRequest(e.id, ANY), function () {
    verifyBriefVirtualMachineRequestUpdated(e.id);
  });
});

bthread("BriefVirtualMachineRequest delete verification", function () {
  const e = waitForAnyBriefVirtualMachineRequestDeleted();
  block(matchAddBriefVirtualMachineRequest(e.id, ANY), function () {
    verifyBriefVirtualMachineRequestDoesNotExist(e.id);
  });
});

bthread("VirtualDiskRequest create verification", function () {
  const e = waitForAnyVirtualDiskRequestAdded();
  block(matchDeleteVirtualDiskRequest(e.id, ANY), function () {
    verifyVirtualDiskRequestExists(e.id);
  });
});

bthread("VirtualDiskRequest update verification", function () {
  const e = waitForAnyVirtualDiskRequestUpdated();
  block(matchDeleteVirtualDiskRequest(e.id, ANY), function () {
    verifyVirtualDiskRequestUpdated(e.id);
  });
});

bthread("VirtualDiskRequest delete verification", function () {
  const e = waitForAnyVirtualDiskRequestDeleted();
  block(matchAddVirtualDiskRequest(e.id, ANY), function () {
    verifyVirtualDiskRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritablePowerOutletTemplateRequest create verification", function () {
  const e = waitForAnyPatchedWritablePowerOutletTemplateRequestAdded();
  block(matchDeletePatchedWritablePowerOutletTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerOutletTemplateRequestExists(e.id);
  });
});

bthread("PatchedWritablePowerOutletTemplateRequest update verification", function () {
  const e = waitForAnyPatchedWritablePowerOutletTemplateRequestUpdated();
  block(matchDeletePatchedWritablePowerOutletTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerOutletTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedWritablePowerOutletTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedWritablePowerOutletTemplateRequestDeleted();
  block(matchAddPatchedWritablePowerOutletTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritablePowerOutletTemplateRequestDoesNotExist(e.id);
  });
});

bthread("WebhookRequest create verification", function () {
  const e = waitForAnyWebhookRequestAdded();
  block(matchDeleteWebhookRequest(e.id, ANY), function () {
    verifyWebhookRequestExists(e.id);
  });
});

bthread("WebhookRequest update verification", function () {
  const e = waitForAnyWebhookRequestUpdated();
  block(matchDeleteWebhookRequest(e.id, ANY), function () {
    verifyWebhookRequestUpdated(e.id);
  });
});

bthread("WebhookRequest delete verification", function () {
  const e = waitForAnyWebhookRequestDeleted();
  block(matchAddWebhookRequest(e.id, ANY), function () {
    verifyWebhookRequestDoesNotExist(e.id);
  });
});

bthread("WritablePowerOutletRequest create verification", function () {
  const e = waitForAnyWritablePowerOutletRequestAdded();
  block(matchDeleteWritablePowerOutletRequest(e.id, ANY), function () {
    verifyWritablePowerOutletRequestExists(e.id);
  });
});

bthread("WritablePowerOutletRequest update verification", function () {
  const e = waitForAnyWritablePowerOutletRequestUpdated();
  block(matchDeleteWritablePowerOutletRequest(e.id, ANY), function () {
    verifyWritablePowerOutletRequestUpdated(e.id);
  });
});

bthread("WritablePowerOutletRequest delete verification", function () {
  const e = waitForAnyWritablePowerOutletRequestDeleted();
  block(matchAddWritablePowerOutletRequest(e.id, ANY), function () {
    verifyWritablePowerOutletRequestDoesNotExist(e.id);
  });
});

bthread("WritablePowerOutletTemplateRequest create verification", function () {
  const e = waitForAnyWritablePowerOutletTemplateRequestAdded();
  block(matchDeleteWritablePowerOutletTemplateRequest(e.id, ANY), function () {
    verifyWritablePowerOutletTemplateRequestExists(e.id);
  });
});

bthread("WritablePowerOutletTemplateRequest update verification", function () {
  const e = waitForAnyWritablePowerOutletTemplateRequestUpdated();
  block(matchDeleteWritablePowerOutletTemplateRequest(e.id, ANY), function () {
    verifyWritablePowerOutletTemplateRequestUpdated(e.id);
  });
});

bthread("WritablePowerOutletTemplateRequest delete verification", function () {
  const e = waitForAnyWritablePowerOutletTemplateRequestDeleted();
  block(matchAddWritablePowerOutletTemplateRequest(e.id, ANY), function () {
    verifyWritablePowerOutletTemplateRequestDoesNotExist(e.id);
  });
});

bthread("PatchedWritableServiceRequest create verification", function () {
  const e = waitForAnyPatchedWritableServiceRequestAdded();
  block(matchDeletePatchedWritableServiceRequest(e.id, ANY), function () {
    verifyPatchedWritableServiceRequestExists(e.id);
  });
});

bthread("PatchedWritableServiceRequest update verification", function () {
  const e = waitForAnyPatchedWritableServiceRequestUpdated();
  block(matchDeletePatchedWritableServiceRequest(e.id, ANY), function () {
    verifyPatchedWritableServiceRequestUpdated(e.id);
  });
});

bthread("PatchedWritableServiceRequest delete verification", function () {
  const e = waitForAnyPatchedWritableServiceRequestDeleted();
  block(matchAddPatchedWritableServiceRequest(e.id, ANY), function () {
    verifyPatchedWritableServiceRequestDoesNotExist(e.id);
  });
});

bthread("WritableServiceRequest create verification", function () {
  const e = waitForAnyWritableServiceRequestAdded();
  block(matchDeleteWritableServiceRequest(e.id, ANY), function () {
    verifyWritableServiceRequestExists(e.id);
  });
});

bthread("WritableServiceRequest update verification", function () {
  const e = waitForAnyWritableServiceRequestUpdated();
  block(matchDeleteWritableServiceRequest(e.id, ANY), function () {
    verifyWritableServiceRequestUpdated(e.id);
  });
});

bthread("WritableServiceRequest delete verification", function () {
  const e = waitForAnyWritableServiceRequestDeleted();
  block(matchAddWritableServiceRequest(e.id, ANY), function () {
    verifyWritableServiceRequestDoesNotExist(e.id);
  });
});

bthread("PatchedManufacturerRequest create verification", function () {
  const e = waitForAnyPatchedManufacturerRequestAdded();
  block(matchDeletePatchedManufacturerRequest(e.id, ANY), function () {
    verifyPatchedManufacturerRequestExists(e.id);
  });
});

bthread("PatchedManufacturerRequest update verification", function () {
  const e = waitForAnyPatchedManufacturerRequestUpdated();
  block(matchDeletePatchedManufacturerRequest(e.id, ANY), function () {
    verifyPatchedManufacturerRequestUpdated(e.id);
  });
});

bthread("PatchedManufacturerRequest delete verification", function () {
  const e = waitForAnyPatchedManufacturerRequestDeleted();
  block(matchAddPatchedManufacturerRequest(e.id, ANY), function () {
    verifyPatchedManufacturerRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedRackReservationList create verification", function () {
  const e = waitForAnyPaginatedRackReservationListAdded();
  block(matchDeletePaginatedRackReservationList(e.id, ANY), function () {
    verifyPaginatedRackReservationListExists(e.id);
  });
});

bthread("PaginatedRackReservationList update verification", function () {
  const e = waitForAnyPaginatedRackReservationListUpdated();
  block(matchDeletePaginatedRackReservationList(e.id, ANY), function () {
    verifyPaginatedRackReservationListUpdated(e.id);
  });
});

bthread("PaginatedRackReservationList delete verification", function () {
  const e = waitForAnyPaginatedRackReservationListDeleted();
  block(matchAddPaginatedRackReservationList(e.id, ANY), function () {
    verifyPaginatedRackReservationListDoesNotExist(e.id);
  });
});

bthread("ManufacturerRequest create verification", function () {
  const e = waitForAnyManufacturerRequestAdded();
  block(matchDeleteManufacturerRequest(e.id, ANY), function () {
    verifyManufacturerRequestExists(e.id);
  });
});

bthread("ManufacturerRequest update verification", function () {
  const e = waitForAnyManufacturerRequestUpdated();
  block(matchDeleteManufacturerRequest(e.id, ANY), function () {
    verifyManufacturerRequestUpdated(e.id);
  });
});

bthread("ManufacturerRequest delete verification", function () {
  const e = waitForAnyManufacturerRequestDeleted();
  block(matchAddManufacturerRequest(e.id, ANY), function () {
    verifyManufacturerRequestDoesNotExist(e.id);
  });
});

bthread("RouteTarget create verification", function () {
  const e = waitForAnyRouteTargetAdded();
  block(matchDeleteRouteTarget(e.id, ANY), function () {
    verifyRouteTargetExists(e.id);
  });
});

bthread("RouteTarget update verification", function () {
  const e = waitForAnyRouteTargetUpdated();
  block(matchDeleteRouteTarget(e.id, ANY), function () {
    verifyRouteTargetUpdated(e.id);
  });
});

bthread("RouteTarget delete verification", function () {
  const e = waitForAnyRouteTargetDeleted();
  block(matchAddRouteTarget(e.id, ANY), function () {
    verifyRouteTargetDoesNotExist(e.id);
  });
});

bthread("VRFRequest create verification", function () {
  const e = waitForAnyVRFRequestAdded();
  block(matchDeleteVRFRequest(e.id, ANY), function () {
    verifyVRFRequestExists(e.id);
  });
});

bthread("VRFRequest update verification", function () {
  const e = waitForAnyVRFRequestUpdated();
  block(matchDeleteVRFRequest(e.id, ANY), function () {
    verifyVRFRequestUpdated(e.id);
  });
});

bthread("VRFRequest delete verification", function () {
  const e = waitForAnyVRFRequestDeleted();
  block(matchAddVRFRequest(e.id, ANY), function () {
    verifyVRFRequestDoesNotExist(e.id);
  });
});

bthread("ConfigContextProfile create verification", function () {
  const e = waitForAnyConfigContextProfileAdded();
  block(matchDeleteConfigContextProfile(e.id, ANY), function () {
    verifyConfigContextProfileExists(e.id);
  });
});

bthread("ConfigContextProfile update verification", function () {
  const e = waitForAnyConfigContextProfileUpdated();
  block(matchDeleteConfigContextProfile(e.id, ANY), function () {
    verifyConfigContextProfileUpdated(e.id);
  });
});

bthread("ConfigContextProfile delete verification", function () {
  const e = waitForAnyConfigContextProfileDeleted();
  block(matchAddConfigContextProfile(e.id, ANY), function () {
    verifyConfigContextProfileDoesNotExist(e.id);
  });
});

bthread("PaginatedASNList create verification", function () {
  const e = waitForAnyPaginatedASNListAdded();
  block(matchDeletePaginatedASNList(e.id, ANY), function () {
    verifyPaginatedASNListExists(e.id);
  });
});

bthread("PaginatedASNList update verification", function () {
  const e = waitForAnyPaginatedASNListUpdated();
  block(matchDeletePaginatedASNList(e.id, ANY), function () {
    verifyPaginatedASNListUpdated(e.id);
  });
});

bthread("PaginatedASNList delete verification", function () {
  const e = waitForAnyPaginatedASNListDeleted();
  block(matchAddPaginatedASNList(e.id, ANY), function () {
    verifyPaginatedASNListDoesNotExist(e.id);
  });
});

bthread("VRF create verification", function () {
  const e = waitForAnyVRFAdded();
  block(matchDeleteVRF(e.id, ANY), function () {
    verifyVRFExists(e.id);
  });
});

bthread("VRF update verification", function () {
  const e = waitForAnyVRFUpdated();
  block(matchDeleteVRF(e.id, ANY), function () {
    verifyVRFUpdated(e.id);
  });
});

bthread("VRF delete verification", function () {
  const e = waitForAnyVRFDeleted();
  block(matchAddVRF(e.id, ANY), function () {
    verifyVRFDoesNotExist(e.id);
  });
});

bthread("BriefIPAddressRequest create verification", function () {
  const e = waitForAnyBriefIPAddressRequestAdded();
  block(matchDeleteBriefIPAddressRequest(e.id, ANY), function () {
    verifyBriefIPAddressRequestExists(e.id);
  });
});

bthread("BriefIPAddressRequest update verification", function () {
  const e = waitForAnyBriefIPAddressRequestUpdated();
  block(matchDeleteBriefIPAddressRequest(e.id, ANY), function () {
    verifyBriefIPAddressRequestUpdated(e.id);
  });
});

bthread("BriefIPAddressRequest delete verification", function () {
  const e = waitForAnyBriefIPAddressRequestDeleted();
  block(matchAddBriefIPAddressRequest(e.id, ANY), function () {
    verifyBriefIPAddressRequestDoesNotExist(e.id);
  });
});

bthread("WritableCableRequest create verification", function () {
  const e = waitForAnyWritableCableRequestAdded();
  block(matchDeleteWritableCableRequest(e.id, ANY), function () {
    verifyWritableCableRequestExists(e.id);
  });
});

bthread("WritableCableRequest update verification", function () {
  const e = waitForAnyWritableCableRequestUpdated();
  block(matchDeleteWritableCableRequest(e.id, ANY), function () {
    verifyWritableCableRequestUpdated(e.id);
  });
});

bthread("WritableCableRequest delete verification", function () {
  const e = waitForAnyWritableCableRequestDeleted();
  block(matchAddWritableCableRequest(e.id, ANY), function () {
    verifyWritableCableRequestDoesNotExist(e.id);
  });
});

bthread("PatchedProviderNetworkRequest create verification", function () {
  const e = waitForAnyPatchedProviderNetworkRequestAdded();
  block(matchDeletePatchedProviderNetworkRequest(e.id, ANY), function () {
    verifyPatchedProviderNetworkRequestExists(e.id);
  });
});

bthread("PatchedProviderNetworkRequest update verification", function () {
  const e = waitForAnyPatchedProviderNetworkRequestUpdated();
  block(matchDeletePatchedProviderNetworkRequest(e.id, ANY), function () {
    verifyPatchedProviderNetworkRequestUpdated(e.id);
  });
});

bthread("PatchedProviderNetworkRequest delete verification", function () {
  const e = waitForAnyPatchedProviderNetworkRequestDeleted();
  block(matchAddPatchedProviderNetworkRequest(e.id, ANY), function () {
    verifyPatchedProviderNetworkRequestDoesNotExist(e.id);
  });
});

bthread("WritableRackRequest create verification", function () {
  const e = waitForAnyWritableRackRequestAdded();
  block(matchDeleteWritableRackRequest(e.id, ANY), function () {
    verifyWritableRackRequestExists(e.id);
  });
});

bthread("WritableRackRequest update verification", function () {
  const e = waitForAnyWritableRackRequestUpdated();
  block(matchDeleteWritableRackRequest(e.id, ANY), function () {
    verifyWritableRackRequestUpdated(e.id);
  });
});

bthread("WritableRackRequest delete verification", function () {
  const e = waitForAnyWritableRackRequestDeleted();
  block(matchAddWritableRackRequest(e.id, ANY), function () {
    verifyWritableRackRequestDoesNotExist(e.id);
  });
});

bthread("FrontPort create verification", function () {
  const e = waitForAnyFrontPortAdded();
  block(matchDeleteFrontPort(e.id, ANY), function () {
    verifyFrontPortExists(e.id);
  });
});

bthread("FrontPort update verification", function () {
  const e = waitForAnyFrontPortUpdated();
  block(matchDeleteFrontPort(e.id, ANY), function () {
    verifyFrontPortUpdated(e.id);
  });
});

bthread("FrontPort delete verification", function () {
  const e = waitForAnyFrontPortDeleted();
  block(matchAddFrontPort(e.id, ANY), function () {
    verifyFrontPortDoesNotExist(e.id);
  });
});

bthread("WritableWirelessLANRequest create verification", function () {
  const e = waitForAnyWritableWirelessLANRequestAdded();
  block(matchDeleteWritableWirelessLANRequest(e.id, ANY), function () {
    verifyWritableWirelessLANRequestExists(e.id);
  });
});

bthread("WritableWirelessLANRequest update verification", function () {
  const e = waitForAnyWritableWirelessLANRequestUpdated();
  block(matchDeleteWritableWirelessLANRequest(e.id, ANY), function () {
    verifyWritableWirelessLANRequestUpdated(e.id);
  });
});

bthread("WritableWirelessLANRequest delete verification", function () {
  const e = waitForAnyWritableWirelessLANRequestDeleted();
  block(matchAddWritableWirelessLANRequest(e.id, ANY), function () {
    verifyWritableWirelessLANRequestDoesNotExist(e.id);
  });
});

bthread("PaginatedPowerPanelList create verification", function () {
  const e = waitForAnyPaginatedPowerPanelListAdded();
  block(matchDeletePaginatedPowerPanelList(e.id, ANY), function () {
    verifyPaginatedPowerPanelListExists(e.id);
  });
});

bthread("PaginatedPowerPanelList update verification", function () {
  const e = waitForAnyPaginatedPowerPanelListUpdated();
  block(matchDeletePaginatedPowerPanelList(e.id, ANY), function () {
    verifyPaginatedPowerPanelListUpdated(e.id);
  });
});

bthread("PaginatedPowerPanelList delete verification", function () {
  const e = waitForAnyPaginatedPowerPanelListDeleted();
  block(matchAddPaginatedPowerPanelList(e.id, ANY), function () {
    verifyPaginatedPowerPanelListDoesNotExist(e.id);
  });
});

bthread("PaginatedCustomFieldChoiceSetList create verification", function () {
  const e = waitForAnyPaginatedCustomFieldChoiceSetListAdded();
  block(matchDeletePaginatedCustomFieldChoiceSetList(e.id, ANY), function () {
    verifyPaginatedCustomFieldChoiceSetListExists(e.id);
  });
});

bthread("PaginatedCustomFieldChoiceSetList update verification", function () {
  const e = waitForAnyPaginatedCustomFieldChoiceSetListUpdated();
  block(matchDeletePaginatedCustomFieldChoiceSetList(e.id, ANY), function () {
    verifyPaginatedCustomFieldChoiceSetListUpdated(e.id);
  });
});

bthread("PaginatedCustomFieldChoiceSetList delete verification", function () {
  const e = waitForAnyPaginatedCustomFieldChoiceSetListDeleted();
  block(matchAddPaginatedCustomFieldChoiceSetList(e.id, ANY), function () {
    verifyPaginatedCustomFieldChoiceSetListDoesNotExist(e.id);
  });
});

bthread("PaginatedDeviceRoleList create verification", function () {
  const e = waitForAnyPaginatedDeviceRoleListAdded();
  block(matchDeletePaginatedDeviceRoleList(e.id, ANY), function () {
    verifyPaginatedDeviceRoleListExists(e.id);
  });
});

bthread("PaginatedDeviceRoleList update verification", function () {
  const e = waitForAnyPaginatedDeviceRoleListUpdated();
  block(matchDeletePaginatedDeviceRoleList(e.id, ANY), function () {
    verifyPaginatedDeviceRoleListUpdated(e.id);
  });
});

bthread("PaginatedDeviceRoleList delete verification", function () {
  const e = waitForAnyPaginatedDeviceRoleListDeleted();
  block(matchAddPaginatedDeviceRoleList(e.id, ANY), function () {
    verifyPaginatedDeviceRoleListDoesNotExist(e.id);
  });
});

bthread("PatchedWritableRearPortTemplateRequest create verification", function () {
  const e = waitForAnyPatchedWritableRearPortTemplateRequestAdded();
  block(matchDeletePatchedWritableRearPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableRearPortTemplateRequestExists(e.id);
  });
});

bthread("PatchedWritableRearPortTemplateRequest update verification", function () {
  const e = waitForAnyPatchedWritableRearPortTemplateRequestUpdated();
  block(matchDeletePatchedWritableRearPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableRearPortTemplateRequestUpdated(e.id);
  });
});

bthread("PatchedWritableRearPortTemplateRequest delete verification", function () {
  const e = waitForAnyPatchedWritableRearPortTemplateRequestDeleted();
  block(matchAddPatchedWritableRearPortTemplateRequest(e.id, ANY), function () {
    verifyPatchedWritableRearPortTemplateRequestDoesNotExist(e.id);
  });
});

bthread("BriefVirtualCircuit create verification", function () {
  const e = waitForAnyBriefVirtualCircuitAdded();
  block(matchDeleteBriefVirtualCircuit(e.id, ANY), function () {
    verifyBriefVirtualCircuitExists(e.id);
  });
});

bthread("BriefVirtualCircuit update verification", function () {
  const e = waitForAnyBriefVirtualCircuitUpdated();
  block(matchDeleteBriefVirtualCircuit(e.id, ANY), function () {
    verifyBriefVirtualCircuitUpdated(e.id);
  });
});

bthread("BriefVirtualCircuit delete verification", function () {
  const e = waitForAnyBriefVirtualCircuitDeleted();
  block(matchAddBriefVirtualCircuit(e.id, ANY), function () {
    verifyBriefVirtualCircuitDoesNotExist(e.id);
  });
});

bthread("NestedVirtualMachine create verification", function () {
  const e = waitForAnyNestedVirtualMachineAdded();
  block(matchDeleteNestedVirtualMachine(e.id, ANY), function () {
    verifyNestedVirtualMachineExists(e.id);
  });
});

bthread("NestedVirtualMachine update verification", function () {
  const e = waitForAnyNestedVirtualMachineUpdated();
  block(matchDeleteNestedVirtualMachine(e.id, ANY), function () {
    verifyNestedVirtualMachineUpdated(e.id);
  });
});

bthread("NestedVirtualMachine delete verification", function () {
  const e = waitForAnyNestedVirtualMachineDeleted();
  block(matchAddNestedVirtualMachine(e.id, ANY), function () {
    verifyNestedVirtualMachineDoesNotExist(e.id);
  });
});

bthread("BriefClusterRequest create verification", function () {
  const e = waitForAnyBriefClusterRequestAdded();
  block(matchDeleteBriefClusterRequest(e.id, ANY), function () {
    verifyBriefClusterRequestExists(e.id);
  });
});

bthread("BriefClusterRequest update verification", function () {
  const e = waitForAnyBriefClusterRequestUpdated();
  block(matchDeleteBriefClusterRequest(e.id, ANY), function () {
    verifyBriefClusterRequestUpdated(e.id);
  });
});

bthread("BriefClusterRequest delete verification", function () {
  const e = waitForAnyBriefClusterRequestDeleted();
  block(matchAddBriefClusterRequest(e.id, ANY), function () {
    verifyBriefClusterRequestDoesNotExist(e.id);
  });
});

bthread("WritablePowerPortRequest create verification", function () {
  const e = waitForAnyWritablePowerPortRequestAdded();
  block(matchDeleteWritablePowerPortRequest(e.id, ANY), function () {
    verifyWritablePowerPortRequestExists(e.id);
  });
});

bthread("WritablePowerPortRequest update verification", function () {
  const e = waitForAnyWritablePowerPortRequestUpdated();
  block(matchDeleteWritablePowerPortRequest(e.id, ANY), function () {
    verifyWritablePowerPortRequestUpdated(e.id);
  });
});

bthread("WritablePowerPortRequest delete verification", function () {
  const e = waitForAnyWritablePowerPortRequestDeleted();
  block(matchAddWritablePowerPortRequest(e.id, ANY), function () {
    verifyWritablePowerPortRequestDoesNotExist(e.id);
  });
});

bthread("ExportTemplate create verification", function () {
  const e = waitForAnyExportTemplateAdded();
  block(matchDeleteExportTemplate(e.id, ANY), function () {
    verifyExportTemplateExists(e.id);
  });
});

bthread("ExportTemplate update verification", function () {
  const e = waitForAnyExportTemplateUpdated();
  block(matchDeleteExportTemplate(e.id, ANY), function () {
    verifyExportTemplateUpdated(e.id);
  });
});

bthread("ExportTemplate delete verification", function () {
  const e = waitForAnyExportTemplateDeleted();
  block(matchAddExportTemplate(e.id, ANY), function () {
    verifyExportTemplateDoesNotExist(e.id);
  });
});

// ===== RELATIONSHIP GUARDS =====

// ===== UNIQUENESS GUARDS =====

bthread("Guard: Unique PaginatedFrontPortTemplateList", function () {
  const x = waitForAnyPaginatedFrontPortTemplateListAdded();
  block(matchAddPaginatedFrontPortTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefDataSourceRequest", function () {
  const x = waitForAnyBriefDataSourceRequestAdded();
  block(matchAddBriefDataSourceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedASNRangeList", function () {
  const x = waitForAnyPaginatedASNRangeListAdded();
  block(matchAddPaginatedASNRangeList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedNotificationGroupRequest", function () {
  const x = waitForAnyPatchedNotificationGroupRequestAdded();
  block(matchAddPatchedNotificationGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RearPortTemplateRequest", function () {
  const x = waitForAnyRearPortTemplateRequestAdded();
  block(matchAddRearPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique IPAddressRequest", function () {
  const x = waitForAnyIPAddressRequestAdded();
  block(matchAddIPAddressRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ProviderNetworkRequest", function () {
  const x = waitForAnyProviderNetworkRequestAdded();
  block(matchAddProviderNetworkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefL2VPNTerminationRequest", function () {
  const x = waitForAnyBriefL2VPNTerminationRequestAdded();
  block(matchAddBriefL2VPNTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ObjectPermission", function () {
  const x = waitForAnyObjectPermissionAdded();
  block(matchAddObjectPermission(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedIPAddressList", function () {
  const x = waitForAnyPaginatedIPAddressListAdded();
  block(matchAddPaginatedIPAddressList(x.id, ANY), function () {});
});

bthread("Guard: Unique FrontPortRearPort", function () {
  const x = waitForAnyFrontPortRearPortAdded();
  block(matchAddFrontPortRearPort(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableEventRuleRequest", function () {
  const x = waitForAnyPatchedWritableEventRuleRequestAdded();
  block(matchAddPatchedWritableEventRuleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRackRequest", function () {
  const x = waitForAnyBriefRackRequestAdded();
  block(matchAddBriefRackRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique CustomLinkRequest", function () {
  const x = waitForAnyCustomLinkRequestAdded();
  block(matchAddCustomLinkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ConsoleServerPort", function () {
  const x = waitForAnyConsoleServerPortAdded();
  block(matchAddConsoleServerPort(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedCircuitTypeRequest", function () {
  const x = waitForAnyPatchedCircuitTypeRequestAdded();
  block(matchAddPatchedCircuitTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVirtualChassis", function () {
  const x = waitForAnyBriefVirtualChassisAdded();
  block(matchAddBriefVirtualChassis(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefMACAddressRequest", function () {
  const x = waitForAnyBriefMACAddressRequestAdded();
  block(matchAddBriefMACAddressRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique IPSecPolicy", function () {
  const x = waitForAnyIPSecPolicyAdded();
  block(matchAddIPSecPolicy(x.id, ANY), function () {});
});

bthread("Guard: Unique IPRangeRequest", function () {
  const x = waitForAnyIPRangeRequestAdded();
  block(matchAddIPRangeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritablePowerPortTemplateRequest", function () {
  const x = waitForAnyWritablePowerPortTemplateRequestAdded();
  block(matchAddWritablePowerPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedCircuitGroupList", function () {
  const x = waitForAnyPaginatedCircuitGroupListAdded();
  block(matchAddPaginatedCircuitGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefModuleTypeProfile", function () {
  const x = waitForAnyBriefModuleTypeProfileAdded();
  block(matchAddBriefModuleTypeProfile(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVRF", function () {
  const x = waitForAnyBriefVRFAdded();
  block(matchAddBriefVRF(x.id, ANY), function () {});
});

bthread("Guard: Unique FrontPortRequest", function () {
  const x = waitForAnyFrontPortRequestAdded();
  block(matchAddFrontPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedConsoleServerPortList", function () {
  const x = waitForAnyPaginatedConsoleServerPortListAdded();
  block(matchAddPaginatedConsoleServerPortList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefTunnelGroup", function () {
  const x = waitForAnyBriefTunnelGroupAdded();
  block(matchAddBriefTunnelGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableVirtualMachineWithConfigContextRequest", function () {
  const x = waitForAnyWritableVirtualMachineWithConfigContextRequestAdded();
  block(matchAddWritableVirtualMachineWithConfigContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableRackReservationRequest", function () {
  const x = waitForAnyPatchedWritableRackReservationRequestAdded();
  block(matchAddPatchedWritableRackReservationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ConsoleServerPortRequest", function () {
  const x = waitForAnyConsoleServerPortRequestAdded();
  block(matchAddConsoleServerPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableWirelessLinkRequest", function () {
  const x = waitForAnyWritableWirelessLinkRequestAdded();
  block(matchAddWritableWirelessLinkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableVirtualDeviceContextRequest", function () {
  const x = waitForAnyWritableVirtualDeviceContextRequestAdded();
  block(matchAddWritableVirtualDeviceContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefLocation", function () {
  const x = waitForAnyBriefLocationAdded();
  block(matchAddBriefLocation(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableInterfaceTemplateRequest", function () {
  const x = waitForAnyWritableInterfaceTemplateRequestAdded();
  block(matchAddWritableInterfaceTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritablePowerPortTemplateRequest", function () {
  const x = waitForAnyPatchedWritablePowerPortTemplateRequestAdded();
  block(matchAddPatchedWritablePowerPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableConsolePortRequest", function () {
  const x = waitForAnyPatchedWritableConsolePortRequestAdded();
  block(matchAddPatchedWritableConsolePortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedVMInterfaceRequest", function () {
  const x = waitForAnyNestedVMInterfaceRequestAdded();
  block(matchAddNestedVMInterfaceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCustomFieldChoiceSetRequest", function () {
  const x = waitForAnyBriefCustomFieldChoiceSetRequestAdded();
  block(matchAddBriefCustomFieldChoiceSetRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableIPRangeRequest", function () {
  const x = waitForAnyWritableIPRangeRequestAdded();
  block(matchAddWritableIPRangeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique DeviceRole", function () {
  const x = waitForAnyDeviceRoleAdded();
  block(matchAddDeviceRole(x.id, ANY), function () {});
});

bthread("Guard: Unique ConfigContextRequest", function () {
  const x = waitForAnyConfigContextRequestAdded();
  block(matchAddConfigContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RackReservation", function () {
  const x = waitForAnyRackReservationAdded();
  block(matchAddRackReservation(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedVMInterface", function () {
  const x = waitForAnyNestedVMInterfaceAdded();
  block(matchAddNestedVMInterface(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRackRoleRequest", function () {
  const x = waitForAnyBriefRackRoleRequestAdded();
  block(matchAddBriefRackRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVLANList", function () {
  const x = waitForAnyPaginatedVLANListAdded();
  block(matchAddPaginatedVLANList(x.id, ANY), function () {});
});

bthread("Guard: Unique VLANRequest", function () {
  const x = waitForAnyVLANRequestAdded();
  block(matchAddVLANRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique TunnelRequest", function () {
  const x = waitForAnyTunnelRequestAdded();
  block(matchAddTunnelRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedConsolePortTemplateList", function () {
  const x = waitForAnyPaginatedConsolePortTemplateListAdded();
  block(matchAddPaginatedConsolePortTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique ServiceTemplateRequest", function () {
  const x = waitForAnyServiceTemplateRequestAdded();
  block(matchAddServiceTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Script", function () {
  const x = waitForAnyScriptAdded();
  block(matchAddScript(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedVirtualDiskRequest", function () {
  const x = waitForAnyPatchedVirtualDiskRequestAdded();
  block(matchAddPatchedVirtualDiskRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique SubscriptionRequest", function () {
  const x = waitForAnySubscriptionRequestAdded();
  block(matchAddSubscriptionRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique InventoryItemTemplate", function () {
  const x = waitForAnyInventoryItemTemplateAdded();
  block(matchAddInventoryItemTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVirtualDiskList", function () {
  const x = waitForAnyPaginatedVirtualDiskListAdded();
  block(matchAddPaginatedVirtualDiskList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedCircuitTerminationRequest", function () {
  const x = waitForAnyPatchedCircuitTerminationRequestAdded();
  block(matchAddPatchedCircuitTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRegionList", function () {
  const x = waitForAnyPaginatedRegionListAdded();
  block(matchAddPaginatedRegionList(x.id, ANY), function () {});
});

bthread("Guard: Unique CableTermination", function () {
  const x = waitForAnyCableTerminationAdded();
  block(matchAddCableTermination(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitTerminationRequest", function () {
  const x = waitForAnyCircuitTerminationRequestAdded();
  block(matchAddCircuitTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedIPSecProfileList", function () {
  const x = waitForAnyPaginatedIPSecProfileListAdded();
  block(matchAddPaginatedIPSecProfileList(x.id, ANY), function () {});
});

bthread("Guard: Unique VLANTranslationPolicyRequest", function () {
  const x = waitForAnyVLANTranslationPolicyRequestAdded();
  block(matchAddVLANTranslationPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableJournalEntryRequest", function () {
  const x = waitForAnyWritableJournalEntryRequestAdded();
  block(matchAddWritableJournalEntryRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Prefix", function () {
  const x = waitForAnyPrefixAdded();
  block(matchAddPrefix(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableWirelessLANRequest", function () {
  const x = waitForAnyPatchedWritableWirelessLANRequestAdded();
  block(matchAddPatchedWritableWirelessLANRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitType", function () {
  const x = waitForAnyCircuitTypeAdded();
  block(matchAddCircuitType(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableCircuitGroupAssignmentRequest", function () {
  const x = waitForAnyWritableCircuitGroupAssignmentRequestAdded();
  block(matchAddWritableCircuitGroupAssignmentRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedWirelessLANGroupRequest", function () {
  const x = waitForAnyNestedWirelessLANGroupRequestAdded();
  block(matchAddNestedWirelessLANGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRackTypeList", function () {
  const x = waitForAnyPaginatedRackTypeListAdded();
  block(matchAddPaginatedRackTypeList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedWebhookList", function () {
  const x = waitForAnyPaginatedWebhookListAdded();
  block(matchAddPaginatedWebhookList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedVLANTranslationPolicyRequest", function () {
  const x = waitForAnyPatchedVLANTranslationPolicyRequestAdded();
  block(matchAddPatchedVLANTranslationPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedCableList", function () {
  const x = waitForAnyPaginatedCableListAdded();
  block(matchAddPaginatedCableList(x.id, ANY), function () {});
});

bthread("Guard: Unique Webhook", function () {
  const x = waitForAnyWebhookAdded();
  block(matchAddWebhook(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRackList", function () {
  const x = waitForAnyPaginatedRackListAdded();
  block(matchAddPaginatedRackList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedFHRPGroupRequest", function () {
  const x = waitForAnyPatchedFHRPGroupRequestAdded();
  block(matchAddPatchedFHRPGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualCircuitType", function () {
  const x = waitForAnyVirtualCircuitTypeAdded();
  block(matchAddVirtualCircuitType(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVLANTranslationPolicy", function () {
  const x = waitForAnyBriefVLANTranslationPolicyAdded();
  block(matchAddBriefVLANTranslationPolicy(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefIPSecProfile", function () {
  const x = waitForAnyBriefIPSecProfileAdded();
  block(matchAddBriefIPSecProfile(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedTableConfigList", function () {
  const x = waitForAnyPaginatedTableConfigListAdded();
  block(matchAddPaginatedTableConfigList(x.id, ANY), function () {});
});

bthread("Guard: Unique ModuleBayTemplate", function () {
  const x = waitForAnyModuleBayTemplateAdded();
  block(matchAddModuleBayTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefWirelessLANGroupRequest", function () {
  const x = waitForAnyBriefWirelessLANGroupRequestAdded();
  block(matchAddBriefWirelessLANGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedContactRoleList", function () {
  const x = waitForAnyPaginatedContactRoleListAdded();
  block(matchAddPaginatedContactRoleList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedUserRequest", function () {
  const x = waitForAnyPatchedUserRequestAdded();
  block(matchAddPatchedUserRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ContactGroup", function () {
  const x = waitForAnyContactGroupAdded();
  block(matchAddContactGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique CableRequest", function () {
  const x = waitForAnyCableRequestAdded();
  block(matchAddCableRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RouteTargetRequest", function () {
  const x = waitForAnyRouteTargetRequestAdded();
  block(matchAddRouteTargetRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique IPSecProposalRequest", function () {
  const x = waitForAnyIPSecProposalRequestAdded();
  block(matchAddIPSecProposalRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRackUnitList", function () {
  const x = waitForAnyPaginatedRackUnitListAdded();
  block(matchAddPaginatedRackUnitList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedTunnelTerminationList", function () {
  const x = waitForAnyPaginatedTunnelTerminationListAdded();
  block(matchAddPaginatedTunnelTerminationList(x.id, ANY), function () {});
});

bthread("Guard: Unique DashboardRequest", function () {
  const x = waitForAnyDashboardRequestAdded();
  block(matchAddDashboardRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVLANTranslationPolicyRequest", function () {
  const x = waitForAnyBriefVLANTranslationPolicyRequestAdded();
  block(matchAddBriefVLANTranslationPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefContactRoleRequest", function () {
  const x = waitForAnyBriefContactRoleRequestAdded();
  block(matchAddBriefContactRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique SiteRequest", function () {
  const x = waitForAnySiteRequestAdded();
  block(matchAddSiteRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedInterfaceTemplate", function () {
  const x = waitForAnyNestedInterfaceTemplateAdded();
  block(matchAddNestedInterfaceTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedModuleTypeList", function () {
  const x = waitForAnyPaginatedModuleTypeListAdded();
  block(matchAddPaginatedModuleTypeList(x.id, ANY), function () {});
});

bthread("Guard: Unique FrontPortTemplate", function () {
  const x = waitForAnyFrontPortTemplateAdded();
  block(matchAddFrontPortTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRIR", function () {
  const x = waitForAnyBriefRIRAdded();
  block(matchAddBriefRIR(x.id, ANY), function () {});
});

bthread("Guard: Unique Job", function () {
  const x = waitForAnyJobAdded();
  block(matchAddJob(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefContactRequest", function () {
  const x = waitForAnyBriefContactRequestAdded();
  block(matchAddBriefContactRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedImageAttachmentList", function () {
  const x = waitForAnyPaginatedImageAttachmentListAdded();
  block(matchAddPaginatedImageAttachmentList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableModuleTypeRequest", function () {
  const x = waitForAnyWritableModuleTypeRequestAdded();
  block(matchAddWritableModuleTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RackTypeRequest", function () {
  const x = waitForAnyRackTypeRequestAdded();
  block(matchAddRackTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique CableTerminationRequest", function () {
  const x = waitForAnyCableTerminationRequestAdded();
  block(matchAddCableTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedJobList", function () {
  const x = waitForAnyPaginatedJobListAdded();
  block(matchAddPaginatedJobList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefPowerPortTemplate", function () {
  const x = waitForAnyBriefPowerPortTemplateAdded();
  block(matchAddBriefPowerPortTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique DeviceBayTemplateRequest", function () {
  const x = waitForAnyDeviceBayTemplateRequestAdded();
  block(matchAddDeviceBayTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedContactGroupList", function () {
  const x = waitForAnyPaginatedContactGroupListAdded();
  block(matchAddPaginatedContactGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique Platform", function () {
  const x = waitForAnyPlatformAdded();
  block(matchAddPlatform(x.id, ANY), function () {});
});

bthread("Guard: Unique CustomFieldRequest", function () {
  const x = waitForAnyCustomFieldRequestAdded();
  block(matchAddCustomFieldRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedClusterList", function () {
  const x = waitForAnyPaginatedClusterListAdded();
  block(matchAddPaginatedClusterList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableCustomFieldRequest", function () {
  const x = waitForAnyPatchedWritableCustomFieldRequestAdded();
  block(matchAddPatchedWritableCustomFieldRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVirtualCircuitTypeList", function () {
  const x = waitForAnyPaginatedVirtualCircuitTypeListAdded();
  block(matchAddPaginatedVirtualCircuitTypeList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableRackTypeRequest", function () {
  const x = waitForAnyPatchedWritableRackTypeRequestAdded();
  block(matchAddPatchedWritableRackTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableConsoleServerPortRequest", function () {
  const x = waitForAnyPatchedWritableConsoleServerPortRequestAdded();
  block(matchAddPatchedWritableConsoleServerPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableIKEProposalRequest", function () {
  const x = waitForAnyPatchedWritableIKEProposalRequestAdded();
  block(matchAddPatchedWritableIKEProposalRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableConsoleServerPortTemplateRequest", function () {
  const x = waitForAnyWritableConsoleServerPortTemplateRequestAdded();
  block(matchAddWritableConsoleServerPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableAggregateRequest", function () {
  const x = waitForAnyPatchedWritableAggregateRequestAdded();
  block(matchAddPatchedWritableAggregateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefFHRPGroup", function () {
  const x = waitForAnyBriefFHRPGroupAdded();
  block(matchAddBriefFHRPGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedContactRequest", function () {
  const x = waitForAnyPatchedContactRequestAdded();
  block(matchAddPatchedContactRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedSavedFilterRequest", function () {
  const x = waitForAnyPatchedSavedFilterRequestAdded();
  block(matchAddPatchedSavedFilterRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefSiteGroup", function () {
  const x = waitForAnyBriefSiteGroupAdded();
  block(matchAddBriefSiteGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedVRFRequest", function () {
  const x = waitForAnyPatchedVRFRequestAdded();
  block(matchAddPatchedVRFRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualCircuitTermination", function () {
  const x = waitForAnyVirtualCircuitTerminationAdded();
  block(matchAddVirtualCircuitTermination(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefIPSecPolicyRequest", function () {
  const x = waitForAnyBriefIPSecPolicyRequestAdded();
  block(matchAddBriefIPSecPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ClusterTypeRequest", function () {
  const x = waitForAnyClusterTypeRequestAdded();
  block(matchAddClusterTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Service", function () {
  const x = waitForAnyServiceAdded();
  block(matchAddService(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVLANRequest", function () {
  const x = waitForAnyBriefVLANRequestAdded();
  block(matchAddBriefVLANRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedInventoryItemRoleList", function () {
  const x = waitForAnyPaginatedInventoryItemRoleListAdded();
  block(matchAddPaginatedInventoryItemRoleList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefPowerPanelRequest", function () {
  const x = waitForAnyBriefPowerPanelRequestAdded();
  block(matchAddBriefPowerPanelRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedConfigTemplateRequest", function () {
  const x = waitForAnyPatchedConfigTemplateRequestAdded();
  block(matchAddPatchedConfigTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique TaggedItem", function () {
  const x = waitForAnyTaggedItemAdded();
  block(matchAddTaggedItem(x.id, ANY), function () {});
});

bthread("Guard: Unique CustomFieldChoiceSetRequest", function () {
  const x = waitForAnyCustomFieldChoiceSetRequestAdded();
  block(matchAddCustomFieldChoiceSetRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefDataFile", function () {
  const x = waitForAnyBriefDataFileAdded();
  block(matchAddBriefDataFile(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedObjectPermissionList", function () {
  const x = waitForAnyPaginatedObjectPermissionListAdded();
  block(matchAddPaginatedObjectPermissionList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefIPSecProfileRequest", function () {
  const x = waitForAnyBriefIPSecProfileRequestAdded();
  block(matchAddBriefIPSecProfileRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedTenantRequest", function () {
  const x = waitForAnyPatchedTenantRequestAdded();
  block(matchAddPatchedTenantRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique AvailableVLAN", function () {
  const x = waitForAnyAvailableVLANAdded();
  block(matchAddAvailableVLAN(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedContactList", function () {
  const x = waitForAnyPaginatedContactListAdded();
  block(matchAddPaginatedContactList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedPowerPortList", function () {
  const x = waitForAnyPaginatedPowerPortListAdded();
  block(matchAddPaginatedPowerPortList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableSiteRequest", function () {
  const x = waitForAnyWritableSiteRequestAdded();
  block(matchAddWritableSiteRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ConfigTemplate", function () {
  const x = waitForAnyConfigTemplateAdded();
  block(matchAddConfigTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableFrontPortRequest", function () {
  const x = waitForAnyWritableFrontPortRequestAdded();
  block(matchAddWritableFrontPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique CustomField", function () {
  const x = waitForAnyCustomFieldAdded();
  block(matchAddCustomField(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedConfigContextProfileRequest", function () {
  const x = waitForAnyPatchedConfigContextProfileRequestAdded();
  block(matchAddPatchedConfigContextProfileRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCustomFieldChoiceSet", function () {
  const x = waitForAnyBriefCustomFieldChoiceSetAdded();
  block(matchAddBriefCustomFieldChoiceSet(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRIRList", function () {
  const x = waitForAnyPaginatedRIRListAdded();
  block(matchAddPaginatedRIRList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedScriptInputRequest", function () {
  const x = waitForAnyPatchedScriptInputRequestAdded();
  block(matchAddPatchedScriptInputRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PrefixRequest", function () {
  const x = waitForAnyPrefixRequestAdded();
  block(matchAddPrefixRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefJob", function () {
  const x = waitForAnyBriefJobAdded();
  block(matchAddBriefJob(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableDeviceRoleRequest", function () {
  const x = waitForAnyWritableDeviceRoleRequestAdded();
  block(matchAddWritableDeviceRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Tenant", function () {
  const x = waitForAnyTenantAdded();
  block(matchAddTenant(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedServiceList", function () {
  const x = waitForAnyPaginatedServiceListAdded();
  block(matchAddPaginatedServiceList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedInventoryItemTemplateRequest", function () {
  const x = waitForAnyPatchedInventoryItemTemplateRequestAdded();
  block(matchAddPatchedInventoryItemTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique InterfaceRequest", function () {
  const x = waitForAnyInterfaceRequestAdded();
  block(matchAddInterfaceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefTenantGroupRequest", function () {
  const x = waitForAnyBriefTenantGroupRequestAdded();
  block(matchAddBriefTenantGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique CustomLink", function () {
  const x = waitForAnyCustomLinkAdded();
  block(matchAddCustomLink(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedDeviceBayList", function () {
  const x = waitForAnyPaginatedDeviceBayListAdded();
  block(matchAddPaginatedDeviceBayList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableLocationRequest", function () {
  const x = waitForAnyWritableLocationRequestAdded();
  block(matchAddWritableLocationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedModuleBayRequest", function () {
  const x = waitForAnyPatchedModuleBayRequestAdded();
  block(matchAddPatchedModuleBayRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualMachineWithConfigContext", function () {
  const x = waitForAnyVirtualMachineWithConfigContextAdded();
  block(matchAddVirtualMachineWithConfigContext(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableIPSecPolicyRequest", function () {
  const x = waitForAnyPatchedWritableIPSecPolicyRequestAdded();
  block(matchAddPatchedWritableIPSecPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableL2VPNRequest", function () {
  const x = waitForAnyPatchedWritableL2VPNRequestAdded();
  block(matchAddPatchedWritableL2VPNRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitGroupAssignment", function () {
  const x = waitForAnyCircuitGroupAssignmentAdded();
  block(matchAddCircuitGroupAssignment(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRearPortTemplate", function () {
  const x = waitForAnyBriefRearPortTemplateAdded();
  block(matchAddBriefRearPortTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedDeviceBayTemplateList", function () {
  const x = waitForAnyPaginatedDeviceBayTemplateListAdded();
  block(matchAddPaginatedDeviceBayTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedRegion", function () {
  const x = waitForAnyNestedRegionAdded();
  block(matchAddNestedRegion(x.id, ANY), function () {});
});

bthread("Guard: Unique ContactAssignmentRequest", function () {
  const x = waitForAnyContactAssignmentRequestAdded();
  block(matchAddContactAssignmentRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ConsolePortTemplateRequest", function () {
  const x = waitForAnyConsolePortTemplateRequestAdded();
  block(matchAddConsolePortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableDataSourceRequest", function () {
  const x = waitForAnyWritableDataSourceRequestAdded();
  block(matchAddWritableDataSourceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique LocationRequest", function () {
  const x = waitForAnyLocationRequestAdded();
  block(matchAddLocationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedConsoleServerPortTemplateList", function () {
  const x = waitForAnyPaginatedConsoleServerPortTemplateListAdded();
  block(matchAddPaginatedConsoleServerPortTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerPortTemplateRequest", function () {
  const x = waitForAnyPowerPortTemplateRequestAdded();
  block(matchAddPowerPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedCircuitGroupAssignmentList", function () {
  const x = waitForAnyPaginatedCircuitGroupAssignmentListAdded();
  block(matchAddPaginatedCircuitGroupAssignmentList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVirtualCircuitList", function () {
  const x = waitForAnyPaginatedVirtualCircuitListAdded();
  block(matchAddPaginatedVirtualCircuitList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRackType", function () {
  const x = waitForAnyBriefRackTypeAdded();
  block(matchAddBriefRackType(x.id, ANY), function () {});
});

bthread("Guard: Unique RearPortRequest", function () {
  const x = waitForAnyRearPortRequestAdded();
  block(matchAddRearPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ExportTemplateRequest", function () {
  const x = waitForAnyExportTemplateRequestAdded();
  block(matchAddExportTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRackRole", function () {
  const x = waitForAnyBriefRackRoleAdded();
  block(matchAddBriefRackRole(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedClusterGroupList", function () {
  const x = waitForAnyPaginatedClusterGroupListAdded();
  block(matchAddPaginatedClusterGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedConfigContextRequest", function () {
  const x = waitForAnyPatchedConfigContextRequestAdded();
  block(matchAddPatchedConfigContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedTokenList", function () {
  const x = waitForAnyPaginatedTokenListAdded();
  block(matchAddPaginatedTokenList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedVLANGroupRequest", function () {
  const x = waitForAnyPatchedVLANGroupRequestAdded();
  block(matchAddPatchedVLANGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique TenantGroup", function () {
  const x = waitForAnyTenantGroupAdded();
  block(matchAddTenantGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedProviderRequest", function () {
  const x = waitForAnyPatchedProviderRequestAdded();
  block(matchAddPatchedProviderRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RIRRequest", function () {
  const x = waitForAnyRIRRequestAdded();
  block(matchAddRIRRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableVirtualMachineWithConfigContextRequest", function () {
  const x = waitForAnyPatchedWritableVirtualMachineWithConfigContextRequestAdded();
  block(matchAddPatchedWritableVirtualMachineWithConfigContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCableRequest", function () {
  const x = waitForAnyBriefCableRequestAdded();
  block(matchAddBriefCableRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableVirtualDeviceContextRequest", function () {
  const x = waitForAnyPatchedWritableVirtualDeviceContextRequestAdded();
  block(matchAddPatchedWritableVirtualDeviceContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableServiceTemplateRequest", function () {
  const x = waitForAnyWritableServiceTemplateRequestAdded();
  block(matchAddWritableServiceTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefContactRole", function () {
  const x = waitForAnyBriefContactRoleAdded();
  block(matchAddBriefContactRole(x.id, ANY), function () {});
});

bthread("Guard: Unique DeviceBayRequest", function () {
  const x = waitForAnyDeviceBayRequestAdded();
  block(matchAddDeviceBayRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique InventoryItemTemplateRequest", function () {
  const x = waitForAnyInventoryItemTemplateRequestAdded();
  block(matchAddInventoryItemTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VLANTranslationPolicy", function () {
  const x = waitForAnyVLANTranslationPolicyAdded();
  block(matchAddVLANTranslationPolicy(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableIPSecProposalRequest", function () {
  const x = waitForAnyPatchedWritableIPSecProposalRequestAdded();
  block(matchAddPatchedWritableIPSecProposalRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedWirelessLinkList", function () {
  const x = waitForAnyPaginatedWirelessLinkListAdded();
  block(matchAddPaginatedWirelessLinkList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVirtualCircuitRequest", function () {
  const x = waitForAnyBriefVirtualCircuitRequestAdded();
  block(matchAddBriefVirtualCircuitRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableRegionRequest", function () {
  const x = waitForAnyPatchedWritableRegionRequestAdded();
  block(matchAddPatchedWritableRegionRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefClusterGroupRequest", function () {
  const x = waitForAnyBriefClusterGroupRequestAdded();
  block(matchAddBriefClusterGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ModuleRequest", function () {
  const x = waitForAnyModuleRequestAdded();
  block(matchAddModuleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableFrontPortRequest", function () {
  const x = waitForAnyPatchedWritableFrontPortRequestAdded();
  block(matchAddPatchedWritableFrontPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableModuleRequest", function () {
  const x = waitForAnyWritableModuleRequestAdded();
  block(matchAddWritableModuleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedDeviceRoleRequest", function () {
  const x = waitForAnyNestedDeviceRoleRequestAdded();
  block(matchAddNestedDeviceRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedDeviceRole", function () {
  const x = waitForAnyNestedDeviceRoleAdded();
  block(matchAddNestedDeviceRole(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedInterfaceTemplateRequest", function () {
  const x = waitForAnyNestedInterfaceTemplateRequestAdded();
  block(matchAddNestedInterfaceTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BookmarkRequest", function () {
  const x = waitForAnyBookmarkRequestAdded();
  block(matchAddBookmarkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedTenantList", function () {
  const x = waitForAnyPaginatedTenantListAdded();
  block(matchAddPaginatedTenantList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableCircuitRequest", function () {
  const x = waitForAnyWritableCircuitRequestAdded();
  block(matchAddWritableCircuitRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritablePrefixRequest", function () {
  const x = waitForAnyPatchedWritablePrefixRequestAdded();
  block(matchAddPatchedWritablePrefixRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVLAN", function () {
  const x = waitForAnyBriefVLANAdded();
  block(matchAddBriefVLAN(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedExportTemplateList", function () {
  const x = waitForAnyPaginatedExportTemplateListAdded();
  block(matchAddPaginatedExportTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedConfigContextList", function () {
  const x = waitForAnyPaginatedConfigContextListAdded();
  block(matchAddPaginatedConfigContextList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedTagRequest", function () {
  const x = waitForAnyPatchedTagRequestAdded();
  block(matchAddPatchedTagRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableClusterRequest", function () {
  const x = waitForAnyPatchedWritableClusterRequestAdded();
  block(matchAddPatchedWritableClusterRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVirtualCircuitTerminationList", function () {
  const x = waitForAnyPaginatedVirtualCircuitTerminationListAdded();
  block(matchAddPaginatedVirtualCircuitTerminationList(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitTermination", function () {
  const x = waitForAnyCircuitTerminationAdded();
  block(matchAddCircuitTermination(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedSavedFilterList", function () {
  const x = waitForAnyPaginatedSavedFilterListAdded();
  block(matchAddPaginatedSavedFilterList(x.id, ANY), function () {});
});

bthread("Guard: Unique AvailableIP", function () {
  const x = waitForAnyAvailableIPAdded();
  block(matchAddAvailableIP(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCircuitRequest", function () {
  const x = waitForAnyBriefCircuitRequestAdded();
  block(matchAddBriefCircuitRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableIPAddressRequest", function () {
  const x = waitForAnyWritableIPAddressRequestAdded();
  block(matchAddWritableIPAddressRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedCableTerminationRequest", function () {
  const x = waitForAnyPatchedCableTerminationRequestAdded();
  block(matchAddPatchedCableTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedDeviceRequest", function () {
  const x = waitForAnyNestedDeviceRequestAdded();
  block(matchAddNestedDeviceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableTunnelTerminationRequest", function () {
  const x = waitForAnyWritableTunnelTerminationRequestAdded();
  block(matchAddWritableTunnelTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefIPSecPolicy", function () {
  const x = waitForAnyBriefIPSecPolicyAdded();
  block(matchAddBriefIPSecPolicy(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedPowerOutletList", function () {
  const x = waitForAnyPaginatedPowerOutletListAdded();
  block(matchAddPaginatedPowerOutletList(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitCircuitTerminationRequest", function () {
  const x = waitForAnyCircuitCircuitTerminationRequestAdded();
  block(matchAddCircuitCircuitTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Group", function () {
  const x = waitForAnyGroupAdded();
  block(matchAddGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique TableConfig", function () {
  const x = waitForAnyTableConfigAdded();
  block(matchAddTableConfig(x.id, ANY), function () {});
});

bthread("Guard: Unique Interface", function () {
  const x = waitForAnyInterfaceAdded();
  block(matchAddInterface(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableDeviceWithConfigContextRequest", function () {
  const x = waitForAnyWritableDeviceWithConfigContextRequestAdded();
  block(matchAddWritableDeviceWithConfigContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedInterfaceRequest", function () {
  const x = waitForAnyNestedInterfaceRequestAdded();
  block(matchAddNestedInterfaceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerPortRequest", function () {
  const x = waitForAnyPowerPortRequestAdded();
  block(matchAddPowerPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ModuleTypeProfileRequest", function () {
  const x = waitForAnyModuleTypeProfileRequestAdded();
  block(matchAddModuleTypeProfileRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRearPortTemplateRequest", function () {
  const x = waitForAnyBriefRearPortTemplateRequestAdded();
  block(matchAddBriefRearPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefPowerPortTemplateRequest", function () {
  const x = waitForAnyBriefPowerPortTemplateRequestAdded();
  block(matchAddBriefPowerPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedIPAddress", function () {
  const x = waitForAnyNestedIPAddressAdded();
  block(matchAddNestedIPAddress(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedModuleTypeProfileList", function () {
  const x = waitForAnyPaginatedModuleTypeProfileListAdded();
  block(matchAddPaginatedModuleTypeProfileList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedRIRRequest", function () {
  const x = waitForAnyPatchedRIRRequestAdded();
  block(matchAddPatchedRIRRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRegionRequest", function () {
  const x = waitForAnyBriefRegionRequestAdded();
  block(matchAddBriefRegionRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BackgroundTask", function () {
  const x = waitForAnyBackgroundTaskAdded();
  block(matchAddBackgroundTask(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedASNRangeRequest", function () {
  const x = waitForAnyPatchedASNRangeRequestAdded();
  block(matchAddPatchedASNRangeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCircuit", function () {
  const x = waitForAnyBriefCircuitAdded();
  block(matchAddBriefCircuit(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefWirelessLANGroup", function () {
  const x = waitForAnyBriefWirelessLANGroupAdded();
  block(matchAddBriefWirelessLANGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedDataSourceList", function () {
  const x = waitForAnyPaginatedDataSourceListAdded();
  block(matchAddPaginatedDataSourceList(x.id, ANY), function () {});
});

bthread("Guard: Unique TunnelGroupRequest", function () {
  const x = waitForAnyTunnelGroupRequestAdded();
  block(matchAddTunnelGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableVirtualChassisRequest", function () {
  const x = waitForAnyWritableVirtualChassisRequestAdded();
  block(matchAddWritableVirtualChassisRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Location", function () {
  const x = waitForAnyLocationAdded();
  block(matchAddLocation(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableWirelessLANGroupRequest", function () {
  const x = waitForAnyPatchedWritableWirelessLANGroupRequestAdded();
  block(matchAddPatchedWritableWirelessLANGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Circuit", function () {
  const x = waitForAnyCircuitAdded();
  block(matchAddCircuit(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedMACAddressRequest", function () {
  const x = waitForAnyPatchedMACAddressRequestAdded();
  block(matchAddPatchedMACAddressRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique TokenRequest", function () {
  const x = waitForAnyTokenRequestAdded();
  block(matchAddTokenRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique InterfaceTemplate", function () {
  const x = waitForAnyInterfaceTemplateAdded();
  block(matchAddInterfaceTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedTunnelList", function () {
  const x = waitForAnyPaginatedTunnelListAdded();
  block(matchAddPaginatedTunnelList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefIKEPolicyRequest", function () {
  const x = waitForAnyBriefIKEPolicyRequestAdded();
  block(matchAddBriefIKEPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefManufacturer", function () {
  const x = waitForAnyBriefManufacturerAdded();
  block(matchAddBriefManufacturer(x.id, ANY), function () {});
});

bthread("Guard: Unique Aggregate", function () {
  const x = waitForAnyAggregateAdded();
  block(matchAddAggregate(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableRearPortRequest", function () {
  const x = waitForAnyPatchedWritableRearPortRequestAdded();
  block(matchAddPatchedWritableRearPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedContactAssignmentList", function () {
  const x = waitForAnyPaginatedContactAssignmentListAdded();
  block(matchAddPaginatedContactAssignmentList(x.id, ANY), function () {});
});

bthread("Guard: Unique Device", function () {
  const x = waitForAnyDeviceAdded();
  block(matchAddDevice(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableCustomFieldRequest", function () {
  const x = waitForAnyWritableCustomFieldRequestAdded();
  block(matchAddWritableCustomFieldRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritablePowerFeedRequest", function () {
  const x = waitForAnyWritablePowerFeedRequestAdded();
  block(matchAddWritablePowerFeedRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WirelessLinkRequest", function () {
  const x = waitForAnyWirelessLinkRequestAdded();
  block(matchAddWirelessLinkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVRFList", function () {
  const x = waitForAnyPaginatedVRFListAdded();
  block(matchAddPaginatedVRFList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableInventoryItemRequest", function () {
  const x = waitForAnyWritableInventoryItemRequestAdded();
  block(matchAddWritableInventoryItemRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitCircuitTermination", function () {
  const x = waitForAnyCircuitCircuitTerminationAdded();
  block(matchAddCircuitCircuitTermination(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefProviderAccountRequest", function () {
  const x = waitForAnyBriefProviderAccountRequestAdded();
  block(matchAddBriefProviderAccountRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableContactAssignmentRequest", function () {
  const x = waitForAnyPatchedWritableContactAssignmentRequestAdded();
  block(matchAddPatchedWritableContactAssignmentRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique TableConfigRequest", function () {
  const x = waitForAnyTableConfigRequestAdded();
  block(matchAddTableConfigRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique EventRule", function () {
  const x = waitForAnyEventRuleAdded();
  block(matchAddEventRule(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualCircuit", function () {
  const x = waitForAnyVirtualCircuitAdded();
  block(matchAddVirtualCircuit(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefProviderRequest", function () {
  const x = waitForAnyBriefProviderRequestAdded();
  block(matchAddBriefProviderRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedProviderNetworkList", function () {
  const x = waitForAnyPaginatedProviderNetworkListAdded();
  block(matchAddPaginatedProviderNetworkList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedScriptList", function () {
  const x = waitForAnyPaginatedScriptListAdded();
  block(matchAddPaginatedScriptList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritablePowerPortRequest", function () {
  const x = waitForAnyPatchedWritablePowerPortRequestAdded();
  block(matchAddPatchedWritablePowerPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualDeviceContext", function () {
  const x = waitForAnyVirtualDeviceContextAdded();
  block(matchAddVirtualDeviceContext(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerPort", function () {
  const x = waitForAnyPowerPortAdded();
  block(matchAddPowerPort(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefSiteRequest", function () {
  const x = waitForAnyBriefSiteRequestAdded();
  block(matchAddBriefSiteRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedModuleList", function () {
  const x = waitForAnyPaginatedModuleListAdded();
  block(matchAddPaginatedModuleList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVLANTranslationRuleList", function () {
  const x = waitForAnyPaginatedVLANTranslationRuleListAdded();
  block(matchAddPaginatedVLANTranslationRuleList(x.id, ANY), function () {});
});

bthread("Guard: Unique ASNRequest", function () {
  const x = waitForAnyASNRequestAdded();
  block(matchAddASNRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique SavedFilter", function () {
  const x = waitForAnySavedFilterAdded();
  block(matchAddSavedFilter(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRouteTargetList", function () {
  const x = waitForAnyPaginatedRouteTargetListAdded();
  block(matchAddPaginatedRouteTargetList(x.id, ANY), function () {});
});

bthread("Guard: Unique TenantRequest", function () {
  const x = waitForAnyTenantRequestAdded();
  block(matchAddTenantRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedModuleBay", function () {
  const x = waitForAnyNestedModuleBayAdded();
  block(matchAddNestedModuleBay(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedVLANTranslationRuleRequest", function () {
  const x = waitForAnyPatchedVLANTranslationRuleRequestAdded();
  block(matchAddPatchedVLANTranslationRuleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableVLANRequest", function () {
  const x = waitForAnyWritableVLANRequestAdded();
  block(matchAddWritableVLANRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableRackRequest", function () {
  const x = waitForAnyPatchedWritableRackRequestAdded();
  block(matchAddPatchedWritableRackRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableJournalEntryRequest", function () {
  const x = waitForAnyPatchedWritableJournalEntryRequestAdded();
  block(matchAddPatchedWritableJournalEntryRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedProviderAccountList", function () {
  const x = waitForAnyPaginatedProviderAccountListAdded();
  block(matchAddPaginatedProviderAccountList(x.id, ANY), function () {});
});

bthread("Guard: Unique Token", function () {
  const x = waitForAnyTokenAdded();
  block(matchAddToken(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedPowerFeedList", function () {
  const x = waitForAnyPaginatedPowerFeedListAdded();
  block(matchAddPaginatedPowerFeedList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedClusterTypeRequest", function () {
  const x = waitForAnyPatchedClusterTypeRequestAdded();
  block(matchAddPatchedClusterTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerOutletRequest", function () {
  const x = waitForAnyPowerOutletRequestAdded();
  block(matchAddPowerOutletRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefDeviceRequest", function () {
  const x = waitForAnyBriefDeviceRequestAdded();
  block(matchAddBriefDeviceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedTenantGroupList", function () {
  const x = waitForAnyPaginatedTenantGroupListAdded();
  block(matchAddPaginatedTenantGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableLocationRequest", function () {
  const x = waitForAnyPatchedWritableLocationRequestAdded();
  block(matchAddPatchedWritableLocationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefProviderNetworkRequest", function () {
  const x = waitForAnyBriefProviderNetworkRequestAdded();
  block(matchAddBriefProviderNetworkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique SiteGroup", function () {
  const x = waitForAnySiteGroupAdded();
  block(matchAddSiteGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCircuitGroupAssignmentSerializer_Request", function () {
  const x = waitForAnyBriefCircuitGroupAssignmentSerializer_RequestAdded();
  block(matchAddBriefCircuitGroupAssignmentSerializer_Request(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedImageAttachmentRequest", function () {
  const x = waitForAnyPatchedImageAttachmentRequestAdded();
  block(matchAddPatchedImageAttachmentRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedPrefixList", function () {
  const x = waitForAnyPaginatedPrefixListAdded();
  block(matchAddPaginatedPrefixList(x.id, ANY), function () {});
});

bthread("Guard: Unique JournalEntry", function () {
  const x = waitForAnyJournalEntryAdded();
  block(matchAddJournalEntry(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableVirtualCircuitRequest", function () {
  const x = waitForAnyPatchedWritableVirtualCircuitRequestAdded();
  block(matchAddPatchedWritableVirtualCircuitRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefTenantGroup", function () {
  const x = waitForAnyBriefTenantGroupAdded();
  block(matchAddBriefTenantGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedTableConfigRequest", function () {
  const x = waitForAnyPatchedTableConfigRequestAdded();
  block(matchAddPatchedTableConfigRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedContactGroupRequest", function () {
  const x = waitForAnyNestedContactGroupRequestAdded();
  block(matchAddNestedContactGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableDataSourceRequest", function () {
  const x = waitForAnyPatchedWritableDataSourceRequestAdded();
  block(matchAddPatchedWritableDataSourceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCircuitGroupRequest", function () {
  const x = waitForAnyBriefCircuitGroupRequestAdded();
  block(matchAddBriefCircuitGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableDeviceTypeRequest", function () {
  const x = waitForAnyWritableDeviceTypeRequestAdded();
  block(matchAddWritableDeviceTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedConfigContextProfileList", function () {
  const x = waitForAnyPaginatedConfigContextProfileListAdded();
  block(matchAddPaginatedConfigContextProfileList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedIPRangeList", function () {
  const x = waitForAnyPaginatedIPRangeListAdded();
  block(matchAddPaginatedIPRangeList(x.id, ANY), function () {});
});

bthread("Guard: Unique SavedFilterRequest", function () {
  const x = waitForAnySavedFilterRequestAdded();
  block(matchAddSavedFilterRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Site", function () {
  const x = waitForAnySiteAdded();
  block(matchAddSite(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefL2VPN", function () {
  const x = waitForAnyBriefL2VPNAdded();
  block(matchAddBriefL2VPN(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRegion", function () {
  const x = waitForAnyBriefRegionAdded();
  block(matchAddBriefRegion(x.id, ANY), function () {});
});

bthread("Guard: Unique GenericObject", function () {
  const x = waitForAnyGenericObjectAdded();
  block(matchAddGenericObject(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableConsoleServerPortRequest", function () {
  const x = waitForAnyWritableConsoleServerPortRequestAdded();
  block(matchAddWritableConsoleServerPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefL2VPNRequest", function () {
  const x = waitForAnyBriefL2VPNRequestAdded();
  block(matchAddBriefL2VPNRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VLANGroup", function () {
  const x = waitForAnyVLANGroupAdded();
  block(matchAddVLANGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique VLANTranslationRuleRequest", function () {
  const x = waitForAnyVLANTranslationRuleRequestAdded();
  block(matchAddVLANTranslationRuleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique DataSourceRequest", function () {
  const x = waitForAnyDataSourceRequestAdded();
  block(matchAddDataSourceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ClusterGroupRequest", function () {
  const x = waitForAnyClusterGroupRequestAdded();
  block(matchAddClusterGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique L2VPNTermination", function () {
  const x = waitForAnyL2VPNTerminationAdded();
  block(matchAddL2VPNTermination(x.id, ANY), function () {});
});

bthread("Guard: Unique ServiceTemplate", function () {
  const x = waitForAnyServiceTemplateAdded();
  block(matchAddServiceTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedGroup", function () {
  const x = waitForAnyNestedGroupAdded();
  block(matchAddNestedGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique DeviceBayTemplate", function () {
  const x = waitForAnyDeviceBayTemplateAdded();
  block(matchAddDeviceBayTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique ASN", function () {
  const x = waitForAnyASNAdded();
  block(matchAddASN(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefConfigContextProfileRequest", function () {
  const x = waitForAnyBriefConfigContextProfileRequestAdded();
  block(matchAddBriefConfigContextProfileRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedSubscriptionRequest", function () {
  const x = waitForAnyPatchedSubscriptionRequestAdded();
  block(matchAddPatchedSubscriptionRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableVMInterfaceRequest", function () {
  const x = waitForAnyPatchedWritableVMInterfaceRequestAdded();
  block(matchAddPatchedWritableVMInterfaceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ConfigTemplateRequest", function () {
  const x = waitForAnyConfigTemplateRequestAdded();
  block(matchAddConfigTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedSiteList", function () {
  const x = waitForAnyPaginatedSiteListAdded();
  block(matchAddPaginatedSiteList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedL2VPNTerminationList", function () {
  const x = waitForAnyPaginatedL2VPNTerminationListAdded();
  block(matchAddPaginatedL2VPNTerminationList(x.id, ANY), function () {});
});

bthread("Guard: Unique RackRequest", function () {
  const x = waitForAnyRackRequestAdded();
  block(matchAddRackRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritablePrefixRequest", function () {
  const x = waitForAnyWritablePrefixRequestAdded();
  block(matchAddWritablePrefixRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique InventoryItemRole", function () {
  const x = waitForAnyInventoryItemRoleAdded();
  block(matchAddInventoryItemRole(x.id, ANY), function () {});
});

bthread("Guard: Unique L2VPNRequest", function () {
  const x = waitForAnyL2VPNRequestAdded();
  block(matchAddL2VPNRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefClusterTypeRequest", function () {
  const x = waitForAnyBriefClusterTypeRequestAdded();
  block(matchAddBriefClusterTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableVirtualCircuitTerminationRequest", function () {
  const x = waitForAnyPatchedWritableVirtualCircuitTerminationRequestAdded();
  block(matchAddPatchedWritableVirtualCircuitTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique FHRPGroupRequest", function () {
  const x = waitForAnyFHRPGroupRequestAdded();
  block(matchAddFHRPGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedLocation", function () {
  const x = waitForAnyNestedLocationAdded();
  block(matchAddNestedLocation(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefSite", function () {
  const x = waitForAnyBriefSiteAdded();
  block(matchAddBriefSite(x.id, ANY), function () {});
});

bthread("Guard: Unique ConfigContext", function () {
  const x = waitForAnyConfigContextAdded();
  block(matchAddConfigContext(x.id, ANY), function () {});
});

bthread("Guard: Unique DeviceRoleRequest", function () {
  const x = waitForAnyDeviceRoleRequestAdded();
  block(matchAddDeviceRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique IPAddress", function () {
  const x = waitForAnyIPAddressAdded();
  block(matchAddIPAddress(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedTag", function () {
  const x = waitForAnyNestedTagAdded();
  block(matchAddNestedTag(x.id, ANY), function () {});
});

bthread("Guard: Unique ObjectType", function () {
  const x = waitForAnyObjectTypeAdded();
  block(matchAddObjectType(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedDeviceTypeList", function () {
  const x = waitForAnyPaginatedDeviceTypeListAdded();
  block(matchAddPaginatedDeviceTypeList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableIKEPolicyRequest", function () {
  const x = waitForAnyWritableIKEPolicyRequestAdded();
  block(matchAddWritableIKEPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefClusterType", function () {
  const x = waitForAnyBriefClusterTypeAdded();
  block(matchAddBriefClusterType(x.id, ANY), function () {});
});

bthread("Guard: Unique ConsolePortRequest", function () {
  const x = waitForAnyConsolePortRequestAdded();
  block(matchAddConsolePortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique GroupRequest", function () {
  const x = waitForAnyGroupRequestAdded();
  block(matchAddGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedIPAddressRequest", function () {
  const x = waitForAnyNestedIPAddressRequestAdded();
  block(matchAddNestedIPAddressRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualCircuitRequest", function () {
  const x = waitForAnyVirtualCircuitRequestAdded();
  block(matchAddVirtualCircuitRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Role", function () {
  const x = waitForAnyRoleAdded();
  block(matchAddRole(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableDeviceWithConfigContextRequest", function () {
  const x = waitForAnyPatchedWritableDeviceWithConfigContextRequestAdded();
  block(matchAddPatchedWritableDeviceWithConfigContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefInterface", function () {
  const x = waitForAnyBriefInterfaceAdded();
  block(matchAddBriefInterface(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedRouteTargetRequest", function () {
  const x = waitForAnyPatchedRouteTargetRequestAdded();
  block(matchAddPatchedRouteTargetRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedContactRoleRequest", function () {
  const x = waitForAnyPatchedContactRoleRequestAdded();
  block(matchAddPatchedContactRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedModuleBayTemplateRequest", function () {
  const x = waitForAnyPatchedModuleBayTemplateRequestAdded();
  block(matchAddPatchedModuleBayTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefMACAddress", function () {
  const x = waitForAnyBriefMACAddressAdded();
  block(matchAddBriefMACAddress(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefModuleTypeRequest", function () {
  const x = waitForAnyBriefModuleTypeRequestAdded();
  block(matchAddBriefModuleTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RackRole", function () {
  const x = waitForAnyRackRoleAdded();
  block(matchAddRackRole(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableFrontPortTemplateRequest", function () {
  const x = waitForAnyWritableFrontPortTemplateRequestAdded();
  block(matchAddWritableFrontPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedCustomFieldList", function () {
  const x = waitForAnyPaginatedCustomFieldListAdded();
  block(matchAddPaginatedCustomFieldList(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedSiteGroup", function () {
  const x = waitForAnyNestedSiteGroupAdded();
  block(matchAddNestedSiteGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedSiteGroupRequest", function () {
  const x = waitForAnyNestedSiteGroupRequestAdded();
  block(matchAddNestedSiteGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedFHRPGroupAssignmentRequest", function () {
  const x = waitForAnyPatchedFHRPGroupAssignmentRequestAdded();
  block(matchAddPatchedFHRPGroupAssignmentRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedNotificationGroupList", function () {
  const x = waitForAnyPaginatedNotificationGroupListAdded();
  block(matchAddPaginatedNotificationGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableRackReservationRequest", function () {
  const x = waitForAnyWritableRackReservationRequestAdded();
  block(matchAddWritableRackReservationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Bookmark", function () {
  const x = waitForAnyBookmarkAdded();
  block(matchAddBookmark(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableIPRangeRequest", function () {
  const x = waitForAnyPatchedWritableIPRangeRequestAdded();
  block(matchAddPatchedWritableIPRangeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCluster", function () {
  const x = waitForAnyBriefClusterAdded();
  block(matchAddBriefCluster(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefClusterGroup", function () {
  const x = waitForAnyBriefClusterGroupAdded();
  block(matchAddBriefClusterGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedClusterTypeList", function () {
  const x = waitForAnyPaginatedClusterTypeListAdded();
  block(matchAddPaginatedClusterTypeList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedWirelessLANGroupList", function () {
  const x = waitForAnyPaginatedWirelessLANGroupListAdded();
  block(matchAddPaginatedWirelessLANGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique RearPort", function () {
  const x = waitForAnyRearPortAdded();
  block(matchAddRearPort(x.id, ANY), function () {});
});

bthread("Guard: Unique ImageAttachment", function () {
  const x = waitForAnyImageAttachmentAdded();
  block(matchAddImageAttachment(x.id, ANY), function () {});
});

bthread("Guard: Unique BackgroundTaskRequest", function () {
  const x = waitForAnyBackgroundTaskRequestAdded();
  block(matchAddBackgroundTaskRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualCircuitTerminationRequest", function () {
  const x = waitForAnyVirtualCircuitTerminationRequestAdded();
  block(matchAddVirtualCircuitTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ContactAssignment", function () {
  const x = waitForAnyContactAssignmentAdded();
  block(matchAddContactAssignment(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefIPAddress", function () {
  const x = waitForAnyBriefIPAddressAdded();
  block(matchAddBriefIPAddress(x.id, ANY), function () {});
});

bthread("Guard: Unique IKEPolicy", function () {
  const x = waitForAnyIKEPolicyAdded();
  block(matchAddIKEPolicy(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVirtualDeviceContextList", function () {
  const x = waitForAnyPaginatedVirtualDeviceContextListAdded();
  block(matchAddPaginatedVirtualDeviceContextList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRackTypeRequest", function () {
  const x = waitForAnyBriefRackTypeRequestAdded();
  block(matchAddBriefRackTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefConfigContextProfile", function () {
  const x = waitForAnyBriefConfigContextProfileAdded();
  block(matchAddBriefConfigContextProfile(x.id, ANY), function () {});
});

bthread("Guard: Unique IKEPolicyRequest", function () {
  const x = waitForAnyIKEPolicyRequestAdded();
  block(matchAddIKEPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVirtualMachineWithConfigContextList", function () {
  const x = waitForAnyPaginatedVirtualMachineWithConfigContextListAdded();
  block(matchAddPaginatedVirtualMachineWithConfigContextList(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitTypeRequest", function () {
  const x = waitForAnyCircuitTypeRequestAdded();
  block(matchAddCircuitTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableIPSecProfileRequest", function () {
  const x = waitForAnyWritableIPSecProfileRequestAdded();
  block(matchAddWritableIPSecProfileRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ServiceRequest", function () {
  const x = waitForAnyServiceRequestAdded();
  block(matchAddServiceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualMachineWithConfigContextRequest", function () {
  const x = waitForAnyVirtualMachineWithConfigContextRequestAdded();
  block(matchAddVirtualMachineWithConfigContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique EventRuleRequest", function () {
  const x = waitForAnyEventRuleRequestAdded();
  block(matchAddEventRuleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefTunnelRequest", function () {
  const x = waitForAnyBriefTunnelRequestAdded();
  block(matchAddBriefTunnelRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefTenant", function () {
  const x = waitForAnyBriefTenantAdded();
  block(matchAddBriefTenant(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableIPSecProfileRequest", function () {
  const x = waitForAnyPatchedWritableIPSecProfileRequestAdded();
  block(matchAddPatchedWritableIPSecProfileRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedFHRPGroupAssignmentList", function () {
  const x = waitForAnyPaginatedFHRPGroupAssignmentListAdded();
  block(matchAddPaginatedFHRPGroupAssignmentList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedModuleBayList", function () {
  const x = waitForAnyPaginatedModuleBayListAdded();
  block(matchAddPaginatedModuleBayList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedDeviceWithConfigContextList", function () {
  const x = waitForAnyPaginatedDeviceWithConfigContextListAdded();
  block(matchAddPaginatedDeviceWithConfigContextList(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualChassisRequest", function () {
  const x = waitForAnyVirtualChassisRequestAdded();
  block(matchAddVirtualChassisRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableSiteGroupRequest", function () {
  const x = waitForAnyWritableSiteGroupRequestAdded();
  block(matchAddWritableSiteGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique IPSecProfile", function () {
  const x = waitForAnyIPSecProfileAdded();
  block(matchAddIPSecProfile(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefL2VPNTermination", function () {
  const x = waitForAnyBriefL2VPNTerminationAdded();
  block(matchAddBriefL2VPNTermination(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefConfigTemplateRequest", function () {
  const x = waitForAnyBriefConfigTemplateRequestAdded();
  block(matchAddBriefConfigTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVLANGroupList", function () {
  const x = waitForAnyPaginatedVLANGroupListAdded();
  block(matchAddPaginatedVLANGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedRackRoleRequest", function () {
  const x = waitForAnyPatchedRackRoleRequestAdded();
  block(matchAddPatchedRackRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VMInterfaceRequest", function () {
  const x = waitForAnyVMInterfaceRequestAdded();
  block(matchAddVMInterfaceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Tag", function () {
  const x = waitForAnyTagAdded();
  block(matchAddTag(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefTenantRequest", function () {
  const x = waitForAnyBriefTenantRequestAdded();
  block(matchAddBriefTenantRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Cable", function () {
  const x = waitForAnyCableAdded();
  block(matchAddCable(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitGroup", function () {
  const x = waitForAnyCircuitGroupAdded();
  block(matchAddCircuitGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedObjectPermissionRequest", function () {
  const x = waitForAnyPatchedObjectPermissionRequestAdded();
  block(matchAddPatchedObjectPermissionRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique FHRPGroup", function () {
  const x = waitForAnyFHRPGroupAdded();
  block(matchAddFHRPGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique IPRange", function () {
  const x = waitForAnyIPRangeAdded();
  block(matchAddIPRange(x.id, ANY), function () {});
});

bthread("Guard: Unique ModuleBayRequest", function () {
  const x = waitForAnyModuleBayRequestAdded();
  block(matchAddModuleBayRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ModuleType", function () {
  const x = waitForAnyModuleTypeAdded();
  block(matchAddModuleType(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVirtualCircuitType", function () {
  const x = waitForAnyBriefVirtualCircuitTypeAdded();
  block(matchAddBriefVirtualCircuitType(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRoleList", function () {
  const x = waitForAnyPaginatedRoleListAdded();
  block(matchAddPaginatedRoleList(x.id, ANY), function () {});
});

bthread("Guard: Unique Tunnel", function () {
  const x = waitForAnyTunnelAdded();
  block(matchAddTunnel(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVRFRequest", function () {
  const x = waitForAnyBriefVRFRequestAdded();
  block(matchAddBriefVRFRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RoleRequest", function () {
  const x = waitForAnyRoleRequestAdded();
  block(matchAddRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ConsolePortTemplate", function () {
  const x = waitForAnyConsolePortTemplateAdded();
  block(matchAddConsolePortTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique UserRequest", function () {
  const x = waitForAnyUserRequestAdded();
  block(matchAddUserRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableContactAssignmentRequest", function () {
  const x = waitForAnyWritableContactAssignmentRequestAdded();
  block(matchAddWritableContactAssignmentRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Cluster", function () {
  const x = waitForAnyClusterAdded();
  block(matchAddCluster(x.id, ANY), function () {});
});

bthread("Guard: Unique IPSecProposal", function () {
  const x = waitForAnyIPSecProposalAdded();
  block(matchAddIPSecProposal(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedPowerOutletTemplateList", function () {
  const x = waitForAnyPaginatedPowerOutletTemplateListAdded();
  block(matchAddPaginatedPowerOutletTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique FrontPortRearPortRequest", function () {
  const x = waitForAnyFrontPortRearPortRequestAdded();
  block(matchAddFrontPortRearPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableClusterRequest", function () {
  const x = waitForAnyWritableClusterRequestAdded();
  block(matchAddWritableClusterRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedProviderAccount", function () {
  const x = waitForAnyNestedProviderAccountAdded();
  block(matchAddNestedProviderAccount(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedDashboardRequest", function () {
  const x = waitForAnyPatchedDashboardRequestAdded();
  block(matchAddPatchedDashboardRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerPanelRequest", function () {
  const x = waitForAnyPowerPanelRequestAdded();
  block(matchAddPowerPanelRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedVirtualMachineRequest", function () {
  const x = waitForAnyNestedVirtualMachineRequestAdded();
  block(matchAddNestedVirtualMachineRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefPowerPanel", function () {
  const x = waitForAnyBriefPowerPanelAdded();
  block(matchAddBriefPowerPanel(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableIKEProposalRequest", function () {
  const x = waitForAnyWritableIKEProposalRequestAdded();
  block(matchAddWritableIKEProposalRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedFHRPGroupList", function () {
  const x = waitForAnyPaginatedFHRPGroupListAdded();
  block(matchAddPaginatedFHRPGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRole", function () {
  const x = waitForAnyBriefRoleAdded();
  block(matchAddBriefRole(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedCircuitList", function () {
  const x = waitForAnyPaginatedCircuitListAdded();
  block(matchAddPaginatedCircuitList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableSiteRequest", function () {
  const x = waitForAnyPatchedWritableSiteRequestAdded();
  block(matchAddPatchedWritableSiteRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedTunnelGroupList", function () {
  const x = waitForAnyPaginatedTunnelGroupListAdded();
  block(matchAddPaginatedTunnelGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualCircuitTypeRequest", function () {
  const x = waitForAnyVirtualCircuitTypeRequestAdded();
  block(matchAddVirtualCircuitTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCircuitType", function () {
  const x = waitForAnyBriefCircuitTypeAdded();
  block(matchAddBriefCircuitType(x.id, ANY), function () {});
});

bthread("Guard: Unique TunnelGroup", function () {
  const x = waitForAnyTunnelGroupAdded();
  block(matchAddTunnelGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefProvider", function () {
  const x = waitForAnyBriefProviderAdded();
  block(matchAddBriefProvider(x.id, ANY), function () {});
});

bthread("Guard: Unique L2VPNTerminationRequest", function () {
  const x = waitForAnyL2VPNTerminationRequestAdded();
  block(matchAddL2VPNTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedGroupRequest", function () {
  const x = waitForAnyPatchedGroupRequestAdded();
  block(matchAddPatchedGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableConsolePortTemplateRequest", function () {
  const x = waitForAnyPatchedWritableConsolePortTemplateRequestAdded();
  block(matchAddPatchedWritableConsolePortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique AvailableASN", function () {
  const x = waitForAnyAvailableASNAdded();
  block(matchAddAvailableASN(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefDeviceRole", function () {
  const x = waitForAnyBriefDeviceRoleAdded();
  block(matchAddBriefDeviceRole(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualDisk", function () {
  const x = waitForAnyVirtualDiskAdded();
  block(matchAddVirtualDisk(x.id, ANY), function () {});
});

bthread("Guard: Unique IKEProposalRequest", function () {
  const x = waitForAnyIKEProposalRequestAdded();
  block(matchAddIKEProposalRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedTunnelGroupRequest", function () {
  const x = waitForAnyPatchedTunnelGroupRequestAdded();
  block(matchAddPatchedTunnelGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefModuleRequest", function () {
  const x = waitForAnyBriefModuleRequestAdded();
  block(matchAddBriefModuleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedFrontPortList", function () {
  const x = waitForAnyPaginatedFrontPortListAdded();
  block(matchAddPaginatedFrontPortList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVLANGroup", function () {
  const x = waitForAnyBriefVLANGroupAdded();
  block(matchAddBriefVLANGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique NotificationGroup", function () {
  const x = waitForAnyNotificationGroupAdded();
  block(matchAddNotificationGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedMACAddressList", function () {
  const x = waitForAnyPaginatedMACAddressListAdded();
  block(matchAddPaginatedMACAddressList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableIKEPolicyRequest", function () {
  const x = waitForAnyPatchedWritableIKEPolicyRequestAdded();
  block(matchAddPatchedWritableIKEPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique MACAddressRequest", function () {
  const x = waitForAnyMACAddressRequestAdded();
  block(matchAddMACAddressRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedInterfaceTemplateList", function () {
  const x = waitForAnyPaginatedInterfaceTemplateListAdded();
  block(matchAddPaginatedInterfaceTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefPlatform", function () {
  const x = waitForAnyBriefPlatformAdded();
  block(matchAddBriefPlatform(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerFeedRequest", function () {
  const x = waitForAnyPowerFeedRequestAdded();
  block(matchAddPowerFeedRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedSubscriptionList", function () {
  const x = waitForAnyPaginatedSubscriptionListAdded();
  block(matchAddPaginatedSubscriptionList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableInterfaceRequest", function () {
  const x = waitForAnyWritableInterfaceRequestAdded();
  block(matchAddWritableInterfaceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefTag", function () {
  const x = waitForAnyBriefTagAdded();
  block(matchAddBriefTag(x.id, ANY), function () {});
});

bthread("Guard: Unique ASNRange", function () {
  const x = waitForAnyASNRangeAdded();
  block(matchAddASNRange(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedIKEPolicyList", function () {
  const x = waitForAnyPaginatedIKEPolicyListAdded();
  block(matchAddPaginatedIKEPolicyList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedVirtualCircuitTypeRequest", function () {
  const x = waitForAnyPatchedVirtualCircuitTypeRequestAdded();
  block(matchAddPatchedVirtualCircuitTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableEventRuleRequest", function () {
  const x = waitForAnyWritableEventRuleRequestAdded();
  block(matchAddWritableEventRuleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedAggregateList", function () {
  const x = waitForAnyPaginatedAggregateListAdded();
  block(matchAddPaginatedAggregateList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedInventoryItemRoleRequest", function () {
  const x = waitForAnyPatchedInventoryItemRoleRequestAdded();
  block(matchAddPatchedInventoryItemRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableWirelessLinkRequest", function () {
  const x = waitForAnyPatchedWritableWirelessLinkRequestAdded();
  block(matchAddPatchedWritableWirelessLinkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedModuleBayTemplateList", function () {
  const x = waitForAnyPaginatedModuleBayTemplateListAdded();
  block(matchAddPaginatedModuleBayTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique ProviderRequest", function () {
  const x = waitForAnyProviderRequestAdded();
  block(matchAddProviderRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCable", function () {
  const x = waitForAnyBriefCableAdded();
  block(matchAddBriefCable(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedConsolePortList", function () {
  const x = waitForAnyPaginatedConsolePortListAdded();
  block(matchAddPaginatedConsolePortList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritablePowerFeedRequest", function () {
  const x = waitForAnyPatchedWritablePowerFeedRequestAdded();
  block(matchAddPatchedWritablePowerFeedRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ClusterGroup", function () {
  const x = waitForAnyClusterGroupAdded();
  block(matchAddClusterGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedCircuitTerminationList", function () {
  const x = waitForAnyPaginatedCircuitTerminationListAdded();
  block(matchAddPaginatedCircuitTerminationList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableVirtualCircuitRequest", function () {
  const x = waitForAnyWritableVirtualCircuitRequestAdded();
  block(matchAddWritableVirtualCircuitRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ContactGroupRequest", function () {
  const x = waitForAnyContactGroupRequestAdded();
  block(matchAddContactGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ContactRequest", function () {
  const x = waitForAnyContactRequestAdded();
  block(matchAddContactRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRack", function () {
  const x = waitForAnyBriefRackAdded();
  block(matchAddBriefRack(x.id, ANY), function () {});
});

bthread("Guard: Unique ModuleTypeProfile", function () {
  const x = waitForAnyModuleTypeProfileAdded();
  block(matchAddModuleTypeProfile(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefConfigTemplate", function () {
  const x = waitForAnyBriefConfigTemplateAdded();
  block(matchAddBriefConfigTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRearPortList", function () {
  const x = waitForAnyPaginatedRearPortListAdded();
  block(matchAddPaginatedRearPortList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedProviderAccountRequest", function () {
  const x = waitForAnyPatchedProviderAccountRequestAdded();
  block(matchAddPatchedProviderAccountRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefLocationRequest", function () {
  const x = waitForAnyBriefLocationRequestAdded();
  block(matchAddBriefLocationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedASNRequest", function () {
  const x = waitForAnyPatchedASNRequestAdded();
  block(matchAddPatchedASNRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedRegionRequest", function () {
  const x = waitForAnyNestedRegionRequestAdded();
  block(matchAddNestedRegionRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableFrontPortTemplateRequest", function () {
  const x = waitForAnyPatchedWritableFrontPortTemplateRequestAdded();
  block(matchAddPatchedWritableFrontPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique DataSource", function () {
  const x = waitForAnyDataSourceAdded();
  block(matchAddDataSource(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableCircuitRequest", function () {
  const x = waitForAnyPatchedWritableCircuitRequestAdded();
  block(matchAddPatchedWritableCircuitRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RIR", function () {
  const x = waitForAnyRIRAdded();
  block(matchAddRIR(x.id, ANY), function () {});
});

bthread("Guard: Unique Module", function () {
  const x = waitForAnyModuleAdded();
  block(matchAddModule(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableL2VPNRequest", function () {
  const x = waitForAnyWritableL2VPNRequestAdded();
  block(matchAddWritableL2VPNRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCircuitGroupAssignmentSerializer_", function () {
  const x = waitForAnyBriefCircuitGroupAssignmentSerializer_Added();
  block(matchAddBriefCircuitGroupAssignmentSerializer_(x.id, ANY), function () {});
});

bthread("Guard: Unique PlatformRequest", function () {
  const x = waitForAnyPlatformRequestAdded();
  block(matchAddPlatformRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VLANTranslationRule", function () {
  const x = waitForAnyVLANTranslationRuleAdded();
  block(matchAddVLANTranslationRule(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedCustomLinkRequest", function () {
  const x = waitForAnyPatchedCustomLinkRequestAdded();
  block(matchAddPatchedCustomLinkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedServiceTemplateList", function () {
  const x = waitForAnyPaginatedServiceTemplateListAdded();
  block(matchAddPaginatedServiceTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedPowerPanelRequest", function () {
  const x = waitForAnyPatchedPowerPanelRequestAdded();
  block(matchAddPatchedPowerPanelRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableCustomFieldChoiceSetRequest", function () {
  const x = waitForAnyPatchedWritableCustomFieldChoiceSetRequestAdded();
  block(matchAddPatchedWritableCustomFieldChoiceSetRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefUser", function () {
  const x = waitForAnyBriefUserAdded();
  block(matchAddBriefUser(x.id, ANY), function () {});
});

bthread("Guard: Unique Contact", function () {
  const x = waitForAnyContactAdded();
  block(matchAddContact(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableVLANRequest", function () {
  const x = waitForAnyPatchedWritableVLANRequestAdded();
  block(matchAddPatchedWritableVLANRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Rack", function () {
  const x = waitForAnyRackAdded();
  block(matchAddRack(x.id, ANY), function () {});
});

bthread("Guard: Unique RegionRequest", function () {
  const x = waitForAnyRegionRequestAdded();
  block(matchAddRegionRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique User", function () {
  const x = waitForAnyUserAdded();
  block(matchAddUser(x.id, ANY), function () {});
});

bthread("Guard: Unique CustomFieldChoiceSet", function () {
  const x = waitForAnyCustomFieldChoiceSetAdded();
  block(matchAddCustomFieldChoiceSet(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRackRoleList", function () {
  const x = waitForAnyPaginatedRackRoleListAdded();
  block(matchAddPaginatedRackRoleList(x.id, ANY), function () {});
});

bthread("Guard: Unique Region", function () {
  const x = waitForAnyRegionAdded();
  block(matchAddRegion(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitGroupRequest", function () {
  const x = waitForAnyCircuitGroupRequestAdded();
  block(matchAddCircuitGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique DeviceWithConfigContextRequest", function () {
  const x = waitForAnyDeviceWithConfigContextRequestAdded();
  block(matchAddDeviceWithConfigContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableTenantGroupRequest", function () {
  const x = waitForAnyPatchedWritableTenantGroupRequestAdded();
  block(matchAddPatchedWritableTenantGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritablePlatformRequest", function () {
  const x = waitForAnyPatchedWritablePlatformRequestAdded();
  block(matchAddPatchedWritablePlatformRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique AvailablePrefix", function () {
  const x = waitForAnyAvailablePrefixAdded();
  block(matchAddAvailablePrefix(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableContactGroupRequest", function () {
  const x = waitForAnyWritableContactGroupRequestAdded();
  block(matchAddWritableContactGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique GenericObjectRequest", function () {
  const x = waitForAnyGenericObjectRequestAdded();
  block(matchAddGenericObjectRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefProviderAccount", function () {
  const x = waitForAnyBriefProviderAccountAdded();
  block(matchAddBriefProviderAccount(x.id, ANY), function () {});
});

bthread("Guard: Unique ConsoleServerPortTemplate", function () {
  const x = waitForAnyConsoleServerPortTemplateAdded();
  block(matchAddConsoleServerPortTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedPlatformList", function () {
  const x = waitForAnyPaginatedPlatformListAdded();
  block(matchAddPaginatedPlatformList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefPowerPort", function () {
  const x = waitForAnyBriefPowerPortAdded();
  block(matchAddBriefPowerPort(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedTenantGroup", function () {
  const x = waitForAnyNestedTenantGroupAdded();
  block(matchAddNestedTenantGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedModuleTypeProfileRequest", function () {
  const x = waitForAnyPatchedModuleTypeProfileRequestAdded();
  block(matchAddPatchedModuleTypeProfileRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableTunnelTerminationRequest", function () {
  const x = waitForAnyPatchedWritableTunnelTerminationRequestAdded();
  block(matchAddPatchedWritableTunnelTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefInventoryItemRole", function () {
  const x = waitForAnyBriefInventoryItemRoleAdded();
  block(matchAddBriefInventoryItemRole(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedObjectTypeList", function () {
  const x = waitForAnyPaginatedObjectTypeListAdded();
  block(matchAddPaginatedObjectTypeList(x.id, ANY), function () {});
});

bthread("Guard: Unique Subscription", function () {
  const x = waitForAnySubscriptionAdded();
  block(matchAddSubscription(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefSiteGroupRequest", function () {
  const x = waitForAnyBriefSiteGroupRequestAdded();
  block(matchAddBriefSiteGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefTunnelGroupRequest", function () {
  const x = waitForAnyBriefTunnelGroupRequestAdded();
  block(matchAddBriefTunnelGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableRearPortTemplateRequest", function () {
  const x = waitForAnyWritableRearPortTemplateRequestAdded();
  block(matchAddWritableRearPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedInterface", function () {
  const x = waitForAnyNestedInterfaceAdded();
  block(matchAddNestedInterface(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableConsoleServerPortTemplateRequest", function () {
  const x = waitForAnyPatchedWritableConsoleServerPortTemplateRequestAdded();
  block(matchAddPatchedWritableConsoleServerPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedContactGroup", function () {
  const x = waitForAnyNestedContactGroupAdded();
  block(matchAddNestedContactGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique InventoryItemRoleRequest", function () {
  const x = waitForAnyInventoryItemRoleRequestAdded();
  block(matchAddInventoryItemRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique InterfaceTemplateRequest", function () {
  const x = waitForAnyInterfaceTemplateRequestAdded();
  block(matchAddInterfaceTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WirelessLink", function () {
  const x = waitForAnyWirelessLinkAdded();
  block(matchAddWirelessLink(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableVirtualCircuitTerminationRequest", function () {
  const x = waitForAnyWritableVirtualCircuitTerminationRequestAdded();
  block(matchAddWritableVirtualCircuitTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerPortTemplate", function () {
  const x = waitForAnyPowerPortTemplateAdded();
  block(matchAddPowerPortTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique ProviderAccount", function () {
  const x = waitForAnyProviderAccountAdded();
  block(matchAddProviderAccount(x.id, ANY), function () {});
});

bthread("Guard: Unique ScriptInputRequest", function () {
  const x = waitForAnyScriptInputRequestAdded();
  block(matchAddScriptInputRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ProviderNetwork", function () {
  const x = waitForAnyProviderNetworkAdded();
  block(matchAddProviderNetwork(x.id, ANY), function () {});
});

bthread("Guard: Unique IntegerRange", function () {
  const x = waitForAnyIntegerRangeAdded();
  block(matchAddIntegerRange(x.id, ANY), function () {});
});

bthread("Guard: Unique InventoryItem", function () {
  const x = waitForAnyInventoryItemAdded();
  block(matchAddInventoryItem(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedConfigTemplateList", function () {
  const x = waitForAnyPaginatedConfigTemplateListAdded();
  block(matchAddPaginatedConfigTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualDeviceContextRequest", function () {
  const x = waitForAnyVirtualDeviceContextRequestAdded();
  block(matchAddVirtualDeviceContextRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableConsolePortTemplateRequest", function () {
  const x = waitForAnyWritableConsolePortTemplateRequestAdded();
  block(matchAddWritableConsolePortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedWirelessLANList", function () {
  const x = waitForAnyPaginatedWirelessLANListAdded();
  block(matchAddPaginatedWirelessLANList(x.id, ANY), function () {});
});

bthread("Guard: Unique SiteGroupRequest", function () {
  const x = waitForAnySiteGroupRequestAdded();
  block(matchAddSiteGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefFHRPGroupRequest", function () {
  const x = waitForAnyBriefFHRPGroupRequestAdded();
  block(matchAddBriefFHRPGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerOutlet", function () {
  const x = waitForAnyPowerOutletAdded();
  block(matchAddPowerOutlet(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualChassis", function () {
  const x = waitForAnyVirtualChassisAdded();
  block(matchAddVirtualChassis(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableContactGroupRequest", function () {
  const x = waitForAnyPatchedWritableContactGroupRequestAdded();
  block(matchAddPatchedWritableContactGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedDevice", function () {
  const x = waitForAnyNestedDeviceAdded();
  block(matchAddNestedDevice(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedIPSecProposalList", function () {
  const x = waitForAnyPaginatedIPSecProposalListAdded();
  block(matchAddPaginatedIPSecProposalList(x.id, ANY), function () {});
});

bthread("Guard: Unique ContactRole", function () {
  const x = waitForAnyContactRoleAdded();
  block(matchAddContactRole(x.id, ANY), function () {});
});

bthread("Guard: Unique TokenProvision", function () {
  const x = waitForAnyTokenProvisionAdded();
  block(matchAddTokenProvision(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedBookmarkList", function () {
  const x = waitForAnyPaginatedBookmarkListAdded();
  block(matchAddPaginatedBookmarkList(x.id, ANY), function () {});
});

bthread("Guard: Unique WirelessLANGroupRequest", function () {
  const x = waitForAnyWirelessLANGroupRequestAdded();
  block(matchAddWirelessLANGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedLocationList", function () {
  const x = waitForAnyPaginatedLocationListAdded();
  block(matchAddPaginatedLocationList(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedTagRequest", function () {
  const x = waitForAnyNestedTagRequestAdded();
  block(matchAddNestedTagRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedPlatformRequest", function () {
  const x = waitForAnyNestedPlatformRequestAdded();
  block(matchAddNestedPlatformRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRearPortTemplateList", function () {
  const x = waitForAnyPaginatedRearPortTemplateListAdded();
  block(matchAddPaginatedRearPortTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerFeed", function () {
  const x = waitForAnyPowerFeedAdded();
  block(matchAddPowerFeed(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableRegionRequest", function () {
  const x = waitForAnyWritableRegionRequestAdded();
  block(matchAddWritableRegionRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedCircuitTypeList", function () {
  const x = waitForAnyPaginatedCircuitTypeListAdded();
  block(matchAddPaginatedCircuitTypeList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVirtualMachine", function () {
  const x = waitForAnyBriefVirtualMachineAdded();
  block(matchAddBriefVirtualMachine(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitGroupAssignmentRequest", function () {
  const x = waitForAnyCircuitGroupAssignmentRequestAdded();
  block(matchAddCircuitGroupAssignmentRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritablePowerOutletRequest", function () {
  const x = waitForAnyPatchedWritablePowerOutletRequestAdded();
  block(matchAddPatchedWritablePowerOutletRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefDeviceType", function () {
  const x = waitForAnyBriefDeviceTypeAdded();
  block(matchAddBriefDeviceType(x.id, ANY), function () {});
});

bthread("Guard: Unique TokenProvisionRequest", function () {
  const x = waitForAnyTokenProvisionRequestAdded();
  block(matchAddTokenProvisionRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique TunnelTermination", function () {
  const x = waitForAnyTunnelTerminationAdded();
  block(matchAddTunnelTermination(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedProviderList", function () {
  const x = waitForAnyPaginatedProviderListAdded();
  block(matchAddPaginatedProviderList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableRearPortRequest", function () {
  const x = waitForAnyWritableRearPortRequestAdded();
  block(matchAddWritableRearPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefPowerPortRequest", function () {
  const x = waitForAnyBriefPowerPortRequestAdded();
  block(matchAddBriefPowerPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRoleRequest", function () {
  const x = waitForAnyBriefRoleRequestAdded();
  block(matchAddBriefRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefJobRequest", function () {
  const x = waitForAnyBriefJobRequestAdded();
  block(matchAddBriefJobRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefUserRequest", function () {
  const x = waitForAnyBriefUserRequestAdded();
  block(matchAddBriefUserRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VMInterface", function () {
  const x = waitForAnyVMInterfaceAdded();
  block(matchAddVMInterface(x.id, ANY), function () {});
});

bthread("Guard: Unique FHRPGroupAssignmentRequest", function () {
  const x = waitForAnyFHRPGroupAssignmentRequestAdded();
  block(matchAddFHRPGroupAssignmentRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCircuitTypeRequest", function () {
  const x = waitForAnyBriefCircuitTypeRequestAdded();
  block(matchAddBriefCircuitTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedL2VPNList", function () {
  const x = waitForAnyPaginatedL2VPNListAdded();
  block(matchAddPaginatedL2VPNList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedManufacturerList", function () {
  const x = waitForAnyPaginatedManufacturerListAdded();
  block(matchAddPaginatedManufacturerList(x.id, ANY), function () {});
});

bthread("Guard: Unique VLANGroupRequest", function () {
  const x = waitForAnyVLANGroupRequestAdded();
  block(matchAddVLANGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableAggregateRequest", function () {
  const x = waitForAnyWritableAggregateRequestAdded();
  block(matchAddWritableAggregateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefIKEPolicy", function () {
  const x = waitForAnyBriefIKEPolicyAdded();
  block(matchAddBriefIKEPolicy(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefDataSource", function () {
  const x = waitForAnyBriefDataSourceAdded();
  block(matchAddBriefDataSource(x.id, ANY), function () {});
});

bthread("Guard: Unique RackReservationRequest", function () {
  const x = waitForAnyRackReservationRequestAdded();
  block(matchAddRackReservationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique DeviceBay", function () {
  const x = waitForAnyDeviceBayAdded();
  block(matchAddDeviceBay(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefCircuitGroup", function () {
  const x = waitForAnyBriefCircuitGroupAdded();
  block(matchAddBriefCircuitGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedWirelessLink", function () {
  const x = waitForAnyNestedWirelessLinkAdded();
  block(matchAddNestedWirelessLink(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefRIRRequest", function () {
  const x = waitForAnyBriefRIRRequestAdded();
  block(matchAddBriefRIRRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedTagList", function () {
  const x = waitForAnyPaginatedTagListAdded();
  block(matchAddPaginatedTagList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefTunnel", function () {
  const x = waitForAnyBriefTunnelAdded();
  block(matchAddBriefTunnel(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedLocationRequest", function () {
  const x = waitForAnyNestedLocationRequestAdded();
  block(matchAddNestedLocationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedWirelessLANGroup", function () {
  const x = waitForAnyNestedWirelessLANGroupAdded();
  block(matchAddNestedWirelessLANGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedIKEProposalList", function () {
  const x = waitForAnyPaginatedIKEProposalListAdded();
  block(matchAddPaginatedIKEProposalList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVMInterfaceList", function () {
  const x = waitForAnyPaginatedVMInterfaceListAdded();
  block(matchAddPaginatedVMInterfaceList(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedVLANRequest", function () {
  const x = waitForAnyNestedVLANRequestAdded();
  block(matchAddNestedVLANRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWebhookRequest", function () {
  const x = waitForAnyPatchedWebhookRequestAdded();
  block(matchAddPatchedWebhookRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableIPAddressRequest", function () {
  const x = waitForAnyPatchedWritableIPAddressRequestAdded();
  block(matchAddPatchedWritableIPAddressRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableIPSecProposalRequest", function () {
  const x = waitForAnyWritableIPSecProposalRequestAdded();
  block(matchAddWritableIPSecProposalRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedNotificationRequest", function () {
  const x = waitForAnyPatchedNotificationRequestAdded();
  block(matchAddPatchedNotificationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritablePlatformRequest", function () {
  const x = waitForAnyWritablePlatformRequestAdded();
  block(matchAddWritablePlatformRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerOutletTemplate", function () {
  const x = waitForAnyPowerOutletTemplateAdded();
  block(matchAddPowerOutletTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedDeviceBayRequest", function () {
  const x = waitForAnyPatchedDeviceBayRequestAdded();
  block(matchAddPatchedDeviceBayRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedBookmarkRequest", function () {
  const x = waitForAnyPatchedBookmarkRequestAdded();
  block(matchAddPatchedBookmarkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefDeviceRoleRequest", function () {
  const x = waitForAnyBriefDeviceRoleRequestAdded();
  block(matchAddBriefDeviceRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableIPSecPolicyRequest", function () {
  const x = waitForAnyWritableIPSecPolicyRequestAdded();
  block(matchAddWritableIPSecPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique CircuitRequest", function () {
  const x = waitForAnyCircuitRequestAdded();
  block(matchAddCircuitRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique MACAddress", function () {
  const x = waitForAnyMACAddressAdded();
  block(matchAddMACAddress(x.id, ANY), function () {});
});

bthread("Guard: Unique DataFile", function () {
  const x = waitForAnyDataFileAdded();
  block(matchAddDataFile(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableConsolePortRequest", function () {
  const x = waitForAnyWritableConsolePortRequestAdded();
  block(matchAddWritableConsolePortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique DeviceTypeRequest", function () {
  const x = waitForAnyDeviceTypeRequestAdded();
  block(matchAddDeviceTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedCustomLinkList", function () {
  const x = waitForAnyPaginatedCustomLinkListAdded();
  block(matchAddPaginatedCustomLinkList(x.id, ANY), function () {});
});

bthread("Guard: Unique DeviceType", function () {
  const x = waitForAnyDeviceTypeAdded();
  block(matchAddDeviceType(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedTokenRequest", function () {
  const x = waitForAnyPatchedTokenRequestAdded();
  block(matchAddPatchedTokenRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefModuleTypeProfileRequest", function () {
  const x = waitForAnyBriefModuleTypeProfileRequestAdded();
  block(matchAddBriefModuleTypeProfileRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique DeviceWithConfigContext", function () {
  const x = waitForAnyDeviceWithConfigContextAdded();
  block(matchAddDeviceWithConfigContext(x.id, ANY), function () {});
});

bthread("Guard: Unique ModuleBayTemplateRequest", function () {
  const x = waitForAnyModuleBayTemplateRequestAdded();
  block(matchAddModuleBayTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ProviderAccountRequest", function () {
  const x = waitForAnyProviderAccountRequestAdded();
  block(matchAddProviderAccountRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableRackTypeRequest", function () {
  const x = waitForAnyWritableRackTypeRequestAdded();
  block(matchAddWritableRackTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefInventoryItemRoleRequest", function () {
  const x = waitForAnyBriefInventoryItemRoleRequestAdded();
  block(matchAddBriefInventoryItemRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedUserList", function () {
  const x = waitForAnyPaginatedUserListAdded();
  block(matchAddPaginatedUserList(x.id, ANY), function () {});
});

bthread("Guard: Unique IPSecProfileRequest", function () {
  const x = waitForAnyIPSecProfileRequestAdded();
  block(matchAddIPSecProfileRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedInventoryItemList", function () {
  const x = waitForAnyPaginatedInventoryItemListAdded();
  block(matchAddPaginatedInventoryItemList(x.id, ANY), function () {});
});

bthread("Guard: Unique RackRoleRequest", function () {
  const x = waitForAnyRackRoleRequestAdded();
  block(matchAddRackRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefModule", function () {
  const x = waitForAnyBriefModuleAdded();
  block(matchAddBriefModule(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableSiteGroupRequest", function () {
  const x = waitForAnyPatchedWritableSiteGroupRequestAdded();
  block(matchAddPatchedWritableSiteGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WirelessLANRequest", function () {
  const x = waitForAnyWirelessLANRequestAdded();
  block(matchAddWirelessLANRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedDataFileList", function () {
  const x = waitForAnyPaginatedDataFileListAdded();
  block(matchAddPaginatedDataFileList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVLANTranslationPolicyList", function () {
  const x = waitForAnyPaginatedVLANTranslationPolicyListAdded();
  block(matchAddPaginatedVLANTranslationPolicyList(x.id, ANY), function () {});
});

bthread("Guard: Unique Provider", function () {
  const x = waitForAnyProviderAdded();
  block(matchAddProvider(x.id, ANY), function () {});
});

bthread("Guard: Unique TagRequest", function () {
  const x = waitForAnyTagRequestAdded();
  block(matchAddTagRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefInterfaceRequest", function () {
  const x = waitForAnyBriefInterfaceRequestAdded();
  block(matchAddBriefInterfaceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ContactRoleRequest", function () {
  const x = waitForAnyContactRoleRequestAdded();
  block(matchAddContactRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique IntegerRangeRequest", function () {
  const x = waitForAnyIntegerRangeRequestAdded();
  block(matchAddIntegerRangeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedTenantGroupRequest", function () {
  const x = waitForAnyNestedTenantGroupRequestAdded();
  block(matchAddNestedTenantGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableDeviceRoleRequest", function () {
  const x = waitForAnyPatchedWritableDeviceRoleRequestAdded();
  block(matchAddPatchedWritableDeviceRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NotificationRequest", function () {
  const x = waitForAnyNotificationRequestAdded();
  block(matchAddNotificationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableDeviceTypeRequest", function () {
  const x = waitForAnyPatchedWritableDeviceTypeRequestAdded();
  block(matchAddPatchedWritableDeviceTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableModuleRequest", function () {
  const x = waitForAnyPatchedWritableModuleRequestAdded();
  block(matchAddPatchedWritableModuleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RackUnit", function () {
  const x = waitForAnyRackUnitAdded();
  block(matchAddRackUnit(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedVirtualChassisList", function () {
  const x = waitForAnyPaginatedVirtualChassisListAdded();
  block(matchAddPaginatedVirtualChassisList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefDevice", function () {
  const x = waitForAnyBriefDeviceAdded();
  block(matchAddBriefDevice(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedEventRuleList", function () {
  const x = waitForAnyPaginatedEventRuleListAdded();
  block(matchAddPaginatedEventRuleList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVLANGroupRequest", function () {
  const x = waitForAnyBriefVLANGroupRequestAdded();
  block(matchAddBriefVLANGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableModuleTypeRequest", function () {
  const x = waitForAnyPatchedWritableModuleTypeRequestAdded();
  block(matchAddPatchedWritableModuleTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableInterfaceTemplateRequest", function () {
  const x = waitForAnyPatchedWritableInterfaceTemplateRequestAdded();
  block(matchAddPatchedWritableInterfaceTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ClusterType", function () {
  const x = waitForAnyClusterTypeAdded();
  block(matchAddClusterType(x.id, ANY), function () {});
});

bthread("Guard: Unique Notification", function () {
  const x = waitForAnyNotificationAdded();
  block(matchAddNotification(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableWirelessLANGroupRequest", function () {
  const x = waitForAnyWritableWirelessLANGroupRequestAdded();
  block(matchAddWritableWirelessLANGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique TunnelTerminationRequest", function () {
  const x = waitForAnyTunnelTerminationRequestAdded();
  block(matchAddTunnelTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ObjectPermissionRequest", function () {
  const x = waitForAnyObjectPermissionRequestAdded();
  block(matchAddObjectPermissionRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VLAN", function () {
  const x = waitForAnyVLANAdded();
  block(matchAddVLAN(x.id, ANY), function () {});
});

bthread("Guard: Unique FrontPortTemplateRequest", function () {
  const x = waitForAnyFrontPortTemplateRequestAdded();
  block(matchAddFrontPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedVLAN", function () {
  const x = waitForAnyNestedVLANAdded();
  block(matchAddNestedVLAN(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefManufacturerRequest", function () {
  const x = waitForAnyBriefManufacturerRequestAdded();
  block(matchAddBriefManufacturerRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableCircuitGroupAssignmentRequest", function () {
  const x = waitForAnyPatchedWritableCircuitGroupAssignmentRequestAdded();
  block(matchAddPatchedWritableCircuitGroupAssignmentRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique InventoryItemRequest", function () {
  const x = waitForAnyInventoryItemRequestAdded();
  block(matchAddInventoryItemRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique L2VPN", function () {
  const x = waitForAnyL2VPNAdded();
  block(matchAddL2VPN(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedUser", function () {
  const x = waitForAnyNestedUserAdded();
  block(matchAddNestedUser(x.id, ANY), function () {});
});

bthread("Guard: Unique ConsolePort", function () {
  const x = waitForAnyConsolePortAdded();
  block(matchAddConsolePort(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableCustomFieldChoiceSetRequest", function () {
  const x = waitForAnyWritableCustomFieldChoiceSetRequestAdded();
  block(matchAddWritableCustomFieldChoiceSetRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedTaggedItemList", function () {
  const x = waitForAnyPaginatedTaggedItemListAdded();
  block(matchAddPaginatedTaggedItemList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVirtualCircuitTypeRequest", function () {
  const x = waitForAnyBriefVirtualCircuitTypeRequestAdded();
  block(matchAddBriefVirtualCircuitTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique Manufacturer", function () {
  const x = waitForAnyManufacturerAdded();
  block(matchAddManufacturer(x.id, ANY), function () {});
});

bthread("Guard: Unique ModuleTypeRequest", function () {
  const x = waitForAnyModuleTypeRequestAdded();
  block(matchAddModuleTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableTenantGroupRequest", function () {
  const x = waitForAnyWritableTenantGroupRequestAdded();
  block(matchAddWritableTenantGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RearPortTemplate", function () {
  const x = waitForAnyRearPortTemplateAdded();
  block(matchAddRearPortTemplate(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefProviderNetwork", function () {
  const x = waitForAnyBriefProviderNetworkAdded();
  block(matchAddBriefProviderNetwork(x.id, ANY), function () {});
});

bthread("Guard: Unique NotificationGroupRequest", function () {
  const x = waitForAnyNotificationGroupRequestAdded();
  block(matchAddNotificationGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedClusterGroupRequest", function () {
  const x = waitForAnyPatchedClusterGroupRequestAdded();
  block(matchAddPatchedClusterGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ClusterRequest", function () {
  const x = waitForAnyClusterRequestAdded();
  block(matchAddClusterRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedCircuitGroupRequest", function () {
  const x = waitForAnyPatchedCircuitGroupRequestAdded();
  block(matchAddPatchedCircuitGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableTunnelRequest", function () {
  const x = waitForAnyWritableTunnelRequestAdded();
  block(matchAddWritableTunnelRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedInterfaceList", function () {
  const x = waitForAnyPaginatedInterfaceListAdded();
  block(matchAddPaginatedInterfaceList(x.id, ANY), function () {});
});

bthread("Guard: Unique WirelessLANGroup", function () {
  const x = waitForAnyWirelessLANGroupAdded();
  block(matchAddWirelessLANGroup(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableServiceTemplateRequest", function () {
  const x = waitForAnyPatchedWritableServiceTemplateRequestAdded();
  block(matchAddPatchedWritableServiceTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique IKEProposal", function () {
  const x = waitForAnyIKEProposalAdded();
  block(matchAddIKEProposal(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableTunnelRequest", function () {
  const x = waitForAnyPatchedWritableTunnelRequestAdded();
  block(matchAddPatchedWritableTunnelRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableInterfaceRequest", function () {
  const x = waitForAnyPatchedWritableInterfaceRequestAdded();
  block(matchAddPatchedWritableInterfaceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedPlatform", function () {
  const x = waitForAnyNestedPlatformAdded();
  block(matchAddNestedPlatform(x.id, ANY), function () {});
});

bthread("Guard: Unique Dashboard", function () {
  const x = waitForAnyDashboardAdded();
  block(matchAddDashboard(x.id, ANY), function () {});
});

bthread("Guard: Unique ConsoleServerPortTemplateRequest", function () {
  const x = waitForAnyConsoleServerPortTemplateRequestAdded();
  block(matchAddConsoleServerPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedL2VPNTerminationRequest", function () {
  const x = waitForAnyPatchedL2VPNTerminationRequestAdded();
  block(matchAddPatchedL2VPNTerminationRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefModuleType", function () {
  const x = waitForAnyBriefModuleTypeAdded();
  block(matchAddBriefModuleType(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefContact", function () {
  const x = waitForAnyBriefContactAdded();
  block(matchAddBriefContact(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableCableRequest", function () {
  const x = waitForAnyPatchedWritableCableRequestAdded();
  block(matchAddPatchedWritableCableRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ConfigContextProfileRequest", function () {
  const x = waitForAnyConfigContextProfileRequestAdded();
  block(matchAddConfigContextProfileRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ASNRangeRequest", function () {
  const x = waitForAnyASNRangeRequestAdded();
  block(matchAddASNRangeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ObjectChange", function () {
  const x = waitForAnyObjectChangeAdded();
  block(matchAddObjectChange(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedRoleRequest", function () {
  const x = waitForAnyPatchedRoleRequestAdded();
  block(matchAddPatchedRoleRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefPlatformRequest", function () {
  const x = waitForAnyBriefPlatformRequestAdded();
  block(matchAddBriefPlatformRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableVirtualChassisRequest", function () {
  const x = waitForAnyPatchedWritableVirtualChassisRequestAdded();
  block(matchAddPatchedWritableVirtualChassisRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedObjectChangeList", function () {
  const x = waitForAnyPaginatedObjectChangeListAdded();
  block(matchAddPaginatedObjectChangeList(x.id, ANY), function () {});
});

bthread("Guard: Unique RackType", function () {
  const x = waitForAnyRackTypeAdded();
  block(matchAddRackType(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedIPSecPolicyList", function () {
  const x = waitForAnyPaginatedIPSecPolicyListAdded();
  block(matchAddPaginatedIPSecPolicyList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedJournalEntryList", function () {
  const x = waitForAnyPaginatedJournalEntryListAdded();
  block(matchAddPaginatedJournalEntryList(x.id, ANY), function () {});
});

bthread("Guard: Unique ModuleBay", function () {
  const x = waitForAnyModuleBayAdded();
  block(matchAddModuleBay(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedPowerPortTemplateList", function () {
  const x = waitForAnyPaginatedPowerPortTemplateListAdded();
  block(matchAddPaginatedPowerPortTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableVMInterfaceRequest", function () {
  const x = waitForAnyWritableVMInterfaceRequestAdded();
  block(matchAddWritableVMInterfaceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedModuleBayRequest", function () {
  const x = waitForAnyNestedModuleBayRequestAdded();
  block(matchAddNestedModuleBayRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedInventoryItemTemplateList", function () {
  const x = waitForAnyPaginatedInventoryItemTemplateListAdded();
  block(matchAddPaginatedInventoryItemTemplateList(x.id, ANY), function () {});
});

bthread("Guard: Unique WirelessLAN", function () {
  const x = waitForAnyWirelessLANAdded();
  block(matchAddWirelessLAN(x.id, ANY), function () {});
});

bthread("Guard: Unique ImageAttachmentRequest", function () {
  const x = waitForAnyImageAttachmentRequestAdded();
  block(matchAddImageAttachmentRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique JournalEntryRequest", function () {
  const x = waitForAnyJournalEntryRequestAdded();
  block(matchAddJournalEntryRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedGroupList", function () {
  const x = waitForAnyPaginatedGroupListAdded();
  block(matchAddPaginatedGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique TenantGroupRequest", function () {
  const x = waitForAnyTenantGroupRequestAdded();
  block(matchAddTenantGroupRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedSiteGroupList", function () {
  const x = waitForAnyPaginatedSiteGroupListAdded();
  block(matchAddPaginatedSiteGroupList(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerOutletTemplateRequest", function () {
  const x = waitForAnyPowerOutletTemplateRequestAdded();
  block(matchAddPowerOutletTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedCableTerminationList", function () {
  const x = waitForAnyPaginatedCableTerminationListAdded();
  block(matchAddPaginatedCableTerminationList(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVirtualChassisRequest", function () {
  const x = waitForAnyBriefVirtualChassisRequestAdded();
  block(matchAddBriefVirtualChassisRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedWirelessLinkRequest", function () {
  const x = waitForAnyNestedWirelessLinkRequestAdded();
  block(matchAddNestedWirelessLinkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PowerPanel", function () {
  const x = waitForAnyPowerPanelAdded();
  block(matchAddPowerPanel(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableInventoryItemRequest", function () {
  const x = waitForAnyPatchedWritableInventoryItemRequestAdded();
  block(matchAddPatchedWritableInventoryItemRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique IPSecPolicyRequest", function () {
  const x = waitForAnyIPSecPolicyRequestAdded();
  block(matchAddIPSecPolicyRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedExportTemplateRequest", function () {
  const x = waitForAnyPatchedExportTemplateRequestAdded();
  block(matchAddPatchedExportTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique FHRPGroupAssignment", function () {
  const x = waitForAnyFHRPGroupAssignmentAdded();
  block(matchAddFHRPGroupAssignment(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedDeviceBayTemplateRequest", function () {
  const x = waitForAnyPatchedDeviceBayTemplateRequestAdded();
  block(matchAddPatchedDeviceBayTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedNotificationList", function () {
  const x = waitForAnyPaginatedNotificationListAdded();
  block(matchAddPaginatedNotificationList(x.id, ANY), function () {});
});

bthread("Guard: Unique AggregateRequest", function () {
  const x = waitForAnyAggregateRequestAdded();
  block(matchAddAggregateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefDeviceTypeRequest", function () {
  const x = waitForAnyBriefDeviceTypeRequestAdded();
  block(matchAddBriefDeviceTypeRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVirtualMachineRequest", function () {
  const x = waitForAnyBriefVirtualMachineRequestAdded();
  block(matchAddBriefVirtualMachineRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique VirtualDiskRequest", function () {
  const x = waitForAnyVirtualDiskRequestAdded();
  block(matchAddVirtualDiskRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritablePowerOutletTemplateRequest", function () {
  const x = waitForAnyPatchedWritablePowerOutletTemplateRequestAdded();
  block(matchAddPatchedWritablePowerOutletTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WebhookRequest", function () {
  const x = waitForAnyWebhookRequestAdded();
  block(matchAddWebhookRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritablePowerOutletRequest", function () {
  const x = waitForAnyWritablePowerOutletRequestAdded();
  block(matchAddWritablePowerOutletRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritablePowerOutletTemplateRequest", function () {
  const x = waitForAnyWritablePowerOutletTemplateRequestAdded();
  block(matchAddWritablePowerOutletTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableServiceRequest", function () {
  const x = waitForAnyPatchedWritableServiceRequestAdded();
  block(matchAddPatchedWritableServiceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableServiceRequest", function () {
  const x = waitForAnyWritableServiceRequestAdded();
  block(matchAddWritableServiceRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedManufacturerRequest", function () {
  const x = waitForAnyPatchedManufacturerRequestAdded();
  block(matchAddPatchedManufacturerRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedRackReservationList", function () {
  const x = waitForAnyPaginatedRackReservationListAdded();
  block(matchAddPaginatedRackReservationList(x.id, ANY), function () {});
});

bthread("Guard: Unique ManufacturerRequest", function () {
  const x = waitForAnyManufacturerRequestAdded();
  block(matchAddManufacturerRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique RouteTarget", function () {
  const x = waitForAnyRouteTargetAdded();
  block(matchAddRouteTarget(x.id, ANY), function () {});
});

bthread("Guard: Unique VRFRequest", function () {
  const x = waitForAnyVRFRequestAdded();
  block(matchAddVRFRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ConfigContextProfile", function () {
  const x = waitForAnyConfigContextProfileAdded();
  block(matchAddConfigContextProfile(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedASNList", function () {
  const x = waitForAnyPaginatedASNListAdded();
  block(matchAddPaginatedASNList(x.id, ANY), function () {});
});

bthread("Guard: Unique VRF", function () {
  const x = waitForAnyVRFAdded();
  block(matchAddVRF(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefIPAddressRequest", function () {
  const x = waitForAnyBriefIPAddressRequestAdded();
  block(matchAddBriefIPAddressRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableCableRequest", function () {
  const x = waitForAnyWritableCableRequestAdded();
  block(matchAddWritableCableRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedProviderNetworkRequest", function () {
  const x = waitForAnyPatchedProviderNetworkRequestAdded();
  block(matchAddPatchedProviderNetworkRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableRackRequest", function () {
  const x = waitForAnyWritableRackRequestAdded();
  block(matchAddWritableRackRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique FrontPort", function () {
  const x = waitForAnyFrontPortAdded();
  block(matchAddFrontPort(x.id, ANY), function () {});
});

bthread("Guard: Unique WritableWirelessLANRequest", function () {
  const x = waitForAnyWritableWirelessLANRequestAdded();
  block(matchAddWritableWirelessLANRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedPowerPanelList", function () {
  const x = waitForAnyPaginatedPowerPanelListAdded();
  block(matchAddPaginatedPowerPanelList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedCustomFieldChoiceSetList", function () {
  const x = waitForAnyPaginatedCustomFieldChoiceSetListAdded();
  block(matchAddPaginatedCustomFieldChoiceSetList(x.id, ANY), function () {});
});

bthread("Guard: Unique PaginatedDeviceRoleList", function () {
  const x = waitForAnyPaginatedDeviceRoleListAdded();
  block(matchAddPaginatedDeviceRoleList(x.id, ANY), function () {});
});

bthread("Guard: Unique PatchedWritableRearPortTemplateRequest", function () {
  const x = waitForAnyPatchedWritableRearPortTemplateRequestAdded();
  block(matchAddPatchedWritableRearPortTemplateRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefVirtualCircuit", function () {
  const x = waitForAnyBriefVirtualCircuitAdded();
  block(matchAddBriefVirtualCircuit(x.id, ANY), function () {});
});

bthread("Guard: Unique NestedVirtualMachine", function () {
  const x = waitForAnyNestedVirtualMachineAdded();
  block(matchAddNestedVirtualMachine(x.id, ANY), function () {});
});

bthread("Guard: Unique BriefClusterRequest", function () {
  const x = waitForAnyBriefClusterRequestAdded();
  block(matchAddBriefClusterRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique WritablePowerPortRequest", function () {
  const x = waitForAnyWritablePowerPortRequestAdded();
  block(matchAddWritablePowerPortRequest(x.id, ANY), function () {});
});

bthread("Guard: Unique ExportTemplate", function () {
  const x = waitForAnyExportTemplateAdded();
  block(matchAddExportTemplate(x.id, ANY), function () {});
});

// ===== NEGATIVE/EDGE STATUS GUARDS =====
