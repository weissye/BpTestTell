@echo off
setlocal EnableExtensions EnableDelayedExpansion

if "%~1"=="" (
  echo Usage: %~nx0 ^<sut_name^> [realworld^|7suts]
  echo Example: %~nx0 github realworld
  echo          %~nx0 banking 7suts
  exit /b 2
)

set "SUT=%~1"
set "KIND=%~2"
if "%KIND%"=="" set "KIND=realworld"

set "ROOT=%~dp0..\..\.."
set "PY_EXE=%ROOT%\.venv\Scripts\python.exe"
if not exist "%PY_EXE%" set "PY_EXE=python"

if not defined GEN_PY set "GEN_PY=%ROOT%\scripts\llm\emit_llm_gold_from_openapi.py"
if not exist "%GEN_PY%" for %%F in ("%ROOT%\scripts\llm\emit_llm_gold_from_openapi*.py") do (
  set "GEN_PY=%%~fF"
  goto :got_gen
)
:got_gen
if not exist "%GEN_PY%" (
  echo [ERR] Generator script not found at "%GEN_PY%".
  exit /b 1
)

if not defined PROVIDER set "PROVIDER=openai"
if not defined MODEL set "MODEL=gpt-4o-mini"

set "EXTRA="
if "%FORCE%"=="1" set "EXTRA=%EXTRA% --force"

echo(
if /i "%KIND%"=="realworld" (
  echo ==== %SUT% (REAL-WORLD^) ====
  set "SPEC=%ROOT%\packs\realworld\%SUT%\openapi.json"
  set "OUT=%ROOT%\artifacts\det_checked\real_world_llm_provider\%SUT%"
) else (
  echo ==== %SUT% (7-SUTS^) ====
  rem Try common 7-suts locations
  set "SPEC="
  if exist "%ROOT%\packs\7_suts\%SUT%\openapi.json" set "SPEC=%ROOT%\packs\7_suts\%SUT%\openapi.json"
  if not defined SPEC if exist "%ROOT%\packs\7_suts_llm_provider\%SUT%\openapi.json" set "SPEC=%ROOT%\packs\7_suts_llm_provider\%SUT%\openapi.json"
  set "OUT=%ROOT%\artifacts\det_checked\7_suts_llm_provider\%SUT%"
)

if not exist "%SPEC%" (
  echo [ERR] Could not locate openapi.json for "%SUT%".
  exit /b 3
)

if "%CLEAN%"=="1" (
  if exist "%OUT%" rmdir /s /q "%OUT%"
)
if not exist "%OUT%" mkdir "%OUT%" >nul 2>&1

echo [INFO] CWD=%CD%
echo [RUN] provider=%PROVIDER%  model=%MODEL%
echo [RUN] spec="%SPEC%"  out="%OUT%"

"%PY_EXE%" "%GEN_PY%" --provider "%PROVIDER%" --model "%MODEL%" --spec "%SPEC%" --out "%OUT%" %EXTRA%
if errorlevel 1 (
  echo [ERR] Generator failed for "%SUT%".
  exit /b 1
) else (
  echo [OK] %SUT%
  exit /b 0
)
