@echo off
setlocal EnableExtensions EnableDelayedExpansion
REM ------------------------------------------------------------
REM gen_hls_nondet_sharded_for_list.bat
REM Drives HLS NONDET generation for a list of SUTs.
REM Usage: gen_hls_nondet_sharded_for_list.bat <list_file>
REM List format:
REM   ; comments start with semicolon
REM   <sut-name> on each non-empty line
REM
REM Env of interest:
REM   HLS_DEBUG=1
REM   HLS_DRYRUN=1                      (echo only; do not run)
REM   HLS_SEED=<int>                    (base seed)
REM   HLS_NONDET_MAX=<int>              (cap, optional)
REM   HLS_NONDET_PER_SUT=<int>          (used for SUTs provider)
REM   HLS_SHARDS=<int>                  (used for RW provider; default 1)
REM   HLS_NONDET_PER_SHARD=<int>        (stories per RW shard)
REM   HLS_KEEP_SHARDS=1                 (keep shard files after merge)
REM ------------------------------------------------------------

if "%~1"=="" (
  echo Usage: %~nx0 ^<list_file^>
  exit /b 2
)

set "LIST=%~1"

REM Resolve repo ROOT from this script location
set "SCRIPT_DIR=%~dp0"
pushd "%SCRIPT_DIR%\..\.." >nul
set "ROOT=%CD%"
popd >nul

set "GEN=%ROOT%\scripts\hls\gen_hls_nondet.bat"
set "MERGER=%ROOT%\scripts\hls\merge_nondet_shards.py"
set "PY=%ROOT%\.venv\Scripts\python.exe"

echo ============================================
echo HLS-NONDET (sharded) from: "%LIST%"
echo CWD   : %CD%
echo ROOT  : %ROOT%
echo GEN   : %GEN%
echo DET-7 : %ROOT%\artifacts\hls_det\7_suts_llm_provider
echo DET-RW: %ROOT%\artifacts\hls_det\real_world_llm_provider
echo ============================================

if defined HLS_DEBUG (
  echo [DBG] where python:
  where "%PY%" 2>nul || echo INFO: Could not find files for the given pattern^(s^).
  echo [DBG] env:
  echo       HLS_DEBUG=%HLS_DEBUG%
  echo       HLS_DRYRUN=%HLS_DRYRUN%
  echo       HLS_SHARDS=%HLS_SHARDS%
  echo       HLS_NONDET_PER_SHARD=%HLS_NONDET_PER_SHARD%
  echo       HLS_NONDET_MAX=%HLS_NONDET_MAX%
  echo       HLS_SEED=%HLS_SEED%
  echo       HLS_KEEP_SHARDS=%HLS_KEEP_SHARDS%
)

if not exist "%LIST%" (
  echo [ERR] list file not found: %LIST%
  exit /b 3
)

REM Dump list with line numbers
if defined HLS_DEBUG (
  echo [DBG] Dumping "%LIST%" with line numbers:
  set /a __ln=0
  for /f "usebackq eol=; tokens=* delims=" %%L in ("%LIST%") do (
    set /a __ln+=1
    echo   [DBG] !__ln!: %%L
  )
)

echo [DBG] Entering generation loop...
for /f "usebackq eol=; tokens=* delims=" %%L in ("%LIST%") do (
  set "SUT=%%~L"
  REM skip blank lines
  if "!SUT!"=="" (
    REM skip
  ) else (
    call :PROCESS_SUT "!SUT!"
    if errorlevel 1 (
      echo [ERR] processing failed for "!SUT!"
      exit /b 1
    )
  )
)

echo [DONE] %~nx0 finished.
exit /b 0

:PROCESS_SUT
setlocal EnableDelayedExpansion
set "SUT=%~1"
echo [DBG ] PROCESS SUT="!SUT!"

REM Probe which provider has DET
set "P1=%ROOT%\artifacts\hls_det\7_suts_llm_provider\!SUT!\hls_det_gold.json"
set "P2=%ROOT%\artifacts\hls_det\real_world_llm_provider\!SUT!\hls_det_gold.json"

echo [DBG ]   probe P1="!P1!"
if exist "!P1!" (
  echo [DBG ]   ^> P1 exists ^> provider=7_suts_llm_provider
  set "PROVIDER=7_suts_llm_provider"
) else (
  echo [DBG ]   probe P2="!P2!"
  if exist "!P2!" (
    echo [DBG ]   ^> P2 exists ^> provider=real_world_llm_provider
    set "PROVIDER=real_world_llm_provider"
  ) else (
    echo [WARN] skipping "!SUT!" ^(no DET gold found in either provider^)
    endlocal & exit /b 0
  )
)

if /I "!PROVIDER!"=="7_suts_llm_provider" (
  if defined HLS_DEBUG echo [CALL] "%GEN%" "!SUT!" "!PROVIDER!"
  if defined HLS_DRYRUN ( endlocal & exit /b 0 )
  call "%GEN%" "!SUT!" "!PROVIDER!"
  endlocal & exit /b !ERRORLEVEL!
)

REM Real-world: do sharded generation then merge
set "SHARDS=%HLS_SHARDS%"
if not defined SHARDS set "SHARDS=1"
set /a LAST=SHARDS-1
echo [DBG ] starting shards for "!SUT!" total=!SHARDS!

for /L %%I in (0,1,!LAST!) do (
  set "HLS_SHARD_INDEX=%%I"
  if defined HLS_DEBUG echo [CALL] shard %%I/!SHARDS!: "%GEN%" "!SUT!" "!PROVIDER!"
  if defined HLS_DRYRUN (
    REM dry-run skips execution
  ) else (
    call "%GEN%" "!SUT!" "!PROVIDER!"
    if errorlevel 1 (
      echo [ERR ] shard %%I failed for "!SUT!"
      endlocal & exit /b 1
    )
  )
)

REM Merge shard files -> OUT
set "OUT=artifacts\hls_nondet\!PROVIDER!\!SUT!\hls_nondet_gold.json"
set "PAT=!OUT!.shard*.json"

if defined HLS_DRYRUN (
  echo [DRY] merge shards: "%PY%" "%MERGER%" --out "!OUT!" --glob "!PAT!"
) else (
  echo [MERGE] !SUT!: merging shards -> "!OUT!"
  "%PY%" -u "%MERGER%" --out "!OUT!" --glob "!PAT!"
  if errorlevel 1 (
    echo [ERR ] MERGE failed for "!SUT!"
    endlocal & exit /b 1
  )
  if not defined HLS_KEEP_SHARDS (
    del /q "!PAT!" 2>nul
  )
)

endlocal & exit /b 0
