// ====================================================================
// Auto-generated garage-style High-Level Stories (HLS)
// SUT: twilio
// ====================================================================

var ANY = (typeof H !== 'undefined' && H.ANY) ? H.ANY : (typeof ANY !== 'undefined' ? ANY : '*');

// ===== ACTIVE LIFECYCLES =====


bthread("Api.v2010.account.call.stream lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call.stream(x.id);
  updateApi.v2010.account.call.stream(x.id);
  updateApi.v2010.account.call.stream(x.id);
  verifyApi.v2010.account.call.streamExists(x.id);
  verifyApi.v2010.account.call.streamUpdated(x.id);
});

bthread("Api.v2010.account.authorized_connect_app lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.authorized_connect_app(x.id);
  updateApi.v2010.account.authorized_connect_app(x.id);
  updateApi.v2010.account.authorized_connect_app(x.id);
  verifyApi.v2010.account.authorized_connect_appExists(x.id);
  verifyApi.v2010.account.authorized_connect_appUpdated(x.id);
});

bthread("Message_enum_schedule_type lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessage_enum_schedule_type(x.id);
  updateMessage_enum_schedule_type(x.id);
  updateMessage_enum_schedule_type(x.id);
  verifyMessage_enum_schedule_typeExists(x.id);
  verifyMessage_enum_schedule_typeUpdated(x.id);
});

bthread("Realtime_transcription_enum_update_status lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealtime_transcription_enum_update_status(x.id);
  updateRealtime_transcription_enum_update_status(x.id);
  updateRealtime_transcription_enum_update_status(x.id);
  verifyRealtime_transcription_enum_update_statusExists(x.id);
  verifyRealtime_transcription_enum_update_statusUpdated(x.id);
});

bthread("Recording_enum_status lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRecording_enum_status(x.id);
  updateRecording_enum_status(x.id);
  updateRecording_enum_status(x.id);
  verifyRecording_enum_statusExists(x.id);
  verifyRecording_enum_statusUpdated(x.id);
});

bthread("Account_enum_type lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAccount_enum_type(x.id);
  updateAccount_enum_type(x.id);
  updateAccount_enum_type(x.id);
  verifyAccount_enum_typeExists(x.id);
  verifyAccount_enum_typeUpdated(x.id);
});

bthread("Incoming_phone_number_enum_voice_receive_mode lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_enum_voice_receive_mode(x.id);
  updateIncoming_phone_number_enum_voice_receive_mode(x.id);
  updateIncoming_phone_number_enum_voice_receive_mode(x.id);
  verifyIncoming_phone_number_enum_voice_receive_modeExists(x.id);
  verifyIncoming_phone_number_enum_voice_receive_modeUpdated(x.id);
});

bthread("Api.v2010.account.recording.recording_transcription lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.recording.recording_transcription(x.id);
  updateApi.v2010.account.recording.recording_transcription(x.id);
  updateApi.v2010.account.recording.recording_transcription(x.id);
  verifyApi.v2010.account.recording.recording_transcriptionExists(x.id);
  verifyApi.v2010.account.recording.recording_transcriptionUpdated(x.id);
});

bthread("Recording_add_on_result_enum_status lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRecording_add_on_result_enum_status(x.id);
  updateRecording_add_on_result_enum_status(x.id);
  updateRecording_add_on_result_enum_status(x.id);
  verifyRecording_add_on_result_enum_statusExists(x.id);
  verifyRecording_add_on_result_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account.notification-instance lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.notification-instance(x.id);
  updateApi.v2010.account.notification-instance(x.id);
  updateApi.v2010.account.notification-instance(x.id);
  verifyApi.v2010.account.notification-instanceExists(x.id);
  verifyApi.v2010.account.notification-instanceUpdated(x.id);
});

bthread("Api.v2010.account.usage.usage_record.usage_record_monthly lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage.usage_record.usage_record_monthly(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_monthly(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_monthly(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_monthlyExists(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_monthlyUpdated(x.id);
});

bthread("Api.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data(x.id);
  updateApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data(x.id);
  updateApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data(x.id);
  verifyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_dataExists(x.id);
  verifyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_dataUpdated(x.id);
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_local lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.available_phone_number_country.available_phone_number_local(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_local(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_local(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_localExists(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_localUpdated(x.id);
});

bthread("Incoming_phone_number_local_enum_emergency_status lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_local_enum_emergency_status(x.id);
  updateIncoming_phone_number_local_enum_emergency_status(x.id);
  updateIncoming_phone_number_local_enum_emergency_status(x.id);
  verifyIncoming_phone_number_local_enum_emergency_statusExists(x.id);
  verifyIncoming_phone_number_local_enum_emergency_statusUpdated(x.id);
});

bthread("Connect_app_enum_permission lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConnect_app_enum_permission(x.id);
  updateConnect_app_enum_permission(x.id);
  updateConnect_app_enum_permission(x.id);
  verifyConnect_app_enum_permissionExists(x.id);
  verifyConnect_app_enum_permissionUpdated(x.id);
});

bthread("Sms_feedback_enum_outcome lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSms_feedback_enum_outcome(x.id);
  updateSms_feedback_enum_outcome(x.id);
  updateSms_feedback_enum_outcome(x.id);
  verifySms_feedback_enum_outcomeExists(x.id);
  verifySms_feedback_enum_outcomeUpdated(x.id);
});

bthread("Message_feedback_enum_outcome lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessage_feedback_enum_outcome(x.id);
  updateMessage_feedback_enum_outcome(x.id);
  updateMessage_feedback_enum_outcome(x.id);
  verifyMessage_feedback_enum_outcomeExists(x.id);
  verifyMessage_feedback_enum_outcomeUpdated(x.id);
});

bthread("Api.v2010.account.recording lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.recording(x.id);
  updateApi.v2010.account.recording(x.id);
  updateApi.v2010.account.recording(x.id);
  verifyApi.v2010.account.recordingExists(x.id);
  verifyApi.v2010.account.recordingUpdated(x.id);
});

bthread("Stream_enum_update_status lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addStream_enum_update_status(x.id);
  updateStream_enum_update_status(x.id);
  updateStream_enum_update_status(x.id);
  verifyStream_enum_update_statusExists(x.id);
  verifyStream_enum_update_statusUpdated(x.id);
});

bthread("Sms_message_enum_direction lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSms_message_enum_direction(x.id);
  updateSms_message_enum_direction(x.id);
  updateSms_message_enum_direction(x.id);
  verifySms_message_enum_directionExists(x.id);
  verifySms_message_enum_directionUpdated(x.id);
});

bthread("Api.v2010.account.message.message_feedback lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.message.message_feedback(x.id);
  updateApi.v2010.account.message.message_feedback(x.id);
  updateApi.v2010.account.message.message_feedback(x.id);
  verifyApi.v2010.account.message.message_feedbackExists(x.id);
  verifyApi.v2010.account.message.message_feedbackUpdated(x.id);
});

bthread("Incoming_phone_number_toll_free_enum_emergency_status lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_toll_free_enum_emergency_status(x.id);
  updateIncoming_phone_number_toll_free_enum_emergency_status(x.id);
  updateIncoming_phone_number_toll_free_enum_emergency_status(x.id);
  verifyIncoming_phone_number_toll_free_enum_emergency_statusExists(x.id);
  verifyIncoming_phone_number_toll_free_enum_emergency_statusUpdated(x.id);
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machineExists(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machineUpdated(x.id);
});

bthread("Api.v2010.account.connect_app lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.connect_app(x.id);
  updateApi.v2010.account.connect_app(x.id);
  updateApi.v2010.account.connect_app(x.id);
  verifyApi.v2010.account.connect_appExists(x.id);
  verifyApi.v2010.account.connect_appUpdated(x.id);
});

bthread("Incoming_phone_number_enum_emergency_status lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_enum_emergency_status(x.id);
  updateIncoming_phone_number_enum_emergency_status(x.id);
  updateIncoming_phone_number_enum_emergency_status(x.id);
  verifyIncoming_phone_number_enum_emergency_statusExists(x.id);
  verifyIncoming_phone_number_enum_emergency_statusUpdated(x.id);
});

bthread("Call_recording_enum_status lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCall_recording_enum_status(x.id);
  updateCall_recording_enum_status(x.id);
  updateCall_recording_enum_status(x.id);
  verifyCall_recording_enum_statusExists(x.id);
  verifyCall_recording_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account.token lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.token(x.id);
  updateApi.v2010.account.token(x.id);
  updateApi.v2010.account.token(x.id);
  verifyApi.v2010.account.tokenExists(x.id);
  verifyApi.v2010.account.tokenUpdated(x.id);
});

bthread("Payments_enum_bank_account_type lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPayments_enum_bank_account_type(x.id);
  updatePayments_enum_bank_account_type(x.id);
  updatePayments_enum_bank_account_type(x.id);
  verifyPayments_enum_bank_account_typeExists(x.id);
  verifyPayments_enum_bank_account_typeUpdated(x.id);
});

bthread("Api.v2010.account.call.call_notification lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call.call_notification(x.id);
  updateApi.v2010.account.call.call_notification(x.id);
  updateApi.v2010.account.call.call_notification(x.id);
  verifyApi.v2010.account.call.call_notificationExists(x.id);
  verifyApi.v2010.account.call.call_notificationUpdated(x.id);
});

bthread("Conference_recording_enum_source lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConference_recording_enum_source(x.id);
  updateConference_recording_enum_source(x.id);
  updateConference_recording_enum_source(x.id);
  verifyConference_recording_enum_sourceExists(x.id);
  verifyConference_recording_enum_sourceUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mappingExists(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mappingUpdated(x.id);
});

bthread("Account_enum_status lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAccount_enum_status(x.id);
  updateAccount_enum_status(x.id);
  updateAccount_enum_status(x.id);
  verifyAccount_enum_statusExists(x.id);
  verifyAccount_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account.transcription lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.transcription(x.id);
  updateApi.v2010.account.transcription(x.id);
  updateApi.v2010.account.transcription(x.id);
  verifyApi.v2010.account.transcriptionExists(x.id);
  verifyApi.v2010.account.transcriptionUpdated(x.id);
});

bthread("Incoming_phone_number_local_enum_voice_receive_mode lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_local_enum_voice_receive_mode(x.id);
  updateIncoming_phone_number_local_enum_voice_receive_mode(x.id);
  updateIncoming_phone_number_local_enum_voice_receive_mode(x.id);
  verifyIncoming_phone_number_local_enum_voice_receive_modeExists(x.id);
  verifyIncoming_phone_number_local_enum_voice_receive_modeUpdated(x.id);
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_mobile lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.available_phone_number_country.available_phone_number_mobile(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_mobile(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_mobile(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_mobileExists(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_mobileUpdated(x.id);
});

bthread("Conference_recording_enum_status lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConference_recording_enum_status(x.id);
  updateConference_recording_enum_status(x.id);
  updateConference_recording_enum_status(x.id);
  verifyConference_recording_enum_statusExists(x.id);
  verifyConference_recording_enum_statusUpdated(x.id);
});

bthread("Message_enum_address_retention lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessage_enum_address_retention(x.id);
  updateMessage_enum_address_retention(x.id);
  updateMessage_enum_address_retention(x.id);
  verifyMessage_enum_address_retentionExists(x.id);
  verifyMessage_enum_address_retentionUpdated(x.id);
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_shared_cost lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.available_phone_number_country.available_phone_number_shared_cost(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_shared_cost(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_shared_cost(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_shared_costExists(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_shared_costUpdated(x.id);
});

bthread("Call_recording_enum_source lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCall_recording_enum_source(x.id);
  updateCall_recording_enum_source(x.id);
  updateCall_recording_enum_source(x.id);
  verifyCall_recording_enum_sourceExists(x.id);
  verifyCall_recording_enum_sourceUpdated(x.id);
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension(x.id);
  updateApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension(x.id);
  updateApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension(x.id);
  verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extensionExists(x.id);
  verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extensionUpdated(x.id);
});

bthread("Incoming_phone_number_local_enum_emergency_address_status lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_local_enum_emergency_address_status(x.id);
  updateIncoming_phone_number_local_enum_emergency_address_status(x.id);
  updateIncoming_phone_number_local_enum_emergency_address_status(x.id);
  verifyIncoming_phone_number_local_enum_emergency_address_statusExists(x.id);
  verifyIncoming_phone_number_local_enum_emergency_address_statusUpdated(x.id);
});

bthread("Api.v2010.account.call.user_defined_message_subscription lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call.user_defined_message_subscription(x.id);
  updateApi.v2010.account.call.user_defined_message_subscription(x.id);
  updateApi.v2010.account.call.user_defined_message_subscription(x.id);
  verifyApi.v2010.account.call.user_defined_message_subscriptionExists(x.id);
  verifyApi.v2010.account.call.user_defined_message_subscriptionUpdated(x.id);
});

bthread("Api.v2010.account.call.call_event lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call.call_event(x.id);
  updateApi.v2010.account.call.call_event(x.id);
  updateApi.v2010.account.call.call_event(x.id);
  verifyApi.v2010.account.call.call_eventExists(x.id);
  verifyApi.v2010.account.call.call_eventUpdated(x.id);
});

bthread("Realtime_transcription_enum_track lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealtime_transcription_enum_track(x.id);
  updateRealtime_transcription_enum_track(x.id);
  updateRealtime_transcription_enum_track(x.id);
  verifyRealtime_transcription_enum_trackExists(x.id);
  verifyRealtime_transcription_enum_trackUpdated(x.id);
});

bthread("Usage_trigger_enum_trigger_field lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUsage_trigger_enum_trigger_field(x.id);
  updateUsage_trigger_enum_trigger_field(x.id);
  updateUsage_trigger_enum_trigger_field(x.id);
  verifyUsage_trigger_enum_trigger_fieldExists(x.id);
  verifyUsage_trigger_enum_trigger_fieldUpdated(x.id);
});

bthread("Incoming_phone_number_toll_free_enum_emergency_address_status lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_toll_free_enum_emergency_address_status(x.id);
  updateIncoming_phone_number_toll_free_enum_emergency_address_status(x.id);
  updateIncoming_phone_number_toll_free_enum_emergency_address_status(x.id);
  verifyIncoming_phone_number_toll_free_enum_emergency_address_statusExists(x.id);
  verifyIncoming_phone_number_toll_free_enum_emergency_address_statusUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_credential_list lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_credential_list(x.id);
  updateApi.v2010.account.sip.sip_credential_list(x.id);
  updateApi.v2010.account.sip.sip_credential_list(x.id);
  verifyApi.v2010.account.sip.sip_credential_listExists(x.id);
  verifyApi.v2010.account.sip.sip_credential_listUpdated(x.id);
});

bthread("Message_enum_status lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessage_enum_status(x.id);
  updateMessage_enum_status(x.id);
  updateMessage_enum_status(x.id);
  verifyMessage_enum_statusExists(x.id);
  verifyMessage_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_mobile lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.incoming_phone_number.incoming_phone_number_mobile(x.id);
  updateApi.v2010.account.incoming_phone_number.incoming_phone_number_mobile(x.id);
  updateApi.v2010.account.incoming_phone_number.incoming_phone_number_mobile(x.id);
  verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_mobileExists(x.id);
  verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_mobileUpdated(x.id);
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on(x.id);
  updateApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on(x.id);
  updateApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on(x.id);
  verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_onExists(x.id);
  verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_onUpdated(x.id);
});

bthread("Api.v2010.account.usage.usage_record.usage_record_all_time lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage.usage_record.usage_record_all_time(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_all_time(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_all_time(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_all_timeExists(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_all_timeUpdated(x.id);
});

bthread("Incoming_phone_number_mobile_enum_emergency_address_status lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_mobile_enum_emergency_address_status(x.id);
  updateIncoming_phone_number_mobile_enum_emergency_address_status(x.id);
  updateIncoming_phone_number_mobile_enum_emergency_address_status(x.id);
  verifyIncoming_phone_number_mobile_enum_emergency_address_statusExists(x.id);
  verifyIncoming_phone_number_mobile_enum_emergency_address_statusUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mappingExists(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mappingUpdated(x.id);
});

bthread("Api.v2010.account.conference.conference_recording lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.conference.conference_recording(x.id);
  updateApi.v2010.account.conference.conference_recording(x.id);
  updateApi.v2010.account.conference.conference_recording(x.id);
  verifyApi.v2010.account.conference.conference_recordingExists(x.id);
  verifyApi.v2010.account.conference.conference_recordingUpdated(x.id);
});

bthread("Conference_enum_status lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConference_enum_status(x.id);
  updateConference_enum_status(x.id);
  updateConference_enum_status(x.id);
  verifyConference_enum_statusExists(x.id);
  verifyConference_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account.notification lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.notification(x.id);
  updateApi.v2010.account.notification(x.id);
  updateApi.v2010.account.notification(x.id);
  verifyApi.v2010.account.notificationExists(x.id);
  verifyApi.v2010.account.notificationUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mappingExists(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mappingUpdated(x.id);
});

bthread("Call_enum_update_status lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCall_enum_update_status(x.id);
  updateCall_enum_update_status(x.id);
  updateCall_enum_update_status(x.id);
  verifyCall_enum_update_statusExists(x.id);
  verifyCall_enum_update_statusUpdated(x.id);
});

bthread("Usage_trigger_enum_recurring lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUsage_trigger_enum_recurring(x.id);
  updateUsage_trigger_enum_recurring(x.id);
  updateUsage_trigger_enum_recurring(x.id);
  verifyUsage_trigger_enum_recurringExists(x.id);
  verifyUsage_trigger_enum_recurringUpdated(x.id);
});

bthread("Realtime_transcription_enum_status lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRealtime_transcription_enum_status(x.id);
  updateRealtime_transcription_enum_status(x.id);
  updateRealtime_transcription_enum_status(x.id);
  verifyRealtime_transcription_enum_statusExists(x.id);
  verifyRealtime_transcription_enum_statusUpdated(x.id);
});

bthread("Incoming_phone_number_mobile_enum_emergency_status lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_mobile_enum_emergency_status(x.id);
  updateIncoming_phone_number_mobile_enum_emergency_status(x.id);
  updateIncoming_phone_number_mobile_enum_emergency_status(x.id);
  verifyIncoming_phone_number_mobile_enum_emergency_statusExists(x.id);
  verifyIncoming_phone_number_mobile_enum_emergency_statusUpdated(x.id);
});

bthread("Api.v2010.account.conference.participant lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.conference.participant(x.id);
  updateApi.v2010.account.conference.participant(x.id);
  updateApi.v2010.account.conference.participant(x.id);
  verifyApi.v2010.account.conference.participantExists(x.id);
  verifyApi.v2010.account.conference.participantUpdated(x.id);
});

bthread("Api.v2010.account.recording.recording_add_on_result lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.recording.recording_add_on_result(x.id);
  updateApi.v2010.account.recording.recording_add_on_result(x.id);
  updateApi.v2010.account.recording.recording_add_on_result(x.id);
  verifyApi.v2010.account.recording.recording_add_on_resultExists(x.id);
  verifyApi.v2010.account.recording.recording_add_on_resultUpdated(x.id);
});

bthread("Api.v2010.account.conference lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.conference(x.id);
  updateApi.v2010.account.conference(x.id);
  updateApi.v2010.account.conference(x.id);
  verifyApi.v2010.account.conferenceExists(x.id);
  verifyApi.v2010.account.conferenceUpdated(x.id);
});

bthread("Api.v2010.account.usage.usage_record.usage_record_yearly lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage.usage_record.usage_record_yearly(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_yearly(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_yearly(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_yearlyExists(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_yearlyUpdated(x.id);
});

bthread("Recording_transcription_enum_status lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRecording_transcription_enum_status(x.id);
  updateRecording_transcription_enum_status(x.id);
  updateRecording_transcription_enum_status(x.id);
  verifyRecording_transcription_enum_statusExists(x.id);
  verifyRecording_transcription_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_domain.sip_credential_list_mapping lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_domain.sip_credential_list_mapping(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_credential_list_mapping(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_credential_list_mapping(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_credential_list_mappingExists(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_credential_list_mappingUpdated(x.id);
});

bthread("Api.v2010.account.balance lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.balance(x.id);
  updateApi.v2010.account.balance(x.id);
  updateApi.v2010.account.balance(x.id);
  verifyApi.v2010.account.balanceExists(x.id);
  verifyApi.v2010.account.balanceUpdated(x.id);
});

bthread("Authorized_connect_app_enum_permission lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addAuthorized_connect_app_enum_permission(x.id);
  updateAuthorized_connect_app_enum_permission(x.id);
  updateAuthorized_connect_app_enum_permission(x.id);
  verifyAuthorized_connect_app_enum_permissionExists(x.id);
  verifyAuthorized_connect_app_enum_permissionUpdated(x.id);
});

bthread("Conference_enum_update_status lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConference_enum_update_status(x.id);
  updateConference_enum_update_status(x.id);
  updateConference_enum_update_status(x.id);
  verifyConference_enum_update_statusExists(x.id);
  verifyConference_enum_update_statusUpdated(x.id);
});

bthread("Api.v2010.account.usage.usage_record.usage_record_last_month lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage.usage_record.usage_record_last_month(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_last_month(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_last_month(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_last_monthExists(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_last_monthUpdated(x.id);
});

bthread("Api.v2010.account.new_signing_key lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.new_signing_key(x.id);
  updateApi.v2010.account.new_signing_key(x.id);
  updateApi.v2010.account.new_signing_key(x.id);
  verifyApi.v2010.account.new_signing_keyExists(x.id);
  verifyApi.v2010.account.new_signing_keyUpdated(x.id);
});

bthread("Api.v2010.account.key lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.key(x.id);
  updateApi.v2010.account.key(x.id);
  updateApi.v2010.account.key(x.id);
  verifyApi.v2010.account.keyExists(x.id);
  verifyApi.v2010.account.keyUpdated(x.id);
});

bthread("Dependent_phone_number_enum_emergency_status lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDependent_phone_number_enum_emergency_status(x.id);
  updateDependent_phone_number_enum_emergency_status(x.id);
  updateDependent_phone_number_enum_emergency_status(x.id);
  verifyDependent_phone_number_enum_emergency_statusExists(x.id);
  verifyDependent_phone_number_enum_emergency_statusUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_domain.sip_auth(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_authExists(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_authUpdated(x.id);
});

bthread("Message_enum_content_retention lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessage_enum_content_retention(x.id);
  updateMessage_enum_content_retention(x.id);
  updateMessage_enum_content_retention(x.id);
  verifyMessage_enum_content_retentionExists(x.id);
  verifyMessage_enum_content_retentionUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrationsExists(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrationsUpdated(x.id);
});

bthread("Api.v2010.account.usage.usage_record.usage_record_this_month lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage.usage_record.usage_record_this_month(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_this_month(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_this_month(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_this_monthExists(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_this_monthUpdated(x.id);
});

bthread("Call_enum_status lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCall_enum_status(x.id);
  updateCall_enum_status(x.id);
  updateCall_enum_status(x.id);
  verifyCall_enum_statusExists(x.id);
  verifyCall_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_callsExists(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_callsUpdated(x.id);
});

bthread("Message_enum_risk_check lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessage_enum_risk_check(x.id);
  updateMessage_enum_risk_check(x.id);
  updateMessage_enum_risk_check(x.id);
  verifyMessage_enum_risk_checkExists(x.id);
  verifyMessage_enum_risk_checkUpdated(x.id);
});

bthread("Api.v2010.account.message.media lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.message.media(x.id);
  updateApi.v2010.account.message.media(x.id);
  updateApi.v2010.account.message.media(x.id);
  verifyApi.v2010.account.message.mediaExists(x.id);
  verifyApi.v2010.account.message.mediaUpdated(x.id);
});

bthread("Api.v2010.account.outgoing_caller_id lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.outgoing_caller_id(x.id);
  updateApi.v2010.account.outgoing_caller_id(x.id);
  updateApi.v2010.account.outgoing_caller_id(x.id);
  verifyApi.v2010.account.outgoing_caller_idExists(x.id);
  verifyApi.v2010.account.outgoing_caller_idUpdated(x.id);
});

bthread("Api.v2010.account.usage.usage_trigger lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage.usage_trigger(x.id);
  updateApi.v2010.account.usage.usage_trigger(x.id);
  updateApi.v2010.account.usage.usage_trigger(x.id);
  verifyApi.v2010.account.usage.usage_triggerExists(x.id);
  verifyApi.v2010.account.usage.usage_triggerUpdated(x.id);
});

bthread("Dependent_phone_number_enum_address_requirement lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDependent_phone_number_enum_address_requirement(x.id);
  updateDependent_phone_number_enum_address_requirement(x.id);
  updateDependent_phone_number_enum_address_requirement(x.id);
  verifyDependent_phone_number_enum_address_requirementExists(x.id);
  verifyDependent_phone_number_enum_address_requirementUpdated(x.id);
});

bthread("Incoming_phone_number_mobile_enum_voice_receive_mode lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_mobile_enum_voice_receive_mode(x.id);
  updateIncoming_phone_number_mobile_enum_voice_receive_mode(x.id);
  updateIncoming_phone_number_mobile_enum_voice_receive_mode(x.id);
  verifyIncoming_phone_number_mobile_enum_voice_receive_modeExists(x.id);
  verifyIncoming_phone_number_mobile_enum_voice_receive_modeUpdated(x.id);
});

bthread("Api.v2010.account.signing_key lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.signing_key(x.id);
  updateApi.v2010.account.signing_key(x.id);
  updateApi.v2010.account.signing_key(x.id);
  verifyApi.v2010.account.signing_keyExists(x.id);
  verifyApi.v2010.account.signing_keyUpdated(x.id);
});

bthread("Api.v2010.account.usage lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage(x.id);
  updateApi.v2010.account.usage(x.id);
  updateApi.v2010.account.usage(x.id);
  verifyApi.v2010.account.usageExists(x.id);
  verifyApi.v2010.account.usageUpdated(x.id);
});

bthread("Api.v2010.account.address lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.address(x.id);
  updateApi.v2010.account.address(x.id);
  updateApi.v2010.account.address(x.id);
  verifyApi.v2010.account.addressExists(x.id);
  verifyApi.v2010.account.addressUpdated(x.id);
});

bthread("Incoming_phone_number_enum_emergency_address_status lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_enum_emergency_address_status(x.id);
  updateIncoming_phone_number_enum_emergency_address_status(x.id);
  updateIncoming_phone_number_enum_emergency_address_status(x.id);
  verifyIncoming_phone_number_enum_emergency_address_statusExists(x.id);
  verifyIncoming_phone_number_enum_emergency_address_statusUpdated(x.id);
});

bthread("Api.v2010.account.call.payments lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call.payments(x.id);
  updateApi.v2010.account.call.payments(x.id);
  updateApi.v2010.account.call.payments(x.id);
  verifyApi.v2010.account.call.paymentsExists(x.id);
  verifyApi.v2010.account.call.paymentsUpdated(x.id);
});

bthread("Message_enum_traffic_type lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessage_enum_traffic_type(x.id);
  updateMessage_enum_traffic_type(x.id);
  updateMessage_enum_traffic_type(x.id);
  verifyMessage_enum_traffic_typeExists(x.id);
  verifyMessage_enum_traffic_typeUpdated(x.id);
});

bthread("Api.v2010.account.short_code lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.short_code(x.id);
  updateApi.v2010.account.short_code(x.id);
  updateApi.v2010.account.short_code(x.id);
  verifyApi.v2010.account.short_codeExists(x.id);
  verifyApi.v2010.account.short_codeUpdated(x.id);
});

bthread("Stream_enum_track lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addStream_enum_track(x.id);
  updateStream_enum_track(x.id);
  updateStream_enum_track(x.id);
  verifyStream_enum_trackExists(x.id);
  verifyStream_enum_trackUpdated(x.id);
});

bthread("Payments_enum_payment_method lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPayments_enum_payment_method(x.id);
  updatePayments_enum_payment_method(x.id);
  updatePayments_enum_payment_method(x.id);
  verifyPayments_enum_payment_methodExists(x.id);
  verifyPayments_enum_payment_methodUpdated(x.id);
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_toll_free lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.available_phone_number_country.available_phone_number_toll_free(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_toll_free(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_toll_free(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_toll_freeExists(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_toll_freeUpdated(x.id);
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_toll_free lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_free(x.id);
  updateApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_free(x.id);
  updateApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_free(x.id);
  verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_freeExists(x.id);
  verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_freeUpdated(x.id);
});

bthread("Payments_enum_capture lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPayments_enum_capture(x.id);
  updatePayments_enum_capture(x.id);
  updatePayments_enum_capture(x.id);
  verifyPayments_enum_captureExists(x.id);
  verifyPayments_enum_captureUpdated(x.id);
});

bthread("Api.v2010.account.validation_request lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.validation_request(x.id);
  updateApi.v2010.account.validation_request(x.id);
  updateApi.v2010.account.validation_request(x.id);
  verifyApi.v2010.account.validation_requestExists(x.id);
  verifyApi.v2010.account.validation_requestUpdated(x.id);
});

bthread("Call_enum_event lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCall_enum_event(x.id);
  updateCall_enum_event(x.id);
  updateCall_enum_event(x.id);
  verifyCall_enum_eventExists(x.id);
  verifyCall_enum_eventUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_domain lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_domain(x.id);
  updateApi.v2010.account.sip.sip_domain(x.id);
  updateApi.v2010.account.sip.sip_domain(x.id);
  verifyApi.v2010.account.sip.sip_domainExists(x.id);
  verifyApi.v2010.account.sip.sip_domainUpdated(x.id);
});

bthread("Api.v2010.account.call.user_defined_message lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call.user_defined_message(x.id);
  updateApi.v2010.account.call.user_defined_message(x.id);
  updateApi.v2010.account.call.user_defined_message(x.id);
  verifyApi.v2010.account.call.user_defined_messageExists(x.id);
  verifyApi.v2010.account.call.user_defined_messageUpdated(x.id);
});

bthread("Message_enum_direction lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessage_enum_direction(x.id);
  updateMessage_enum_direction(x.id);
  updateMessage_enum_direction(x.id);
  verifyMessage_enum_directionExists(x.id);
  verifyMessage_enum_directionUpdated(x.id);
});

bthread("Incoming_phone_number_local_enum_address_requirement lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_local_enum_address_requirement(x.id);
  updateIncoming_phone_number_local_enum_address_requirement(x.id);
  updateIncoming_phone_number_local_enum_address_requirement(x.id);
  verifyIncoming_phone_number_local_enum_address_requirementExists(x.id);
  verifyIncoming_phone_number_local_enum_address_requirementUpdated(x.id);
});

bthread("Api.v2010.account.usage.usage_record.usage_record_today lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage.usage_record.usage_record_today(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_today(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_today(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_todayExists(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_todayUpdated(x.id);
});

bthread("Conference_enum_reason_conference_ended lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addConference_enum_reason_conference_ended(x.id);
  updateConference_enum_reason_conference_ended(x.id);
  updateConference_enum_reason_conference_ended(x.id);
  verifyConference_enum_reason_conference_endedExists(x.id);
  verifyConference_enum_reason_conference_endedUpdated(x.id);
});

bthread("Incoming_phone_number_toll_free_enum_address_requirement lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_toll_free_enum_address_requirement(x.id);
  updateIncoming_phone_number_toll_free_enum_address_requirement(x.id);
  updateIncoming_phone_number_toll_free_enum_address_requirement(x.id);
  verifyIncoming_phone_number_toll_free_enum_address_requirementExists(x.id);
  verifyIncoming_phone_number_toll_free_enum_address_requirementUpdated(x.id);
});

bthread("Api.v2010.account.call.realtime_transcription lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call.realtime_transcription(x.id);
  updateApi.v2010.account.call.realtime_transcription(x.id);
  updateApi.v2010.account.call.realtime_transcription(x.id);
  verifyApi.v2010.account.call.realtime_transcriptionExists(x.id);
  verifyApi.v2010.account.call.realtime_transcriptionUpdated(x.id);
});

bthread("Message_enum_update_status lifecycle", function () {
  const x = pick([{id: "M001"}, {id: "M002"}]);
  addMessage_enum_update_status(x.id);
  updateMessage_enum_update_status(x.id);
  updateMessage_enum_update_status(x.id);
  verifyMessage_enum_update_statusExists(x.id);
  verifyMessage_enum_update_statusUpdated(x.id);
});

bthread("Api.v2010.account.incoming_phone_number lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.incoming_phone_number(x.id);
  updateApi.v2010.account.incoming_phone_number(x.id);
  updateApi.v2010.account.incoming_phone_number(x.id);
  verifyApi.v2010.account.incoming_phone_numberExists(x.id);
  verifyApi.v2010.account.incoming_phone_numberUpdated(x.id);
});

bthread("Api.v2010.account.call.call_notification-instance lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call.call_notification-instance(x.id);
  updateApi.v2010.account.call.call_notification-instance(x.id);
  updateApi.v2010.account.call.call_notification-instance(x.id);
  verifyApi.v2010.account.call.call_notification-instanceExists(x.id);
  verifyApi.v2010.account.call.call_notification-instanceUpdated(x.id);
});

bthread("Api.v2010.account.call.call_recording lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call.call_recording(x.id);
  updateApi.v2010.account.call.call_recording(x.id);
  updateApi.v2010.account.call.call_recording(x.id);
  verifyApi.v2010.account.call.call_recordingExists(x.id);
  verifyApi.v2010.account.call.call_recordingUpdated(x.id);
});

bthread("Api.v2010.account.sip lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip(x.id);
  updateApi.v2010.account.sip(x.id);
  updateApi.v2010.account.sip(x.id);
  verifyApi.v2010.account.sipExists(x.id);
  verifyApi.v2010.account.sipUpdated(x.id);
});

bthread("Api.v2010.account.message lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.message(x.id);
  updateApi.v2010.account.message(x.id);
  updateApi.v2010.account.message(x.id);
  verifyApi.v2010.account.messageExists(x.id);
  verifyApi.v2010.account.messageUpdated(x.id);
});

bthread("Incoming_phone_number_enum_address_requirement lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_enum_address_requirement(x.id);
  updateIncoming_phone_number_enum_address_requirement(x.id);
  updateIncoming_phone_number_enum_address_requirement(x.id);
  verifyIncoming_phone_number_enum_address_requirementExists(x.id);
  verifyIncoming_phone_number_enum_address_requirementUpdated(x.id);
});

bthread("Api.v2010.account.queue.member lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.queue.member(x.id);
  updateApi.v2010.account.queue.member(x.id);
  updateApi.v2010.account.queue.member(x.id);
  verifyApi.v2010.account.queue.memberExists(x.id);
  verifyApi.v2010.account.queue.memberUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_credential_list.sip_credential lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_credential_list.sip_credential(x.id);
  updateApi.v2010.account.sip.sip_credential_list.sip_credential(x.id);
  updateApi.v2010.account.sip.sip_credential_list.sip_credential(x.id);
  verifyApi.v2010.account.sip.sip_credential_list.sip_credentialExists(x.id);
  verifyApi.v2010.account.sip.sip_credential_list.sip_credentialUpdated(x.id);
});

bthread("Participant_enum_status lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addParticipant_enum_status(x.id);
  updateParticipant_enum_status(x.id);
  updateParticipant_enum_status(x.id);
  verifyParticipant_enum_statusExists(x.id);
  verifyParticipant_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account.queue lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.queue(x.id);
  updateApi.v2010.account.queue(x.id);
  updateApi.v2010.account.queue(x.id);
  verifyApi.v2010.account.queueExists(x.id);
  verifyApi.v2010.account.queueUpdated(x.id);
});

bthread("Api.v2010.account.available_phone_number_country lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.available_phone_number_country(x.id);
  updateApi.v2010.account.available_phone_number_country(x.id);
  updateApi.v2010.account.available_phone_number_country(x.id);
  verifyApi.v2010.account.available_phone_number_countryExists(x.id);
  verifyApi.v2010.account.available_phone_number_countryUpdated(x.id);
});

bthread("Siprec_enum_status lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSiprec_enum_status(x.id);
  updateSiprec_enum_status(x.id);
  updateSiprec_enum_status(x.id);
  verifySiprec_enum_statusExists(x.id);
  verifySiprec_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account.address.dependent_phone_number lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.address.dependent_phone_number(x.id);
  updateApi.v2010.account.address.dependent_phone_number(x.id);
  updateApi.v2010.account.address.dependent_phone_number(x.id);
  verifyApi.v2010.account.address.dependent_phone_numberExists(x.id);
  verifyApi.v2010.account.address.dependent_phone_numberUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping(x.id);
  updateApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mappingExists(x.id);
  verifyApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mappingUpdated(x.id);
});

bthread("Api.v2010.account.usage.usage_record.usage_record_yesterday lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage.usage_record.usage_record_yesterday(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_yesterday(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_yesterday(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_yesterdayExists(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_yesterdayUpdated(x.id);
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_voip lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.available_phone_number_country.available_phone_number_voip(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_voip(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_voip(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_voipExists(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_voipUpdated(x.id);
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_national lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.available_phone_number_country.available_phone_number_national(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_national(x.id);
  updateApi.v2010.account.available_phone_number_country.available_phone_number_national(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_nationalExists(x.id);
  verifyApi.v2010.account.available_phone_number_country.available_phone_number_nationalUpdated(x.id);
});

bthread("Sms_message_enum_status lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSms_message_enum_status(x.id);
  updateSms_message_enum_status(x.id);
  updateSms_message_enum_status(x.id);
  verifySms_message_enum_statusExists(x.id);
  verifySms_message_enum_statusUpdated(x.id);
});

bthread("Stream_enum_status lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addStream_enum_status(x.id);
  updateStream_enum_status(x.id);
  updateStream_enum_status(x.id);
  verifyStream_enum_statusExists(x.id);
  verifyStream_enum_statusUpdated(x.id);
});

bthread("Recording_enum_source lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRecording_enum_source(x.id);
  updateRecording_enum_source(x.id);
  updateRecording_enum_source(x.id);
  verifyRecording_enum_sourceExists(x.id);
  verifyRecording_enum_sourceUpdated(x.id);
});

bthread("Payments_enum_status lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPayments_enum_status(x.id);
  updatePayments_enum_status(x.id);
  updatePayments_enum_status(x.id);
  verifyPayments_enum_statusExists(x.id);
  verifyPayments_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_ip_access_control_list lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_ip_access_control_list(x.id);
  updateApi.v2010.account.sip.sip_ip_access_control_list(x.id);
  updateApi.v2010.account.sip.sip_ip_access_control_list(x.id);
  verifyApi.v2010.account.sip.sip_ip_access_control_listExists(x.id);
  verifyApi.v2010.account.sip.sip_ip_access_control_listUpdated(x.id);
});

bthread("Siprec_enum_track lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSiprec_enum_track(x.id);
  updateSiprec_enum_track(x.id);
  updateSiprec_enum_track(x.id);
  verifySiprec_enum_trackExists(x.id);
  verifySiprec_enum_trackUpdated(x.id);
});

bthread("Payments_enum_token_type lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPayments_enum_token_type(x.id);
  updatePayments_enum_token_type(x.id);
  updatePayments_enum_token_type(x.id);
  verifyPayments_enum_token_typeExists(x.id);
  verifyPayments_enum_token_typeUpdated(x.id);
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_local lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.incoming_phone_number.incoming_phone_number_local(x.id);
  updateApi.v2010.account.incoming_phone_number.incoming_phone_number_local(x.id);
  updateApi.v2010.account.incoming_phone_number.incoming_phone_number_local(x.id);
  verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_localExists(x.id);
  verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_localUpdated(x.id);
});

bthread("Siprec_enum_update_status lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSiprec_enum_update_status(x.id);
  updateSiprec_enum_update_status(x.id);
  updateSiprec_enum_update_status(x.id);
  verifySiprec_enum_update_statusExists(x.id);
  verifySiprec_enum_update_statusUpdated(x.id);
});

bthread("Api.v2010.account.application lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.application(x.id);
  updateApi.v2010.account.application(x.id);
  updateApi.v2010.account.application(x.id);
  verifyApi.v2010.account.applicationExists(x.id);
  verifyApi.v2010.account.applicationUpdated(x.id);
});

bthread("Api.v2010.account.usage.usage_record lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage.usage_record(x.id);
  updateApi.v2010.account.usage.usage_record(x.id);
  updateApi.v2010.account.usage.usage_record(x.id);
  verifyApi.v2010.account.usage.usage_recordExists(x.id);
  verifyApi.v2010.account.usage.usage_recordUpdated(x.id);
});

bthread("Transcription_enum_status lifecycle", function () {
  const x = pick([{id: "T001"}, {id: "T002"}]);
  addTranscription_enum_status(x.id);
  updateTranscription_enum_status(x.id);
  updateTranscription_enum_status(x.id);
  verifyTranscription_enum_statusExists(x.id);
  verifyTranscription_enum_statusUpdated(x.id);
});

bthread("Api.v2010.account lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account(x.id);
  updateApi.v2010.account(x.id);
  updateApi.v2010.account(x.id);
  verifyApi.v2010.accountExists(x.id);
  verifyApi.v2010.accountUpdated(x.id);
});

bthread("Incoming_phone_number_toll_free_enum_voice_receive_mode lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_toll_free_enum_voice_receive_mode(x.id);
  updateIncoming_phone_number_toll_free_enum_voice_receive_mode(x.id);
  updateIncoming_phone_number_toll_free_enum_voice_receive_mode(x.id);
  verifyIncoming_phone_number_toll_free_enum_voice_receive_modeExists(x.id);
  verifyIncoming_phone_number_toll_free_enum_voice_receive_modeUpdated(x.id);
});

bthread("Api.v2010.account.call lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call(x.id);
  updateApi.v2010.account.call(x.id);
  updateApi.v2010.account.call(x.id);
  verifyApi.v2010.account.callExists(x.id);
  verifyApi.v2010.account.callUpdated(x.id);
});

bthread("Incoming_phone_number_mobile_enum_address_requirement lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addIncoming_phone_number_mobile_enum_address_requirement(x.id);
  updateIncoming_phone_number_mobile_enum_address_requirement(x.id);
  updateIncoming_phone_number_mobile_enum_address_requirement(x.id);
  verifyIncoming_phone_number_mobile_enum_address_requirementExists(x.id);
  verifyIncoming_phone_number_mobile_enum_address_requirementUpdated(x.id);
});

bthread("Api.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload(x.id);
  updateApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload(x.id);
  updateApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload(x.id);
  verifyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payloadExists(x.id);
  verifyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payloadUpdated(x.id);
});

bthread("Api.v2010.account.new_key lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.new_key(x.id);
  updateApi.v2010.account.new_key(x.id);
  updateApi.v2010.account.new_key(x.id);
  verifyApi.v2010.account.new_keyExists(x.id);
  verifyApi.v2010.account.new_keyUpdated(x.id);
});

bthread("Api.v2010.account.usage.usage_record.usage_record_daily lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.usage.usage_record.usage_record_daily(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_daily(x.id);
  updateApi.v2010.account.usage.usage_record.usage_record_daily(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_dailyExists(x.id);
  verifyApi.v2010.account.usage.usage_record.usage_record_dailyUpdated(x.id);
});

bthread("Api.v2010.account.sip.sip_ip_access_control_list.sip_ip_address lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_address(x.id);
  updateApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_address(x.id);
  updateApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_address(x.id);
  verifyApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_addressExists(x.id);
  verifyApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_addressUpdated(x.id);
});

bthread("Api.v2010.account.call.siprec lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addApi.v2010.account.call.siprec(x.id);
  updateApi.v2010.account.call.siprec(x.id);
  updateApi.v2010.account.call.siprec(x.id);
  verifyApi.v2010.account.call.siprecExists(x.id);
  verifyApi.v2010.account.call.siprecUpdated(x.id);
});

// ===== PASSIVE ASSERTIONS =====

bthread("Api.v2010.account.call.stream create verification", function () {
  const e = waitForAnyApi.v2010.account.call.streamAdded();
  block(matchDeleteApi.v2010.account.call.stream(e.id, ANY), function () {
    verifyApi.v2010.account.call.streamExists(e.id);
  });
});

bthread("Api.v2010.account.call.stream update verification", function () {
  const e = waitForAnyApi.v2010.account.call.streamUpdated();
  block(matchDeleteApi.v2010.account.call.stream(e.id, ANY), function () {
    verifyApi.v2010.account.call.streamUpdated(e.id);
  });
});

bthread("Api.v2010.account.call.stream delete verification", function () {
  const e = waitForAnyApi.v2010.account.call.streamDeleted();
  block(matchAddApi.v2010.account.call.stream(e.id, ANY), function () {
    verifyApi.v2010.account.call.streamDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.authorized_connect_app create verification", function () {
  const e = waitForAnyApi.v2010.account.authorized_connect_appAdded();
  block(matchDeleteApi.v2010.account.authorized_connect_app(e.id, ANY), function () {
    verifyApi.v2010.account.authorized_connect_appExists(e.id);
  });
});

bthread("Api.v2010.account.authorized_connect_app update verification", function () {
  const e = waitForAnyApi.v2010.account.authorized_connect_appUpdated();
  block(matchDeleteApi.v2010.account.authorized_connect_app(e.id, ANY), function () {
    verifyApi.v2010.account.authorized_connect_appUpdated(e.id);
  });
});

bthread("Api.v2010.account.authorized_connect_app delete verification", function () {
  const e = waitForAnyApi.v2010.account.authorized_connect_appDeleted();
  block(matchAddApi.v2010.account.authorized_connect_app(e.id, ANY), function () {
    verifyApi.v2010.account.authorized_connect_appDoesNotExist(e.id);
  });
});

bthread("Message_enum_schedule_type create verification", function () {
  const e = waitForAnyMessage_enum_schedule_typeAdded();
  block(matchDeleteMessage_enum_schedule_type(e.id, ANY), function () {
    verifyMessage_enum_schedule_typeExists(e.id);
  });
});

bthread("Message_enum_schedule_type update verification", function () {
  const e = waitForAnyMessage_enum_schedule_typeUpdated();
  block(matchDeleteMessage_enum_schedule_type(e.id, ANY), function () {
    verifyMessage_enum_schedule_typeUpdated(e.id);
  });
});

bthread("Message_enum_schedule_type delete verification", function () {
  const e = waitForAnyMessage_enum_schedule_typeDeleted();
  block(matchAddMessage_enum_schedule_type(e.id, ANY), function () {
    verifyMessage_enum_schedule_typeDoesNotExist(e.id);
  });
});

bthread("Realtime_transcription_enum_update_status create verification", function () {
  const e = waitForAnyRealtime_transcription_enum_update_statusAdded();
  block(matchDeleteRealtime_transcription_enum_update_status(e.id, ANY), function () {
    verifyRealtime_transcription_enum_update_statusExists(e.id);
  });
});

bthread("Realtime_transcription_enum_update_status update verification", function () {
  const e = waitForAnyRealtime_transcription_enum_update_statusUpdated();
  block(matchDeleteRealtime_transcription_enum_update_status(e.id, ANY), function () {
    verifyRealtime_transcription_enum_update_statusUpdated(e.id);
  });
});

bthread("Realtime_transcription_enum_update_status delete verification", function () {
  const e = waitForAnyRealtime_transcription_enum_update_statusDeleted();
  block(matchAddRealtime_transcription_enum_update_status(e.id, ANY), function () {
    verifyRealtime_transcription_enum_update_statusDoesNotExist(e.id);
  });
});

bthread("Recording_enum_status create verification", function () {
  const e = waitForAnyRecording_enum_statusAdded();
  block(matchDeleteRecording_enum_status(e.id, ANY), function () {
    verifyRecording_enum_statusExists(e.id);
  });
});

bthread("Recording_enum_status update verification", function () {
  const e = waitForAnyRecording_enum_statusUpdated();
  block(matchDeleteRecording_enum_status(e.id, ANY), function () {
    verifyRecording_enum_statusUpdated(e.id);
  });
});

bthread("Recording_enum_status delete verification", function () {
  const e = waitForAnyRecording_enum_statusDeleted();
  block(matchAddRecording_enum_status(e.id, ANY), function () {
    verifyRecording_enum_statusDoesNotExist(e.id);
  });
});

bthread("Account_enum_type create verification", function () {
  const e = waitForAnyAccount_enum_typeAdded();
  block(matchDeleteAccount_enum_type(e.id, ANY), function () {
    verifyAccount_enum_typeExists(e.id);
  });
});

bthread("Account_enum_type update verification", function () {
  const e = waitForAnyAccount_enum_typeUpdated();
  block(matchDeleteAccount_enum_type(e.id, ANY), function () {
    verifyAccount_enum_typeUpdated(e.id);
  });
});

bthread("Account_enum_type delete verification", function () {
  const e = waitForAnyAccount_enum_typeDeleted();
  block(matchAddAccount_enum_type(e.id, ANY), function () {
    verifyAccount_enum_typeDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_enum_voice_receive_mode create verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_voice_receive_modeAdded();
  block(matchDeleteIncoming_phone_number_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_voice_receive_modeExists(e.id);
  });
});

bthread("Incoming_phone_number_enum_voice_receive_mode update verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_voice_receive_modeUpdated();
  block(matchDeleteIncoming_phone_number_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_voice_receive_modeUpdated(e.id);
  });
});

bthread("Incoming_phone_number_enum_voice_receive_mode delete verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_voice_receive_modeDeleted();
  block(matchAddIncoming_phone_number_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_voice_receive_modeDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_transcription create verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_transcriptionAdded();
  block(matchDeleteApi.v2010.account.recording.recording_transcription(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_transcriptionExists(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_transcription update verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_transcriptionUpdated();
  block(matchDeleteApi.v2010.account.recording.recording_transcription(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_transcriptionUpdated(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_transcription delete verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_transcriptionDeleted();
  block(matchAddApi.v2010.account.recording.recording_transcription(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_transcriptionDoesNotExist(e.id);
  });
});

bthread("Recording_add_on_result_enum_status create verification", function () {
  const e = waitForAnyRecording_add_on_result_enum_statusAdded();
  block(matchDeleteRecording_add_on_result_enum_status(e.id, ANY), function () {
    verifyRecording_add_on_result_enum_statusExists(e.id);
  });
});

bthread("Recording_add_on_result_enum_status update verification", function () {
  const e = waitForAnyRecording_add_on_result_enum_statusUpdated();
  block(matchDeleteRecording_add_on_result_enum_status(e.id, ANY), function () {
    verifyRecording_add_on_result_enum_statusUpdated(e.id);
  });
});

bthread("Recording_add_on_result_enum_status delete verification", function () {
  const e = waitForAnyRecording_add_on_result_enum_statusDeleted();
  block(matchAddRecording_add_on_result_enum_status(e.id, ANY), function () {
    verifyRecording_add_on_result_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.notification-instance create verification", function () {
  const e = waitForAnyApi.v2010.account.notification-instanceAdded();
  block(matchDeleteApi.v2010.account.notification-instance(e.id, ANY), function () {
    verifyApi.v2010.account.notification-instanceExists(e.id);
  });
});

bthread("Api.v2010.account.notification-instance update verification", function () {
  const e = waitForAnyApi.v2010.account.notification-instanceUpdated();
  block(matchDeleteApi.v2010.account.notification-instance(e.id, ANY), function () {
    verifyApi.v2010.account.notification-instanceUpdated(e.id);
  });
});

bthread("Api.v2010.account.notification-instance delete verification", function () {
  const e = waitForAnyApi.v2010.account.notification-instanceDeleted();
  block(matchAddApi.v2010.account.notification-instance(e.id, ANY), function () {
    verifyApi.v2010.account.notification-instanceDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_monthly create verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_monthlyAdded();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_monthly(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_monthlyExists(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_monthly update verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_monthlyUpdated();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_monthly(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_monthlyUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_monthly delete verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_monthlyDeleted();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_monthly(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_monthlyDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data create verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_dataAdded();
  block(matchDeleteApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_dataExists(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data update verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_dataUpdated();
  block(matchDeleteApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_dataUpdated(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data delete verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_dataDeleted();
  block(matchAddApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_dataDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_local create verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_localAdded();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_local(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_localExists(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_local update verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_localUpdated();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_local(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_localUpdated(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_local delete verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_localDeleted();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_local(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_localDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_emergency_status create verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_emergency_statusAdded();
  block(matchDeleteIncoming_phone_number_local_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_emergency_statusExists(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_emergency_status update verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_emergency_statusUpdated();
  block(matchDeleteIncoming_phone_number_local_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_emergency_statusUpdated(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_emergency_status delete verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_emergency_statusDeleted();
  block(matchAddIncoming_phone_number_local_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_emergency_statusDoesNotExist(e.id);
  });
});

bthread("Connect_app_enum_permission create verification", function () {
  const e = waitForAnyConnect_app_enum_permissionAdded();
  block(matchDeleteConnect_app_enum_permission(e.id, ANY), function () {
    verifyConnect_app_enum_permissionExists(e.id);
  });
});

bthread("Connect_app_enum_permission update verification", function () {
  const e = waitForAnyConnect_app_enum_permissionUpdated();
  block(matchDeleteConnect_app_enum_permission(e.id, ANY), function () {
    verifyConnect_app_enum_permissionUpdated(e.id);
  });
});

bthread("Connect_app_enum_permission delete verification", function () {
  const e = waitForAnyConnect_app_enum_permissionDeleted();
  block(matchAddConnect_app_enum_permission(e.id, ANY), function () {
    verifyConnect_app_enum_permissionDoesNotExist(e.id);
  });
});

bthread("Sms_feedback_enum_outcome create verification", function () {
  const e = waitForAnySms_feedback_enum_outcomeAdded();
  block(matchDeleteSms_feedback_enum_outcome(e.id, ANY), function () {
    verifySms_feedback_enum_outcomeExists(e.id);
  });
});

bthread("Sms_feedback_enum_outcome update verification", function () {
  const e = waitForAnySms_feedback_enum_outcomeUpdated();
  block(matchDeleteSms_feedback_enum_outcome(e.id, ANY), function () {
    verifySms_feedback_enum_outcomeUpdated(e.id);
  });
});

bthread("Sms_feedback_enum_outcome delete verification", function () {
  const e = waitForAnySms_feedback_enum_outcomeDeleted();
  block(matchAddSms_feedback_enum_outcome(e.id, ANY), function () {
    verifySms_feedback_enum_outcomeDoesNotExist(e.id);
  });
});

bthread("Message_feedback_enum_outcome create verification", function () {
  const e = waitForAnyMessage_feedback_enum_outcomeAdded();
  block(matchDeleteMessage_feedback_enum_outcome(e.id, ANY), function () {
    verifyMessage_feedback_enum_outcomeExists(e.id);
  });
});

bthread("Message_feedback_enum_outcome update verification", function () {
  const e = waitForAnyMessage_feedback_enum_outcomeUpdated();
  block(matchDeleteMessage_feedback_enum_outcome(e.id, ANY), function () {
    verifyMessage_feedback_enum_outcomeUpdated(e.id);
  });
});

bthread("Message_feedback_enum_outcome delete verification", function () {
  const e = waitForAnyMessage_feedback_enum_outcomeDeleted();
  block(matchAddMessage_feedback_enum_outcome(e.id, ANY), function () {
    verifyMessage_feedback_enum_outcomeDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.recording create verification", function () {
  const e = waitForAnyApi.v2010.account.recordingAdded();
  block(matchDeleteApi.v2010.account.recording(e.id, ANY), function () {
    verifyApi.v2010.account.recordingExists(e.id);
  });
});

bthread("Api.v2010.account.recording update verification", function () {
  const e = waitForAnyApi.v2010.account.recordingUpdated();
  block(matchDeleteApi.v2010.account.recording(e.id, ANY), function () {
    verifyApi.v2010.account.recordingUpdated(e.id);
  });
});

bthread("Api.v2010.account.recording delete verification", function () {
  const e = waitForAnyApi.v2010.account.recordingDeleted();
  block(matchAddApi.v2010.account.recording(e.id, ANY), function () {
    verifyApi.v2010.account.recordingDoesNotExist(e.id);
  });
});

bthread("Stream_enum_update_status create verification", function () {
  const e = waitForAnyStream_enum_update_statusAdded();
  block(matchDeleteStream_enum_update_status(e.id, ANY), function () {
    verifyStream_enum_update_statusExists(e.id);
  });
});

bthread("Stream_enum_update_status update verification", function () {
  const e = waitForAnyStream_enum_update_statusUpdated();
  block(matchDeleteStream_enum_update_status(e.id, ANY), function () {
    verifyStream_enum_update_statusUpdated(e.id);
  });
});

bthread("Stream_enum_update_status delete verification", function () {
  const e = waitForAnyStream_enum_update_statusDeleted();
  block(matchAddStream_enum_update_status(e.id, ANY), function () {
    verifyStream_enum_update_statusDoesNotExist(e.id);
  });
});

bthread("Sms_message_enum_direction create verification", function () {
  const e = waitForAnySms_message_enum_directionAdded();
  block(matchDeleteSms_message_enum_direction(e.id, ANY), function () {
    verifySms_message_enum_directionExists(e.id);
  });
});

bthread("Sms_message_enum_direction update verification", function () {
  const e = waitForAnySms_message_enum_directionUpdated();
  block(matchDeleteSms_message_enum_direction(e.id, ANY), function () {
    verifySms_message_enum_directionUpdated(e.id);
  });
});

bthread("Sms_message_enum_direction delete verification", function () {
  const e = waitForAnySms_message_enum_directionDeleted();
  block(matchAddSms_message_enum_direction(e.id, ANY), function () {
    verifySms_message_enum_directionDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.message.message_feedback create verification", function () {
  const e = waitForAnyApi.v2010.account.message.message_feedbackAdded();
  block(matchDeleteApi.v2010.account.message.message_feedback(e.id, ANY), function () {
    verifyApi.v2010.account.message.message_feedbackExists(e.id);
  });
});

bthread("Api.v2010.account.message.message_feedback update verification", function () {
  const e = waitForAnyApi.v2010.account.message.message_feedbackUpdated();
  block(matchDeleteApi.v2010.account.message.message_feedback(e.id, ANY), function () {
    verifyApi.v2010.account.message.message_feedbackUpdated(e.id);
  });
});

bthread("Api.v2010.account.message.message_feedback delete verification", function () {
  const e = waitForAnyApi.v2010.account.message.message_feedbackDeleted();
  block(matchAddApi.v2010.account.message.message_feedback(e.id, ANY), function () {
    verifyApi.v2010.account.message.message_feedbackDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_emergency_status create verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_emergency_statusAdded();
  block(matchDeleteIncoming_phone_number_toll_free_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_emergency_statusExists(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_emergency_status update verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_emergency_statusUpdated();
  block(matchDeleteIncoming_phone_number_toll_free_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_emergency_statusUpdated(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_emergency_status delete verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_emergency_statusDeleted();
  block(matchAddIncoming_phone_number_toll_free_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_emergency_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine create verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machineAdded();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machineExists(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine update verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machineUpdated();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machineUpdated(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine delete verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machineDeleted();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machineDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.connect_app create verification", function () {
  const e = waitForAnyApi.v2010.account.connect_appAdded();
  block(matchDeleteApi.v2010.account.connect_app(e.id, ANY), function () {
    verifyApi.v2010.account.connect_appExists(e.id);
  });
});

bthread("Api.v2010.account.connect_app update verification", function () {
  const e = waitForAnyApi.v2010.account.connect_appUpdated();
  block(matchDeleteApi.v2010.account.connect_app(e.id, ANY), function () {
    verifyApi.v2010.account.connect_appUpdated(e.id);
  });
});

bthread("Api.v2010.account.connect_app delete verification", function () {
  const e = waitForAnyApi.v2010.account.connect_appDeleted();
  block(matchAddApi.v2010.account.connect_app(e.id, ANY), function () {
    verifyApi.v2010.account.connect_appDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_enum_emergency_status create verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_emergency_statusAdded();
  block(matchDeleteIncoming_phone_number_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_emergency_statusExists(e.id);
  });
});

bthread("Incoming_phone_number_enum_emergency_status update verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_emergency_statusUpdated();
  block(matchDeleteIncoming_phone_number_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_emergency_statusUpdated(e.id);
  });
});

bthread("Incoming_phone_number_enum_emergency_status delete verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_emergency_statusDeleted();
  block(matchAddIncoming_phone_number_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_emergency_statusDoesNotExist(e.id);
  });
});

bthread("Call_recording_enum_status create verification", function () {
  const e = waitForAnyCall_recording_enum_statusAdded();
  block(matchDeleteCall_recording_enum_status(e.id, ANY), function () {
    verifyCall_recording_enum_statusExists(e.id);
  });
});

bthread("Call_recording_enum_status update verification", function () {
  const e = waitForAnyCall_recording_enum_statusUpdated();
  block(matchDeleteCall_recording_enum_status(e.id, ANY), function () {
    verifyCall_recording_enum_statusUpdated(e.id);
  });
});

bthread("Call_recording_enum_status delete verification", function () {
  const e = waitForAnyCall_recording_enum_statusDeleted();
  block(matchAddCall_recording_enum_status(e.id, ANY), function () {
    verifyCall_recording_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.token create verification", function () {
  const e = waitForAnyApi.v2010.account.tokenAdded();
  block(matchDeleteApi.v2010.account.token(e.id, ANY), function () {
    verifyApi.v2010.account.tokenExists(e.id);
  });
});

bthread("Api.v2010.account.token update verification", function () {
  const e = waitForAnyApi.v2010.account.tokenUpdated();
  block(matchDeleteApi.v2010.account.token(e.id, ANY), function () {
    verifyApi.v2010.account.tokenUpdated(e.id);
  });
});

bthread("Api.v2010.account.token delete verification", function () {
  const e = waitForAnyApi.v2010.account.tokenDeleted();
  block(matchAddApi.v2010.account.token(e.id, ANY), function () {
    verifyApi.v2010.account.tokenDoesNotExist(e.id);
  });
});

bthread("Payments_enum_bank_account_type create verification", function () {
  const e = waitForAnyPayments_enum_bank_account_typeAdded();
  block(matchDeletePayments_enum_bank_account_type(e.id, ANY), function () {
    verifyPayments_enum_bank_account_typeExists(e.id);
  });
});

bthread("Payments_enum_bank_account_type update verification", function () {
  const e = waitForAnyPayments_enum_bank_account_typeUpdated();
  block(matchDeletePayments_enum_bank_account_type(e.id, ANY), function () {
    verifyPayments_enum_bank_account_typeUpdated(e.id);
  });
});

bthread("Payments_enum_bank_account_type delete verification", function () {
  const e = waitForAnyPayments_enum_bank_account_typeDeleted();
  block(matchAddPayments_enum_bank_account_type(e.id, ANY), function () {
    verifyPayments_enum_bank_account_typeDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.call.call_notification create verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_notificationAdded();
  block(matchDeleteApi.v2010.account.call.call_notification(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_notificationExists(e.id);
  });
});

bthread("Api.v2010.account.call.call_notification update verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_notificationUpdated();
  block(matchDeleteApi.v2010.account.call.call_notification(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_notificationUpdated(e.id);
  });
});

bthread("Api.v2010.account.call.call_notification delete verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_notificationDeleted();
  block(matchAddApi.v2010.account.call.call_notification(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_notificationDoesNotExist(e.id);
  });
});

bthread("Conference_recording_enum_source create verification", function () {
  const e = waitForAnyConference_recording_enum_sourceAdded();
  block(matchDeleteConference_recording_enum_source(e.id, ANY), function () {
    verifyConference_recording_enum_sourceExists(e.id);
  });
});

bthread("Conference_recording_enum_source update verification", function () {
  const e = waitForAnyConference_recording_enum_sourceUpdated();
  block(matchDeleteConference_recording_enum_source(e.id, ANY), function () {
    verifyConference_recording_enum_sourceUpdated(e.id);
  });
});

bthread("Conference_recording_enum_source delete verification", function () {
  const e = waitForAnyConference_recording_enum_sourceDeleted();
  block(matchAddConference_recording_enum_source(e.id, ANY), function () {
    verifyConference_recording_enum_sourceDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mappingAdded();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mappingExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mappingUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mappingUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mappingDeleted();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mappingDoesNotExist(e.id);
  });
});

bthread("Account_enum_status create verification", function () {
  const e = waitForAnyAccount_enum_statusAdded();
  block(matchDeleteAccount_enum_status(e.id, ANY), function () {
    verifyAccount_enum_statusExists(e.id);
  });
});

bthread("Account_enum_status update verification", function () {
  const e = waitForAnyAccount_enum_statusUpdated();
  block(matchDeleteAccount_enum_status(e.id, ANY), function () {
    verifyAccount_enum_statusUpdated(e.id);
  });
});

bthread("Account_enum_status delete verification", function () {
  const e = waitForAnyAccount_enum_statusDeleted();
  block(matchAddAccount_enum_status(e.id, ANY), function () {
    verifyAccount_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.transcription create verification", function () {
  const e = waitForAnyApi.v2010.account.transcriptionAdded();
  block(matchDeleteApi.v2010.account.transcription(e.id, ANY), function () {
    verifyApi.v2010.account.transcriptionExists(e.id);
  });
});

bthread("Api.v2010.account.transcription update verification", function () {
  const e = waitForAnyApi.v2010.account.transcriptionUpdated();
  block(matchDeleteApi.v2010.account.transcription(e.id, ANY), function () {
    verifyApi.v2010.account.transcriptionUpdated(e.id);
  });
});

bthread("Api.v2010.account.transcription delete verification", function () {
  const e = waitForAnyApi.v2010.account.transcriptionDeleted();
  block(matchAddApi.v2010.account.transcription(e.id, ANY), function () {
    verifyApi.v2010.account.transcriptionDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_voice_receive_mode create verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_voice_receive_modeAdded();
  block(matchDeleteIncoming_phone_number_local_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_voice_receive_modeExists(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_voice_receive_mode update verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_voice_receive_modeUpdated();
  block(matchDeleteIncoming_phone_number_local_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_voice_receive_modeUpdated(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_voice_receive_mode delete verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_voice_receive_modeDeleted();
  block(matchAddIncoming_phone_number_local_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_voice_receive_modeDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_mobile create verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_mobileAdded();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_mobile(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_mobileExists(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_mobile update verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_mobileUpdated();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_mobile(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_mobileUpdated(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_mobile delete verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_mobileDeleted();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_mobile(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_mobileDoesNotExist(e.id);
  });
});

bthread("Conference_recording_enum_status create verification", function () {
  const e = waitForAnyConference_recording_enum_statusAdded();
  block(matchDeleteConference_recording_enum_status(e.id, ANY), function () {
    verifyConference_recording_enum_statusExists(e.id);
  });
});

bthread("Conference_recording_enum_status update verification", function () {
  const e = waitForAnyConference_recording_enum_statusUpdated();
  block(matchDeleteConference_recording_enum_status(e.id, ANY), function () {
    verifyConference_recording_enum_statusUpdated(e.id);
  });
});

bthread("Conference_recording_enum_status delete verification", function () {
  const e = waitForAnyConference_recording_enum_statusDeleted();
  block(matchAddConference_recording_enum_status(e.id, ANY), function () {
    verifyConference_recording_enum_statusDoesNotExist(e.id);
  });
});

bthread("Message_enum_address_retention create verification", function () {
  const e = waitForAnyMessage_enum_address_retentionAdded();
  block(matchDeleteMessage_enum_address_retention(e.id, ANY), function () {
    verifyMessage_enum_address_retentionExists(e.id);
  });
});

bthread("Message_enum_address_retention update verification", function () {
  const e = waitForAnyMessage_enum_address_retentionUpdated();
  block(matchDeleteMessage_enum_address_retention(e.id, ANY), function () {
    verifyMessage_enum_address_retentionUpdated(e.id);
  });
});

bthread("Message_enum_address_retention delete verification", function () {
  const e = waitForAnyMessage_enum_address_retentionDeleted();
  block(matchAddMessage_enum_address_retention(e.id, ANY), function () {
    verifyMessage_enum_address_retentionDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_shared_cost create verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_shared_costAdded();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_shared_cost(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_shared_costExists(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_shared_cost update verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_shared_costUpdated();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_shared_cost(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_shared_costUpdated(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_shared_cost delete verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_shared_costDeleted();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_shared_cost(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_shared_costDoesNotExist(e.id);
  });
});

bthread("Call_recording_enum_source create verification", function () {
  const e = waitForAnyCall_recording_enum_sourceAdded();
  block(matchDeleteCall_recording_enum_source(e.id, ANY), function () {
    verifyCall_recording_enum_sourceExists(e.id);
  });
});

bthread("Call_recording_enum_source update verification", function () {
  const e = waitForAnyCall_recording_enum_sourceUpdated();
  block(matchDeleteCall_recording_enum_source(e.id, ANY), function () {
    verifyCall_recording_enum_sourceUpdated(e.id);
  });
});

bthread("Call_recording_enum_source delete verification", function () {
  const e = waitForAnyCall_recording_enum_sourceDeleted();
  block(matchAddCall_recording_enum_source(e.id, ANY), function () {
    verifyCall_recording_enum_sourceDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension create verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extensionAdded();
  block(matchDeleteApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extensionExists(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension update verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extensionUpdated();
  block(matchDeleteApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extensionUpdated(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension delete verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extensionDeleted();
  block(matchAddApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extensionDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_emergency_address_status create verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_emergency_address_statusAdded();
  block(matchDeleteIncoming_phone_number_local_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_emergency_address_statusExists(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_emergency_address_status update verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_emergency_address_statusUpdated();
  block(matchDeleteIncoming_phone_number_local_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_emergency_address_statusUpdated(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_emergency_address_status delete verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_emergency_address_statusDeleted();
  block(matchAddIncoming_phone_number_local_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_emergency_address_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.call.user_defined_message_subscription create verification", function () {
  const e = waitForAnyApi.v2010.account.call.user_defined_message_subscriptionAdded();
  block(matchDeleteApi.v2010.account.call.user_defined_message_subscription(e.id, ANY), function () {
    verifyApi.v2010.account.call.user_defined_message_subscriptionExists(e.id);
  });
});

bthread("Api.v2010.account.call.user_defined_message_subscription update verification", function () {
  const e = waitForAnyApi.v2010.account.call.user_defined_message_subscriptionUpdated();
  block(matchDeleteApi.v2010.account.call.user_defined_message_subscription(e.id, ANY), function () {
    verifyApi.v2010.account.call.user_defined_message_subscriptionUpdated(e.id);
  });
});

bthread("Api.v2010.account.call.user_defined_message_subscription delete verification", function () {
  const e = waitForAnyApi.v2010.account.call.user_defined_message_subscriptionDeleted();
  block(matchAddApi.v2010.account.call.user_defined_message_subscription(e.id, ANY), function () {
    verifyApi.v2010.account.call.user_defined_message_subscriptionDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.call.call_event create verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_eventAdded();
  block(matchDeleteApi.v2010.account.call.call_event(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_eventExists(e.id);
  });
});

bthread("Api.v2010.account.call.call_event update verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_eventUpdated();
  block(matchDeleteApi.v2010.account.call.call_event(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_eventUpdated(e.id);
  });
});

bthread("Api.v2010.account.call.call_event delete verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_eventDeleted();
  block(matchAddApi.v2010.account.call.call_event(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_eventDoesNotExist(e.id);
  });
});

bthread("Realtime_transcription_enum_track create verification", function () {
  const e = waitForAnyRealtime_transcription_enum_trackAdded();
  block(matchDeleteRealtime_transcription_enum_track(e.id, ANY), function () {
    verifyRealtime_transcription_enum_trackExists(e.id);
  });
});

bthread("Realtime_transcription_enum_track update verification", function () {
  const e = waitForAnyRealtime_transcription_enum_trackUpdated();
  block(matchDeleteRealtime_transcription_enum_track(e.id, ANY), function () {
    verifyRealtime_transcription_enum_trackUpdated(e.id);
  });
});

bthread("Realtime_transcription_enum_track delete verification", function () {
  const e = waitForAnyRealtime_transcription_enum_trackDeleted();
  block(matchAddRealtime_transcription_enum_track(e.id, ANY), function () {
    verifyRealtime_transcription_enum_trackDoesNotExist(e.id);
  });
});

bthread("Usage_trigger_enum_trigger_field create verification", function () {
  const e = waitForAnyUsage_trigger_enum_trigger_fieldAdded();
  block(matchDeleteUsage_trigger_enum_trigger_field(e.id, ANY), function () {
    verifyUsage_trigger_enum_trigger_fieldExists(e.id);
  });
});

bthread("Usage_trigger_enum_trigger_field update verification", function () {
  const e = waitForAnyUsage_trigger_enum_trigger_fieldUpdated();
  block(matchDeleteUsage_trigger_enum_trigger_field(e.id, ANY), function () {
    verifyUsage_trigger_enum_trigger_fieldUpdated(e.id);
  });
});

bthread("Usage_trigger_enum_trigger_field delete verification", function () {
  const e = waitForAnyUsage_trigger_enum_trigger_fieldDeleted();
  block(matchAddUsage_trigger_enum_trigger_field(e.id, ANY), function () {
    verifyUsage_trigger_enum_trigger_fieldDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_emergency_address_status create verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_emergency_address_statusAdded();
  block(matchDeleteIncoming_phone_number_toll_free_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_emergency_address_statusExists(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_emergency_address_status update verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_emergency_address_statusUpdated();
  block(matchDeleteIncoming_phone_number_toll_free_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_emergency_address_statusUpdated(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_emergency_address_status delete verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_emergency_address_statusDeleted();
  block(matchAddIncoming_phone_number_toll_free_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_emergency_address_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_credential_list create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_credential_listAdded();
  block(matchDeleteApi.v2010.account.sip.sip_credential_list(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_credential_listExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_credential_list update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_credential_listUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_credential_list(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_credential_listUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_credential_list delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_credential_listDeleted();
  block(matchAddApi.v2010.account.sip.sip_credential_list(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_credential_listDoesNotExist(e.id);
  });
});

bthread("Message_enum_status create verification", function () {
  const e = waitForAnyMessage_enum_statusAdded();
  block(matchDeleteMessage_enum_status(e.id, ANY), function () {
    verifyMessage_enum_statusExists(e.id);
  });
});

bthread("Message_enum_status update verification", function () {
  const e = waitForAnyMessage_enum_statusUpdated();
  block(matchDeleteMessage_enum_status(e.id, ANY), function () {
    verifyMessage_enum_statusUpdated(e.id);
  });
});

bthread("Message_enum_status delete verification", function () {
  const e = waitForAnyMessage_enum_statusDeleted();
  block(matchAddMessage_enum_status(e.id, ANY), function () {
    verifyMessage_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_mobile create verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_mobileAdded();
  block(matchDeleteApi.v2010.account.incoming_phone_number.incoming_phone_number_mobile(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_mobileExists(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_mobile update verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_mobileUpdated();
  block(matchDeleteApi.v2010.account.incoming_phone_number.incoming_phone_number_mobile(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_mobileUpdated(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_mobile delete verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_mobileDeleted();
  block(matchAddApi.v2010.account.incoming_phone_number.incoming_phone_number_mobile(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_mobileDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on create verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_onAdded();
  block(matchDeleteApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_onExists(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on update verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_onUpdated();
  block(matchDeleteApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_onUpdated(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on delete verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_onDeleted();
  block(matchAddApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_onDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_all_time create verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_all_timeAdded();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_all_time(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_all_timeExists(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_all_time update verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_all_timeUpdated();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_all_time(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_all_timeUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_all_time delete verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_all_timeDeleted();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_all_time(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_all_timeDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_emergency_address_status create verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_emergency_address_statusAdded();
  block(matchDeleteIncoming_phone_number_mobile_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_emergency_address_statusExists(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_emergency_address_status update verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_emergency_address_statusUpdated();
  block(matchDeleteIncoming_phone_number_mobile_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_emergency_address_statusUpdated(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_emergency_address_status delete verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_emergency_address_statusDeleted();
  block(matchAddIncoming_phone_number_mobile_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_emergency_address_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mappingAdded();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mappingExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mappingUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mappingUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mappingDeleted();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mappingDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.conference.conference_recording create verification", function () {
  const e = waitForAnyApi.v2010.account.conference.conference_recordingAdded();
  block(matchDeleteApi.v2010.account.conference.conference_recording(e.id, ANY), function () {
    verifyApi.v2010.account.conference.conference_recordingExists(e.id);
  });
});

bthread("Api.v2010.account.conference.conference_recording update verification", function () {
  const e = waitForAnyApi.v2010.account.conference.conference_recordingUpdated();
  block(matchDeleteApi.v2010.account.conference.conference_recording(e.id, ANY), function () {
    verifyApi.v2010.account.conference.conference_recordingUpdated(e.id);
  });
});

bthread("Api.v2010.account.conference.conference_recording delete verification", function () {
  const e = waitForAnyApi.v2010.account.conference.conference_recordingDeleted();
  block(matchAddApi.v2010.account.conference.conference_recording(e.id, ANY), function () {
    verifyApi.v2010.account.conference.conference_recordingDoesNotExist(e.id);
  });
});

bthread("Conference_enum_status create verification", function () {
  const e = waitForAnyConference_enum_statusAdded();
  block(matchDeleteConference_enum_status(e.id, ANY), function () {
    verifyConference_enum_statusExists(e.id);
  });
});

bthread("Conference_enum_status update verification", function () {
  const e = waitForAnyConference_enum_statusUpdated();
  block(matchDeleteConference_enum_status(e.id, ANY), function () {
    verifyConference_enum_statusUpdated(e.id);
  });
});

bthread("Conference_enum_status delete verification", function () {
  const e = waitForAnyConference_enum_statusDeleted();
  block(matchAddConference_enum_status(e.id, ANY), function () {
    verifyConference_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.notification create verification", function () {
  const e = waitForAnyApi.v2010.account.notificationAdded();
  block(matchDeleteApi.v2010.account.notification(e.id, ANY), function () {
    verifyApi.v2010.account.notificationExists(e.id);
  });
});

bthread("Api.v2010.account.notification update verification", function () {
  const e = waitForAnyApi.v2010.account.notificationUpdated();
  block(matchDeleteApi.v2010.account.notification(e.id, ANY), function () {
    verifyApi.v2010.account.notificationUpdated(e.id);
  });
});

bthread("Api.v2010.account.notification delete verification", function () {
  const e = waitForAnyApi.v2010.account.notificationDeleted();
  block(matchAddApi.v2010.account.notification(e.id, ANY), function () {
    verifyApi.v2010.account.notificationDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mappingAdded();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mappingExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mappingUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mappingUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mappingDeleted();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mappingDoesNotExist(e.id);
  });
});

bthread("Call_enum_update_status create verification", function () {
  const e = waitForAnyCall_enum_update_statusAdded();
  block(matchDeleteCall_enum_update_status(e.id, ANY), function () {
    verifyCall_enum_update_statusExists(e.id);
  });
});

bthread("Call_enum_update_status update verification", function () {
  const e = waitForAnyCall_enum_update_statusUpdated();
  block(matchDeleteCall_enum_update_status(e.id, ANY), function () {
    verifyCall_enum_update_statusUpdated(e.id);
  });
});

bthread("Call_enum_update_status delete verification", function () {
  const e = waitForAnyCall_enum_update_statusDeleted();
  block(matchAddCall_enum_update_status(e.id, ANY), function () {
    verifyCall_enum_update_statusDoesNotExist(e.id);
  });
});

bthread("Usage_trigger_enum_recurring create verification", function () {
  const e = waitForAnyUsage_trigger_enum_recurringAdded();
  block(matchDeleteUsage_trigger_enum_recurring(e.id, ANY), function () {
    verifyUsage_trigger_enum_recurringExists(e.id);
  });
});

bthread("Usage_trigger_enum_recurring update verification", function () {
  const e = waitForAnyUsage_trigger_enum_recurringUpdated();
  block(matchDeleteUsage_trigger_enum_recurring(e.id, ANY), function () {
    verifyUsage_trigger_enum_recurringUpdated(e.id);
  });
});

bthread("Usage_trigger_enum_recurring delete verification", function () {
  const e = waitForAnyUsage_trigger_enum_recurringDeleted();
  block(matchAddUsage_trigger_enum_recurring(e.id, ANY), function () {
    verifyUsage_trigger_enum_recurringDoesNotExist(e.id);
  });
});

bthread("Realtime_transcription_enum_status create verification", function () {
  const e = waitForAnyRealtime_transcription_enum_statusAdded();
  block(matchDeleteRealtime_transcription_enum_status(e.id, ANY), function () {
    verifyRealtime_transcription_enum_statusExists(e.id);
  });
});

bthread("Realtime_transcription_enum_status update verification", function () {
  const e = waitForAnyRealtime_transcription_enum_statusUpdated();
  block(matchDeleteRealtime_transcription_enum_status(e.id, ANY), function () {
    verifyRealtime_transcription_enum_statusUpdated(e.id);
  });
});

bthread("Realtime_transcription_enum_status delete verification", function () {
  const e = waitForAnyRealtime_transcription_enum_statusDeleted();
  block(matchAddRealtime_transcription_enum_status(e.id, ANY), function () {
    verifyRealtime_transcription_enum_statusDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_emergency_status create verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_emergency_statusAdded();
  block(matchDeleteIncoming_phone_number_mobile_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_emergency_statusExists(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_emergency_status update verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_emergency_statusUpdated();
  block(matchDeleteIncoming_phone_number_mobile_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_emergency_statusUpdated(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_emergency_status delete verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_emergency_statusDeleted();
  block(matchAddIncoming_phone_number_mobile_enum_emergency_status(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_emergency_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.conference.participant create verification", function () {
  const e = waitForAnyApi.v2010.account.conference.participantAdded();
  block(matchDeleteApi.v2010.account.conference.participant(e.id, ANY), function () {
    verifyApi.v2010.account.conference.participantExists(e.id);
  });
});

bthread("Api.v2010.account.conference.participant update verification", function () {
  const e = waitForAnyApi.v2010.account.conference.participantUpdated();
  block(matchDeleteApi.v2010.account.conference.participant(e.id, ANY), function () {
    verifyApi.v2010.account.conference.participantUpdated(e.id);
  });
});

bthread("Api.v2010.account.conference.participant delete verification", function () {
  const e = waitForAnyApi.v2010.account.conference.participantDeleted();
  block(matchAddApi.v2010.account.conference.participant(e.id, ANY), function () {
    verifyApi.v2010.account.conference.participantDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_add_on_result create verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_add_on_resultAdded();
  block(matchDeleteApi.v2010.account.recording.recording_add_on_result(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_add_on_resultExists(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_add_on_result update verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_add_on_resultUpdated();
  block(matchDeleteApi.v2010.account.recording.recording_add_on_result(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_add_on_resultUpdated(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_add_on_result delete verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_add_on_resultDeleted();
  block(matchAddApi.v2010.account.recording.recording_add_on_result(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_add_on_resultDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.conference create verification", function () {
  const e = waitForAnyApi.v2010.account.conferenceAdded();
  block(matchDeleteApi.v2010.account.conference(e.id, ANY), function () {
    verifyApi.v2010.account.conferenceExists(e.id);
  });
});

bthread("Api.v2010.account.conference update verification", function () {
  const e = waitForAnyApi.v2010.account.conferenceUpdated();
  block(matchDeleteApi.v2010.account.conference(e.id, ANY), function () {
    verifyApi.v2010.account.conferenceUpdated(e.id);
  });
});

bthread("Api.v2010.account.conference delete verification", function () {
  const e = waitForAnyApi.v2010.account.conferenceDeleted();
  block(matchAddApi.v2010.account.conference(e.id, ANY), function () {
    verifyApi.v2010.account.conferenceDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_yearly create verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_yearlyAdded();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_yearly(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_yearlyExists(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_yearly update verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_yearlyUpdated();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_yearly(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_yearlyUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_yearly delete verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_yearlyDeleted();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_yearly(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_yearlyDoesNotExist(e.id);
  });
});

bthread("Recording_transcription_enum_status create verification", function () {
  const e = waitForAnyRecording_transcription_enum_statusAdded();
  block(matchDeleteRecording_transcription_enum_status(e.id, ANY), function () {
    verifyRecording_transcription_enum_statusExists(e.id);
  });
});

bthread("Recording_transcription_enum_status update verification", function () {
  const e = waitForAnyRecording_transcription_enum_statusUpdated();
  block(matchDeleteRecording_transcription_enum_status(e.id, ANY), function () {
    verifyRecording_transcription_enum_statusUpdated(e.id);
  });
});

bthread("Recording_transcription_enum_status delete verification", function () {
  const e = waitForAnyRecording_transcription_enum_statusDeleted();
  block(matchAddRecording_transcription_enum_status(e.id, ANY), function () {
    verifyRecording_transcription_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_credential_list_mapping create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_credential_list_mappingAdded();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_credential_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_credential_list_mappingExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_credential_list_mapping update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_credential_list_mappingUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_credential_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_credential_list_mappingUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_credential_list_mapping delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_credential_list_mappingDeleted();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_credential_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_credential_list_mappingDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.balance create verification", function () {
  const e = waitForAnyApi.v2010.account.balanceAdded();
  block(matchDeleteApi.v2010.account.balance(e.id, ANY), function () {
    verifyApi.v2010.account.balanceExists(e.id);
  });
});

bthread("Api.v2010.account.balance update verification", function () {
  const e = waitForAnyApi.v2010.account.balanceUpdated();
  block(matchDeleteApi.v2010.account.balance(e.id, ANY), function () {
    verifyApi.v2010.account.balanceUpdated(e.id);
  });
});

bthread("Api.v2010.account.balance delete verification", function () {
  const e = waitForAnyApi.v2010.account.balanceDeleted();
  block(matchAddApi.v2010.account.balance(e.id, ANY), function () {
    verifyApi.v2010.account.balanceDoesNotExist(e.id);
  });
});

bthread("Authorized_connect_app_enum_permission create verification", function () {
  const e = waitForAnyAuthorized_connect_app_enum_permissionAdded();
  block(matchDeleteAuthorized_connect_app_enum_permission(e.id, ANY), function () {
    verifyAuthorized_connect_app_enum_permissionExists(e.id);
  });
});

bthread("Authorized_connect_app_enum_permission update verification", function () {
  const e = waitForAnyAuthorized_connect_app_enum_permissionUpdated();
  block(matchDeleteAuthorized_connect_app_enum_permission(e.id, ANY), function () {
    verifyAuthorized_connect_app_enum_permissionUpdated(e.id);
  });
});

bthread("Authorized_connect_app_enum_permission delete verification", function () {
  const e = waitForAnyAuthorized_connect_app_enum_permissionDeleted();
  block(matchAddAuthorized_connect_app_enum_permission(e.id, ANY), function () {
    verifyAuthorized_connect_app_enum_permissionDoesNotExist(e.id);
  });
});

bthread("Conference_enum_update_status create verification", function () {
  const e = waitForAnyConference_enum_update_statusAdded();
  block(matchDeleteConference_enum_update_status(e.id, ANY), function () {
    verifyConference_enum_update_statusExists(e.id);
  });
});

bthread("Conference_enum_update_status update verification", function () {
  const e = waitForAnyConference_enum_update_statusUpdated();
  block(matchDeleteConference_enum_update_status(e.id, ANY), function () {
    verifyConference_enum_update_statusUpdated(e.id);
  });
});

bthread("Conference_enum_update_status delete verification", function () {
  const e = waitForAnyConference_enum_update_statusDeleted();
  block(matchAddConference_enum_update_status(e.id, ANY), function () {
    verifyConference_enum_update_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_last_month create verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_last_monthAdded();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_last_month(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_last_monthExists(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_last_month update verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_last_monthUpdated();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_last_month(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_last_monthUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_last_month delete verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_last_monthDeleted();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_last_month(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_last_monthDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.new_signing_key create verification", function () {
  const e = waitForAnyApi.v2010.account.new_signing_keyAdded();
  block(matchDeleteApi.v2010.account.new_signing_key(e.id, ANY), function () {
    verifyApi.v2010.account.new_signing_keyExists(e.id);
  });
});

bthread("Api.v2010.account.new_signing_key update verification", function () {
  const e = waitForAnyApi.v2010.account.new_signing_keyUpdated();
  block(matchDeleteApi.v2010.account.new_signing_key(e.id, ANY), function () {
    verifyApi.v2010.account.new_signing_keyUpdated(e.id);
  });
});

bthread("Api.v2010.account.new_signing_key delete verification", function () {
  const e = waitForAnyApi.v2010.account.new_signing_keyDeleted();
  block(matchAddApi.v2010.account.new_signing_key(e.id, ANY), function () {
    verifyApi.v2010.account.new_signing_keyDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.key create verification", function () {
  const e = waitForAnyApi.v2010.account.keyAdded();
  block(matchDeleteApi.v2010.account.key(e.id, ANY), function () {
    verifyApi.v2010.account.keyExists(e.id);
  });
});

bthread("Api.v2010.account.key update verification", function () {
  const e = waitForAnyApi.v2010.account.keyUpdated();
  block(matchDeleteApi.v2010.account.key(e.id, ANY), function () {
    verifyApi.v2010.account.keyUpdated(e.id);
  });
});

bthread("Api.v2010.account.key delete verification", function () {
  const e = waitForAnyApi.v2010.account.keyDeleted();
  block(matchAddApi.v2010.account.key(e.id, ANY), function () {
    verifyApi.v2010.account.keyDoesNotExist(e.id);
  });
});

bthread("Dependent_phone_number_enum_emergency_status create verification", function () {
  const e = waitForAnyDependent_phone_number_enum_emergency_statusAdded();
  block(matchDeleteDependent_phone_number_enum_emergency_status(e.id, ANY), function () {
    verifyDependent_phone_number_enum_emergency_statusExists(e.id);
  });
});

bthread("Dependent_phone_number_enum_emergency_status update verification", function () {
  const e = waitForAnyDependent_phone_number_enum_emergency_statusUpdated();
  block(matchDeleteDependent_phone_number_enum_emergency_status(e.id, ANY), function () {
    verifyDependent_phone_number_enum_emergency_statusUpdated(e.id);
  });
});

bthread("Dependent_phone_number_enum_emergency_status delete verification", function () {
  const e = waitForAnyDependent_phone_number_enum_emergency_statusDeleted();
  block(matchAddDependent_phone_number_enum_emergency_status(e.id, ANY), function () {
    verifyDependent_phone_number_enum_emergency_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_authAdded();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_authExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_authUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_authUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_authDeleted();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_authDoesNotExist(e.id);
  });
});

bthread("Message_enum_content_retention create verification", function () {
  const e = waitForAnyMessage_enum_content_retentionAdded();
  block(matchDeleteMessage_enum_content_retention(e.id, ANY), function () {
    verifyMessage_enum_content_retentionExists(e.id);
  });
});

bthread("Message_enum_content_retention update verification", function () {
  const e = waitForAnyMessage_enum_content_retentionUpdated();
  block(matchDeleteMessage_enum_content_retention(e.id, ANY), function () {
    verifyMessage_enum_content_retentionUpdated(e.id);
  });
});

bthread("Message_enum_content_retention delete verification", function () {
  const e = waitForAnyMessage_enum_content_retentionDeleted();
  block(matchAddMessage_enum_content_retention(e.id, ANY), function () {
    verifyMessage_enum_content_retentionDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrationsAdded();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrationsExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrationsUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrationsUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrationsDeleted();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrationsDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_this_month create verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_this_monthAdded();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_this_month(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_this_monthExists(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_this_month update verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_this_monthUpdated();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_this_month(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_this_monthUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_this_month delete verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_this_monthDeleted();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_this_month(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_this_monthDoesNotExist(e.id);
  });
});

bthread("Call_enum_status create verification", function () {
  const e = waitForAnyCall_enum_statusAdded();
  block(matchDeleteCall_enum_status(e.id, ANY), function () {
    verifyCall_enum_statusExists(e.id);
  });
});

bthread("Call_enum_status update verification", function () {
  const e = waitForAnyCall_enum_statusUpdated();
  block(matchDeleteCall_enum_status(e.id, ANY), function () {
    verifyCall_enum_statusUpdated(e.id);
  });
});

bthread("Call_enum_status delete verification", function () {
  const e = waitForAnyCall_enum_statusDeleted();
  block(matchAddCall_enum_status(e.id, ANY), function () {
    verifyCall_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_callsAdded();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_callsExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_callsUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_callsUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_callsDeleted();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_callsDoesNotExist(e.id);
  });
});

bthread("Message_enum_risk_check create verification", function () {
  const e = waitForAnyMessage_enum_risk_checkAdded();
  block(matchDeleteMessage_enum_risk_check(e.id, ANY), function () {
    verifyMessage_enum_risk_checkExists(e.id);
  });
});

bthread("Message_enum_risk_check update verification", function () {
  const e = waitForAnyMessage_enum_risk_checkUpdated();
  block(matchDeleteMessage_enum_risk_check(e.id, ANY), function () {
    verifyMessage_enum_risk_checkUpdated(e.id);
  });
});

bthread("Message_enum_risk_check delete verification", function () {
  const e = waitForAnyMessage_enum_risk_checkDeleted();
  block(matchAddMessage_enum_risk_check(e.id, ANY), function () {
    verifyMessage_enum_risk_checkDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.message.media create verification", function () {
  const e = waitForAnyApi.v2010.account.message.mediaAdded();
  block(matchDeleteApi.v2010.account.message.media(e.id, ANY), function () {
    verifyApi.v2010.account.message.mediaExists(e.id);
  });
});

bthread("Api.v2010.account.message.media update verification", function () {
  const e = waitForAnyApi.v2010.account.message.mediaUpdated();
  block(matchDeleteApi.v2010.account.message.media(e.id, ANY), function () {
    verifyApi.v2010.account.message.mediaUpdated(e.id);
  });
});

bthread("Api.v2010.account.message.media delete verification", function () {
  const e = waitForAnyApi.v2010.account.message.mediaDeleted();
  block(matchAddApi.v2010.account.message.media(e.id, ANY), function () {
    verifyApi.v2010.account.message.mediaDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.outgoing_caller_id create verification", function () {
  const e = waitForAnyApi.v2010.account.outgoing_caller_idAdded();
  block(matchDeleteApi.v2010.account.outgoing_caller_id(e.id, ANY), function () {
    verifyApi.v2010.account.outgoing_caller_idExists(e.id);
  });
});

bthread("Api.v2010.account.outgoing_caller_id update verification", function () {
  const e = waitForAnyApi.v2010.account.outgoing_caller_idUpdated();
  block(matchDeleteApi.v2010.account.outgoing_caller_id(e.id, ANY), function () {
    verifyApi.v2010.account.outgoing_caller_idUpdated(e.id);
  });
});

bthread("Api.v2010.account.outgoing_caller_id delete verification", function () {
  const e = waitForAnyApi.v2010.account.outgoing_caller_idDeleted();
  block(matchAddApi.v2010.account.outgoing_caller_id(e.id, ANY), function () {
    verifyApi.v2010.account.outgoing_caller_idDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_trigger create verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_triggerAdded();
  block(matchDeleteApi.v2010.account.usage.usage_trigger(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_triggerExists(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_trigger update verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_triggerUpdated();
  block(matchDeleteApi.v2010.account.usage.usage_trigger(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_triggerUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_trigger delete verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_triggerDeleted();
  block(matchAddApi.v2010.account.usage.usage_trigger(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_triggerDoesNotExist(e.id);
  });
});

bthread("Dependent_phone_number_enum_address_requirement create verification", function () {
  const e = waitForAnyDependent_phone_number_enum_address_requirementAdded();
  block(matchDeleteDependent_phone_number_enum_address_requirement(e.id, ANY), function () {
    verifyDependent_phone_number_enum_address_requirementExists(e.id);
  });
});

bthread("Dependent_phone_number_enum_address_requirement update verification", function () {
  const e = waitForAnyDependent_phone_number_enum_address_requirementUpdated();
  block(matchDeleteDependent_phone_number_enum_address_requirement(e.id, ANY), function () {
    verifyDependent_phone_number_enum_address_requirementUpdated(e.id);
  });
});

bthread("Dependent_phone_number_enum_address_requirement delete verification", function () {
  const e = waitForAnyDependent_phone_number_enum_address_requirementDeleted();
  block(matchAddDependent_phone_number_enum_address_requirement(e.id, ANY), function () {
    verifyDependent_phone_number_enum_address_requirementDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_voice_receive_mode create verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_voice_receive_modeAdded();
  block(matchDeleteIncoming_phone_number_mobile_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_voice_receive_modeExists(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_voice_receive_mode update verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_voice_receive_modeUpdated();
  block(matchDeleteIncoming_phone_number_mobile_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_voice_receive_modeUpdated(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_voice_receive_mode delete verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_voice_receive_modeDeleted();
  block(matchAddIncoming_phone_number_mobile_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_voice_receive_modeDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.signing_key create verification", function () {
  const e = waitForAnyApi.v2010.account.signing_keyAdded();
  block(matchDeleteApi.v2010.account.signing_key(e.id, ANY), function () {
    verifyApi.v2010.account.signing_keyExists(e.id);
  });
});

bthread("Api.v2010.account.signing_key update verification", function () {
  const e = waitForAnyApi.v2010.account.signing_keyUpdated();
  block(matchDeleteApi.v2010.account.signing_key(e.id, ANY), function () {
    verifyApi.v2010.account.signing_keyUpdated(e.id);
  });
});

bthread("Api.v2010.account.signing_key delete verification", function () {
  const e = waitForAnyApi.v2010.account.signing_keyDeleted();
  block(matchAddApi.v2010.account.signing_key(e.id, ANY), function () {
    verifyApi.v2010.account.signing_keyDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage create verification", function () {
  const e = waitForAnyApi.v2010.account.usageAdded();
  block(matchDeleteApi.v2010.account.usage(e.id, ANY), function () {
    verifyApi.v2010.account.usageExists(e.id);
  });
});

bthread("Api.v2010.account.usage update verification", function () {
  const e = waitForAnyApi.v2010.account.usageUpdated();
  block(matchDeleteApi.v2010.account.usage(e.id, ANY), function () {
    verifyApi.v2010.account.usageUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage delete verification", function () {
  const e = waitForAnyApi.v2010.account.usageDeleted();
  block(matchAddApi.v2010.account.usage(e.id, ANY), function () {
    verifyApi.v2010.account.usageDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.address create verification", function () {
  const e = waitForAnyApi.v2010.account.addressAdded();
  block(matchDeleteApi.v2010.account.address(e.id, ANY), function () {
    verifyApi.v2010.account.addressExists(e.id);
  });
});

bthread("Api.v2010.account.address update verification", function () {
  const e = waitForAnyApi.v2010.account.addressUpdated();
  block(matchDeleteApi.v2010.account.address(e.id, ANY), function () {
    verifyApi.v2010.account.addressUpdated(e.id);
  });
});

bthread("Api.v2010.account.address delete verification", function () {
  const e = waitForAnyApi.v2010.account.addressDeleted();
  block(matchAddApi.v2010.account.address(e.id, ANY), function () {
    verifyApi.v2010.account.addressDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_enum_emergency_address_status create verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_emergency_address_statusAdded();
  block(matchDeleteIncoming_phone_number_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_emergency_address_statusExists(e.id);
  });
});

bthread("Incoming_phone_number_enum_emergency_address_status update verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_emergency_address_statusUpdated();
  block(matchDeleteIncoming_phone_number_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_emergency_address_statusUpdated(e.id);
  });
});

bthread("Incoming_phone_number_enum_emergency_address_status delete verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_emergency_address_statusDeleted();
  block(matchAddIncoming_phone_number_enum_emergency_address_status(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_emergency_address_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.call.payments create verification", function () {
  const e = waitForAnyApi.v2010.account.call.paymentsAdded();
  block(matchDeleteApi.v2010.account.call.payments(e.id, ANY), function () {
    verifyApi.v2010.account.call.paymentsExists(e.id);
  });
});

bthread("Api.v2010.account.call.payments update verification", function () {
  const e = waitForAnyApi.v2010.account.call.paymentsUpdated();
  block(matchDeleteApi.v2010.account.call.payments(e.id, ANY), function () {
    verifyApi.v2010.account.call.paymentsUpdated(e.id);
  });
});

bthread("Api.v2010.account.call.payments delete verification", function () {
  const e = waitForAnyApi.v2010.account.call.paymentsDeleted();
  block(matchAddApi.v2010.account.call.payments(e.id, ANY), function () {
    verifyApi.v2010.account.call.paymentsDoesNotExist(e.id);
  });
});

bthread("Message_enum_traffic_type create verification", function () {
  const e = waitForAnyMessage_enum_traffic_typeAdded();
  block(matchDeleteMessage_enum_traffic_type(e.id, ANY), function () {
    verifyMessage_enum_traffic_typeExists(e.id);
  });
});

bthread("Message_enum_traffic_type update verification", function () {
  const e = waitForAnyMessage_enum_traffic_typeUpdated();
  block(matchDeleteMessage_enum_traffic_type(e.id, ANY), function () {
    verifyMessage_enum_traffic_typeUpdated(e.id);
  });
});

bthread("Message_enum_traffic_type delete verification", function () {
  const e = waitForAnyMessage_enum_traffic_typeDeleted();
  block(matchAddMessage_enum_traffic_type(e.id, ANY), function () {
    verifyMessage_enum_traffic_typeDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.short_code create verification", function () {
  const e = waitForAnyApi.v2010.account.short_codeAdded();
  block(matchDeleteApi.v2010.account.short_code(e.id, ANY), function () {
    verifyApi.v2010.account.short_codeExists(e.id);
  });
});

bthread("Api.v2010.account.short_code update verification", function () {
  const e = waitForAnyApi.v2010.account.short_codeUpdated();
  block(matchDeleteApi.v2010.account.short_code(e.id, ANY), function () {
    verifyApi.v2010.account.short_codeUpdated(e.id);
  });
});

bthread("Api.v2010.account.short_code delete verification", function () {
  const e = waitForAnyApi.v2010.account.short_codeDeleted();
  block(matchAddApi.v2010.account.short_code(e.id, ANY), function () {
    verifyApi.v2010.account.short_codeDoesNotExist(e.id);
  });
});

bthread("Stream_enum_track create verification", function () {
  const e = waitForAnyStream_enum_trackAdded();
  block(matchDeleteStream_enum_track(e.id, ANY), function () {
    verifyStream_enum_trackExists(e.id);
  });
});

bthread("Stream_enum_track update verification", function () {
  const e = waitForAnyStream_enum_trackUpdated();
  block(matchDeleteStream_enum_track(e.id, ANY), function () {
    verifyStream_enum_trackUpdated(e.id);
  });
});

bthread("Stream_enum_track delete verification", function () {
  const e = waitForAnyStream_enum_trackDeleted();
  block(matchAddStream_enum_track(e.id, ANY), function () {
    verifyStream_enum_trackDoesNotExist(e.id);
  });
});

bthread("Payments_enum_payment_method create verification", function () {
  const e = waitForAnyPayments_enum_payment_methodAdded();
  block(matchDeletePayments_enum_payment_method(e.id, ANY), function () {
    verifyPayments_enum_payment_methodExists(e.id);
  });
});

bthread("Payments_enum_payment_method update verification", function () {
  const e = waitForAnyPayments_enum_payment_methodUpdated();
  block(matchDeletePayments_enum_payment_method(e.id, ANY), function () {
    verifyPayments_enum_payment_methodUpdated(e.id);
  });
});

bthread("Payments_enum_payment_method delete verification", function () {
  const e = waitForAnyPayments_enum_payment_methodDeleted();
  block(matchAddPayments_enum_payment_method(e.id, ANY), function () {
    verifyPayments_enum_payment_methodDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_toll_free create verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_toll_freeAdded();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_toll_free(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_toll_freeExists(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_toll_free update verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_toll_freeUpdated();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_toll_free(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_toll_freeUpdated(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_toll_free delete verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_toll_freeDeleted();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_toll_free(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_toll_freeDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_toll_free create verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_freeAdded();
  block(matchDeleteApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_free(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_freeExists(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_toll_free update verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_freeUpdated();
  block(matchDeleteApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_free(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_freeUpdated(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_toll_free delete verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_freeDeleted();
  block(matchAddApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_free(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_freeDoesNotExist(e.id);
  });
});

bthread("Payments_enum_capture create verification", function () {
  const e = waitForAnyPayments_enum_captureAdded();
  block(matchDeletePayments_enum_capture(e.id, ANY), function () {
    verifyPayments_enum_captureExists(e.id);
  });
});

bthread("Payments_enum_capture update verification", function () {
  const e = waitForAnyPayments_enum_captureUpdated();
  block(matchDeletePayments_enum_capture(e.id, ANY), function () {
    verifyPayments_enum_captureUpdated(e.id);
  });
});

bthread("Payments_enum_capture delete verification", function () {
  const e = waitForAnyPayments_enum_captureDeleted();
  block(matchAddPayments_enum_capture(e.id, ANY), function () {
    verifyPayments_enum_captureDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.validation_request create verification", function () {
  const e = waitForAnyApi.v2010.account.validation_requestAdded();
  block(matchDeleteApi.v2010.account.validation_request(e.id, ANY), function () {
    verifyApi.v2010.account.validation_requestExists(e.id);
  });
});

bthread("Api.v2010.account.validation_request update verification", function () {
  const e = waitForAnyApi.v2010.account.validation_requestUpdated();
  block(matchDeleteApi.v2010.account.validation_request(e.id, ANY), function () {
    verifyApi.v2010.account.validation_requestUpdated(e.id);
  });
});

bthread("Api.v2010.account.validation_request delete verification", function () {
  const e = waitForAnyApi.v2010.account.validation_requestDeleted();
  block(matchAddApi.v2010.account.validation_request(e.id, ANY), function () {
    verifyApi.v2010.account.validation_requestDoesNotExist(e.id);
  });
});

bthread("Call_enum_event create verification", function () {
  const e = waitForAnyCall_enum_eventAdded();
  block(matchDeleteCall_enum_event(e.id, ANY), function () {
    verifyCall_enum_eventExists(e.id);
  });
});

bthread("Call_enum_event update verification", function () {
  const e = waitForAnyCall_enum_eventUpdated();
  block(matchDeleteCall_enum_event(e.id, ANY), function () {
    verifyCall_enum_eventUpdated(e.id);
  });
});

bthread("Call_enum_event delete verification", function () {
  const e = waitForAnyCall_enum_eventDeleted();
  block(matchAddCall_enum_event(e.id, ANY), function () {
    verifyCall_enum_eventDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domainAdded();
  block(matchDeleteApi.v2010.account.sip.sip_domain(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domainExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domainUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_domain(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domainUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domainDeleted();
  block(matchAddApi.v2010.account.sip.sip_domain(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domainDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.call.user_defined_message create verification", function () {
  const e = waitForAnyApi.v2010.account.call.user_defined_messageAdded();
  block(matchDeleteApi.v2010.account.call.user_defined_message(e.id, ANY), function () {
    verifyApi.v2010.account.call.user_defined_messageExists(e.id);
  });
});

bthread("Api.v2010.account.call.user_defined_message update verification", function () {
  const e = waitForAnyApi.v2010.account.call.user_defined_messageUpdated();
  block(matchDeleteApi.v2010.account.call.user_defined_message(e.id, ANY), function () {
    verifyApi.v2010.account.call.user_defined_messageUpdated(e.id);
  });
});

bthread("Api.v2010.account.call.user_defined_message delete verification", function () {
  const e = waitForAnyApi.v2010.account.call.user_defined_messageDeleted();
  block(matchAddApi.v2010.account.call.user_defined_message(e.id, ANY), function () {
    verifyApi.v2010.account.call.user_defined_messageDoesNotExist(e.id);
  });
});

bthread("Message_enum_direction create verification", function () {
  const e = waitForAnyMessage_enum_directionAdded();
  block(matchDeleteMessage_enum_direction(e.id, ANY), function () {
    verifyMessage_enum_directionExists(e.id);
  });
});

bthread("Message_enum_direction update verification", function () {
  const e = waitForAnyMessage_enum_directionUpdated();
  block(matchDeleteMessage_enum_direction(e.id, ANY), function () {
    verifyMessage_enum_directionUpdated(e.id);
  });
});

bthread("Message_enum_direction delete verification", function () {
  const e = waitForAnyMessage_enum_directionDeleted();
  block(matchAddMessage_enum_direction(e.id, ANY), function () {
    verifyMessage_enum_directionDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_address_requirement create verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_address_requirementAdded();
  block(matchDeleteIncoming_phone_number_local_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_address_requirementExists(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_address_requirement update verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_address_requirementUpdated();
  block(matchDeleteIncoming_phone_number_local_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_address_requirementUpdated(e.id);
  });
});

bthread("Incoming_phone_number_local_enum_address_requirement delete verification", function () {
  const e = waitForAnyIncoming_phone_number_local_enum_address_requirementDeleted();
  block(matchAddIncoming_phone_number_local_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_local_enum_address_requirementDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_today create verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_todayAdded();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_today(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_todayExists(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_today update verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_todayUpdated();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_today(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_todayUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_today delete verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_todayDeleted();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_today(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_todayDoesNotExist(e.id);
  });
});

bthread("Conference_enum_reason_conference_ended create verification", function () {
  const e = waitForAnyConference_enum_reason_conference_endedAdded();
  block(matchDeleteConference_enum_reason_conference_ended(e.id, ANY), function () {
    verifyConference_enum_reason_conference_endedExists(e.id);
  });
});

bthread("Conference_enum_reason_conference_ended update verification", function () {
  const e = waitForAnyConference_enum_reason_conference_endedUpdated();
  block(matchDeleteConference_enum_reason_conference_ended(e.id, ANY), function () {
    verifyConference_enum_reason_conference_endedUpdated(e.id);
  });
});

bthread("Conference_enum_reason_conference_ended delete verification", function () {
  const e = waitForAnyConference_enum_reason_conference_endedDeleted();
  block(matchAddConference_enum_reason_conference_ended(e.id, ANY), function () {
    verifyConference_enum_reason_conference_endedDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_address_requirement create verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_address_requirementAdded();
  block(matchDeleteIncoming_phone_number_toll_free_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_address_requirementExists(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_address_requirement update verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_address_requirementUpdated();
  block(matchDeleteIncoming_phone_number_toll_free_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_address_requirementUpdated(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_address_requirement delete verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_address_requirementDeleted();
  block(matchAddIncoming_phone_number_toll_free_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_address_requirementDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.call.realtime_transcription create verification", function () {
  const e = waitForAnyApi.v2010.account.call.realtime_transcriptionAdded();
  block(matchDeleteApi.v2010.account.call.realtime_transcription(e.id, ANY), function () {
    verifyApi.v2010.account.call.realtime_transcriptionExists(e.id);
  });
});

bthread("Api.v2010.account.call.realtime_transcription update verification", function () {
  const e = waitForAnyApi.v2010.account.call.realtime_transcriptionUpdated();
  block(matchDeleteApi.v2010.account.call.realtime_transcription(e.id, ANY), function () {
    verifyApi.v2010.account.call.realtime_transcriptionUpdated(e.id);
  });
});

bthread("Api.v2010.account.call.realtime_transcription delete verification", function () {
  const e = waitForAnyApi.v2010.account.call.realtime_transcriptionDeleted();
  block(matchAddApi.v2010.account.call.realtime_transcription(e.id, ANY), function () {
    verifyApi.v2010.account.call.realtime_transcriptionDoesNotExist(e.id);
  });
});

bthread("Message_enum_update_status create verification", function () {
  const e = waitForAnyMessage_enum_update_statusAdded();
  block(matchDeleteMessage_enum_update_status(e.id, ANY), function () {
    verifyMessage_enum_update_statusExists(e.id);
  });
});

bthread("Message_enum_update_status update verification", function () {
  const e = waitForAnyMessage_enum_update_statusUpdated();
  block(matchDeleteMessage_enum_update_status(e.id, ANY), function () {
    verifyMessage_enum_update_statusUpdated(e.id);
  });
});

bthread("Message_enum_update_status delete verification", function () {
  const e = waitForAnyMessage_enum_update_statusDeleted();
  block(matchAddMessage_enum_update_status(e.id, ANY), function () {
    verifyMessage_enum_update_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number create verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_numberAdded();
  block(matchDeleteApi.v2010.account.incoming_phone_number(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_numberExists(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number update verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_numberUpdated();
  block(matchDeleteApi.v2010.account.incoming_phone_number(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_numberUpdated(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number delete verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_numberDeleted();
  block(matchAddApi.v2010.account.incoming_phone_number(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_numberDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.call.call_notification-instance create verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_notification-instanceAdded();
  block(matchDeleteApi.v2010.account.call.call_notification-instance(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_notification-instanceExists(e.id);
  });
});

bthread("Api.v2010.account.call.call_notification-instance update verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_notification-instanceUpdated();
  block(matchDeleteApi.v2010.account.call.call_notification-instance(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_notification-instanceUpdated(e.id);
  });
});

bthread("Api.v2010.account.call.call_notification-instance delete verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_notification-instanceDeleted();
  block(matchAddApi.v2010.account.call.call_notification-instance(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_notification-instanceDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.call.call_recording create verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_recordingAdded();
  block(matchDeleteApi.v2010.account.call.call_recording(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_recordingExists(e.id);
  });
});

bthread("Api.v2010.account.call.call_recording update verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_recordingUpdated();
  block(matchDeleteApi.v2010.account.call.call_recording(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_recordingUpdated(e.id);
  });
});

bthread("Api.v2010.account.call.call_recording delete verification", function () {
  const e = waitForAnyApi.v2010.account.call.call_recordingDeleted();
  block(matchAddApi.v2010.account.call.call_recording(e.id, ANY), function () {
    verifyApi.v2010.account.call.call_recordingDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip create verification", function () {
  const e = waitForAnyApi.v2010.account.sipAdded();
  block(matchDeleteApi.v2010.account.sip(e.id, ANY), function () {
    verifyApi.v2010.account.sipExists(e.id);
  });
});

bthread("Api.v2010.account.sip update verification", function () {
  const e = waitForAnyApi.v2010.account.sipUpdated();
  block(matchDeleteApi.v2010.account.sip(e.id, ANY), function () {
    verifyApi.v2010.account.sipUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip delete verification", function () {
  const e = waitForAnyApi.v2010.account.sipDeleted();
  block(matchAddApi.v2010.account.sip(e.id, ANY), function () {
    verifyApi.v2010.account.sipDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.message create verification", function () {
  const e = waitForAnyApi.v2010.account.messageAdded();
  block(matchDeleteApi.v2010.account.message(e.id, ANY), function () {
    verifyApi.v2010.account.messageExists(e.id);
  });
});

bthread("Api.v2010.account.message update verification", function () {
  const e = waitForAnyApi.v2010.account.messageUpdated();
  block(matchDeleteApi.v2010.account.message(e.id, ANY), function () {
    verifyApi.v2010.account.messageUpdated(e.id);
  });
});

bthread("Api.v2010.account.message delete verification", function () {
  const e = waitForAnyApi.v2010.account.messageDeleted();
  block(matchAddApi.v2010.account.message(e.id, ANY), function () {
    verifyApi.v2010.account.messageDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_enum_address_requirement create verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_address_requirementAdded();
  block(matchDeleteIncoming_phone_number_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_address_requirementExists(e.id);
  });
});

bthread("Incoming_phone_number_enum_address_requirement update verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_address_requirementUpdated();
  block(matchDeleteIncoming_phone_number_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_address_requirementUpdated(e.id);
  });
});

bthread("Incoming_phone_number_enum_address_requirement delete verification", function () {
  const e = waitForAnyIncoming_phone_number_enum_address_requirementDeleted();
  block(matchAddIncoming_phone_number_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_enum_address_requirementDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.queue.member create verification", function () {
  const e = waitForAnyApi.v2010.account.queue.memberAdded();
  block(matchDeleteApi.v2010.account.queue.member(e.id, ANY), function () {
    verifyApi.v2010.account.queue.memberExists(e.id);
  });
});

bthread("Api.v2010.account.queue.member update verification", function () {
  const e = waitForAnyApi.v2010.account.queue.memberUpdated();
  block(matchDeleteApi.v2010.account.queue.member(e.id, ANY), function () {
    verifyApi.v2010.account.queue.memberUpdated(e.id);
  });
});

bthread("Api.v2010.account.queue.member delete verification", function () {
  const e = waitForAnyApi.v2010.account.queue.memberDeleted();
  block(matchAddApi.v2010.account.queue.member(e.id, ANY), function () {
    verifyApi.v2010.account.queue.memberDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_credential_list.sip_credential create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_credential_list.sip_credentialAdded();
  block(matchDeleteApi.v2010.account.sip.sip_credential_list.sip_credential(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_credential_list.sip_credentialExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_credential_list.sip_credential update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_credential_list.sip_credentialUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_credential_list.sip_credential(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_credential_list.sip_credentialUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_credential_list.sip_credential delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_credential_list.sip_credentialDeleted();
  block(matchAddApi.v2010.account.sip.sip_credential_list.sip_credential(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_credential_list.sip_credentialDoesNotExist(e.id);
  });
});

bthread("Participant_enum_status create verification", function () {
  const e = waitForAnyParticipant_enum_statusAdded();
  block(matchDeleteParticipant_enum_status(e.id, ANY), function () {
    verifyParticipant_enum_statusExists(e.id);
  });
});

bthread("Participant_enum_status update verification", function () {
  const e = waitForAnyParticipant_enum_statusUpdated();
  block(matchDeleteParticipant_enum_status(e.id, ANY), function () {
    verifyParticipant_enum_statusUpdated(e.id);
  });
});

bthread("Participant_enum_status delete verification", function () {
  const e = waitForAnyParticipant_enum_statusDeleted();
  block(matchAddParticipant_enum_status(e.id, ANY), function () {
    verifyParticipant_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.queue create verification", function () {
  const e = waitForAnyApi.v2010.account.queueAdded();
  block(matchDeleteApi.v2010.account.queue(e.id, ANY), function () {
    verifyApi.v2010.account.queueExists(e.id);
  });
});

bthread("Api.v2010.account.queue update verification", function () {
  const e = waitForAnyApi.v2010.account.queueUpdated();
  block(matchDeleteApi.v2010.account.queue(e.id, ANY), function () {
    verifyApi.v2010.account.queueUpdated(e.id);
  });
});

bthread("Api.v2010.account.queue delete verification", function () {
  const e = waitForAnyApi.v2010.account.queueDeleted();
  block(matchAddApi.v2010.account.queue(e.id, ANY), function () {
    verifyApi.v2010.account.queueDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country create verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_countryAdded();
  block(matchDeleteApi.v2010.account.available_phone_number_country(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_countryExists(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country update verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_countryUpdated();
  block(matchDeleteApi.v2010.account.available_phone_number_country(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_countryUpdated(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country delete verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_countryDeleted();
  block(matchAddApi.v2010.account.available_phone_number_country(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_countryDoesNotExist(e.id);
  });
});

bthread("Siprec_enum_status create verification", function () {
  const e = waitForAnySiprec_enum_statusAdded();
  block(matchDeleteSiprec_enum_status(e.id, ANY), function () {
    verifySiprec_enum_statusExists(e.id);
  });
});

bthread("Siprec_enum_status update verification", function () {
  const e = waitForAnySiprec_enum_statusUpdated();
  block(matchDeleteSiprec_enum_status(e.id, ANY), function () {
    verifySiprec_enum_statusUpdated(e.id);
  });
});

bthread("Siprec_enum_status delete verification", function () {
  const e = waitForAnySiprec_enum_statusDeleted();
  block(matchAddSiprec_enum_status(e.id, ANY), function () {
    verifySiprec_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.address.dependent_phone_number create verification", function () {
  const e = waitForAnyApi.v2010.account.address.dependent_phone_numberAdded();
  block(matchDeleteApi.v2010.account.address.dependent_phone_number(e.id, ANY), function () {
    verifyApi.v2010.account.address.dependent_phone_numberExists(e.id);
  });
});

bthread("Api.v2010.account.address.dependent_phone_number update verification", function () {
  const e = waitForAnyApi.v2010.account.address.dependent_phone_numberUpdated();
  block(matchDeleteApi.v2010.account.address.dependent_phone_number(e.id, ANY), function () {
    verifyApi.v2010.account.address.dependent_phone_numberUpdated(e.id);
  });
});

bthread("Api.v2010.account.address.dependent_phone_number delete verification", function () {
  const e = waitForAnyApi.v2010.account.address.dependent_phone_numberDeleted();
  block(matchAddApi.v2010.account.address.dependent_phone_number(e.id, ANY), function () {
    verifyApi.v2010.account.address.dependent_phone_numberDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mappingAdded();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mappingExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mappingUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mappingUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mappingDeleted();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mappingDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_yesterday create verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_yesterdayAdded();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_yesterday(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_yesterdayExists(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_yesterday update verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_yesterdayUpdated();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_yesterday(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_yesterdayUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_yesterday delete verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_yesterdayDeleted();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_yesterday(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_yesterdayDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_voip create verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_voipAdded();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_voip(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_voipExists(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_voip update verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_voipUpdated();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_voip(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_voipUpdated(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_voip delete verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_voipDeleted();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_voip(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_voipDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_national create verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_nationalAdded();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_national(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_nationalExists(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_national update verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_nationalUpdated();
  block(matchDeleteApi.v2010.account.available_phone_number_country.available_phone_number_national(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_nationalUpdated(e.id);
  });
});

bthread("Api.v2010.account.available_phone_number_country.available_phone_number_national delete verification", function () {
  const e = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_nationalDeleted();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_national(e.id, ANY), function () {
    verifyApi.v2010.account.available_phone_number_country.available_phone_number_nationalDoesNotExist(e.id);
  });
});

bthread("Sms_message_enum_status create verification", function () {
  const e = waitForAnySms_message_enum_statusAdded();
  block(matchDeleteSms_message_enum_status(e.id, ANY), function () {
    verifySms_message_enum_statusExists(e.id);
  });
});

bthread("Sms_message_enum_status update verification", function () {
  const e = waitForAnySms_message_enum_statusUpdated();
  block(matchDeleteSms_message_enum_status(e.id, ANY), function () {
    verifySms_message_enum_statusUpdated(e.id);
  });
});

bthread("Sms_message_enum_status delete verification", function () {
  const e = waitForAnySms_message_enum_statusDeleted();
  block(matchAddSms_message_enum_status(e.id, ANY), function () {
    verifySms_message_enum_statusDoesNotExist(e.id);
  });
});

bthread("Stream_enum_status create verification", function () {
  const e = waitForAnyStream_enum_statusAdded();
  block(matchDeleteStream_enum_status(e.id, ANY), function () {
    verifyStream_enum_statusExists(e.id);
  });
});

bthread("Stream_enum_status update verification", function () {
  const e = waitForAnyStream_enum_statusUpdated();
  block(matchDeleteStream_enum_status(e.id, ANY), function () {
    verifyStream_enum_statusUpdated(e.id);
  });
});

bthread("Stream_enum_status delete verification", function () {
  const e = waitForAnyStream_enum_statusDeleted();
  block(matchAddStream_enum_status(e.id, ANY), function () {
    verifyStream_enum_statusDoesNotExist(e.id);
  });
});

bthread("Recording_enum_source create verification", function () {
  const e = waitForAnyRecording_enum_sourceAdded();
  block(matchDeleteRecording_enum_source(e.id, ANY), function () {
    verifyRecording_enum_sourceExists(e.id);
  });
});

bthread("Recording_enum_source update verification", function () {
  const e = waitForAnyRecording_enum_sourceUpdated();
  block(matchDeleteRecording_enum_source(e.id, ANY), function () {
    verifyRecording_enum_sourceUpdated(e.id);
  });
});

bthread("Recording_enum_source delete verification", function () {
  const e = waitForAnyRecording_enum_sourceDeleted();
  block(matchAddRecording_enum_source(e.id, ANY), function () {
    verifyRecording_enum_sourceDoesNotExist(e.id);
  });
});

bthread("Payments_enum_status create verification", function () {
  const e = waitForAnyPayments_enum_statusAdded();
  block(matchDeletePayments_enum_status(e.id, ANY), function () {
    verifyPayments_enum_statusExists(e.id);
  });
});

bthread("Payments_enum_status update verification", function () {
  const e = waitForAnyPayments_enum_statusUpdated();
  block(matchDeletePayments_enum_status(e.id, ANY), function () {
    verifyPayments_enum_statusUpdated(e.id);
  });
});

bthread("Payments_enum_status delete verification", function () {
  const e = waitForAnyPayments_enum_statusDeleted();
  block(matchAddPayments_enum_status(e.id, ANY), function () {
    verifyPayments_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_ip_access_control_list create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_ip_access_control_listAdded();
  block(matchDeleteApi.v2010.account.sip.sip_ip_access_control_list(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_ip_access_control_listExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_ip_access_control_list update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_ip_access_control_listUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_ip_access_control_list(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_ip_access_control_listUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_ip_access_control_list delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_ip_access_control_listDeleted();
  block(matchAddApi.v2010.account.sip.sip_ip_access_control_list(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_ip_access_control_listDoesNotExist(e.id);
  });
});

bthread("Siprec_enum_track create verification", function () {
  const e = waitForAnySiprec_enum_trackAdded();
  block(matchDeleteSiprec_enum_track(e.id, ANY), function () {
    verifySiprec_enum_trackExists(e.id);
  });
});

bthread("Siprec_enum_track update verification", function () {
  const e = waitForAnySiprec_enum_trackUpdated();
  block(matchDeleteSiprec_enum_track(e.id, ANY), function () {
    verifySiprec_enum_trackUpdated(e.id);
  });
});

bthread("Siprec_enum_track delete verification", function () {
  const e = waitForAnySiprec_enum_trackDeleted();
  block(matchAddSiprec_enum_track(e.id, ANY), function () {
    verifySiprec_enum_trackDoesNotExist(e.id);
  });
});

bthread("Payments_enum_token_type create verification", function () {
  const e = waitForAnyPayments_enum_token_typeAdded();
  block(matchDeletePayments_enum_token_type(e.id, ANY), function () {
    verifyPayments_enum_token_typeExists(e.id);
  });
});

bthread("Payments_enum_token_type update verification", function () {
  const e = waitForAnyPayments_enum_token_typeUpdated();
  block(matchDeletePayments_enum_token_type(e.id, ANY), function () {
    verifyPayments_enum_token_typeUpdated(e.id);
  });
});

bthread("Payments_enum_token_type delete verification", function () {
  const e = waitForAnyPayments_enum_token_typeDeleted();
  block(matchAddPayments_enum_token_type(e.id, ANY), function () {
    verifyPayments_enum_token_typeDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_local create verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_localAdded();
  block(matchDeleteApi.v2010.account.incoming_phone_number.incoming_phone_number_local(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_localExists(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_local update verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_localUpdated();
  block(matchDeleteApi.v2010.account.incoming_phone_number.incoming_phone_number_local(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_localUpdated(e.id);
  });
});

bthread("Api.v2010.account.incoming_phone_number.incoming_phone_number_local delete verification", function () {
  const e = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_localDeleted();
  block(matchAddApi.v2010.account.incoming_phone_number.incoming_phone_number_local(e.id, ANY), function () {
    verifyApi.v2010.account.incoming_phone_number.incoming_phone_number_localDoesNotExist(e.id);
  });
});

bthread("Siprec_enum_update_status create verification", function () {
  const e = waitForAnySiprec_enum_update_statusAdded();
  block(matchDeleteSiprec_enum_update_status(e.id, ANY), function () {
    verifySiprec_enum_update_statusExists(e.id);
  });
});

bthread("Siprec_enum_update_status update verification", function () {
  const e = waitForAnySiprec_enum_update_statusUpdated();
  block(matchDeleteSiprec_enum_update_status(e.id, ANY), function () {
    verifySiprec_enum_update_statusUpdated(e.id);
  });
});

bthread("Siprec_enum_update_status delete verification", function () {
  const e = waitForAnySiprec_enum_update_statusDeleted();
  block(matchAddSiprec_enum_update_status(e.id, ANY), function () {
    verifySiprec_enum_update_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.application create verification", function () {
  const e = waitForAnyApi.v2010.account.applicationAdded();
  block(matchDeleteApi.v2010.account.application(e.id, ANY), function () {
    verifyApi.v2010.account.applicationExists(e.id);
  });
});

bthread("Api.v2010.account.application update verification", function () {
  const e = waitForAnyApi.v2010.account.applicationUpdated();
  block(matchDeleteApi.v2010.account.application(e.id, ANY), function () {
    verifyApi.v2010.account.applicationUpdated(e.id);
  });
});

bthread("Api.v2010.account.application delete verification", function () {
  const e = waitForAnyApi.v2010.account.applicationDeleted();
  block(matchAddApi.v2010.account.application(e.id, ANY), function () {
    verifyApi.v2010.account.applicationDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record create verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_recordAdded();
  block(matchDeleteApi.v2010.account.usage.usage_record(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_recordExists(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record update verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_recordUpdated();
  block(matchDeleteApi.v2010.account.usage.usage_record(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_recordUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record delete verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_recordDeleted();
  block(matchAddApi.v2010.account.usage.usage_record(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_recordDoesNotExist(e.id);
  });
});

bthread("Transcription_enum_status create verification", function () {
  const e = waitForAnyTranscription_enum_statusAdded();
  block(matchDeleteTranscription_enum_status(e.id, ANY), function () {
    verifyTranscription_enum_statusExists(e.id);
  });
});

bthread("Transcription_enum_status update verification", function () {
  const e = waitForAnyTranscription_enum_statusUpdated();
  block(matchDeleteTranscription_enum_status(e.id, ANY), function () {
    verifyTranscription_enum_statusUpdated(e.id);
  });
});

bthread("Transcription_enum_status delete verification", function () {
  const e = waitForAnyTranscription_enum_statusDeleted();
  block(matchAddTranscription_enum_status(e.id, ANY), function () {
    verifyTranscription_enum_statusDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account create verification", function () {
  const e = waitForAnyApi.v2010.accountAdded();
  block(matchDeleteApi.v2010.account(e.id, ANY), function () {
    verifyApi.v2010.accountExists(e.id);
  });
});

bthread("Api.v2010.account update verification", function () {
  const e = waitForAnyApi.v2010.accountUpdated();
  block(matchDeleteApi.v2010.account(e.id, ANY), function () {
    verifyApi.v2010.accountUpdated(e.id);
  });
});

bthread("Api.v2010.account delete verification", function () {
  const e = waitForAnyApi.v2010.accountDeleted();
  block(matchAddApi.v2010.account(e.id, ANY), function () {
    verifyApi.v2010.accountDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_voice_receive_mode create verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_voice_receive_modeAdded();
  block(matchDeleteIncoming_phone_number_toll_free_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_voice_receive_modeExists(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_voice_receive_mode update verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_voice_receive_modeUpdated();
  block(matchDeleteIncoming_phone_number_toll_free_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_voice_receive_modeUpdated(e.id);
  });
});

bthread("Incoming_phone_number_toll_free_enum_voice_receive_mode delete verification", function () {
  const e = waitForAnyIncoming_phone_number_toll_free_enum_voice_receive_modeDeleted();
  block(matchAddIncoming_phone_number_toll_free_enum_voice_receive_mode(e.id, ANY), function () {
    verifyIncoming_phone_number_toll_free_enum_voice_receive_modeDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.call create verification", function () {
  const e = waitForAnyApi.v2010.account.callAdded();
  block(matchDeleteApi.v2010.account.call(e.id, ANY), function () {
    verifyApi.v2010.account.callExists(e.id);
  });
});

bthread("Api.v2010.account.call update verification", function () {
  const e = waitForAnyApi.v2010.account.callUpdated();
  block(matchDeleteApi.v2010.account.call(e.id, ANY), function () {
    verifyApi.v2010.account.callUpdated(e.id);
  });
});

bthread("Api.v2010.account.call delete verification", function () {
  const e = waitForAnyApi.v2010.account.callDeleted();
  block(matchAddApi.v2010.account.call(e.id, ANY), function () {
    verifyApi.v2010.account.callDoesNotExist(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_address_requirement create verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_address_requirementAdded();
  block(matchDeleteIncoming_phone_number_mobile_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_address_requirementExists(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_address_requirement update verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_address_requirementUpdated();
  block(matchDeleteIncoming_phone_number_mobile_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_address_requirementUpdated(e.id);
  });
});

bthread("Incoming_phone_number_mobile_enum_address_requirement delete verification", function () {
  const e = waitForAnyIncoming_phone_number_mobile_enum_address_requirementDeleted();
  block(matchAddIncoming_phone_number_mobile_enum_address_requirement(e.id, ANY), function () {
    verifyIncoming_phone_number_mobile_enum_address_requirementDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload create verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payloadAdded();
  block(matchDeleteApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payloadExists(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload update verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payloadUpdated();
  block(matchDeleteApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payloadUpdated(e.id);
  });
});

bthread("Api.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload delete verification", function () {
  const e = waitForAnyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payloadDeleted();
  block(matchAddApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload(e.id, ANY), function () {
    verifyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payloadDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.new_key create verification", function () {
  const e = waitForAnyApi.v2010.account.new_keyAdded();
  block(matchDeleteApi.v2010.account.new_key(e.id, ANY), function () {
    verifyApi.v2010.account.new_keyExists(e.id);
  });
});

bthread("Api.v2010.account.new_key update verification", function () {
  const e = waitForAnyApi.v2010.account.new_keyUpdated();
  block(matchDeleteApi.v2010.account.new_key(e.id, ANY), function () {
    verifyApi.v2010.account.new_keyUpdated(e.id);
  });
});

bthread("Api.v2010.account.new_key delete verification", function () {
  const e = waitForAnyApi.v2010.account.new_keyDeleted();
  block(matchAddApi.v2010.account.new_key(e.id, ANY), function () {
    verifyApi.v2010.account.new_keyDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_daily create verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_dailyAdded();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_daily(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_dailyExists(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_daily update verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_dailyUpdated();
  block(matchDeleteApi.v2010.account.usage.usage_record.usage_record_daily(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_dailyUpdated(e.id);
  });
});

bthread("Api.v2010.account.usage.usage_record.usage_record_daily delete verification", function () {
  const e = waitForAnyApi.v2010.account.usage.usage_record.usage_record_dailyDeleted();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_daily(e.id, ANY), function () {
    verifyApi.v2010.account.usage.usage_record.usage_record_dailyDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_ip_access_control_list.sip_ip_address create verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_addressAdded();
  block(matchDeleteApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_address(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_addressExists(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_ip_access_control_list.sip_ip_address update verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_addressUpdated();
  block(matchDeleteApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_address(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_addressUpdated(e.id);
  });
});

bthread("Api.v2010.account.sip.sip_ip_access_control_list.sip_ip_address delete verification", function () {
  const e = waitForAnyApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_addressDeleted();
  block(matchAddApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_address(e.id, ANY), function () {
    verifyApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_addressDoesNotExist(e.id);
  });
});

bthread("Api.v2010.account.call.siprec create verification", function () {
  const e = waitForAnyApi.v2010.account.call.siprecAdded();
  block(matchDeleteApi.v2010.account.call.siprec(e.id, ANY), function () {
    verifyApi.v2010.account.call.siprecExists(e.id);
  });
});

bthread("Api.v2010.account.call.siprec update verification", function () {
  const e = waitForAnyApi.v2010.account.call.siprecUpdated();
  block(matchDeleteApi.v2010.account.call.siprec(e.id, ANY), function () {
    verifyApi.v2010.account.call.siprecUpdated(e.id);
  });
});

bthread("Api.v2010.account.call.siprec delete verification", function () {
  const e = waitForAnyApi.v2010.account.call.siprecDeleted();
  block(matchAddApi.v2010.account.call.siprec(e.id, ANY), function () {
    verifyApi.v2010.account.call.siprecDoesNotExist(e.id);
  });
});

// ===== RELATIONSHIP GUARDS =====

// ===== UNIQUENESS GUARDS =====

bthread("Guard: Unique Api.v2010.account.call.stream", function () {
  const x = waitForAnyApi.v2010.account.call.streamAdded();
  block(matchAddApi.v2010.account.call.stream(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.authorized_connect_app", function () {
  const x = waitForAnyApi.v2010.account.authorized_connect_appAdded();
  block(matchAddApi.v2010.account.authorized_connect_app(x.id, ANY), function () {});
});

bthread("Guard: Unique Message_enum_schedule_type", function () {
  const x = waitForAnyMessage_enum_schedule_typeAdded();
  block(matchAddMessage_enum_schedule_type(x.id, ANY), function () {});
});

bthread("Guard: Unique Realtime_transcription_enum_update_status", function () {
  const x = waitForAnyRealtime_transcription_enum_update_statusAdded();
  block(matchAddRealtime_transcription_enum_update_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Recording_enum_status", function () {
  const x = waitForAnyRecording_enum_statusAdded();
  block(matchAddRecording_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Account_enum_type", function () {
  const x = waitForAnyAccount_enum_typeAdded();
  block(matchAddAccount_enum_type(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_enum_voice_receive_mode", function () {
  const x = waitForAnyIncoming_phone_number_enum_voice_receive_modeAdded();
  block(matchAddIncoming_phone_number_enum_voice_receive_mode(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.recording.recording_transcription", function () {
  const x = waitForAnyApi.v2010.account.recording.recording_transcriptionAdded();
  block(matchAddApi.v2010.account.recording.recording_transcription(x.id, ANY), function () {});
});

bthread("Guard: Unique Recording_add_on_result_enum_status", function () {
  const x = waitForAnyRecording_add_on_result_enum_statusAdded();
  block(matchAddRecording_add_on_result_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.notification-instance", function () {
  const x = waitForAnyApi.v2010.account.notification-instanceAdded();
  block(matchAddApi.v2010.account.notification-instance(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage.usage_record.usage_record_monthly", function () {
  const x = waitForAnyApi.v2010.account.usage.usage_record.usage_record_monthlyAdded();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_monthly(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data", function () {
  const x = waitForAnyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_dataAdded();
  block(matchAddApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload.recording_add_on_result_payload_data(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.available_phone_number_country.available_phone_number_local", function () {
  const x = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_localAdded();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_local(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_local_enum_emergency_status", function () {
  const x = waitForAnyIncoming_phone_number_local_enum_emergency_statusAdded();
  block(matchAddIncoming_phone_number_local_enum_emergency_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Connect_app_enum_permission", function () {
  const x = waitForAnyConnect_app_enum_permissionAdded();
  block(matchAddConnect_app_enum_permission(x.id, ANY), function () {});
});

bthread("Guard: Unique Sms_feedback_enum_outcome", function () {
  const x = waitForAnySms_feedback_enum_outcomeAdded();
  block(matchAddSms_feedback_enum_outcome(x.id, ANY), function () {});
});

bthread("Guard: Unique Message_feedback_enum_outcome", function () {
  const x = waitForAnyMessage_feedback_enum_outcomeAdded();
  block(matchAddMessage_feedback_enum_outcome(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.recording", function () {
  const x = waitForAnyApi.v2010.account.recordingAdded();
  block(matchAddApi.v2010.account.recording(x.id, ANY), function () {});
});

bthread("Guard: Unique Stream_enum_update_status", function () {
  const x = waitForAnyStream_enum_update_statusAdded();
  block(matchAddStream_enum_update_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Sms_message_enum_direction", function () {
  const x = waitForAnySms_message_enum_directionAdded();
  block(matchAddSms_message_enum_direction(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.message.message_feedback", function () {
  const x = waitForAnyApi.v2010.account.message.message_feedbackAdded();
  block(matchAddApi.v2010.account.message.message_feedback(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_toll_free_enum_emergency_status", function () {
  const x = waitForAnyIncoming_phone_number_toll_free_enum_emergency_statusAdded();
  block(matchAddIncoming_phone_number_toll_free_enum_emergency_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine", function () {
  const x = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machineAdded();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_machine_to_machine(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.connect_app", function () {
  const x = waitForAnyApi.v2010.account.connect_appAdded();
  block(matchAddApi.v2010.account.connect_app(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_enum_emergency_status", function () {
  const x = waitForAnyIncoming_phone_number_enum_emergency_statusAdded();
  block(matchAddIncoming_phone_number_enum_emergency_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Call_recording_enum_status", function () {
  const x = waitForAnyCall_recording_enum_statusAdded();
  block(matchAddCall_recording_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.token", function () {
  const x = waitForAnyApi.v2010.account.tokenAdded();
  block(matchAddApi.v2010.account.token(x.id, ANY), function () {});
});

bthread("Guard: Unique Payments_enum_bank_account_type", function () {
  const x = waitForAnyPayments_enum_bank_account_typeAdded();
  block(matchAddPayments_enum_bank_account_type(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.call.call_notification", function () {
  const x = waitForAnyApi.v2010.account.call.call_notificationAdded();
  block(matchAddApi.v2010.account.call.call_notification(x.id, ANY), function () {});
});

bthread("Guard: Unique Conference_recording_enum_source", function () {
  const x = waitForAnyConference_recording_enum_sourceAdded();
  block(matchAddConference_recording_enum_source(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mappingAdded();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_ip_access_control_list_mapping(x.id, ANY), function () {});
});

bthread("Guard: Unique Account_enum_status", function () {
  const x = waitForAnyAccount_enum_statusAdded();
  block(matchAddAccount_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.transcription", function () {
  const x = waitForAnyApi.v2010.account.transcriptionAdded();
  block(matchAddApi.v2010.account.transcription(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_local_enum_voice_receive_mode", function () {
  const x = waitForAnyIncoming_phone_number_local_enum_voice_receive_modeAdded();
  block(matchAddIncoming_phone_number_local_enum_voice_receive_mode(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.available_phone_number_country.available_phone_number_mobile", function () {
  const x = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_mobileAdded();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_mobile(x.id, ANY), function () {});
});

bthread("Guard: Unique Conference_recording_enum_status", function () {
  const x = waitForAnyConference_recording_enum_statusAdded();
  block(matchAddConference_recording_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Message_enum_address_retention", function () {
  const x = waitForAnyMessage_enum_address_retentionAdded();
  block(matchAddMessage_enum_address_retention(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.available_phone_number_country.available_phone_number_shared_cost", function () {
  const x = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_shared_costAdded();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_shared_cost(x.id, ANY), function () {});
});

bthread("Guard: Unique Call_recording_enum_source", function () {
  const x = waitForAnyCall_recording_enum_sourceAdded();
  block(matchAddCall_recording_enum_source(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension", function () {
  const x = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extensionAdded();
  block(matchAddApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on.incoming_phone_number_assigned_add_on_extension(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_local_enum_emergency_address_status", function () {
  const x = waitForAnyIncoming_phone_number_local_enum_emergency_address_statusAdded();
  block(matchAddIncoming_phone_number_local_enum_emergency_address_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.call.user_defined_message_subscription", function () {
  const x = waitForAnyApi.v2010.account.call.user_defined_message_subscriptionAdded();
  block(matchAddApi.v2010.account.call.user_defined_message_subscription(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.call.call_event", function () {
  const x = waitForAnyApi.v2010.account.call.call_eventAdded();
  block(matchAddApi.v2010.account.call.call_event(x.id, ANY), function () {});
});

bthread("Guard: Unique Realtime_transcription_enum_track", function () {
  const x = waitForAnyRealtime_transcription_enum_trackAdded();
  block(matchAddRealtime_transcription_enum_track(x.id, ANY), function () {});
});

bthread("Guard: Unique Usage_trigger_enum_trigger_field", function () {
  const x = waitForAnyUsage_trigger_enum_trigger_fieldAdded();
  block(matchAddUsage_trigger_enum_trigger_field(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_toll_free_enum_emergency_address_status", function () {
  const x = waitForAnyIncoming_phone_number_toll_free_enum_emergency_address_statusAdded();
  block(matchAddIncoming_phone_number_toll_free_enum_emergency_address_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_credential_list", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_credential_listAdded();
  block(matchAddApi.v2010.account.sip.sip_credential_list(x.id, ANY), function () {});
});

bthread("Guard: Unique Message_enum_status", function () {
  const x = waitForAnyMessage_enum_statusAdded();
  block(matchAddMessage_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.incoming_phone_number.incoming_phone_number_mobile", function () {
  const x = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_mobileAdded();
  block(matchAddApi.v2010.account.incoming_phone_number.incoming_phone_number_mobile(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on", function () {
  const x = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_onAdded();
  block(matchAddApi.v2010.account.incoming_phone_number.incoming_phone_number_assigned_add_on(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage.usage_record.usage_record_all_time", function () {
  const x = waitForAnyApi.v2010.account.usage.usage_record.usage_record_all_timeAdded();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_all_time(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_mobile_enum_emergency_address_status", function () {
  const x = waitForAnyIncoming_phone_number_mobile_enum_emergency_address_statusAdded();
  block(matchAddIncoming_phone_number_mobile_enum_emergency_address_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mappingAdded();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations.sip_auth_registrations_credential_list_mapping(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.conference.conference_recording", function () {
  const x = waitForAnyApi.v2010.account.conference.conference_recordingAdded();
  block(matchAddApi.v2010.account.conference.conference_recording(x.id, ANY), function () {});
});

bthread("Guard: Unique Conference_enum_status", function () {
  const x = waitForAnyConference_enum_statusAdded();
  block(matchAddConference_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.notification", function () {
  const x = waitForAnyApi.v2010.account.notificationAdded();
  block(matchAddApi.v2010.account.notification(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mappingAdded();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls.sip_auth_calls_credential_list_mapping(x.id, ANY), function () {});
});

bthread("Guard: Unique Call_enum_update_status", function () {
  const x = waitForAnyCall_enum_update_statusAdded();
  block(matchAddCall_enum_update_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Usage_trigger_enum_recurring", function () {
  const x = waitForAnyUsage_trigger_enum_recurringAdded();
  block(matchAddUsage_trigger_enum_recurring(x.id, ANY), function () {});
});

bthread("Guard: Unique Realtime_transcription_enum_status", function () {
  const x = waitForAnyRealtime_transcription_enum_statusAdded();
  block(matchAddRealtime_transcription_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_mobile_enum_emergency_status", function () {
  const x = waitForAnyIncoming_phone_number_mobile_enum_emergency_statusAdded();
  block(matchAddIncoming_phone_number_mobile_enum_emergency_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.conference.participant", function () {
  const x = waitForAnyApi.v2010.account.conference.participantAdded();
  block(matchAddApi.v2010.account.conference.participant(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.recording.recording_add_on_result", function () {
  const x = waitForAnyApi.v2010.account.recording.recording_add_on_resultAdded();
  block(matchAddApi.v2010.account.recording.recording_add_on_result(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.conference", function () {
  const x = waitForAnyApi.v2010.account.conferenceAdded();
  block(matchAddApi.v2010.account.conference(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage.usage_record.usage_record_yearly", function () {
  const x = waitForAnyApi.v2010.account.usage.usage_record.usage_record_yearlyAdded();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_yearly(x.id, ANY), function () {});
});

bthread("Guard: Unique Recording_transcription_enum_status", function () {
  const x = waitForAnyRecording_transcription_enum_statusAdded();
  block(matchAddRecording_transcription_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_domain.sip_credential_list_mapping", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_domain.sip_credential_list_mappingAdded();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_credential_list_mapping(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.balance", function () {
  const x = waitForAnyApi.v2010.account.balanceAdded();
  block(matchAddApi.v2010.account.balance(x.id, ANY), function () {});
});

bthread("Guard: Unique Authorized_connect_app_enum_permission", function () {
  const x = waitForAnyAuthorized_connect_app_enum_permissionAdded();
  block(matchAddAuthorized_connect_app_enum_permission(x.id, ANY), function () {});
});

bthread("Guard: Unique Conference_enum_update_status", function () {
  const x = waitForAnyConference_enum_update_statusAdded();
  block(matchAddConference_enum_update_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage.usage_record.usage_record_last_month", function () {
  const x = waitForAnyApi.v2010.account.usage.usage_record.usage_record_last_monthAdded();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_last_month(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.new_signing_key", function () {
  const x = waitForAnyApi.v2010.account.new_signing_keyAdded();
  block(matchAddApi.v2010.account.new_signing_key(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.key", function () {
  const x = waitForAnyApi.v2010.account.keyAdded();
  block(matchAddApi.v2010.account.key(x.id, ANY), function () {});
});

bthread("Guard: Unique Dependent_phone_number_enum_emergency_status", function () {
  const x = waitForAnyDependent_phone_number_enum_emergency_statusAdded();
  block(matchAddDependent_phone_number_enum_emergency_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_domain.sip_auth", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_domain.sip_authAdded();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth(x.id, ANY), function () {});
});

bthread("Guard: Unique Message_enum_content_retention", function () {
  const x = waitForAnyMessage_enum_content_retentionAdded();
  block(matchAddMessage_enum_content_retention(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrationsAdded();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_registrations(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage.usage_record.usage_record_this_month", function () {
  const x = waitForAnyApi.v2010.account.usage.usage_record.usage_record_this_monthAdded();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_this_month(x.id, ANY), function () {});
});

bthread("Guard: Unique Call_enum_status", function () {
  const x = waitForAnyCall_enum_statusAdded();
  block(matchAddCall_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_callsAdded();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_auth.sip_auth_calls(x.id, ANY), function () {});
});

bthread("Guard: Unique Message_enum_risk_check", function () {
  const x = waitForAnyMessage_enum_risk_checkAdded();
  block(matchAddMessage_enum_risk_check(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.message.media", function () {
  const x = waitForAnyApi.v2010.account.message.mediaAdded();
  block(matchAddApi.v2010.account.message.media(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.outgoing_caller_id", function () {
  const x = waitForAnyApi.v2010.account.outgoing_caller_idAdded();
  block(matchAddApi.v2010.account.outgoing_caller_id(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage.usage_trigger", function () {
  const x = waitForAnyApi.v2010.account.usage.usage_triggerAdded();
  block(matchAddApi.v2010.account.usage.usage_trigger(x.id, ANY), function () {});
});

bthread("Guard: Unique Dependent_phone_number_enum_address_requirement", function () {
  const x = waitForAnyDependent_phone_number_enum_address_requirementAdded();
  block(matchAddDependent_phone_number_enum_address_requirement(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_mobile_enum_voice_receive_mode", function () {
  const x = waitForAnyIncoming_phone_number_mobile_enum_voice_receive_modeAdded();
  block(matchAddIncoming_phone_number_mobile_enum_voice_receive_mode(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.signing_key", function () {
  const x = waitForAnyApi.v2010.account.signing_keyAdded();
  block(matchAddApi.v2010.account.signing_key(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage", function () {
  const x = waitForAnyApi.v2010.account.usageAdded();
  block(matchAddApi.v2010.account.usage(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.address", function () {
  const x = waitForAnyApi.v2010.account.addressAdded();
  block(matchAddApi.v2010.account.address(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_enum_emergency_address_status", function () {
  const x = waitForAnyIncoming_phone_number_enum_emergency_address_statusAdded();
  block(matchAddIncoming_phone_number_enum_emergency_address_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.call.payments", function () {
  const x = waitForAnyApi.v2010.account.call.paymentsAdded();
  block(matchAddApi.v2010.account.call.payments(x.id, ANY), function () {});
});

bthread("Guard: Unique Message_enum_traffic_type", function () {
  const x = waitForAnyMessage_enum_traffic_typeAdded();
  block(matchAddMessage_enum_traffic_type(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.short_code", function () {
  const x = waitForAnyApi.v2010.account.short_codeAdded();
  block(matchAddApi.v2010.account.short_code(x.id, ANY), function () {});
});

bthread("Guard: Unique Stream_enum_track", function () {
  const x = waitForAnyStream_enum_trackAdded();
  block(matchAddStream_enum_track(x.id, ANY), function () {});
});

bthread("Guard: Unique Payments_enum_payment_method", function () {
  const x = waitForAnyPayments_enum_payment_methodAdded();
  block(matchAddPayments_enum_payment_method(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.available_phone_number_country.available_phone_number_toll_free", function () {
  const x = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_toll_freeAdded();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_toll_free(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.incoming_phone_number.incoming_phone_number_toll_free", function () {
  const x = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_freeAdded();
  block(matchAddApi.v2010.account.incoming_phone_number.incoming_phone_number_toll_free(x.id, ANY), function () {});
});

bthread("Guard: Unique Payments_enum_capture", function () {
  const x = waitForAnyPayments_enum_captureAdded();
  block(matchAddPayments_enum_capture(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.validation_request", function () {
  const x = waitForAnyApi.v2010.account.validation_requestAdded();
  block(matchAddApi.v2010.account.validation_request(x.id, ANY), function () {});
});

bthread("Guard: Unique Call_enum_event", function () {
  const x = waitForAnyCall_enum_eventAdded();
  block(matchAddCall_enum_event(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_domain", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_domainAdded();
  block(matchAddApi.v2010.account.sip.sip_domain(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.call.user_defined_message", function () {
  const x = waitForAnyApi.v2010.account.call.user_defined_messageAdded();
  block(matchAddApi.v2010.account.call.user_defined_message(x.id, ANY), function () {});
});

bthread("Guard: Unique Message_enum_direction", function () {
  const x = waitForAnyMessage_enum_directionAdded();
  block(matchAddMessage_enum_direction(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_local_enum_address_requirement", function () {
  const x = waitForAnyIncoming_phone_number_local_enum_address_requirementAdded();
  block(matchAddIncoming_phone_number_local_enum_address_requirement(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage.usage_record.usage_record_today", function () {
  const x = waitForAnyApi.v2010.account.usage.usage_record.usage_record_todayAdded();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_today(x.id, ANY), function () {});
});

bthread("Guard: Unique Conference_enum_reason_conference_ended", function () {
  const x = waitForAnyConference_enum_reason_conference_endedAdded();
  block(matchAddConference_enum_reason_conference_ended(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_toll_free_enum_address_requirement", function () {
  const x = waitForAnyIncoming_phone_number_toll_free_enum_address_requirementAdded();
  block(matchAddIncoming_phone_number_toll_free_enum_address_requirement(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.call.realtime_transcription", function () {
  const x = waitForAnyApi.v2010.account.call.realtime_transcriptionAdded();
  block(matchAddApi.v2010.account.call.realtime_transcription(x.id, ANY), function () {});
});

bthread("Guard: Unique Message_enum_update_status", function () {
  const x = waitForAnyMessage_enum_update_statusAdded();
  block(matchAddMessage_enum_update_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.incoming_phone_number", function () {
  const x = waitForAnyApi.v2010.account.incoming_phone_numberAdded();
  block(matchAddApi.v2010.account.incoming_phone_number(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.call.call_notification-instance", function () {
  const x = waitForAnyApi.v2010.account.call.call_notification-instanceAdded();
  block(matchAddApi.v2010.account.call.call_notification-instance(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.call.call_recording", function () {
  const x = waitForAnyApi.v2010.account.call.call_recordingAdded();
  block(matchAddApi.v2010.account.call.call_recording(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip", function () {
  const x = waitForAnyApi.v2010.account.sipAdded();
  block(matchAddApi.v2010.account.sip(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.message", function () {
  const x = waitForAnyApi.v2010.account.messageAdded();
  block(matchAddApi.v2010.account.message(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_enum_address_requirement", function () {
  const x = waitForAnyIncoming_phone_number_enum_address_requirementAdded();
  block(matchAddIncoming_phone_number_enum_address_requirement(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.queue.member", function () {
  const x = waitForAnyApi.v2010.account.queue.memberAdded();
  block(matchAddApi.v2010.account.queue.member(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_credential_list.sip_credential", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_credential_list.sip_credentialAdded();
  block(matchAddApi.v2010.account.sip.sip_credential_list.sip_credential(x.id, ANY), function () {});
});

bthread("Guard: Unique Participant_enum_status", function () {
  const x = waitForAnyParticipant_enum_statusAdded();
  block(matchAddParticipant_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.queue", function () {
  const x = waitForAnyApi.v2010.account.queueAdded();
  block(matchAddApi.v2010.account.queue(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.available_phone_number_country", function () {
  const x = waitForAnyApi.v2010.account.available_phone_number_countryAdded();
  block(matchAddApi.v2010.account.available_phone_number_country(x.id, ANY), function () {});
});

bthread("Guard: Unique Siprec_enum_status", function () {
  const x = waitForAnySiprec_enum_statusAdded();
  block(matchAddSiprec_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.address.dependent_phone_number", function () {
  const x = waitForAnyApi.v2010.account.address.dependent_phone_numberAdded();
  block(matchAddApi.v2010.account.address.dependent_phone_number(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mappingAdded();
  block(matchAddApi.v2010.account.sip.sip_domain.sip_ip_access_control_list_mapping(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage.usage_record.usage_record_yesterday", function () {
  const x = waitForAnyApi.v2010.account.usage.usage_record.usage_record_yesterdayAdded();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_yesterday(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.available_phone_number_country.available_phone_number_voip", function () {
  const x = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_voipAdded();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_voip(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.available_phone_number_country.available_phone_number_national", function () {
  const x = waitForAnyApi.v2010.account.available_phone_number_country.available_phone_number_nationalAdded();
  block(matchAddApi.v2010.account.available_phone_number_country.available_phone_number_national(x.id, ANY), function () {});
});

bthread("Guard: Unique Sms_message_enum_status", function () {
  const x = waitForAnySms_message_enum_statusAdded();
  block(matchAddSms_message_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Stream_enum_status", function () {
  const x = waitForAnyStream_enum_statusAdded();
  block(matchAddStream_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Recording_enum_source", function () {
  const x = waitForAnyRecording_enum_sourceAdded();
  block(matchAddRecording_enum_source(x.id, ANY), function () {});
});

bthread("Guard: Unique Payments_enum_status", function () {
  const x = waitForAnyPayments_enum_statusAdded();
  block(matchAddPayments_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_ip_access_control_list", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_ip_access_control_listAdded();
  block(matchAddApi.v2010.account.sip.sip_ip_access_control_list(x.id, ANY), function () {});
});

bthread("Guard: Unique Siprec_enum_track", function () {
  const x = waitForAnySiprec_enum_trackAdded();
  block(matchAddSiprec_enum_track(x.id, ANY), function () {});
});

bthread("Guard: Unique Payments_enum_token_type", function () {
  const x = waitForAnyPayments_enum_token_typeAdded();
  block(matchAddPayments_enum_token_type(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.incoming_phone_number.incoming_phone_number_local", function () {
  const x = waitForAnyApi.v2010.account.incoming_phone_number.incoming_phone_number_localAdded();
  block(matchAddApi.v2010.account.incoming_phone_number.incoming_phone_number_local(x.id, ANY), function () {});
});

bthread("Guard: Unique Siprec_enum_update_status", function () {
  const x = waitForAnySiprec_enum_update_statusAdded();
  block(matchAddSiprec_enum_update_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.application", function () {
  const x = waitForAnyApi.v2010.account.applicationAdded();
  block(matchAddApi.v2010.account.application(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage.usage_record", function () {
  const x = waitForAnyApi.v2010.account.usage.usage_recordAdded();
  block(matchAddApi.v2010.account.usage.usage_record(x.id, ANY), function () {});
});

bthread("Guard: Unique Transcription_enum_status", function () {
  const x = waitForAnyTranscription_enum_statusAdded();
  block(matchAddTranscription_enum_status(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account", function () {
  const x = waitForAnyApi.v2010.accountAdded();
  block(matchAddApi.v2010.account(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_toll_free_enum_voice_receive_mode", function () {
  const x = waitForAnyIncoming_phone_number_toll_free_enum_voice_receive_modeAdded();
  block(matchAddIncoming_phone_number_toll_free_enum_voice_receive_mode(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.call", function () {
  const x = waitForAnyApi.v2010.account.callAdded();
  block(matchAddApi.v2010.account.call(x.id, ANY), function () {});
});

bthread("Guard: Unique Incoming_phone_number_mobile_enum_address_requirement", function () {
  const x = waitForAnyIncoming_phone_number_mobile_enum_address_requirementAdded();
  block(matchAddIncoming_phone_number_mobile_enum_address_requirement(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload", function () {
  const x = waitForAnyApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payloadAdded();
  block(matchAddApi.v2010.account.recording.recording_add_on_result.recording_add_on_result_payload(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.new_key", function () {
  const x = waitForAnyApi.v2010.account.new_keyAdded();
  block(matchAddApi.v2010.account.new_key(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.usage.usage_record.usage_record_daily", function () {
  const x = waitForAnyApi.v2010.account.usage.usage_record.usage_record_dailyAdded();
  block(matchAddApi.v2010.account.usage.usage_record.usage_record_daily(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.sip.sip_ip_access_control_list.sip_ip_address", function () {
  const x = waitForAnyApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_addressAdded();
  block(matchAddApi.v2010.account.sip.sip_ip_access_control_list.sip_ip_address(x.id, ANY), function () {});
});

bthread("Guard: Unique Api.v2010.account.call.siprec", function () {
  const x = waitForAnyApi.v2010.account.call.siprecAdded();
  block(matchAddApi.v2010.account.call.siprec(x.id, ANY), function () {});
});

// ===== NEGATIVE/EDGE STATUS GUARDS =====
