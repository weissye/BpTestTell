@echo off
setlocal EnableExtensions EnableDelayedExpansion

rem --- repo root and venv python (prefer .venv, else fall back to python on PATH)
set "ROOT=%~dp0..\..\.."
set "PY_EXE=%ROOT%\.venv\Scripts\python.exe"
if not exist "%PY_EXE%" set "PY_EXE=python"

rem --- allow overriding the generator path via environment (GEN_PY)
if not defined GEN_PY set "GEN_PY=%ROOT%\scripts\llm\emit_llm_gold_from_openapi.py"
if not exist "%GEN_PY%" for %%F in ("%ROOT%\scripts\llm\emit_llm_gold_from_openapi*.py") do (
  set "GEN_PY=%%~fF"
  goto :got_gen
)
:got_gen
if not exist "%GEN_PY%" (
  echo [ERR] Generator script not found at "%GEN_PY%".
  echo       Set GEN_PY to the correct path, e.g.:
  echo       PowerShell: ^$env:GEN_PY = "C:\work\Yeshayahu\BpTestTell\scripts\llm\emit_llm_gold_from_openapi.py"
  exit /b 1
)

rem --- provider/model with safe defaults (can be overridden from env)
if not defined PROVIDER set "PROVIDER=openai"
if not defined MODEL set "MODEL=gpt-4o-mini"

rem --- flags
set "EXTRA="
if "%FORCE%"=="1" set "EXTRA=%EXTRA% --force"

set /a ATTEMPTED=0, OK=0, FAILED=0

rem === real-world SUTs (unchanged list) ===
for %%S in (
  directus gitea github jira_cloud keycloak_admin meilisearch
  netbox stripe trello twilio zulip
) do (
  set /a ATTEMPTED+=1
  echo(
  echo ==== %%S (REAL-WORLD^) ====
  set "SPEC=%ROOT%\packs\realworld\%%S\openapi.json"
  set "OUT=%ROOT%\artifacts\det_checked\real_world_llm_provider\%%S"

  if not exist "!SPEC!" (
    echo [ERR] Could not locate openapi.json for "%%S".
    set /a FAILED+=1
    goto :continue_loop
  )

  if "%CLEAN%"=="1" (
    if exist "!OUT!" rmdir /s /q "!OUT!"
  )
  if not exist "!OUT!" mkdir "!OUT!" >nul 2>&1

  echo [INFO] CWD=%CD%
  echo [RUN] provider=%PROVIDER%  model=%MODEL%
  echo [RUN] spec="!SPEC!"  out="!OUT!"

  "%PY_EXE%" "%GEN_PY%" --provider "%PROVIDER%" --model "%MODEL%" --spec "!SPEC!" --out "!OUT!" %EXTRA%
  if errorlevel 1 (
    echo [ERR] Generator failed for "%%S".
    echo [WARN] %%S failed.
    set /a FAILED+=1
  ) else (
    echo [OK] %%S
    set /a OK+=1
  )

  :continue_loop
)

echo(
echo [SUMMARY] attempted=%ATTEMPTED%  ok=%OK%  failed=%FAILED%
endlocal
