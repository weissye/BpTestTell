// ====================================================================
// Auto-generated garage-style High-Level Stories (HLS)
// SUT: garage
// ====================================================================

var ANY = (typeof H !== 'undefined' && H.ANY) ? H.ANY : (typeof ANY !== 'undefined' ? ANY : '*');

// ===== ACTIVE LIFECYCLES =====


bthread("Customer lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomer(x.id);
  updateCustomer(x.id);
  updateCustomer(x.id);
  verifyCustomerExists(x.id);
  verifyCustomerUpdated(x.id);
});

bthread("CustomerCreate lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomerCreate(x.id);
  updateCustomerCreate(x.id);
  updateCustomerCreate(x.id);
  verifyCustomerCreateExists(x.id);
  verifyCustomerCreateUpdated(x.id);
});

bthread("Error lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addError(x.id);
  updateError(x.id);
  updateError(x.id);
  verifyErrorExists(x.id);
  verifyErrorUpdated(x.id);
});

bthread("ChainCreate lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addChainCreate(x.id);
  updateChainCreate(x.id);
  updateChainCreate(x.id);
  verifyChainCreateExists(x.id);
  verifyChainCreateUpdated(x.id);
});

bthread("Garage lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGarage(x.id);
  updateGarage(x.id);
  updateGarage(x.id);
  verifyGarageExists(x.id);
  verifyGarageUpdated(x.id);
});

bthread("GarageCreate lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGarageCreate(x.id);
  updateGarageCreate(x.id);
  updateGarageCreate(x.id);
  verifyGarageCreateExists(x.id);
  verifyGarageCreateUpdated(x.id);
});

bthread("ROUpdate lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addROUpdate(x.id);
  updateROUpdate(x.id);
  updateROUpdate(x.id);
  verifyROUpdateExists(x.id);
  verifyROUpdateUpdated(x.id);
});

bthread("ROCreate lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addROCreate(x.id);
  updateROCreate(x.id);
  updateROCreate(x.id);
  verifyROCreateExists(x.id);
  verifyROCreateUpdated(x.id);
});

bthread("ChainUpdate lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addChainUpdate(x.id);
  updateChainUpdate(x.id);
  updateChainUpdate(x.id);
  verifyChainUpdateExists(x.id);
  verifyChainUpdateUpdated(x.id);
});

bthread("GarageUpdate lifecycle", function () {
  const x = pick([{id: "G001"}, {id: "G002"}]);
  addGarageUpdate(x.id);
  updateGarageUpdate(x.id);
  updateGarageUpdate(x.id);
  verifyGarageUpdateExists(x.id);
  verifyGarageUpdateUpdated(x.id);
});

bthread("Chain lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addChain(x.id);
  updateChain(x.id);
  updateChain(x.id);
  verifyChainExists(x.id);
  verifyChainUpdated(x.id);
});

bthread("PMUpdate lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPMUpdate(x.id);
  updatePMUpdate(x.id);
  updatePMUpdate(x.id);
  verifyPMUpdateExists(x.id);
  verifyPMUpdateUpdated(x.id);
});

bthread("CarCreate lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCarCreate(x.id);
  updateCarCreate(x.id);
  updateCarCreate(x.id);
  verifyCarCreateExists(x.id);
  verifyCarCreateUpdated(x.id);
});

bthread("Car lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCar(x.id);
  updateCar(x.id);
  updateCar(x.id);
  verifyCarExists(x.id);
  verifyCarUpdated(x.id);
});

bthread("RepairOrder lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRepairOrder(x.id);
  updateRepairOrder(x.id);
  updateRepairOrder(x.id);
  verifyRepairOrderExists(x.id);
  verifyRepairOrderUpdated(x.id);
});

bthread("CustomerUpdate lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCustomerUpdate(x.id);
  updateCustomerUpdate(x.id);
  updateCustomerUpdate(x.id);
  verifyCustomerUpdateExists(x.id);
  verifyCustomerUpdateUpdated(x.id);
});

bthread("PeriodicMaintenance lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPeriodicMaintenance(x.id);
  updatePeriodicMaintenance(x.id);
  updatePeriodicMaintenance(x.id);
  verifyPeriodicMaintenanceExists(x.id);
  verifyPeriodicMaintenanceUpdated(x.id);
});

bthread("CarUpdate lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCarUpdate(x.id);
  updateCarUpdate(x.id);
  updateCarUpdate(x.id);
  verifyCarUpdateExists(x.id);
  verifyCarUpdateUpdated(x.id);
});

bthread("PMCreate lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPMCreate(x.id);
  updatePMCreate(x.id);
  updatePMCreate(x.id);
  verifyPMCreateExists(x.id);
  verifyPMCreateUpdated(x.id);
});

// ===== PASSIVE ASSERTIONS =====

bthread("Customer create verification", function () {
  const e = waitForAnyCustomerAdded();
  block(matchDeleteCustomer(e.id, ANY), function () {
    verifyCustomerExists(e.id);
  });
});

bthread("Customer update verification", function () {
  const e = waitForAnyCustomerUpdated();
  block(matchDeleteCustomer(e.id, ANY), function () {
    verifyCustomerUpdated(e.id);
  });
});

bthread("Customer delete verification", function () {
  const e = waitForAnyCustomerDeleted();
  block(matchAddCustomer(e.id, ANY), function () {
    verifyCustomerDoesNotExist(e.id);
  });
});

bthread("CustomerCreate create verification", function () {
  const e = waitForAnyCustomerCreateAdded();
  block(matchDeleteCustomerCreate(e.id, ANY), function () {
    verifyCustomerCreateExists(e.id);
  });
});

bthread("CustomerCreate update verification", function () {
  const e = waitForAnyCustomerCreateUpdated();
  block(matchDeleteCustomerCreate(e.id, ANY), function () {
    verifyCustomerCreateUpdated(e.id);
  });
});

bthread("CustomerCreate delete verification", function () {
  const e = waitForAnyCustomerCreateDeleted();
  block(matchAddCustomerCreate(e.id, ANY), function () {
    verifyCustomerCreateDoesNotExist(e.id);
  });
});

bthread("Error create verification", function () {
  const e = waitForAnyErrorAdded();
  block(matchDeleteError(e.id, ANY), function () {
    verifyErrorExists(e.id);
  });
});

bthread("Error update verification", function () {
  const e = waitForAnyErrorUpdated();
  block(matchDeleteError(e.id, ANY), function () {
    verifyErrorUpdated(e.id);
  });
});

bthread("Error delete verification", function () {
  const e = waitForAnyErrorDeleted();
  block(matchAddError(e.id, ANY), function () {
    verifyErrorDoesNotExist(e.id);
  });
});

bthread("ChainCreate create verification", function () {
  const e = waitForAnyChainCreateAdded();
  block(matchDeleteChainCreate(e.id, ANY), function () {
    verifyChainCreateExists(e.id);
  });
});

bthread("ChainCreate update verification", function () {
  const e = waitForAnyChainCreateUpdated();
  block(matchDeleteChainCreate(e.id, ANY), function () {
    verifyChainCreateUpdated(e.id);
  });
});

bthread("ChainCreate delete verification", function () {
  const e = waitForAnyChainCreateDeleted();
  block(matchAddChainCreate(e.id, ANY), function () {
    verifyChainCreateDoesNotExist(e.id);
  });
});

bthread("Garage create verification", function () {
  const e = waitForAnyGarageAdded();
  block(matchDeleteGarage(e.id, ANY), function () {
    verifyGarageExists(e.id);
  });
});

bthread("Garage update verification", function () {
  const e = waitForAnyGarageUpdated();
  block(matchDeleteGarage(e.id, ANY), function () {
    verifyGarageUpdated(e.id);
  });
});

bthread("Garage delete verification", function () {
  const e = waitForAnyGarageDeleted();
  block(matchAddGarage(e.id, ANY), function () {
    verifyGarageDoesNotExist(e.id);
  });
});

bthread("GarageCreate create verification", function () {
  const e = waitForAnyGarageCreateAdded();
  block(matchDeleteGarageCreate(e.id, ANY), function () {
    verifyGarageCreateExists(e.id);
  });
});

bthread("GarageCreate update verification", function () {
  const e = waitForAnyGarageCreateUpdated();
  block(matchDeleteGarageCreate(e.id, ANY), function () {
    verifyGarageCreateUpdated(e.id);
  });
});

bthread("GarageCreate delete verification", function () {
  const e = waitForAnyGarageCreateDeleted();
  block(matchAddGarageCreate(e.id, ANY), function () {
    verifyGarageCreateDoesNotExist(e.id);
  });
});

bthread("ROUpdate create verification", function () {
  const e = waitForAnyROUpdateAdded();
  block(matchDeleteROUpdate(e.id, ANY), function () {
    verifyROUpdateExists(e.id);
  });
});

bthread("ROUpdate update verification", function () {
  const e = waitForAnyROUpdateUpdated();
  block(matchDeleteROUpdate(e.id, ANY), function () {
    verifyROUpdateUpdated(e.id);
  });
});

bthread("ROUpdate delete verification", function () {
  const e = waitForAnyROUpdateDeleted();
  block(matchAddROUpdate(e.id, ANY), function () {
    verifyROUpdateDoesNotExist(e.id);
  });
});

bthread("ROCreate create verification", function () {
  const e = waitForAnyROCreateAdded();
  block(matchDeleteROCreate(e.id, ANY), function () {
    verifyROCreateExists(e.id);
  });
});

bthread("ROCreate update verification", function () {
  const e = waitForAnyROCreateUpdated();
  block(matchDeleteROCreate(e.id, ANY), function () {
    verifyROCreateUpdated(e.id);
  });
});

bthread("ROCreate delete verification", function () {
  const e = waitForAnyROCreateDeleted();
  block(matchAddROCreate(e.id, ANY), function () {
    verifyROCreateDoesNotExist(e.id);
  });
});

bthread("ChainUpdate create verification", function () {
  const e = waitForAnyChainUpdateAdded();
  block(matchDeleteChainUpdate(e.id, ANY), function () {
    verifyChainUpdateExists(e.id);
  });
});

bthread("ChainUpdate update verification", function () {
  const e = waitForAnyChainUpdateUpdated();
  block(matchDeleteChainUpdate(e.id, ANY), function () {
    verifyChainUpdateUpdated(e.id);
  });
});

bthread("ChainUpdate delete verification", function () {
  const e = waitForAnyChainUpdateDeleted();
  block(matchAddChainUpdate(e.id, ANY), function () {
    verifyChainUpdateDoesNotExist(e.id);
  });
});

bthread("GarageUpdate create verification", function () {
  const e = waitForAnyGarageUpdateAdded();
  block(matchDeleteGarageUpdate(e.id, ANY), function () {
    verifyGarageUpdateExists(e.id);
  });
});

bthread("GarageUpdate update verification", function () {
  const e = waitForAnyGarageUpdateUpdated();
  block(matchDeleteGarageUpdate(e.id, ANY), function () {
    verifyGarageUpdateUpdated(e.id);
  });
});

bthread("GarageUpdate delete verification", function () {
  const e = waitForAnyGarageUpdateDeleted();
  block(matchAddGarageUpdate(e.id, ANY), function () {
    verifyGarageUpdateDoesNotExist(e.id);
  });
});

bthread("Chain create verification", function () {
  const e = waitForAnyChainAdded();
  block(matchDeleteChain(e.id, ANY), function () {
    verifyChainExists(e.id);
  });
});

bthread("Chain update verification", function () {
  const e = waitForAnyChainUpdated();
  block(matchDeleteChain(e.id, ANY), function () {
    verifyChainUpdated(e.id);
  });
});

bthread("Chain delete verification", function () {
  const e = waitForAnyChainDeleted();
  block(matchAddChain(e.id, ANY), function () {
    verifyChainDoesNotExist(e.id);
  });
});

bthread("PMUpdate create verification", function () {
  const e = waitForAnyPMUpdateAdded();
  block(matchDeletePMUpdate(e.id, ANY), function () {
    verifyPMUpdateExists(e.id);
  });
});

bthread("PMUpdate update verification", function () {
  const e = waitForAnyPMUpdateUpdated();
  block(matchDeletePMUpdate(e.id, ANY), function () {
    verifyPMUpdateUpdated(e.id);
  });
});

bthread("PMUpdate delete verification", function () {
  const e = waitForAnyPMUpdateDeleted();
  block(matchAddPMUpdate(e.id, ANY), function () {
    verifyPMUpdateDoesNotExist(e.id);
  });
});

bthread("CarCreate create verification", function () {
  const e = waitForAnyCarCreateAdded();
  block(matchDeleteCarCreate(e.id, ANY), function () {
    verifyCarCreateExists(e.id);
  });
});

bthread("CarCreate update verification", function () {
  const e = waitForAnyCarCreateUpdated();
  block(matchDeleteCarCreate(e.id, ANY), function () {
    verifyCarCreateUpdated(e.id);
  });
});

bthread("CarCreate delete verification", function () {
  const e = waitForAnyCarCreateDeleted();
  block(matchAddCarCreate(e.id, ANY), function () {
    verifyCarCreateDoesNotExist(e.id);
  });
});

bthread("Car create verification", function () {
  const e = waitForAnyCarAdded();
  block(matchDeleteCar(e.id, ANY), function () {
    verifyCarExists(e.id);
  });
});

bthread("Car update verification", function () {
  const e = waitForAnyCarUpdated();
  block(matchDeleteCar(e.id, ANY), function () {
    verifyCarUpdated(e.id);
  });
});

bthread("Car delete verification", function () {
  const e = waitForAnyCarDeleted();
  block(matchAddCar(e.id, ANY), function () {
    verifyCarDoesNotExist(e.id);
  });
});

bthread("RepairOrder create verification", function () {
  const e = waitForAnyRepairOrderAdded();
  block(matchDeleteRepairOrder(e.id, ANY), function () {
    verifyRepairOrderExists(e.id);
  });
});

bthread("RepairOrder update verification", function () {
  const e = waitForAnyRepairOrderUpdated();
  block(matchDeleteRepairOrder(e.id, ANY), function () {
    verifyRepairOrderUpdated(e.id);
  });
});

bthread("RepairOrder delete verification", function () {
  const e = waitForAnyRepairOrderDeleted();
  block(matchAddRepairOrder(e.id, ANY), function () {
    verifyRepairOrderDoesNotExist(e.id);
  });
});

bthread("CustomerUpdate create verification", function () {
  const e = waitForAnyCustomerUpdateAdded();
  block(matchDeleteCustomerUpdate(e.id, ANY), function () {
    verifyCustomerUpdateExists(e.id);
  });
});

bthread("CustomerUpdate update verification", function () {
  const e = waitForAnyCustomerUpdateUpdated();
  block(matchDeleteCustomerUpdate(e.id, ANY), function () {
    verifyCustomerUpdateUpdated(e.id);
  });
});

bthread("CustomerUpdate delete verification", function () {
  const e = waitForAnyCustomerUpdateDeleted();
  block(matchAddCustomerUpdate(e.id, ANY), function () {
    verifyCustomerUpdateDoesNotExist(e.id);
  });
});

bthread("PeriodicMaintenance create verification", function () {
  const e = waitForAnyPeriodicMaintenanceAdded();
  block(matchDeletePeriodicMaintenance(e.id, ANY), function () {
    verifyPeriodicMaintenanceExists(e.id);
  });
});

bthread("PeriodicMaintenance update verification", function () {
  const e = waitForAnyPeriodicMaintenanceUpdated();
  block(matchDeletePeriodicMaintenance(e.id, ANY), function () {
    verifyPeriodicMaintenanceUpdated(e.id);
  });
});

bthread("PeriodicMaintenance delete verification", function () {
  const e = waitForAnyPeriodicMaintenanceDeleted();
  block(matchAddPeriodicMaintenance(e.id, ANY), function () {
    verifyPeriodicMaintenanceDoesNotExist(e.id);
  });
});

bthread("CarUpdate create verification", function () {
  const e = waitForAnyCarUpdateAdded();
  block(matchDeleteCarUpdate(e.id, ANY), function () {
    verifyCarUpdateExists(e.id);
  });
});

bthread("CarUpdate update verification", function () {
  const e = waitForAnyCarUpdateUpdated();
  block(matchDeleteCarUpdate(e.id, ANY), function () {
    verifyCarUpdateUpdated(e.id);
  });
});

bthread("CarUpdate delete verification", function () {
  const e = waitForAnyCarUpdateDeleted();
  block(matchAddCarUpdate(e.id, ANY), function () {
    verifyCarUpdateDoesNotExist(e.id);
  });
});

bthread("PMCreate create verification", function () {
  const e = waitForAnyPMCreateAdded();
  block(matchDeletePMCreate(e.id, ANY), function () {
    verifyPMCreateExists(e.id);
  });
});

bthread("PMCreate update verification", function () {
  const e = waitForAnyPMCreateUpdated();
  block(matchDeletePMCreate(e.id, ANY), function () {
    verifyPMCreateUpdated(e.id);
  });
});

bthread("PMCreate delete verification", function () {
  const e = waitForAnyPMCreateDeleted();
  block(matchAddPMCreate(e.id, ANY), function () {
    verifyPMCreateDoesNotExist(e.id);
  });
});

// ===== RELATIONSHIP GUARDS =====

// ===== UNIQUENESS GUARDS =====

bthread("Guard: Unique Customer", function () {
  const x = waitForAnyCustomerAdded();
  block(matchAddCustomer(x.id, ANY), function () {});
});

bthread("Guard: Unique CustomerCreate", function () {
  const x = waitForAnyCustomerCreateAdded();
  block(matchAddCustomerCreate(x.id, ANY), function () {});
});

bthread("Guard: Unique Error", function () {
  const x = waitForAnyErrorAdded();
  block(matchAddError(x.id, ANY), function () {});
});

bthread("Guard: Unique ChainCreate", function () {
  const x = waitForAnyChainCreateAdded();
  block(matchAddChainCreate(x.id, ANY), function () {});
});

bthread("Guard: Unique Garage", function () {
  const x = waitForAnyGarageAdded();
  block(matchAddGarage(x.id, ANY), function () {});
});

bthread("Guard: Unique GarageCreate", function () {
  const x = waitForAnyGarageCreateAdded();
  block(matchAddGarageCreate(x.id, ANY), function () {});
});

bthread("Guard: Unique ROUpdate", function () {
  const x = waitForAnyROUpdateAdded();
  block(matchAddROUpdate(x.id, ANY), function () {});
});

bthread("Guard: Unique ROCreate", function () {
  const x = waitForAnyROCreateAdded();
  block(matchAddROCreate(x.id, ANY), function () {});
});

bthread("Guard: Unique ChainUpdate", function () {
  const x = waitForAnyChainUpdateAdded();
  block(matchAddChainUpdate(x.id, ANY), function () {});
});

bthread("Guard: Unique GarageUpdate", function () {
  const x = waitForAnyGarageUpdateAdded();
  block(matchAddGarageUpdate(x.id, ANY), function () {});
});

bthread("Guard: Unique Chain", function () {
  const x = waitForAnyChainAdded();
  block(matchAddChain(x.id, ANY), function () {});
});

bthread("Guard: Unique PMUpdate", function () {
  const x = waitForAnyPMUpdateAdded();
  block(matchAddPMUpdate(x.id, ANY), function () {});
});

bthread("Guard: Unique CarCreate", function () {
  const x = waitForAnyCarCreateAdded();
  block(matchAddCarCreate(x.id, ANY), function () {});
});

bthread("Guard: Unique Car", function () {
  const x = waitForAnyCarAdded();
  block(matchAddCar(x.id, ANY), function () {});
});

bthread("Guard: Unique RepairOrder", function () {
  const x = waitForAnyRepairOrderAdded();
  block(matchAddRepairOrder(x.id, ANY), function () {});
});

bthread("Guard: Unique CustomerUpdate", function () {
  const x = waitForAnyCustomerUpdateAdded();
  block(matchAddCustomerUpdate(x.id, ANY), function () {});
});

bthread("Guard: Unique PeriodicMaintenance", function () {
  const x = waitForAnyPeriodicMaintenanceAdded();
  block(matchAddPeriodicMaintenance(x.id, ANY), function () {});
});

bthread("Guard: Unique CarUpdate", function () {
  const x = waitForAnyCarUpdateAdded();
  block(matchAddCarUpdate(x.id, ANY), function () {});
});

bthread("Guard: Unique PMCreate", function () {
  const x = waitForAnyPMCreateAdded();
  block(matchAddPMCreate(x.id, ANY), function () {});
});

// ===== NEGATIVE/EDGE STATUS GUARDS =====
