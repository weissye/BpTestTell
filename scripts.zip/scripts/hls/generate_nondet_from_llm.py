# scripts/hls/generate_nondet_from_llm.py
# Purpose: create NON-DET HLS gold from a DET gold using your FT model.
# Guarantees:
# - Varies stories (concrete params; extra checks/blocks) vs DET.
# - Retries with higher temperature/seed; final fallback nudges deterministically.
# - Marks each story with "nondet": true.
#
# Usage:
#   python scripts/hls/generate_nondet_from_llm.py ^
#     --sut <NAME> ^
#     --hls_det artifacts\hls_det\...\<name>\hls_det_gold.json ^
#     --trained_model_dir models\hls\ALL ^
#     --out artifacts\hls_nondet\...\<name>\hls_nondet_gold.json ^
#     [--model_id ft:...] [--seed 142]

from __future__ import annotations
import argparse, json, os, sys, random
from pathlib import Path

try:
    from openai import OpenAI
except Exception:
    OpenAI = None  # handled at runtime

def load_json(p: Path):
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)

def save_json(p: Path, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    tmp.replace(p)

def load_model_id(trained_model_dir: Path, override: str | None) -> str | None:
    if override:
        return override
    ref = trained_model_dir / "model_ref.json"
    if ref.exists():
        try:
            j = load_json(ref)
            return j.get("fine_tuned_model") or j.get("model_id") or None
        except Exception:
            return None
    return None

def is_placeholder(v):
    return isinstance(v, str) and v.startswith("<") and v.endswith(">")

def concretize_params(params: dict) -> dict:
    out = dict(params or {})
    rng = random.Random()
    for k, v in list(out.items()):
        if is_placeholder(v):
            base = k.lower()
            if "email" in base:
                out[k] = f"{base}@example.test"
            elif "phone" in base or "tel" in base:
                out[k] = "+1-555-" + str(rng.randrange(1000000, 9999999))
            elif "id" in base or base in ("user","book","loan","invoice","wo","vin","part","customer","vehicle","account","order"):
                out[k] = f"{base}-" + str(rng.randrange(10000, 99999))
            else:
                out[k] = f"{base}-val-{rng.randrange(1000,9999)}"
    return out

def canon(story: dict):
    c = {k: v for k, v in story.items() if k != "nondet"}
    for k in ("blocks", "checks"):
        if k in c and isinstance(c[k], list):
            try:
                c[k] = sorted(c[k], key=lambda x: json.dumps(x, sort_keys=True))
            except Exception:
                pass
    return c

def different_enough(det: dict, cand: dict) -> bool:
    if not isinstance(cand, dict):
        return False
    a, b = canon(det), canon(cand)
    if a != b:
        params = (cand.get("params") or {})
        for v in params.values():
            if is_placeholder(v):
                return False
        return True
    return False

def openai_vary(story: dict, model_id: str, temperature=0.9, max_tokens=700, seed=None) -> dict:
    if OpenAI is None:
        raise RuntimeError("openai package not installed")
    client = OpenAI()

    sys_prompt = (
        "Return ONLY a JSON object for one HLS story with keys: "
        "entity, op, params, blocks, checks. "
        "Keep semantics consistent with the input but make it DISTINCT in at least TWO ways: "
        "(a) change literal param values to realistic concrete values; "
        "(b) add or replace at least one check; "
        "(c) add at least one additional relevant block. "
        "Never output placeholders like <id>. No prose."
    )
    user_prompt = (
        "Vary this HLS story so it's not identical to the input. "
        "Preserve the same entity and op, but adjust 'params' values to concrete realistic ones, "
        "and modify 'blocks'/'checks' as appropriate. "
        "Input story:\n" + json.dumps(story, ensure_ascii=False)
    )

    # Preferred: Responses API
    try:
        resp = client.responses.create(
            model=model_id,
            input=[{"role":"system","content":sys_prompt},
                   {"role":"user","content":user_prompt}],
            temperature=temperature,
            max_output_tokens=max_tokens,
            seed=seed,
            response_format={"type":"json_object"},
        )
        text = getattr(resp, "output_text", None)
        if not text:
            try:
                text = resp.output[0].content[0].text
            except Exception:
                text = None
        if not text:
            raise RuntimeError("OpenAI response missing text")
        return json.loads(text)
    except TypeError:
        # Fallback: Chat Completions JSON mode
        chat = client.chat.completions.create(
            model=model_id,
            messages=[{"role":"system","content":sys_prompt},
                      {"role":"user","content":user_prompt}],
            temperature=temperature,
            max_tokens=max_tokens,
            seed=seed,
            response_format={"type":"json_object"},
        )
        return json.loads(chat.choices[0].message.content)

def vary_one(det_story: dict, model_id: str, base_seed: int | None) -> dict:
    fallback = {**det_story}
    fallback["params"] = concretize_params(fallback.get("params") or {})
    cc = set(fallback.get("checks") or [])
    cc.add("verifyStateConsistent")
    fallback["checks"] = sorted(cc)

    for attempt in range(5):
        temp = 0.9 + 0.15 * attempt
        seed = (base_seed or 0) + attempt
        cand = openai_vary(det_story, model_id, temperature=temp, seed=seed)
        cand["params"] = concretize_params(cand.get("params") or {})
        if different_enough(det_story, cand):
            cand["nondet"] = True
            return cand

    fallback["nondet"] = True
    return fallback

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sut", required=True, help="system under test name")
    ap.add_argument("--hls_det", required=True, help="path to det gold (input)")
    ap.add_argument("--trained_model_dir", required=True, help="dir containing model_ref.json")
    ap.add_argument("--out", required=True, help="path to write nondet gold")
    ap.add_argument("--model_id", default=None, help="override FT model id (else from model_ref.json)")
    ap.add_argument("--seed", type=int, default=142)
    args = ap.parse_args()

    det_path = Path(args.hls_det)
    out_path = Path(args.out)
    model_id = load_model_id(Path(args.trained_model_dir), args.model_id)

    if not det_path.exists():
        print(f"[ERROR] Missing DET input: {det_path}", file=sys.stderr)
        return 2
    if not model_id:
        print(f"[ERROR] No fine-tuned model id. Provide --model_id or models/hls/ALL/model_ref.json", file=sys.stderr)
        return 3

    det = load_json(det_path)
    det_stories = det.get("stories") if isinstance(det, dict) else det
    if not isinstance(det_stories, list):
        print("[ERROR] DET file does not contain a 'stories' array.", file=sys.stderr)
        return 4

    random.seed(args.seed)
    nondet_stories = []
    for s in det_stories:
        if not isinstance(s, dict):
            continue
        try:
            varied = vary_one(s, model_id, args.seed)
            nondet_stories.append(varied)
        except Exception:
            v = {**s}
            v["params"] = concretize_params(v.get("params") or {})
            cc = set(v.get("checks") or [])
            cc.add("verifyStateConsistent")
            v["checks"] = sorted(cc)
            v["nondet"] = True
            nondet_stories.append(v)

    out_obj = {"sut": args.sut, "stories": nondet_stories}
    save_json(out_path, out_obj)
    print(f"[OK] wrote {out_path} with {len(nondet_stories)} stories")

if __name__ == "__main__":
    raise SystemExit(main())
