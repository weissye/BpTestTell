// ====================================================================
// Auto-generated garage-style High-Level Stories (HLS)
// SUT: directus
// ====================================================================

var ANY = (typeof H !== 'undefined' && H.ANY) ? H.ANY : (typeof ANY !== 'undefined' ? ANY : '*');

// ===== ACTIVE LIFECYCLES =====


bthread("Webhooks lifecycle", function () {
  const x = pick([{id: "W001"}, {id: "W002"}]);
  addWebhooks(x.id);
  updateWebhooks(x.id);
  updateWebhooks(x.id);
  verifyWebhooksExists(x.id);
  verifyWebhooksUpdated(x.id);
});

bthread("Activity lifecycle", function () {
  const x = pick([{id: "A001"}, {id: "A002"}]);
  addActivity(x.id);
  updateActivity(x.id);
  updateActivity(x.id);
  verifyActivityExists(x.id);
  verifyActivityUpdated(x.id);
});

bthread("Collections lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addCollections(x.id);
  updateCollections(x.id);
  updateCollections(x.id);
  verifyCollectionsExists(x.id);
  verifyCollectionsUpdated(x.id);
});

bthread("Query lifecycle", function () {
  const x = pick([{id: "Q001"}, {id: "Q002"}]);
  addQuery(x.id);
  updateQuery(x.id);
  updateQuery(x.id);
  verifyQueryExists(x.id);
  verifyQueryUpdated(x.id);
});

bthread("Comments lifecycle", function () {
  const x = pick([{id: "C001"}, {id: "C002"}]);
  addComments(x.id);
  updateComments(x.id);
  updateComments(x.id);
  verifyCommentsExists(x.id);
  verifyCommentsUpdated(x.id);
});

bthread("Flows lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFlows(x.id);
  updateFlows(x.id);
  updateFlows(x.id);
  verifyFlowsExists(x.id);
  verifyFlowsUpdated(x.id);
});

bthread("Fields lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFields(x.id);
  updateFields(x.id);
  updateFields(x.id);
  verifyFieldsExists(x.id);
  verifyFieldsUpdated(x.id);
});

bthread("Revisions lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRevisions(x.id);
  updateRevisions(x.id);
  updateRevisions(x.id);
  verifyRevisionsExists(x.id);
  verifyRevisionsUpdated(x.id);
});

bthread("Operations lifecycle", function () {
  const x = pick([{id: "O001"}, {id: "O002"}]);
  addOperations(x.id);
  updateOperations(x.id);
  updateOperations(x.id);
  verifyOperationsExists(x.id);
  verifyOperationsUpdated(x.id);
});

bthread("Folders lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFolders(x.id);
  updateFolders(x.id);
  updateFolders(x.id);
  verifyFoldersExists(x.id);
  verifyFoldersUpdated(x.id);
});

bthread("Relations lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRelations(x.id);
  updateRelations(x.id);
  updateRelations(x.id);
  verifyRelationsExists(x.id);
  verifyRelationsUpdated(x.id);
});

bthread("Diff lifecycle", function () {
  const x = pick([{id: "D001"}, {id: "D002"}]);
  addDiff(x.id);
  updateDiff(x.id);
  updateDiff(x.id);
  verifyDiffExists(x.id);
  verifyDiffUpdated(x.id);
});

bthread("Items lifecycle", function () {
  const x = pick([{id: "I001"}, {id: "I002"}]);
  addItems(x.id);
  updateItems(x.id);
  updateItems(x.id);
  verifyItemsExists(x.id);
  verifyItemsUpdated(x.id);
});

bthread("Extensions lifecycle", function () {
  const x = pick([{id: "E001"}, {id: "E002"}]);
  addExtensions(x.id);
  updateExtensions(x.id);
  updateExtensions(x.id);
  verifyExtensionsExists(x.id);
  verifyExtensionsUpdated(x.id);
});

bthread("Schema lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSchema(x.id);
  updateSchema(x.id);
  updateSchema(x.id);
  verifySchemaExists(x.id);
  verifySchemaUpdated(x.id);
});

bthread("X-metadata lifecycle", function () {
  const x = pick([{id: "X001"}, {id: "X002"}]);
  addX-metadata(x.id);
  updateX-metadata(x.id);
  updateX-metadata(x.id);
  verifyX-metadataExists(x.id);
  verifyX-metadataUpdated(x.id);
});

bthread("Users lifecycle", function () {
  const x = pick([{id: "U001"}, {id: "U002"}]);
  addUsers(x.id);
  updateUsers(x.id);
  updateUsers(x.id);
  verifyUsersExists(x.id);
  verifyUsersUpdated(x.id);
});

bthread("Roles lifecycle", function () {
  const x = pick([{id: "R001"}, {id: "R002"}]);
  addRoles(x.id);
  updateRoles(x.id);
  updateRoles(x.id);
  verifyRolesExists(x.id);
  verifyRolesUpdated(x.id);
});

bthread("Versions lifecycle", function () {
  const x = pick([{id: "V001"}, {id: "V002"}]);
  addVersions(x.id);
  updateVersions(x.id);
  updateVersions(x.id);
  verifyVersionsExists(x.id);
  verifyVersionsUpdated(x.id);
});

bthread("Permissions lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPermissions(x.id);
  updatePermissions(x.id);
  updatePermissions(x.id);
  verifyPermissionsExists(x.id);
  verifyPermissionsUpdated(x.id);
});

bthread("Presets lifecycle", function () {
  const x = pick([{id: "P001"}, {id: "P002"}]);
  addPresets(x.id);
  updatePresets(x.id);
  updatePresets(x.id);
  verifyPresetsExists(x.id);
  verifyPresetsUpdated(x.id);
});

bthread("Files lifecycle", function () {
  const x = pick([{id: "F001"}, {id: "F002"}]);
  addFiles(x.id);
  updateFiles(x.id);
  updateFiles(x.id);
  verifyFilesExists(x.id);
  verifyFilesUpdated(x.id);
});

bthread("Settings lifecycle", function () {
  const x = pick([{id: "S001"}, {id: "S002"}]);
  addSettings(x.id);
  updateSettings(x.id);
  updateSettings(x.id);
  verifySettingsExists(x.id);
  verifySettingsUpdated(x.id);
});

// ===== PASSIVE ASSERTIONS =====

bthread("Webhooks create verification", function () {
  const e = waitForAnyWebhooksAdded();
  block(matchDeleteWebhooks(e.id, ANY), function () {
    verifyWebhooksExists(e.id);
  });
});

bthread("Webhooks update verification", function () {
  const e = waitForAnyWebhooksUpdated();
  block(matchDeleteWebhooks(e.id, ANY), function () {
    verifyWebhooksUpdated(e.id);
  });
});

bthread("Webhooks delete verification", function () {
  const e = waitForAnyWebhooksDeleted();
  block(matchAddWebhooks(e.id, ANY), function () {
    verifyWebhooksDoesNotExist(e.id);
  });
});

bthread("Activity create verification", function () {
  const e = waitForAnyActivityAdded();
  block(matchDeleteActivity(e.id, ANY), function () {
    verifyActivityExists(e.id);
  });
});

bthread("Activity update verification", function () {
  const e = waitForAnyActivityUpdated();
  block(matchDeleteActivity(e.id, ANY), function () {
    verifyActivityUpdated(e.id);
  });
});

bthread("Activity delete verification", function () {
  const e = waitForAnyActivityDeleted();
  block(matchAddActivity(e.id, ANY), function () {
    verifyActivityDoesNotExist(e.id);
  });
});

bthread("Collections create verification", function () {
  const e = waitForAnyCollectionsAdded();
  block(matchDeleteCollections(e.id, ANY), function () {
    verifyCollectionsExists(e.id);
  });
});

bthread("Collections update verification", function () {
  const e = waitForAnyCollectionsUpdated();
  block(matchDeleteCollections(e.id, ANY), function () {
    verifyCollectionsUpdated(e.id);
  });
});

bthread("Collections delete verification", function () {
  const e = waitForAnyCollectionsDeleted();
  block(matchAddCollections(e.id, ANY), function () {
    verifyCollectionsDoesNotExist(e.id);
  });
});

bthread("Query create verification", function () {
  const e = waitForAnyQueryAdded();
  block(matchDeleteQuery(e.id, ANY), function () {
    verifyQueryExists(e.id);
  });
});

bthread("Query update verification", function () {
  const e = waitForAnyQueryUpdated();
  block(matchDeleteQuery(e.id, ANY), function () {
    verifyQueryUpdated(e.id);
  });
});

bthread("Query delete verification", function () {
  const e = waitForAnyQueryDeleted();
  block(matchAddQuery(e.id, ANY), function () {
    verifyQueryDoesNotExist(e.id);
  });
});

bthread("Comments create verification", function () {
  const e = waitForAnyCommentsAdded();
  block(matchDeleteComments(e.id, ANY), function () {
    verifyCommentsExists(e.id);
  });
});

bthread("Comments update verification", function () {
  const e = waitForAnyCommentsUpdated();
  block(matchDeleteComments(e.id, ANY), function () {
    verifyCommentsUpdated(e.id);
  });
});

bthread("Comments delete verification", function () {
  const e = waitForAnyCommentsDeleted();
  block(matchAddComments(e.id, ANY), function () {
    verifyCommentsDoesNotExist(e.id);
  });
});

bthread("Flows create verification", function () {
  const e = waitForAnyFlowsAdded();
  block(matchDeleteFlows(e.id, ANY), function () {
    verifyFlowsExists(e.id);
  });
});

bthread("Flows update verification", function () {
  const e = waitForAnyFlowsUpdated();
  block(matchDeleteFlows(e.id, ANY), function () {
    verifyFlowsUpdated(e.id);
  });
});

bthread("Flows delete verification", function () {
  const e = waitForAnyFlowsDeleted();
  block(matchAddFlows(e.id, ANY), function () {
    verifyFlowsDoesNotExist(e.id);
  });
});

bthread("Fields create verification", function () {
  const e = waitForAnyFieldsAdded();
  block(matchDeleteFields(e.id, ANY), function () {
    verifyFieldsExists(e.id);
  });
});

bthread("Fields update verification", function () {
  const e = waitForAnyFieldsUpdated();
  block(matchDeleteFields(e.id, ANY), function () {
    verifyFieldsUpdated(e.id);
  });
});

bthread("Fields delete verification", function () {
  const e = waitForAnyFieldsDeleted();
  block(matchAddFields(e.id, ANY), function () {
    verifyFieldsDoesNotExist(e.id);
  });
});

bthread("Revisions create verification", function () {
  const e = waitForAnyRevisionsAdded();
  block(matchDeleteRevisions(e.id, ANY), function () {
    verifyRevisionsExists(e.id);
  });
});

bthread("Revisions update verification", function () {
  const e = waitForAnyRevisionsUpdated();
  block(matchDeleteRevisions(e.id, ANY), function () {
    verifyRevisionsUpdated(e.id);
  });
});

bthread("Revisions delete verification", function () {
  const e = waitForAnyRevisionsDeleted();
  block(matchAddRevisions(e.id, ANY), function () {
    verifyRevisionsDoesNotExist(e.id);
  });
});

bthread("Operations create verification", function () {
  const e = waitForAnyOperationsAdded();
  block(matchDeleteOperations(e.id, ANY), function () {
    verifyOperationsExists(e.id);
  });
});

bthread("Operations update verification", function () {
  const e = waitForAnyOperationsUpdated();
  block(matchDeleteOperations(e.id, ANY), function () {
    verifyOperationsUpdated(e.id);
  });
});

bthread("Operations delete verification", function () {
  const e = waitForAnyOperationsDeleted();
  block(matchAddOperations(e.id, ANY), function () {
    verifyOperationsDoesNotExist(e.id);
  });
});

bthread("Folders create verification", function () {
  const e = waitForAnyFoldersAdded();
  block(matchDeleteFolders(e.id, ANY), function () {
    verifyFoldersExists(e.id);
  });
});

bthread("Folders update verification", function () {
  const e = waitForAnyFoldersUpdated();
  block(matchDeleteFolders(e.id, ANY), function () {
    verifyFoldersUpdated(e.id);
  });
});

bthread("Folders delete verification", function () {
  const e = waitForAnyFoldersDeleted();
  block(matchAddFolders(e.id, ANY), function () {
    verifyFoldersDoesNotExist(e.id);
  });
});

bthread("Relations create verification", function () {
  const e = waitForAnyRelationsAdded();
  block(matchDeleteRelations(e.id, ANY), function () {
    verifyRelationsExists(e.id);
  });
});

bthread("Relations update verification", function () {
  const e = waitForAnyRelationsUpdated();
  block(matchDeleteRelations(e.id, ANY), function () {
    verifyRelationsUpdated(e.id);
  });
});

bthread("Relations delete verification", function () {
  const e = waitForAnyRelationsDeleted();
  block(matchAddRelations(e.id, ANY), function () {
    verifyRelationsDoesNotExist(e.id);
  });
});

bthread("Diff create verification", function () {
  const e = waitForAnyDiffAdded();
  block(matchDeleteDiff(e.id, ANY), function () {
    verifyDiffExists(e.id);
  });
});

bthread("Diff update verification", function () {
  const e = waitForAnyDiffUpdated();
  block(matchDeleteDiff(e.id, ANY), function () {
    verifyDiffUpdated(e.id);
  });
});

bthread("Diff delete verification", function () {
  const e = waitForAnyDiffDeleted();
  block(matchAddDiff(e.id, ANY), function () {
    verifyDiffDoesNotExist(e.id);
  });
});

bthread("Items create verification", function () {
  const e = waitForAnyItemsAdded();
  block(matchDeleteItems(e.id, ANY), function () {
    verifyItemsExists(e.id);
  });
});

bthread("Items update verification", function () {
  const e = waitForAnyItemsUpdated();
  block(matchDeleteItems(e.id, ANY), function () {
    verifyItemsUpdated(e.id);
  });
});

bthread("Items delete verification", function () {
  const e = waitForAnyItemsDeleted();
  block(matchAddItems(e.id, ANY), function () {
    verifyItemsDoesNotExist(e.id);
  });
});

bthread("Extensions create verification", function () {
  const e = waitForAnyExtensionsAdded();
  block(matchDeleteExtensions(e.id, ANY), function () {
    verifyExtensionsExists(e.id);
  });
});

bthread("Extensions update verification", function () {
  const e = waitForAnyExtensionsUpdated();
  block(matchDeleteExtensions(e.id, ANY), function () {
    verifyExtensionsUpdated(e.id);
  });
});

bthread("Extensions delete verification", function () {
  const e = waitForAnyExtensionsDeleted();
  block(matchAddExtensions(e.id, ANY), function () {
    verifyExtensionsDoesNotExist(e.id);
  });
});

bthread("Schema create verification", function () {
  const e = waitForAnySchemaAdded();
  block(matchDeleteSchema(e.id, ANY), function () {
    verifySchemaExists(e.id);
  });
});

bthread("Schema update verification", function () {
  const e = waitForAnySchemaUpdated();
  block(matchDeleteSchema(e.id, ANY), function () {
    verifySchemaUpdated(e.id);
  });
});

bthread("Schema delete verification", function () {
  const e = waitForAnySchemaDeleted();
  block(matchAddSchema(e.id, ANY), function () {
    verifySchemaDoesNotExist(e.id);
  });
});

bthread("X-metadata create verification", function () {
  const e = waitForAnyX-metadataAdded();
  block(matchDeleteX-metadata(e.id, ANY), function () {
    verifyX-metadataExists(e.id);
  });
});

bthread("X-metadata update verification", function () {
  const e = waitForAnyX-metadataUpdated();
  block(matchDeleteX-metadata(e.id, ANY), function () {
    verifyX-metadataUpdated(e.id);
  });
});

bthread("X-metadata delete verification", function () {
  const e = waitForAnyX-metadataDeleted();
  block(matchAddX-metadata(e.id, ANY), function () {
    verifyX-metadataDoesNotExist(e.id);
  });
});

bthread("Users create verification", function () {
  const e = waitForAnyUsersAdded();
  block(matchDeleteUsers(e.id, ANY), function () {
    verifyUsersExists(e.id);
  });
});

bthread("Users update verification", function () {
  const e = waitForAnyUsersUpdated();
  block(matchDeleteUsers(e.id, ANY), function () {
    verifyUsersUpdated(e.id);
  });
});

bthread("Users delete verification", function () {
  const e = waitForAnyUsersDeleted();
  block(matchAddUsers(e.id, ANY), function () {
    verifyUsersDoesNotExist(e.id);
  });
});

bthread("Roles create verification", function () {
  const e = waitForAnyRolesAdded();
  block(matchDeleteRoles(e.id, ANY), function () {
    verifyRolesExists(e.id);
  });
});

bthread("Roles update verification", function () {
  const e = waitForAnyRolesUpdated();
  block(matchDeleteRoles(e.id, ANY), function () {
    verifyRolesUpdated(e.id);
  });
});

bthread("Roles delete verification", function () {
  const e = waitForAnyRolesDeleted();
  block(matchAddRoles(e.id, ANY), function () {
    verifyRolesDoesNotExist(e.id);
  });
});

bthread("Versions create verification", function () {
  const e = waitForAnyVersionsAdded();
  block(matchDeleteVersions(e.id, ANY), function () {
    verifyVersionsExists(e.id);
  });
});

bthread("Versions update verification", function () {
  const e = waitForAnyVersionsUpdated();
  block(matchDeleteVersions(e.id, ANY), function () {
    verifyVersionsUpdated(e.id);
  });
});

bthread("Versions delete verification", function () {
  const e = waitForAnyVersionsDeleted();
  block(matchAddVersions(e.id, ANY), function () {
    verifyVersionsDoesNotExist(e.id);
  });
});

bthread("Permissions create verification", function () {
  const e = waitForAnyPermissionsAdded();
  block(matchDeletePermissions(e.id, ANY), function () {
    verifyPermissionsExists(e.id);
  });
});

bthread("Permissions update verification", function () {
  const e = waitForAnyPermissionsUpdated();
  block(matchDeletePermissions(e.id, ANY), function () {
    verifyPermissionsUpdated(e.id);
  });
});

bthread("Permissions delete verification", function () {
  const e = waitForAnyPermissionsDeleted();
  block(matchAddPermissions(e.id, ANY), function () {
    verifyPermissionsDoesNotExist(e.id);
  });
});

bthread("Presets create verification", function () {
  const e = waitForAnyPresetsAdded();
  block(matchDeletePresets(e.id, ANY), function () {
    verifyPresetsExists(e.id);
  });
});

bthread("Presets update verification", function () {
  const e = waitForAnyPresetsUpdated();
  block(matchDeletePresets(e.id, ANY), function () {
    verifyPresetsUpdated(e.id);
  });
});

bthread("Presets delete verification", function () {
  const e = waitForAnyPresetsDeleted();
  block(matchAddPresets(e.id, ANY), function () {
    verifyPresetsDoesNotExist(e.id);
  });
});

bthread("Files create verification", function () {
  const e = waitForAnyFilesAdded();
  block(matchDeleteFiles(e.id, ANY), function () {
    verifyFilesExists(e.id);
  });
});

bthread("Files update verification", function () {
  const e = waitForAnyFilesUpdated();
  block(matchDeleteFiles(e.id, ANY), function () {
    verifyFilesUpdated(e.id);
  });
});

bthread("Files delete verification", function () {
  const e = waitForAnyFilesDeleted();
  block(matchAddFiles(e.id, ANY), function () {
    verifyFilesDoesNotExist(e.id);
  });
});

bthread("Settings create verification", function () {
  const e = waitForAnySettingsAdded();
  block(matchDeleteSettings(e.id, ANY), function () {
    verifySettingsExists(e.id);
  });
});

bthread("Settings update verification", function () {
  const e = waitForAnySettingsUpdated();
  block(matchDeleteSettings(e.id, ANY), function () {
    verifySettingsUpdated(e.id);
  });
});

bthread("Settings delete verification", function () {
  const e = waitForAnySettingsDeleted();
  block(matchAddSettings(e.id, ANY), function () {
    verifySettingsDoesNotExist(e.id);
  });
});

// ===== RELATIONSHIP GUARDS =====

// ===== UNIQUENESS GUARDS =====

bthread("Guard: Unique Webhooks", function () {
  const x = waitForAnyWebhooksAdded();
  block(matchAddWebhooks(x.id, ANY), function () {});
});

bthread("Guard: Unique Activity", function () {
  const x = waitForAnyActivityAdded();
  block(matchAddActivity(x.id, ANY), function () {});
});

bthread("Guard: Unique Collections", function () {
  const x = waitForAnyCollectionsAdded();
  block(matchAddCollections(x.id, ANY), function () {});
});

bthread("Guard: Unique Query", function () {
  const x = waitForAnyQueryAdded();
  block(matchAddQuery(x.id, ANY), function () {});
});

bthread("Guard: Unique Comments", function () {
  const x = waitForAnyCommentsAdded();
  block(matchAddComments(x.id, ANY), function () {});
});

bthread("Guard: Unique Flows", function () {
  const x = waitForAnyFlowsAdded();
  block(matchAddFlows(x.id, ANY), function () {});
});

bthread("Guard: Unique Fields", function () {
  const x = waitForAnyFieldsAdded();
  block(matchAddFields(x.id, ANY), function () {});
});

bthread("Guard: Unique Revisions", function () {
  const x = waitForAnyRevisionsAdded();
  block(matchAddRevisions(x.id, ANY), function () {});
});

bthread("Guard: Unique Operations", function () {
  const x = waitForAnyOperationsAdded();
  block(matchAddOperations(x.id, ANY), function () {});
});

bthread("Guard: Unique Folders", function () {
  const x = waitForAnyFoldersAdded();
  block(matchAddFolders(x.id, ANY), function () {});
});

bthread("Guard: Unique Relations", function () {
  const x = waitForAnyRelationsAdded();
  block(matchAddRelations(x.id, ANY), function () {});
});

bthread("Guard: Unique Diff", function () {
  const x = waitForAnyDiffAdded();
  block(matchAddDiff(x.id, ANY), function () {});
});

bthread("Guard: Unique Items", function () {
  const x = waitForAnyItemsAdded();
  block(matchAddItems(x.id, ANY), function () {});
});

bthread("Guard: Unique Extensions", function () {
  const x = waitForAnyExtensionsAdded();
  block(matchAddExtensions(x.id, ANY), function () {});
});

bthread("Guard: Unique Schema", function () {
  const x = waitForAnySchemaAdded();
  block(matchAddSchema(x.id, ANY), function () {});
});

bthread("Guard: Unique X-metadata", function () {
  const x = waitForAnyX-metadataAdded();
  block(matchAddX-metadata(x.id, ANY), function () {});
});

bthread("Guard: Unique Users", function () {
  const x = waitForAnyUsersAdded();
  block(matchAddUsers(x.id, ANY), function () {});
});

bthread("Guard: Unique Roles", function () {
  const x = waitForAnyRolesAdded();
  block(matchAddRoles(x.id, ANY), function () {});
});

bthread("Guard: Unique Versions", function () {
  const x = waitForAnyVersionsAdded();
  block(matchAddVersions(x.id, ANY), function () {});
});

bthread("Guard: Unique Permissions", function () {
  const x = waitForAnyPermissionsAdded();
  block(matchAddPermissions(x.id, ANY), function () {});
});

bthread("Guard: Unique Presets", function () {
  const x = waitForAnyPresetsAdded();
  block(matchAddPresets(x.id, ANY), function () {});
});

bthread("Guard: Unique Files", function () {
  const x = waitForAnyFilesAdded();
  block(matchAddFiles(x.id, ANY), function () {});
});

bthread("Guard: Unique Settings", function () {
  const x = waitForAnySettingsAdded();
  block(matchAddSettings(x.id, ANY), function () {});
});

// ===== NEGATIVE/EDGE STATUS GUARDS =====
